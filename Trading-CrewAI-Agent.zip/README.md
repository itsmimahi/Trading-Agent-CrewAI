# Paper Trading Agent (PTA) - Zerodha & Shoonya Setup

## .env placeholders (Zerodha)

```
BROKER=ZERODHA
TRADING_MODE=PAPER
ZERODHA_API_KEY=Z_API_KEY_PLACEHOLDER
ZERODHA_API_SECRET=Z_API_SECRET_PLACEHOLDER
ZERODHA_ACCESS_TOKEN=Z_ACCESS_TOKEN_PLACEHOLDER
# Optional for websocket instrument mapping
# ZERODHA_INSTRUMENTS_CSV=./instruments.csv
```

Notes:
- ACCESS_TOKEN must be refreshed daily via the official login flow.
- If creds are missing, PTA falls back to in-memory prices and polling mocks.
- SSE endpoints: `/stream/ping` and `/stream/prices/<symbol>`.

## .env placeholders (Shoonya/Finvasia)

```
BROKER=SHOONYA
TRADING_MODE=PAPER
SHOONYA_USER=S_USER_PLACEHOLDER
SHOONYA_PASSWORD=S_PASSWORD_PLACEHOLDER
SHOONYA_TOTP=000000
SHOONYA_VENDOR_CODE=S_VENDOR_PLACEHOLDER
SHOONYA_API_KEY=S_APIKEY_PLACEHOLDER
SHOONYA_IMEI=S_IMEI_PLACEHOLDER
```

Notes:
- Shoonya requires a valid app key and vendor code; free WS data works after login.
- If the official Noren API package isn't installed, PTA will fall back to polling/mock.

## Run locally (PowerShell)

```powershell
$env:BROKER="ZERODHA"; $env:ZERODHA_API_KEY="Z_API_KEY_PLACEHOLDER"; $env:ZERODHA_API_SECRET="Z_API_SECRET_PLACEHOLDER"; $env:ZERODHA_ACCESS_TOKEN="Z_ACCESS_TOKEN_PLACEHOLDER"
.\crewenv\Scripts\python.exe -m paper_trading_agent.app
```

Shoonya:

```powershell
$env:BROKER="SHOONYA"; $env:SHOONYA_USER="user"; $env:SHOONYA_PASSWORD="pass"; $env:SHOONYA_TOTP="000000"; $env:SHOONYA_VENDOR_CODE="vendor"; $env:SHOONYA_API_KEY="apikey"; $env:SHOONYA_IMEI="imei"; 
.\crewenv\Scripts\python.exe -m paper_trading_agent.app
```
