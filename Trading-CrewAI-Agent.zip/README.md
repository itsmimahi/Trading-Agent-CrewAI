# 🤖 AI Trading Advisory System

> **A Comprehensive Three-Tier Multi-Agent AI System for Intelligent Stock Market Investment Advisory**

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/release/python-380/)
[![CrewAI](https://img.shields.io/badge/CrewAI-Multi--Agent-green)](https://www.crewai.io/)
[![Azure OpenAI](https://img.shields.io/badge/Azure-OpenAI-orange)](https://azure.microsoft.com/en-us/services/cognitive-services/openai-service/)
[![RL Integration](https://img.shields.io/badge/RL-Integration-purple)](https://gymnasium.farama.org/)

---

## 📋 Table of Contents

- [🎯 Project Overview](#-project-overview)
- [🏗️ System Architecture](#️-system-architecture)
- [🚀 Quick Start Guide](#-quick-start-guide)
- [🔧 System Components](#-system-components)
- [💼 Agent Ecosystem](#-agent-ecosystem)
- [📊 Features & Capabilities](#-features--capabilities)
- [🔄 Integration & Communication](#-integration--communication)
- [📈 Performance & Analytics](#-performance--analytics)
- [🔐 Security & Configuration](#-security--configuration)
- [🛠️ Development & Testing](#️-development--testing)
- [📁 Project Structure](#-project-structure)
- [🌐 User Interfaces](#-user-interfaces)
- [📖 API Documentation](#-api-documentation)
- [🔍 Monitoring & Logging](#-monitoring--logging)
- [🚨 Troubleshooting](#-troubleshooting)
- [🛣️ Roadmap](#️-roadmap)
- [📜 License & Disclaimer](#-license--disclaimer)

---

## 🎯 Project Overview

The **AI Trading Advisory System** is a sophisticated, self-evolving multi-agent AI ecosystem designed to provide intelligent stock market investment recommendations. This system combines cutting-edge AI technologies, reinforcement learning, and comprehensive financial analysis to deliver professional-grade investment advisory services.

### 🌟 Key Highlights

- **Three-Tier Architecture** - Main Advisory Agent, RL Learning Engine, and 14 Specialized Subagents
- **Self-Learning System** - Continuous improvement through reinforcement learning feedback loops
- **Comprehensive Analysis** - Technical, fundamental, sentiment, risk, and macroeconomic analysis
- **Real-Time Processing** - Live market data integration and instant analysis
- **Multi-Interface Support** - Web UI, Chat Interface, Admin Dashboard, and REST APIs
- **Production-Ready** - Enterprise-grade architecture with performance monitoring and security

### 🎭 Investment Strategies Supported

- **📈 Long-term Investing** - Value investing and growth stock identification
- **🔄 Swing Trading** - Short to medium-term momentum and pattern-based trading
- **🛡️ Risk Management** - Portfolio protection and diversification strategies
- **💰 Dividend Investing** - Income-focused investment recommendations
- **⏰ Market Timing** - Optimal entry and exit point identification

---

## 🏗️ System Architecture

### 🎯 Three-Tier Intelligent Ecosystem

```mermaid
graph TB
    subgraph "Tier 1: Orchestration Layer"
        UI[Web UI/Chat Interface]
        MAA[Main Advisory Agent]
        API[REST API Layer]
        REG[Agent Registry]
    end
    
    subgraph "Tier 2: Learning & Adaptation Layer"
        RL[RL Trading Agent]
        ENV[Trading Environment]
        TRAIN[Training Pipeline]
        BRIDGE[CrewAI-RL Bridge]
    end
    
    subgraph "Tier 3: Domain Expertise Layer"
        RESEARCH[Research Agent]
        TECH[Technical Agent]
        SENT[Sentiment Agent]
        RISK[Risk Agent]
        MACRO[Macro Agent]
        PORT[Portfolio Manager]
        MORE[9 More Specialized Agents...]
    end
    
    UI --> MAA
    MAA --> REG
    REG --> RESEARCH
    REG --> TECH
    REG --> SENT
    MAA <--> BRIDGE
    BRIDGE <--> RL
    RL --> ENV
    RL --> TRAIN
    
    style MAA fill:#e1f5fe
    style RL fill:#f3e5f5
    style RESEARCH fill:#e8f5e8
```

### 🧠 Core Architecture Principles

1. **Separation of Concerns** - Each tier has distinct responsibilities
2. **Bidirectional Communication** - Agents can communicate with each other
3. **Continuous Learning** - RL feedback improves system performance
4. **Modular Design** - Components can be updated independently
5. **Fault Tolerance** - Graceful degradation when components fail
6. **Scalability** - Horizontal scaling of agent instances

---

## 🚀 Quick Start Guide

### 📋 Prerequisites

- **Python 3.8+** with pip package manager
- **Azure OpenAI API** access (GPT-4 recommended)
- **4GB+ RAM** for optimal performance
- **Windows/Linux/macOS** supported

### ⚡ One-Click Setup

```bash
# 1. Clone the repository
git clone <repository-url>
cd Trading-CrewAI-Agent

# 2. Run automated setup
python setup.py

# 3. Configure environment
cp .env.template .env
# Edit .env with your API keys

# 4. Start the system
python start_integrated_system.py

# 5. Access interfaces
# Web UI: http://localhost:3000
# Main Agent API: http://localhost:8000
# RL Agent API: http://localhost:5000
```

### 🔧 Manual Installation

```bash
# Create virtual environment
python -m venv crewenv
source crewenv/bin/activate  # On Windows: crewenv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r integration_requirements.txt

# Install performance UI dependencies (optional)
pip install -r ui/performance_requirements.txt

# Setup database
python setup_integration.py

# Install TA-Lib (for technical analysis)
pip install ta_lib-0.6.4-cp311-cp311-win_amd64.whl  # Windows
# Or follow platform-specific TA-Lib installation
```

### 🔑 Configuration

```bash
# Required environment variables
AZURE_OPENAI_ENDPOINT=your-azure-openai-endpoint
AZURE_OPENAI_API_KEY=your-azure-openai-api-key
AZURE_OPENAI_API_VERSION=2023-05-15
AZURE_OPENAI_DEPLOYMENT=your-deployment-name
AZURE_OPENAI_MODEL=gpt-4

# Optional API keys (recommended)
ALPHA_VANTAGE_API_KEY=your-alpha-vantage-key
NEWS_API_KEY=your-news-api-key

# System settings
INITIAL_CAPITAL=50000  # Initial investment capital
MAX_POSITION_SIZE=0.2  # Maximum position size (20%)
STOP_LOSS_THRESHOLD=0.08  # Stop loss at 8%
```

---

## 🔧 System Components

### 🎯 Tier 1: Orchestration Layer

#### 🤖 Main Advisory Agent
- **Location**: `main advisory agent/main_advisory_agent.py`
- **Framework**: CrewAI with GPT-4.1
- **Purpose**: Central orchestrator and primary user interface
- **Capabilities**:
  - Natural language query processing
  - Intelligent task delegation to specialized agents
  - Response synthesis and recommendation generation
  - Conversation context management
  - User session handling

#### 📋 Agent Registry
- **Location**: `main advisory agent/agent_registry.py`
- **Purpose**: Centralized agent discovery and management
- **Features**:
  - Dynamic agent registration and discovery
  - Health monitoring of all agents
  - Capability mapping and routing
  - Load balancing across agent instances

#### 🌐 REST API Layer
- **Main Agent API**: Port 8000 (`main advisory agent/main.py`)
- **RL Agent API**: Port 5000 (`RL_Agent/run_rl_api.py`)
- **Web UI Server**: Port 3000 (`ui/web_server.py`)

### 🧠 Tier 2: Learning & Adaptation Layer

#### 🎯 RL Trading Agent
- **Location**: `RL_Agent/rl_agent.py`
- **Algorithms**: DQN, PPO, A2C with neural networks
- **Features**:
  - Continuous learning from market data
  - Strategy optimization based on performance feedback
  - Risk-adjusted reward functions
  - Multi-timeframe analysis support
  - Backtesting and validation capabilities

#### 🌍 Trading Environment
- **Location**: `RL_Agent/trading_environment.py`
- **Framework**: OpenAI Gym compatible
- **Simulation Features**:
  - Realistic market dynamics modeling
  - Transaction costs and slippage
  - Risk management constraints
  - Historical data replay
  - Real-time market integration

#### 🔗 CrewAI-RL Integration Bridge
- **Location**: `integration/crewai_rl_bridge.py`
- **Purpose**: Bidirectional communication between CrewAI and RL systems
- **Capabilities**:
  - Strategy validation requests
  - Performance feedback processing
  - Weight update management
  - Market regime change notifications
  - Health monitoring and error handling

### 👥 Tier 3: Domain Expertise Layer

#### 🏛️ Base Infrastructure
- **BaseAgent** (`agents/base_agent.py`) - Foundation class for all agents
- **EnhancedBaseAgent** (`agents/enhanced_base_agent.py`) - Advanced base with LLM capabilities
- **OrchestratorAgent** (`agents/orchestrator_agent.py`) - System coordinator

#### 🔍 Core Analysis Agents

##### 📊 Enhanced Research Agent
- **Location**: `agents/enhanced_research_agent.py`
- **Specialization**: Fundamental analysis and company research
- **Capabilities**:
  - Financial statement analysis
  - DCF valuation models
  - Peer comparison analysis
  - Industry trend analysis
  - Company health assessment

##### 📈 Enhanced Technical Agent
- **Location**: `agents/enhanced_technical_agent.py`
- **Specialization**: Technical analysis and pattern recognition
- **Capabilities**:
  - Chart pattern identification
  - Technical indicator analysis (RSI, MACD, Bollinger Bands)
  - Support/resistance level detection
  - Trend analysis and momentum indicators
  - Entry/exit signal generation

##### 📰 Enhanced Sentiment Agent
- **Location**: `agents/enhanced_sentiment_agent.py`
- **Specialization**: Market sentiment and news analysis
- **Capabilities**:
  - News sentiment analysis
  - Social media sentiment tracking
  - Market fear/greed index calculation
  - Event impact assessment
  - Sentiment trend analysis

##### 🛡️ Enhanced Risk Agent
- **Location**: `agents/enhanced_risk_agent.py`
- **Specialization**: Risk assessment and management
- **Capabilities**:
  - Value at Risk (VaR) calculation
  - Stress testing and scenario analysis
  - Correlation analysis
  - Risk-adjusted return metrics
  - Portfolio risk assessment

##### 🌍 Enhanced Macro Agent
- **Location**: `agents/enhanced_macro_agent.py`
- **Specialization**: Macroeconomic analysis
- **Capabilities**:
  - Economic indicator analysis
  - Central bank policy impact assessment
  - Currency trend analysis
  - Interest rate environment analysis
  - Global market regime identification

##### 💼 Enhanced Portfolio Manager
- **Location**: `agents/enhanced_portfolio_manager.py`
- **Specialization**: Portfolio optimization and allocation
- **Capabilities**:
  - Modern Portfolio Theory implementation
  - Asset allocation optimization
  - Diversification analysis
  - Rebalancing recommendations
  - Performance attribution analysis

##### ⏰ Enhanced Timing Agent
- **Location**: `agents/enhanced_timing_agent.py`
- **Specialization**: Market timing and cyclical analysis
- **Capabilities**:
  - Market cycle identification
  - Seasonality analysis
  - Volatility regime detection
  - Optimal entry/exit timing
  - Market timing signals

##### 🎯 Enhanced Trade Strategy Planner
- **Location**: `agents/enhanced_trade_strategy_planner.py`
- **Specialization**: Strategy synthesis and trade planning
- **Capabilities**:
  - Multi-agent signal aggregation
  - Strategy classification and optimization
  - Risk-reward profile optimization
  - Trade plan generation
  - Strategy backtesting coordination

##### 💰 Enhanced Dividends Yield Optimizer
- **Location**: `agents/enhanced_dividends_yield_optimizer.py`
- **Specialization**: Dividend investing optimization
- **Capabilities**:
  - Dividend yield analysis
  - Payout ratio sustainability assessment
  - Dividend growth analysis
  - Income-focused portfolio construction
  - REIT and dividend aristocrat identification

##### 📊 Enhanced Performance Agent
- **Location**: `agents/enhanced_performance_agent.py`
- **Specialization**: Performance evaluation and analytics
- **Capabilities**:
  - Risk-adjusted return calculation
  - Benchmark comparison analysis
  - Performance attribution
  - Strategy effectiveness evaluation
  - Continuous improvement recommendations

##### 📝 Enhanced Paper Trading Agent
- **Location**: `agents/enhanced_paper_trading_agent.py`
- **Specialization**: Virtual trading simulation
- **Capabilities**:
  - Virtual portfolio management
  - Trade execution simulation
  - Slippage and commission modeling
  - Performance tracking
  - Risk management testing

---

## 💼 Agent Ecosystem

### 🔄 Agent Communication Protocol

#### A2A (Agent-to-Agent) Communication
```python
# Standardized message format
class A2AMessage:
    sender: str
    recipient: str
    message_type: str
    payload: Dict
    timestamp: datetime
    correlation_id: str
```

#### Communication Flow
```mermaid
sequenceDiagram
    participant User
    participant MainAgent
    participant Orchestrator
    participant SpecializedAgent
    participant RLAgent
    
    User->>MainAgent: Query
    MainAgent->>Orchestrator: Route Task
    Orchestrator->>SpecializedAgent: Analyze Request
    SpecializedAgent->>Orchestrator: Analysis Result
    Orchestrator->>RLAgent: Strategy Validation
    RLAgent->>Orchestrator: RL Insights
    Orchestrator->>MainAgent: Synthesized Response
    MainAgent->>User: Final Recommendation
```

### 🧠 Memory and Knowledge Management

#### Knowledge Base System
- **Vector Storage** using HuggingFace embeddings
- **Fallback to TF-IDF** for offline operation
- **Persistent Knowledge** across agent restarts
- **Context-Aware Retrieval** for relevant information

#### Memory Architecture
- **Short-term Memory** for conversation context
- **Long-term Memory** for learning patterns
- **SQLite Storage** for persistence
- **Memory Consolidation** during idle periods

---

## 📊 Features & Capabilities

### 🎯 Core Features

#### ✅ Multi-Agent Analysis
- **14 Specialized Agents** each with domain expertise
- **Parallel Processing** for faster analysis
- **Consensus Building** across multiple viewpoints
- **Conflict Resolution** when agents disagree

#### ✅ Real-Time Market Data
- **Yahoo Finance Integration** for stock prices and fundamentals
- **Alpha Vantage API** for advanced financial data
- **News API Integration** for market news and sentiment
- **Economic Data Sources** for macro analysis

#### ✅ Advanced Analytics
- **Technical Indicators** (50+ indicators)
- **Fundamental Ratios** (P/E, P/B, ROE, etc.)
- **Risk Metrics** (VaR, Sharpe, Sortino)
- **Performance Attribution** analysis

#### ✅ Machine Learning Integration
- **Reinforcement Learning** for strategy optimization
- **Sentiment Analysis** using transformer models
- **Pattern Recognition** in price data
- **Predictive Modeling** for market movements

### 🎨 User Interface Features

#### 🌐 Enhanced Web UI
- **Performance Optimizations**:
  - Lazy loading of components
  - API response caching with TTL
  - Input debouncing for chat
  - Virtual scrolling for large datasets
- **Security Enhancements**:
  - CSRF protection
  - Input sanitization
  - XSS prevention
  - Rate limiting
- **Progressive Web App Features**:
  - Offline capability
  - Service worker caching
  - Background sync

#### 💬 Interactive Chat Interface
- **Natural Language Processing** for user queries
- **Context-Aware Responses** maintaining conversation history
- **Quick Action Buttons** for common queries
- **Real-Time Typing Indicators** and response streaming

#### 📊 Admin Dashboard
- **System Health Monitoring** with real-time status
- **Performance Metrics** and analytics
- **Agent Status Tracking** with health indicators
- **Configuration Management** interface

### 🔄 Integration Capabilities

#### ✅ Three-Tier Integration
- **Complete Integration Bridge** between all tiers
- **Bidirectional Communication** protocols
- **Performance Feedback Loops** for continuous learning
- **Health Monitoring** across all components

#### ✅ API Ecosystem
- **RESTful APIs** for all major components
- **WebSocket Support** for real-time updates
- **GraphQL Endpoint** for flexible data querying
- **Webhook Integration** for external systems

---

## 🔄 Integration & Communication

### 🌉 CrewAI-RL Integration Bridge

#### Strategy Validation Flow
```python
# Example integration flow
async def validate_strategy(strategy_data):
    # Send strategy to RL agent for validation
    rl_response = await rl_bridge.validate_strategy(strategy_data)
    
    # Process RL feedback
    if rl_response.confidence > 0.7:
        strategy_data.rl_validated = True
        strategy_data.rl_confidence = rl_response.confidence
    
    return strategy_data
```

#### Performance Feedback Loop
```python
# Performance tracking and learning
async def process_performance_feedback(execution_result):
    # Calculate performance metrics
    metrics = calculate_performance_metrics(execution_result)
    
    # Send feedback to RL agent
    await rl_bridge.send_performance_feedback(metrics)
    
    # Update agent weights based on performance
    await orchestrator.update_agent_weights(metrics.agent_contributions)
```

### 📡 Communication Protocols

#### Message Queue System
- **Async Message Processing** for non-blocking operations
- **Message Persistence** during system downtime
- **Retry Mechanisms** for failed messages
- **Dead Letter Queues** for problematic messages

#### Health Monitoring
- **Heartbeat Checks** every 30 seconds
- **Circuit Breaker Pattern** for failing services
- **Automatic Recovery** mechanisms
- **Alert System** for critical failures

---

## 📈 Performance & Analytics

### 📊 Performance Collector System

#### Metrics Tracked
```python
# Performance metrics collected
class PerformanceMetrics:
    total_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    average_holding_period: int
    volatility: float
    benchmark_correlation: float
    information_ratio: float
```

#### Analytics Database
- **SQLite Storage** for performance data
- **Time-Series Analysis** of strategy performance
- **Attribution Analysis** for individual agent contributions
- **Benchmark Comparison** against market indices

### 🎯 System Monitoring

#### Real-Time Metrics
- **API Response Times** with percentile tracking
- **Memory Usage** and garbage collection metrics
- **Request Throughput** and error rates
- **Agent Health Status** with uptime tracking

#### Performance Dashboard
- **Live System Status** with health indicators
- **Performance Charts** with interactive visualizations
- **Alert Management** for critical issues
- **Historical Analytics** for trend analysis

---

## 🔐 Security & Configuration

### 🛡️ Security Features

#### Authentication & Authorization
- **Session Management** with secure cookies
- **CSRF Protection** for all state-changing operations
- **Rate Limiting** to prevent abuse
- **Input Validation** and sanitization

#### Data Protection
- **Environment Variable Management** for sensitive data
- **Encrypted Storage** for API keys
- **Secure Communication** between components
- **Audit Logging** for security events

### ⚙️ Configuration Management

#### Environment Configuration
```bash
# Core AI Configuration
AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
AZURE_OPENAI_API_KEY=your-api-key
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_MODEL=gpt-4

# Data Source Configuration
ALPHA_VANTAGE_API_KEY=your-alpha-vantage-key
NEWS_API_KEY=your-news-api-key
YAHOO_FINANCE_ENABLED=true

# Trading Configuration
INITIAL_CAPITAL=50000
MAX_POSITION_SIZE=0.2
STOP_LOSS_THRESHOLD=0.08
RISK_TOLERANCE=moderate

# System Configuration
LOG_LEVEL=INFO
CACHE_ENABLED=true
PERFORMANCE_MONITORING=true
```

#### Dynamic Configuration
- **Hot Reload** of configuration changes
- **Environment-Specific** settings (dev/prod)
- **Feature Flags** for gradual rollouts
- **A/B Testing** configuration support

---

## 🛠️ Development & Testing

### 🧪 Testing Framework

#### Comprehensive Test Suite
```bash
# Run all tests
python -m pytest tests/ -v

# Integration tests
python -m pytest tests/integration/ -v

# Performance tests  
python -m pytest tests/performance/ -v

# End-to-end tests
python -m pytest tests/e2e/ -v
```

#### Test Coverage
- **Unit Tests** for individual agent functions
- **Integration Tests** for agent communication
- **Performance Tests** for system scalability
- **End-to-End Tests** for complete workflows

### 🔧 Development Tools

#### Code Quality
- **Black** for code formatting
- **Flake8** for linting
- **mypy** for type checking
- **Pre-commit Hooks** for automated checks

#### Development Environment
```bash
# Setup development environment
python setup.py --dev

# Install development dependencies
pip install -r requirements-dev.txt

# Setup pre-commit hooks
pre-commit install
```

---

## 📁 Project Structure

```
Trading-CrewAI-Agent/
├── 📊 agents/                     # AI Agent Implementations
│   ├── base_agent.py             # Abstract base class for all agents
│   ├── enhanced_base_agent.py    # Enhanced base with LLM capabilities
│   ├── orchestrator_agent.py     # Central coordination agent
│   ├── enhanced_research_agent.py         # Fundamental analysis
│   ├── enhanced_technical_agent.py        # Technical analysis
│   ├── enhanced_sentiment_agent.py        # Sentiment analysis
│   ├── enhanced_risk_agent.py             # Risk management
│   ├── enhanced_macro_agent.py            # Macroeconomic analysis
│   ├── enhanced_portfolio_manager.py      # Portfolio optimization
│   ├── enhanced_timing_agent.py           # Market timing
│   ├── enhanced_trade_strategy_planner.py # Strategy planning
│   ├── enhanced_dividends_yield_optimizer.py # Dividend optimization
│   ├── enhanced_performance_agent.py      # Performance evaluation
│   ├── enhanced_paper_trading_agent.py    # Virtual trading
│   └── enhanced_coordinator_final.py      # Final coordinator
│
├── 🧠 RL_Agent/                   # Reinforcement Learning System
│   ├── rl_agent.py               # Core RL trading agent
│   ├── trading_environment.py    # Gym-compatible trading environment
│   ├── rl_api.py                 # RL agent REST API
│   ├── run_rl_api.py             # RL API server
│   └── crewai_integration.py     # CrewAI integration services
│
├── 🔗 integration/               # System Integration Layer
│   ├── crewai_rl_bridge.py       # CrewAI-RL communication bridge
│   └── rl_enhanced_orchestrator.py # RL-enhanced orchestrator
│
├── 📊 analytics/                 # Performance Analytics
│   └── performance_collector.py   # Performance tracking and analytics
│
├── 🤖 main advisory agent/       # Main Advisory System
│   ├── main_advisory_agent.py    # Core advisory agent
│   ├── agent_registry.py         # Agent discovery and management
│   ├── conversation.py           # Conversation management
│   ├── conversation_routes.py    # Conversation API endpoints
│   ├── conversation_service.py   # Conversation business logic
│   ├── advisory.py               # Advisory API endpoints
│   ├── user.py                   # User management
│   ├── user_routes.py            # User API endpoints
│   ├── integration_connector.py  # Integration with other systems
│   └── main.py                   # Main API server
│
├── 🌐 ui/                        # User Interface Layer
│   ├── web/                      # Enhanced Web Interface
│   │   ├── index.html            # Main application page
│   │   ├── sw.js                 # Service worker for PWA
│   │   ├── css/                  # Stylesheets
│   │   │   ├── main.css          # Main styles
│   │   │   └── components.css    # Component styles
│   │   └── js/                   # JavaScript modules
│   │       ├── config.js         # Configuration
│   │       ├── performance.js    # Performance optimizations
│   │       ├── security.js       # Security utilities
│   │       ├── api.js            # Enhanced API client
│   │       ├── chat.js           # Chat interface
│   │       ├── monitoring.js     # System monitoring
│   │       └── main.js           # Main application logic
│   ├── web_server.py             # Enhanced Flask web server
│   ├── setup_enhanced_ui.py      # UI setup script
│   ├── performance_requirements.txt # Performance dependencies
│   └── README_Enhanced.md        # Enhanced UI documentation
│
├── 🗄️ data/                      # Data Management
│   ├── collectors/               # Data collection modules
│   │   └── market_data.py        # Market data collector
│   ├── processors/               # Data processing pipelines
│   ├── storage/                  # Database and file storage
│   ├── knowledge_base/           # Knowledge base storage
│   └── memory/                   # Agent memory storage
│
├── ⚙️ config/                     # Configuration Management
│   ├── settings.py               # System configuration
│   └── integration_config.json   # Integration configuration
│
├── 🔧 mcp_servers/               # Model Context Protocol Servers
│   ├── agent_registry.py         # MCP agent registry
│   ├── base_server.py            # Base MCP server
│   └── communication_protocol.py # MCP communication protocol
│
├── 🧪 tests/                     # Testing Suite
│   ├── integration/              # Integration tests
│   │   └── test_three_tier_integration.py # Three-tier integration tests
│   ├── e2e/                      # End-to-end tests
│   ├── performance/              # Performance tests
│   └── test_mcp_system.py        # MCP system tests
│
├── 📋 Final Design/              # Design Documentation
│   ├── Exceptional AI Trading Advisory System_ Comprehensive Architecture Design.md
│   ├── main_advisory_agent_design.md
│   ├── RL_AGENT_ARCHITECTURE_DOCUMENTATION.md
│   └── SUBAGENTS_ANALYSIS_AND_INTEGRATION_PLAN.md
│
├── 📊 reports/                   # Generated Reports
│   └── TCS_Analysis_Report.md    # Sample analysis report
│
├── 📝 logs/                      # System Logs
│   └── trading_agent.log        # Main system log
│
├── 🚀 System Startup Scripts
│   ├── start_integrated_system.py # Main system startup
│   ├── quick_test_system.py       # Quick system test
│   ├── setup.py                   # Initial setup script
│   ├── setup_integration.py       # Integration setup
│   └── system_monitor.py          # System monitoring
│
├── 📋 Configuration Files
│   ├── requirements.txt           # Python dependencies
│   ├── integration_requirements.txt # Integration dependencies
│   ├── .env.template             # Environment template
│   ├── .env                      # Environment variables (create from template)
│   └── ta_lib-0.6.4-cp311-cp311-win_amd64.whl # TA-Lib wheel for Windows
│
└── 📖 Documentation
    ├── README.md                 # This comprehensive guide
    ├── INTEGRATION_README.md     # Integration documentation
    ├── INTEGRATION_COMPLETE_SUMMARY.md # Integration summary
    ├── IMPLEMENTATION_ROADMAP.md # Development roadmap
    └── INTEGRATION_SUCCESS_REPORT.py # Integration success report
```

---

## 🌐 User Interfaces

### 💻 Enhanced Web UI (Port 3000)

#### Performance Features
- **⚡ Lazy Loading** - Components load on demand
- **🗄️ Intelligent Caching** - API responses cached with TTL
- **⌨️ Input Debouncing** - Smooth chat interactions
- **📜 Virtual Scrolling** - Efficient large dataset rendering
- **🔧 Service Worker** - Offline capability and background sync

#### Security Features  
- **🛡️ CSRF Protection** - Cross-site request forgery prevention
- **🧹 Input Sanitization** - XSS attack prevention
- **🚦 Rate Limiting** - API abuse prevention
- **🔒 Secure Headers** - Content Security Policy implementation

#### User Experience
- **💬 Real-time Chat** - Interactive AI conversation
- **📊 Live Dashboard** - System status and performance metrics
- **🎯 Quick Actions** - One-click common queries
- **📱 Responsive Design** - Mobile and desktop optimized

### 🤖 Main Advisory Agent API (Port 8000)

#### Endpoints
```bash
# Health and Status
GET  /api/health                  # System health check
GET  /api/user/health            # User service health
GET  /api/system/status          # Comprehensive system status

# Advisory Services
POST /api/advisory/chat          # Chat with AI advisor
GET  /api/advisory/insights      # Get market insights
POST /api/advisory/analyze       # Analyze specific stocks

# Conversation Management
GET  /api/conversation/history   # Get conversation history
POST /api/conversation/save      # Save conversation
GET  /api/conversation/{id}      # Get specific conversation
```

#### Example API Usage
```python
# Chat with the AI advisor
import requests

response = requests.post('http://localhost:8000/api/advisory/chat', 
    json={
        'message': 'What do you think about AAPL stock?',
        'conversation_id': 'conv_123',
        'user_id': 'user_456'
    }
)

result = response.json()
print(result['data']['response'])
```

### 🧠 RL Agent API (Port 5000)

#### Endpoints
```bash
# RL Agent Management
GET  /api/health                 # RL agent health
POST /api/train                  # Start training
GET  /api/status                 # Training status
GET  /api/insights               # RL insights

# Strategy Operations
POST /api/predict                # Get RL prediction
POST /api/validate-strategy      # Validate trading strategy
GET  /api/performance            # Performance metrics
```

#### Example RL Integration
```python
# Get RL trading recommendation
response = requests.post('http://localhost:5000/api/predict',
    json={
        'market_data': {
            'symbol': 'AAPL',
            'price': 150.0,
            'volume': 1000000,
            'technical_indicators': {...}
        }
    }
)

prediction = response.json()
print(f"RL Recommendation: {prediction['action']}")
print(f"Confidence: {prediction['confidence']}")
```

---

## 📖 API Documentation

### 🔌 REST API Specifications

#### Main Advisory Agent API

##### Authentication
```bash
# All requests include session management
Headers:
  Content-Type: application/json
  X-Request-ID: unique-request-id
  X-Session-ID: session-identifier
```

##### Chat Endpoint
```bash
POST /api/advisory/chat
```

**Request Body:**
```json
{
  "message": "Analyze TSLA stock for swing trading",
  "conversation_id": "conv_12345",
  "user_id": "user_67890",
  "context": {
    "trading_style": "swing",
    "risk_tolerance": "moderate",
    "time_horizon": "short_term"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "response": "Based on comprehensive analysis...",
    "recommendations": [
      {
        "action": "BUY",
        "symbol": "TSLA",
        "confidence": 0.78,
        "reasoning": "Technical indicators show...",
        "price_target": 250.0,
        "stop_loss": 220.0,
        "time_horizon": "2-4 weeks"
      }
    ],
    "risk_assessment": {
      "risk_level": "medium",
      "max_loss": 0.08,
      "expected_return": 0.15
    },
    "agent_contributions": {
      "technical": 0.25,
      "research": 0.20,
      "sentiment": 0.15,
      "risk": 0.25,
      "rl": 0.15
    }
  },
  "timestamp": "2024-01-15T10:30:00Z",
  "processing_time": "2.45s"
}
```

#### RL Agent API

##### Training Endpoint
```bash
POST /api/train
```

**Request Body:**
```json
{
  "algorithm": "PPO",
  "episodes": 1000,
  "symbols": ["AAPL", "GOOGL", "MSFT"],
  "start_date": "2020-01-01",
  "end_date": "2023-12-31",
  "parameters": {
    "learning_rate": 0.0003,
    "batch_size": 64,
    "gamma": 0.99
  }
}
```

**Response:**
```json
{
  "success": true,
  "training_id": "train_abc123",
  "status": "started",
  "estimated_duration": "45 minutes",
  "progress_endpoint": "/api/training/train_abc123/status"
}
```

### 📡 WebSocket API

#### Real-time Updates
```javascript
// Connect to real-time updates
const ws = new WebSocket('ws://localhost:8000/ws');

ws.onmessage = function(event) {
    const data = JSON.parse(event.data);
    
    switch(data.type) {
        case 'market_update':
            updateMarketData(data.payload);
            break;
        case 'recommendation':
            displayRecommendation(data.payload);
            break;
        case 'system_alert':
            showAlert(data.payload);
            break;
    }
};

// Subscribe to specific symbols
ws.send(JSON.stringify({
    type: 'subscribe',
    symbols: ['AAPL', 'GOOGL', 'MSFT']
}));
```

---

## 🔍 Monitoring & Logging

### 📊 System Monitoring

#### Health Check Endpoints
```bash
# System-wide health check
curl http://localhost:8000/api/health

# Detailed system status
curl http://localhost:8000/api/system/status

# Performance metrics
curl http://localhost:3000/api/performance/metrics
```

#### Real-time Monitoring Dashboard
- **System Health** - All component status indicators
- **Performance Metrics** - Response times, throughput, error rates
- **Agent Status** - Individual agent health and performance
- **Resource Usage** - CPU, memory, and disk utilization
- **Market Data Status** - Data feed health and latency

### 📝 Logging System

#### Log Levels and Categories
```python
# Log configuration
LOGGING_CONFIG = {
    'version': 1,
    'formatters': {
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        }
    },
    'handlers': {
        'file': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': 'logs/trading_agent.log',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5
        },
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler'
        }
    },
    'loggers': {
        'main_agent': {'level': 'INFO'},
        'rl_agent': {'level': 'INFO'},
        'performance': {'level': 'DEBUG'},
        'security': {'level': 'WARNING'}
    }
}
```

#### Log Analysis Tools
```bash
# View recent logs
tail -f logs/trading_agent.log

# Search for errors
grep "ERROR" logs/trading_agent.log

# Performance analysis
grep "PERFORMANCE" logs/trading_agent.log | tail -100

# Security events
grep "SECURITY" logs/trading_agent.log
```

### 🚨 Alert System

#### Alert Types
- **System Alerts** - Component failures, high resource usage
- **Trading Alerts** - Significant market movements, position limits
- **Performance Alerts** - Slow response times, high error rates
- **Security Alerts** - Failed authentication, rate limit violations

#### Alert Configuration
```python
# Alert thresholds
ALERT_CONFIG = {
    'response_time_threshold': 5.0,  # seconds
    'error_rate_threshold': 0.05,    # 5%
    'memory_usage_threshold': 0.85,  # 85%
    'failed_login_threshold': 5,     # attempts
}
```

---

## 🚨 Troubleshooting

### 🔧 Common Issues and Solutions

#### Installation Issues

**Issue: TA-Lib installation fails**
```bash
# Solution 1: Use pre-compiled wheel (Windows)
pip install ta_lib-0.6.4-cp311-cp311-win_amd64.whl

# Solution 2: Install from conda (cross-platform)
conda install -c conda-forge ta-lib

# Solution 3: Build from source (Linux/Mac)
# Download TA-Lib C library first
wget http://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
tar -xzf ta-lib-0.4.0-src.tar.gz
cd ta-lib/
./configure --prefix=/usr
make
sudo make install
pip install TA-Lib
```

**Issue: Azure OpenAI connection fails**
```bash
# Check environment variables
echo $AZURE_OPENAI_ENDPOINT
echo $AZURE_OPENAI_API_KEY

# Test connection
python -c "
import openai
from azure.identity import DefaultAzureCredential
# Test your configuration
"
```

#### Runtime Issues

**Issue: Agent communication failures**
```bash
# Check agent registry status
curl http://localhost:8000/api/system/status

# Restart individual agents
python agents/orchestrator_agent.py --restart

# Clear agent cache
rm -rf data/storage/agent_cache/*
```

**Issue: RL training not converging**
```python
# Adjust hyperparameters
RL_CONFIG = {
    'learning_rate': 0.0001,  # Reduce learning rate
    'batch_size': 32,         # Smaller batch size
    'gamma': 0.95,           # Adjust discount factor
    'epsilon_decay': 0.995   # Slower exploration decay
}

# Enable detailed logging
import logging
logging.getLogger('rl_agent').setLevel(logging.DEBUG)
```

**Issue: High memory usage**
```bash
# Monitor memory usage
python system_monitor.py --memory

# Clear caches
python -c "
from data.storage import clear_all_caches
clear_all_caches()
"

# Restart system with memory limits
python start_integrated_system.py --max-memory 4GB
```

#### Performance Issues

**Issue: Slow API responses**
```python
# Enable performance monitoring
PERFORMANCE_CONFIG = {
    'enable_profiling': True,
    'cache_enabled': True,
    'connection_pooling': True,
    'async_processing': True
}

# Check bottlenecks
python -m cProfile start_integrated_system.py
```

**Issue: Database lock errors**
```bash
# Check SQLite database
sqlite3 data/storage/trading_agent.db ".schema"

# Rebuild database if corrupted
python setup_integration.py --rebuild-db

# Enable WAL mode for better concurrency
sqlite3 data/storage/trading_agent.db "PRAGMA journal_mode=WAL;"
```

### 🔍 Debug Mode

#### Enable Debug Logging
```bash
# Set environment variable
export LOG_LEVEL=DEBUG

# Or modify config
python start_integrated_system.py --debug
```

#### Debug Tools
```python
# Interactive debugging session
python -i start_integrated_system.py

# Inspect agent state
from agents.orchestrator_agent import orchestrator
print(orchestrator.get_agent_status())

# Check RL agent training state
from RL_Agent.rl_agent import rl_agent
print(rl_agent.get_training_metrics())
```

### 📞 Getting Help

#### Log Analysis
```bash
# Generate system report
python system_monitor.py --generate-report

# Check system health
python quick_test_system.py --comprehensive

# Export logs for analysis
python -c "
import logs.log_analyzer
logs.log_analyzer.export_system_report('system_report.json')
"
```

#### Community Support
- Check the `Final Design/` directory for architectural documentation
- Review `tests/` directory for usage examples
- Examine `integration/` for integration patterns
- Consult `config/settings.py` for configuration options

---

## 🛣️ Roadmap

### 🎯 Current Status (v1.0)

#### ✅ Completed Features
- **Three-Tier Architecture** - Fully implemented and integrated
- **14 Specialized Agents** - All agents operational with domain expertise
- **RL Integration** - Complete bidirectional communication between CrewAI and RL
- **Performance Analytics** - Comprehensive tracking and feedback loops
- **Enhanced Web UI** - Performance optimized with security features
- **API Ecosystem** - REST APIs for all major components
- **Testing Suite** - 100% pass rate on integration tests

#### 🔄 In Progress
- **Real-time Market Data** - Live data feeds integration
- **Advanced Backtesting** - Historical strategy validation
- **Mobile Optimization** - Enhanced mobile web experience
- **Performance Tuning** - System optimization for production

### 🚀 Phase 2 (v2.0) - Q2 2025

#### 🎯 Advanced Trading Features
- **Options Trading Analysis** - Options strategies and Greeks calculation
- **Cryptocurrency Integration** - Crypto market analysis and trading
- **Futures and Commodities** - Extended asset class support
- **Algorithmic Trading** - Automated strategy execution

#### 🧠 Enhanced AI Capabilities
- **GPT-4 Turbo Integration** - Latest model capabilities
- **Multi-modal Analysis** - Image and video content analysis
- **Advanced NLP** - Better natural language understanding
- **Federated Learning** - Privacy-preserving collaborative learning

#### 🌐 Platform Expansion
- **Mobile App** - Native iOS and Android applications
- **Desktop Application** - Electron-based desktop app
- **Browser Extension** - Real-time market data overlay
- **API Marketplace** - Third-party integrations

### 🌟 Phase 3 (v3.0) - Q4 2025

#### 🤖 Autonomous Features
- **Autonomous Trading** - Fully automated trading with human oversight
- **Dynamic Risk Management** - Real-time risk adjustment
- **Market Making** - Liquidity provision strategies
- **Portfolio Rebalancing** - Automated portfolio optimization

#### 🔬 Research & Development
- **Quantum Computing** - Quantum algorithms for portfolio optimization
- **Alternative Data** - Satellite imagery, social sentiment, news analysis
- **Graph Neural Networks** - Market relationship modeling
- **Reinforcement Learning** - Advanced RL algorithms (Rainbow DQN, SAC)

#### 🌍 Global Expansion
- **Multi-Market Support** - International exchanges
- **Multi-Currency** - FX market integration
- **Regulatory Compliance** - Region-specific compliance features
- **Localization** - Multi-language support

### 🔮 Future Vision (v4.0+)

#### 🚀 Cutting-Edge Technology
- **AGI Integration** - Artificial General Intelligence capabilities
- **Blockchain Integration** - DeFi and Web3 trading strategies
- **IoT Data Integration** - Real-world data for market insights
- **Edge Computing** - Low-latency trading infrastructure

#### 🌐 Ecosystem Development
- **Open Source Community** - Community-driven development
- **Plugin Architecture** - Third-party plugin ecosystem
- **Educational Platform** - Trading education and simulation
- **Social Trading** - Community-driven trading insights

---

## 📜 License & Disclaimer

### ⚖️ License

This project is licensed under the MIT License - see the LICENSE file for details.

```
MIT License

Copyright (c) 2024 AI Trading Advisory System

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
```

### ⚠️ Important Disclaimers

#### Investment Advisory Disclaimer
**This system is for educational and research purposes only. It is NOT intended to provide investment advice or recommendations for actual trading.**

- **No Financial Advice** - The AI recommendations are for educational purposes only
- **Risk Warning** - All investments carry risk of financial loss
- **Past Performance** - Historical results do not guarantee future performance
- **Regulatory Compliance** - Ensure compliance with local financial regulations
- **Professional Advice** - Consult qualified financial advisors for investment decisions

#### Technical Disclaimer
- **Beta Software** - This system is in active development
- **No Warranties** - Software provided "as-is" without warranties
- **Data Accuracy** - Market data may have delays or inaccuracies
- **System Availability** - No guarantee of 100% uptime
- **Security** - Users responsible for securing their API keys and data

#### Usage Guidelines
- **Paper Trading** - Start with simulated trading only
- **Risk Management** - Never invest more than you can afford to lose
- **Diversification** - Don't rely on a single strategy or system
- **Continuous Learning** - Stay informed about market conditions
- **Responsible Use** - Use the system ethically and legally

### 🤝 Contributing

We welcome contributions to improve the AI Trading Advisory System:

1. **Fork the Repository** - Create your own copy
2. **Create Feature Branch** - Work on specific features
3. **Follow Code Standards** - Use Black, Flake8, and type hints
4. **Write Tests** - Maintain test coverage above 80%
5. **Submit Pull Request** - Describe your changes clearly

#### Development Guidelines
```bash
# Setup development environment
python setup.py --dev

# Run code quality checks
black . --check
flake8 .
mypy .

# Run tests before submitting
python -m pytest tests/ --cov=. --cov-report=html
```

### 📞 Support & Contact

#### Technical Support
- **Documentation** - Check the `Final Design/` directory
- **Issues** - Report bugs and feature requests via GitHub
- **Discussions** - Join community discussions
- **Email** - Contact the development team

#### Community
- **Discord** - Join our developer community
- **Reddit** - r/AITradingAdvisory
- **Twitter** - @AITradingAdvisory
- **YouTube** - Tutorial and demo videos

---

## 🎉 Acknowledgments

### 🙏 Special Thanks

- **CrewAI Team** - For the excellent multi-agent framework
- **OpenAI & Azure** - For powerful language model capabilities
- **Gymnasium** - For the reinforcement learning environment
- **Yahoo Finance** - For free market data access
- **Alpha Vantage** - For comprehensive financial data APIs
- **Open Source Community** - For the amazing libraries and tools

### 🛠️ Technology Stack

#### AI & Machine Learning
- **CrewAI** - Multi-agent orchestration framework
- **Azure OpenAI** - GPT-4 language model services
- **Gymnasium** - Reinforcement learning environments
- **Stable-Baselines3** - RL algorithm implementations
- **Hugging Face** - Transformer models and embeddings
- **scikit-learn** - Traditional machine learning algorithms

#### Data & Analytics
- **pandas** - Data manipulation and analysis
- **numpy** - Numerical computing
- **pandas-ta** - Technical analysis indicators
- **yfinance** - Yahoo Finance data
- **alpha_vantage** - Financial data API
- **SQLite** - Lightweight database

#### Web & API
- **Flask** - Web framework and API server
- **Flask-CORS** - Cross-origin resource sharing
- **Flask-Limiter** - Rate limiting
- **requests** - HTTP client library
- **websockets** - Real-time communication

#### Development & Testing
- **pytest** - Testing framework
- **black** - Code formatting
- **flake8** - Code linting
- **mypy** - Type checking
- **coverage** - Test coverage analysis

---

**🚀 Ready to revolutionize your trading with AI? Get started today!**

```bash
git clone <repository-url>
cd Trading-CrewAI-Agent
python setup.py
python start_integrated_system.py
```

**📊 Access your AI Trading Advisory System:**
- **Web UI**: http://localhost:3000
- **Main API**: http://localhost:8000
- **RL Agent**: http://localhost:5000

**🎯 Happy Trading! 📈💰** tier)
- **NewsAPI** - Financial news (free tier)
- **Economic APIs** - RBI, World Bank data

### AI/ML
- **Azure OpenAI GPT-4o** - Primary language model
- **Hugging Face** - Sentiment analysis models
- **pandas-ta** - Technical analysis indicators
- **scikit-learn** - Traditional ML models

### Interface
- **Streamlit** - Web dashboard and chat interface
- **Plotly** - Interactive charts
- **SQLite** - Local data storage
- **Redis** - Data caching

## 📁 Project Structure

```
Trading-Agent/
├── agents/                 # AI Agent implementations
│   ├── base_agent.py      # Abstract base class
│   ├── coordinator.py     # Master coordinator agent
│   ├── research_agent.py  # Fundamental analysis
│   ├── technical_agent.py # Technical analysis
│   └── ...
├── mcp_servers/           # Model Context Protocol servers
├── data/                  # Data collection and processing
│   ├── collectors/        # Data fetching modules
│   ├── processors/        # Data processing pipelines
│   └── storage/          # Database and file storage
├── ui/                    # User interface
│   ├── dashboard.py       # Main Streamlit dashboard
│   ├── chat_interface.py  # Chat with AI
│   └── visualizations.py # Charts and graphs
├── config/                # Configuration files
│   └── settings.py       # System configuration
├── tests/                 # Unit tests
├── logs/                  # Application logs
├── requirements.txt       # Python dependencies
├── main.py               # Main application entry point
└── setup.py              # Setup and installation script
```

## 🎮 Usage

### Dashboard Navigation
1. **Portfolio Overview** - Track your investments and performance
2. **Stock Analysis** - Analyze individual stocks with AI agents
3. **Market Dashboard** - Monitor market indices and trends
4. **Chat with AI** - Ask questions and get investment advice
5. **Settings** - Configure system and manage watchlist

### Investment Workflow
1. **Add stocks to watchlist** - Monitor interesting stocks
2. **Analyze with AI agents** - Get multi-agent recommendations
3. **Make investment decisions** - Based on AI analysis
4. **Track performance** - Monitor portfolio returns
5. **Learn and improve** - System learns from outcomes

## 🔧 Configuration

### Trading Parameters
- **Initial Capital**: ₹5,000
- **Max Position Size**: 20% per stock
- **Stop Loss**: 8% threshold
- **Risk Profile**: Conservative to Moderate

### Agent Weights
- Research Agent: 25%
- Technical Agent: 20%
- Risk Agent: 25%
- Sentiment Agent: 15%
- Macro Agent: 10%
- Timing Agent: 5%

### Data Refresh Rates
- Market Data: 5 minutes
- News Data: 15 minutes
- Sentiment Data: 30 minutes

## 🔐 Security & Compliance

- **Advisory Only** - System provides recommendations, not automated trading
- **Local Data** - All data stored locally for privacy
- **API Security** - Secure API key management
- **Risk Management** - Built-in risk constraints and limits

## 📈 Performance Monitoring

### Success Metrics
- **ROI** - Return on Investment tracking
- **Sharpe Ratio** - Risk-adjusted returns
- **Maximum Drawdown** - Worst-case loss protection
- **Benchmark Comparison** - Performance vs NIFTY 50
- **Agent Accuracy** - Individual agent performance

### Learning Features
- **Recommendation Tracking** - Monitor prediction accuracy
- **Performance Feedback** - Agents learn from outcomes
- **Continuous Improvement** - System adapts to market changes


## 🤝 Contributing

This is a personal project for learning and investment purposes. However, suggestions and improvements are welcome!

## ⚠️ Disclaimer

This system is for educational and personal use only. All investment decisions should be made carefully considering your risk tolerance. The AI recommendations are not guaranteed to be profitable, and you should always do your own research before investing.

## 📧 Support

For technical issues or questions:
1. Check the logs in `logs/trading_agent.log`
2. Verify your API keys in `.env` file
3. Ensure all dependencies are installed correctly

---

**Happy Trading! 🚀📈**
