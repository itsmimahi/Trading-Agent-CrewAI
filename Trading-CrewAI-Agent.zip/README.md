# Trading CrewAI Agent — Documentation

A multi-agent AI trading advisory system built on **CrewAI 1.14.5** that orchestrates
12 specialised financial analysis agents, integrates with **Interactive Brokers** (paper
trading) for live portfolio data, and uses a custom **Reinforcement Learning v2** module
for risk-aware trade validation.

> **Test suite status**: 296 / 296 tests passing (Phases 0–6 + RL v2)

---

## System Map

```mermaid
graph TB
    subgraph Input
        U[User Message]
    end

    subgraph Advisory Flow ["Advisory Flow (CrewAI 1.14.5)"]
        IF[initialize_flow<br/>NLU · intent · entities]
        MR[market_router<br/>@router]
        PG[portfolio_gate_step<br/>trade approval]
        MA[market_analysis_step<br/>parallel crews × 5 markets]
        SY[synthesis_step<br/>AnalysisCrew + RL validation]
        AG[approval_gate<br/>@router]
        EX[execution_step<br/>ExecutionCrew + IBKR]
    end

    subgraph Subsystems
        MEM[(LanceDB<br/>Memory)]
        CHK[(SQLite<br/>Checkpoints)]
        IBKR[IBKRPortfolioService<br/>live account]
        RL[RL Agent v2<br/>PPO / SAC]
    end

    subgraph Agents ["12 Specialised Agents"]
        RA[Research] --- TA[Technical]
        SA[Sentiment] --- MA2[Macro]
        RI[Risk] --- PE[Performance]
        TI[Timing] --- SP[Strategy Planner]
    end

    U --> IF --> MR
    MR -->|portfolio| PG
    MR -->|analysis| MA
    MA --> SY --> AG
    AG -->|approved| EX
    EX --> IBKR
    SY --> RL
    MA --> Agents
    MA --> MEM
    SY --> MEM
    EX --> MEM
    IF --> CHK
    MA --> CHK
    SY --> CHK
    EX --> CHK
    IF --> IBKR
```

---

## Documentation Index

| # | File | What it covers |
|---|------|----------------|
| — | **This file** | Navigation, quick-start, system map |
| 01 | [System Overview](01_system_overview.md) | Architecture layers, technology stack, design decisions |
| 02 | [Getting Started](02_getting_started.md) | Install, `.env`, virtual env, first run |
| 03 | [Advisory Flow](03_advisory_flow.md) | CrewAI Flow topology, `AdvisoryFlowState`, all 8 steps |
| 04 | [Market Analysis](04_market_analysis.md) | `MarketCrewBuilder`, 5 markets, Phase 1 + 2 data tools |
| 05 | [Analysis & Synthesis](05_analysis_synthesis.md) | `AnalysisCrewBuilder`, RL A2A v1 + v2, `ValidationResult` |
| 06 | [Execution & Approval](06_execution_approval.md) | `ExecutionCrewBuilder`, approval lifecycle, idempotency |
| 07 | [Memory System](07_memory_system.md) | LanceDB hierarchical memory, Phase 5 hooks |
| 08 | [Flow Persistence](08_flow_persistence.md) | `SQLiteFlowPersistence`, checkpoint/resume, Phase 6 |
| 09 | [RL Agent v2](09_rl_agent_v2.md) | Risk metrics, regime classifier, env, training pipeline |
| 10 | [IBKR Integration](10_ibkr_integration.md) | `IBKRPortfolioService`, real-time data, activation guide |
| 11 | [Specialised Agents](11_specialized_agents.md) | 12 enhanced agents, A2A protocol, agent registry |
| 12 | [Integration Layer](12_integration_layer.md) | `EventBus` (Redis), CrewAI-RL bridge v2 |
| 13 | [Configuration Reference](13_configuration.md) | All environment variables, `settings.py` |
| 14 | [Testing Guide](14_testing.md) | 296 tests across 8 phases, how to run |
| 15 | [Operations](15_operations.md) | Docker, startup sequence, troubleshooting |

---

## Quick Start

```bash
# 1. Activate virtual environment
.\crewenv\Scripts\Activate.ps1          # Windows PowerShell
source crewenv/bin/activate             # macOS / Linux

# 2. Copy and fill in environment variables
copy .env.example .env                  # then edit .env

# 3. Run the full test suite (should print 296/296)
python scripts/test_advisory_flow_topology.py
python scripts/test_rl_v2.py
```

For IBKR paper trading, see [IBKR Integration](10_ibkr_integration.md#activation-guide).

---

## Key Concepts

| Term | Meaning |
|------|---------|
| **Advisory Flow** | The top-level CrewAI `Flow` that orchestrates one end-to-end advisory request |
| **Market Crew** | A `Crew` of specialised agents analysing a single market (IN / US / EU / APAC / CRYPTO) |
| **Synthesis** | Combining 5 market-crew outputs into one advisory recommendation, then RL-validated |
| **Approval Gate** | Human (or programmatic) confirmation before trade orders are submitted to IBKR |
| **Checkpoint** | SQLite-persisted `AdvisoryFlowState` snapshot taken after each expensive step |
| **RL v2** | Stable-Baselines3 PPO/SAC agent trained on multi-asset portfolio gymnasium environment |
| **Regime** | Market state classification: BULL / BEAR / SIDEWAYS / HIGH_VOL (4 states) |
| **No-Trade Override** | RL v2 blocks execution when policy entropy exceeds the uncertainty threshold |
| **IBKR Service** | `IBKRPortfolioService` — live connection to IBKR paper account via `ib_insync` |
