from __future__ import annotations

import os
from typing import Any
from flask import Blueprint, jsonify, current_app, request

admin_bp = Blueprint('admin', __name__)


def _runtime_toggle_allowed() -> bool:
    return os.getenv('ALLOW_RUNTIME_TOGGLE', '0') in ('1', 'true', 'True')


def _check_token() -> bool:
    expected = os.getenv('PTA_ADMIN_TOKEN')
    if not expected:
        return False
    got = request.headers.get('X-Admin-Token') or request.args.get('token') or (request.get_json(silent=True) or {}).get('token')
    return bool(got and got == expected)


def _init_trading_adapter_for_mode(mode: str) -> tuple[bool, str | None]:
    app = current_app
    mode = (mode or 'PAPER').upper()
    app.config['EXECUTION_MODE'] = mode
    app.config['TRADING_ADAPTER'] = None
    if mode == 'SHOONYA' and app.config.get('BROKER') == 'SHOONYA':
        # Safety gates must be enabled
        if not (os.getenv('SHOONYA_LIVE', '0') in ('1', 'true', 'True') and os.getenv('ALLOW_LIVE_TRADING', 'NO') in ('YES', 'yes', '1', 'true', 'True')):
            return False, 'live trading safety toggles not enabled'
        try:
            from paper_trading_agent.adapters.shoonya_trading import ShoonyaTradingAdapter  # type: ignore
            app.config['TRADING_ADAPTER'] = ShoonyaTradingAdapter()
            return True, None
        except Exception as e:  # pragma: no cover
            app.config['TRADING_ADAPTER'] = None
            return False, str(e)
    return True, None


@admin_bp.route('/mode', methods=['GET'])
def get_mode():
    app = current_app
    trading_adapter = app.config.get('TRADING_ADAPTER')
    out: dict[str, Any] = {
        'execution_mode': app.config.get('EXECUTION_MODE', 'PAPER'),
        'broker': app.config.get('BROKER'),
        'live_trading_enabled': bool(trading_adapter),
        'allow_runtime_toggle': _runtime_toggle_allowed(),
        'safety': {
            'SHOONYA_LIVE': os.getenv('SHOONYA_LIVE', '0'),
            'ALLOW_LIVE_TRADING': os.getenv('ALLOW_LIVE_TRADING', 'NO'),
        }
    }
    return jsonify(out)


@admin_bp.route('/mode', methods=['POST'])
def set_mode():
    if not _runtime_toggle_allowed():
        return jsonify({'error': 'runtime toggle disabled'}), 403
    if not _check_token():
        return jsonify({'error': 'unauthorized'}), 401
    data = request.get_json(force=True) or {}
    mode = str(data.get('execution_mode', 'PAPER')).upper()
    if mode not in {'PAPER', 'SHOONYA'}:
        return jsonify({'error': 'invalid execution_mode'}), 400
    ok, err = _init_trading_adapter_for_mode(mode)
    if not ok:
        return jsonify({'error': err or 'failed to init adapter'}), 400
    return jsonify({'status': 'ok', 'execution_mode': mode, 'live_trading_enabled': bool(current_app.config.get('TRADING_ADAPTER'))})
