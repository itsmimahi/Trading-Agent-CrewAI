"""
Conversation routes for the Main Advisory Agent.
"""

from flask import Blueprint, jsonify, request
from conversation_service import ConversationService

conversation_bp = Blueprint('conversation', __name__)
conversation_service = ConversationService()

@conversation_bp.route('/conversation/health')
def conversation_health():
    """Conversation service health check."""
    return jsonify({
        'status': 'healthy',
        'service': 'conversation_service',
        'message': 'Conversation service is operational'
    })

@conversation_bp.route('/conversation/history/<conversation_id>')
def get_conversation_history(conversation_id):
    """Get conversation history for a specific conversation."""
    try:
        history = conversation_service.get_conversation_history(conversation_id)
        return jsonify({
            'conversation_id': conversation_id,
            'history': history,
            'status': 'success'
        })
    except Exception as e:
        return jsonify({
            'error': str(e),
            'status': 'error'
        }), 500

@conversation_bp.route('/conversation/contexts')
def get_active_contexts():
    """Get all active conversation contexts."""
    try:
        contexts = conversation_service.get_active_contexts()
        return jsonify({
            'contexts': contexts,
            'count': len(contexts),
            'status': 'success'
        })
    except Exception as e:
        return jsonify({
            'error': str(e),
            'status': 'error'
        }), 500
