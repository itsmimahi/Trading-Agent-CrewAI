# Advisory Flow

> **Source**: `main_advisory_agent/advisory_flow.py`  
> **Phases documented**: 0 – 6 (all)

The `AdvisoryFlow` is the top-level orchestrator. It extends CrewAI's `Flow[AdvisoryFlowState]`
and processes one advisory request end-to-end via a sequence of typed, checkpointed steps.

---

## Flow topology

```mermaid
flowchart TD
    START([User Message]) --> IF

    IF["@start\ninitialize_flow\nNLU · intent · entities\nportfolio prefetch\ncheckpoint #1"]

    IF --> MR

    MR{"@router\nmarket_router"}

    MR -->|portfolio_gate| PG
    MR -->|market_analysis| MA
    MR -->|advisory_execution_resume| AER

    PG["@listen portfolio_gate\nportfolio_gate_step\nexpiry · approve/reject · new order"]

    MA["@listen market_analysis\nmarket_analysis_step\nasync parallel × N markets\nmemory recall · write\ncheckpoint #2"]

    MA --> SY

    SY["@listen market_analysis_step\nsynthesis_step\nAnalysisCrew · RL validation\nmemory write\ncheckpoint #3"]

    SY --> AG

    AG{"@router\napproval_gate"}

    AG -->|approved| EX
    AG -->|needs_revision| RV
    AG -->|rejected| RJ

    EX["@listen approved\nexecution_step\nIBKR refresh\nExecutionCrew\nmemory write\ncheckpoint #4"]

    AER["@listen advisory_execution_resume\nadvisory_execution_resume_step\napply user decision"]

    RV["@listen needs_revision\nrevision_step\nrecord feedback"]
    RJ["@listen rejected\nrejected_step\ndismissal message"]

    style IF fill:#d4edda
    style MA fill:#d4edda
    style SY fill:#d4edda
    style EX fill:#d4edda
    style PG fill:#fff3cd
    style AER fill:#cce5ff
```

The green steps write a **SQLite checkpoint** after completion. If the process crashes,
the flow can be resumed from the last checkpoint — see [Flow Persistence](08_flow_persistence.md).

---

## `AdvisoryFlowState`

All steps share this single Pydantic model stored in `self.state`.

| Field | Type | Purpose |
|-------|------|---------|
| `user_input` | `str` | Raw text from the user |
| `conversation_id` | `str` | Stable ID for the whole conversation session |
| `request_id` | `str` | Unique ID for this single request |
| `intent` | `str` | Classified intent (see table below) |
| `confidence` | `float` | Intent classification confidence (0–1) |
| `entities` | `List[Dict]` | Extracted stock symbols, time periods, goals |
| `active_markets` | `List[str]` | Markets to analyse (`["IN", "US", ...]`) |
| `invocation_mode` | `str` | `"orchestrated"` or `"single_agent"` |
| `preferred_agents` | `List[str]` | Agent IDs preferred for this intent |
| `bypass_reason` | `str` | Why fast-path was bypassed (if applicable) |
| `market_results` | `Dict[str, Any]` | Raw per-market crew outputs |
| `synthesis_result` | `str` | Combined advisory text (after RL validation) |
| `portfolio_snapshot` | `Dict[str, Any]` | Live IBKR holdings + cash |
| `market_snapshot` | `Dict[str, Any]` | Prefetched index data (for overview queries) |
| `parsed_order` | `Optional[Dict]` | Trade order parsed from user_input |
| `approval_decision` | `str` | `"approve"` / `"reject"` / `""` |
| `approval_id` | `str` | UUID of the pending approval entry |
| `agent_results` | `Dict[str, Any]` | Raw results from specialised agents |
| `execution_result` | `str` | ExecutionCrew output (trade plan markdown) |
| `advisory_approval_pending` | `bool` | True while waiting for human approval |
| `final_response` | `str` | Text returned to the user |
| `response_metadata` | `Dict[str, Any]` | Execution path, trace, timing |
| `step_trace` | `List[str]` | Names of steps visited (observability) |
| `execution_path` | `str` | `"market_analysis"` / `"portfolio_gate"` / … |
| `error` | `Optional[str]` | Error message if a step failed |
| `duration_ms` | `float` | Cumulative wall-clock time in ms |
| `memory_recall` | `Dict[str, Any]` | Per-market memory recall context (Phase 5) |
| `id` | `str` | Flow UUID = `conversation_id` (Phase 6) |

### Intent values

| Intent | Typical trigger words |
|--------|----------------------|
| `fundamental_analysis` | earnings, revenue, profit, P/E, valuation |
| `technical_analysis` | chart, RSI, MACD, support, resistance |
| `sentiment_analysis` | sentiment, news, social, buzz |
| `risk_assessment` | risk, volatility, drawdown, VaR, hedge |
| `timing` | when, entry, exit, buy, sell |
| `strategy` | strategy, plan, approach |
| `general_advice` | advice, suggest, help, should I |

---

## `AdvisoryFlow.__init__` parameters

```python
AdvisoryFlow(
    *,
    llm: LLM,                                     # Azure OpenAI LLM instance
    tools: list,                                  # CrewAI tools (market data, A2A, etc.)
    embedder_config: Optional[dict],              # Local HF embedder config for Crew memory
    entity_extractor: Any,                        # EntityExtractor instance
    intent_classifier: Any,                       # IntentClassifier instance
    default_market: str = "IN",                   # Fallback market when none detected
    advisory_disclaimer: str = "",                # Appended to all responses when set
    verbose: bool = False,                        # CrewAI verbose mode
    append_disclaimer: bool = True,
    enforce_market_hours: bool = True,            # Block orders outside market hours
    approval_timeout_minutes: int = 30,
    idempotency_window_minutes: int = 30,
    max_position_size: float = 0.20,              # Max fraction of portfolio per position
    max_order_risk_fraction: float = 0.05,        # Max order as fraction of portfolio
    portfolio_holdings_fn: Optional[Callable],    # () -> Dict — IBKR holdings
    portfolio_metrics_fn: Optional[Callable],     # () -> Dict — IBKR metrics
    portfolio_preview_fn: Optional[Callable],     # (symbol, side, qty) -> Dict
    portfolio_submit_fn: Optional[Callable],      # (symbol, side, qty, key) -> Dict
    portfolio_available_fn: Optional[Callable],   # () -> bool — is IBKR connected?
    memory_store: Optional[Any] = None,           # Phase 5: MemoryStore instance
    persist_db_path: Optional[str] = None,        # Phase 6: SQLite checkpoint path
)
```

---

## Step-by-step reference

### Step 1 — `initialize_flow` (Phase 0)

**Decorator**: `@start()`  
**Checkpoint**: yes (checkpoint #1)

Actions performed:

1. Set `state.id = state.conversation_id` (Phase 6 persistence key)
2. Resume from checkpoint if `response_metadata["resume_from_checkpoint"] == True`
3. Get or create conversation context via `conversation_manager`
4. Extract entities → `state.entities`
5. Classify intent → `state.intent`, `state.confidence`
6. Detect active markets → `state.active_markets`
7. Determine invocation mode → `state.invocation_mode`
8. Parse trade order → `state.parsed_order`
9. Extract approval decision → `state.approval_decision`, `state.approval_id`
10. Detect advisory approval resume (Phase 4, if `ENABLE_ADVISORY_APPROVAL=1`)
11. Prefetch live portfolio snapshot from IBKR → `state.portfolio_snapshot`
12. Best-effort prefetch market overview (for `risk_assessment` intent)
13. Call `_persist_step("initialize_flow")`

---

### Step 2 — `market_router` (Phase 0)

**Decorator**: `@router(initialize_flow)`  
**Returns**: one of `"portfolio_gate"`, `"market_analysis"`, `"advisory_execution_resume"`

| Condition | Route |
|-----------|-------|
| Advisory approval pending + external outcome received | `"advisory_execution_resume"` |
| Pending approval action + user sent approve/reject | `"portfolio_gate"` |
| New trade order detected (`state.parsed_order` set) | `"portfolio_gate"` |
| All other queries | `"market_analysis"` |

---

### Step 3a — `portfolio_gate_step` (Phase 0)

**Decorator**: `@listen("portfolio_gate")`

Handles the complete **trade approval lifecycle**:

1. **Expiry check** — if a pending approval has timed out, return expiry message
2. **Decision processing** — if user typed `APPROVE <id>` or `REJECT <id>` for an existing pending action, execute via `_execute_approval_decision`
3. **New order** — validate risk limits + market hours, then call `_create_approval_request` which stores the pending action and returns a prompt asking the user to confirm

---

### Step 3b — `market_analysis_step` (Phase 1)

**Decorator**: `@listen("market_analysis")`  
**Async**: yes (`async def`)  
**Checkpoint**: yes (checkpoint #2)

```python
# Phase 5: recall prior market context from LanceDB before crews run
for market in state.active_markets:
    prior = recall_market_history(memory_store, market, user_input)
    if prior:
        state.memory_recall[market] = prior

# Phase 1+2: build MarketCrewBuilder with MCP data tools
builder = MarketCrewBuilder(llm=llm, tools=combined_tools, verbose=verbose)

# Run all market crews in parallel
tasks = [_run_market_crew_async(builder, market, ...) for market in active_markets]
results = await asyncio.gather(*tasks, return_exceptions=True)

# Phase 5: store each market result to LanceDB
for market, result in state.market_results.items():
    remember_market_analysis(memory_store, market, raw_text)
```

---

### Step 4 — `synthesis_step` (Phase 3)

**Decorator**: `@listen(market_analysis_step)`  
**Checkpoint**: yes (checkpoint #3)

```python
# Phase 3 path
builder = AnalysisCrewBuilder(llm=llm, verbose=verbose)
crew = builder.build(market_results=..., portfolio_snapshot=...)
raw = crew.kickoff()
synthesis_text = rl_a2a_validate(str(raw), state.market_results)
state.synthesis_result = synthesis_text

# Phase 0 fallback: inline combine market_results into one text
```

- If `ENABLE_RL_VALIDATION=1`, calls the RL service via HTTP A2A (v1)
- If `ENABLE_RL_VALIDATION_V2=1`, calls `rl_a2a_validate_v2` (local PPO inference)
- Phase 5: stores synthesis to LanceDB via `remember_synthesis`

---

### Step 5 — `approval_gate` (Phase 0)

**Decorator**: `@router(synthesis_step)`  
**Returns**: `"approved"` | `"needs_revision"` | `"rejected"`

- Checks `state.response_metadata["external_approval_outcome"]` for an externally injected decision (Phase 4 webhook)
- Phase 0: always returns `"approved"` (auto-approve)

---

### Step 6 — `execution_step` (Phase 4)

**Decorator**: `@listen("approved")`  
**Checkpoint**: yes (checkpoint #4)

```python
# IBKR portfolio refresh — get current positions before building trade plan
fresh = portfolio_holdings_fn()
if fresh and "error" not in fresh:
    state.portfolio_snapshot = fresh

# Phase 4: advisory approval gate (ENABLE_ADVISORY_APPROVAL=1)
# First pass: create pending advisory entry and return draft to user
# Second pass: user confirms, ExecutionCrew runs

# ExecutionCrew
crew = ExecutionCrewBuilder(...).build(
    synthesis=state.synthesis_result,
    portfolio_snapshot=state.portfolio_snapshot,
)
state.execution_result = str(crew.kickoff())

# Phase 5: store execution result to LanceDB
remember_trade_execution(memory_store, execution_result, conversation_id)
```

---

### Step 7 — `advisory_execution_resume_step` (Phase 4)

**Decorator**: `@listen("advisory_execution_resume")`

Entered when a user responds to a pending advisory synthesis approval.
Restores `synthesis_result` from `AdvisoryApprovalProvider` and either
runs `ExecutionCrewBuilder` (approved) or returns a dismissal message.

---

## Internal helpers

| Method | Purpose |
|--------|---------|
| `_persist_step(method_name)` | Save state to SQLite (silent on failure) |
| `_restore_from_checkpoint(state)` | Load prior state from SQLite, skip expensive fields already computed |
| `_try_prefetch_market_snapshot(context, state)` | Best-effort fetch of market overview + top movers |
| `_create_approval_request(context, state)` | Validate order risk, store pending approval, return confirmation prompt |
| `_execute_approval_decision(context, state, pending)` | Submit or reject a pending trade |
| `_check_and_expire_approval(context, state)` | Return expiry message if approval window has passed |
| `_finalize(context)` | Append disclaimer, store response in conversation context |
| `_run_crew(context, state)` | Phase 0 fallback: run a single orchestrated Crew |
| `_get_crew_agent()` | Lazily create/reuse the main advisory `Agent` instance |
