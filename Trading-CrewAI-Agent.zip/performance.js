/**
 * Performance Optimization Utilities
 * Implements lazy loading, caching, debouncing, and virtual scrolling
 */

class PerformanceOptimizer {
    constructor() {
        this.cache = new Map();
        this.debounceTimers = new Map();
        this.intersectionObserver = null;
    this._throttleFns = new Map();
        this.initIntersectionObserver();
    }

    /**
     * Initialize Intersection Observer for lazy loading
     */
    initIntersectionObserver() {
        if ('IntersectionObserver' in window) {
            this.intersectionObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.loadComponent(entry.target);
                        this.intersectionObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
        }
    }

    /**
     * Lazy load component
     */
    lazyLoad(element, loadFunction) {
        if (this.intersectionObserver) {
            element.dataset.loadFunction = loadFunction.name;
            this.intersectionObserver.observe(element);
        } else {
            // Fallback for browsers without IntersectionObserver
            loadFunction();
        }
    }

    /**
     * Load component when it becomes visible
     */
    async loadComponent(element) {
        const loadFunctionName = element.dataset.loadFunction;
        if (loadFunctionName && window[loadFunctionName]) {
            try {
                await window[loadFunctionName](element);
                element.classList.add('loaded');
            } catch (error) {
                console.error('Failed to load component:', error);
            }
        }
    }

    /**
     * Debounce function calls
     */
    debounce(key, func, delay = 300) {
        if (this.debounceTimers.has(key)) {
            clearTimeout(this.debounceTimers.get(key));
        }

        const timer = setTimeout(() => {
            func();
            this.debounceTimers.delete(key);
        }, delay);

        this.debounceTimers.set(key, timer);
    }

    /**
     * Throttle function calls; returns a throttled function reusable by key
     */
    throttle(key, func, limit = 100) {
        const mapKey = `thr_${key}`;
        if (this._throttleFns.has(mapKey)) {
            return this._throttleFns.get(mapKey);
        }
        let last = 0;
        let timeout = null;
        let trailingArgs = null;
        const throttled = function(...args) {
            const now = Date.now();
            const remaining = limit - (now - last);
            if (remaining <= 0) {
                last = now;
                func.apply(this, args);
            } else {
                trailingArgs = args;
                if (timeout) clearTimeout(timeout);
                timeout = setTimeout(() => {
                    last = Date.now();
                    func.apply(this, trailingArgs || []);
                    timeout = null;
                    trailingArgs = null;
                }, remaining);
            }
        };
        this._throttleFns.set(mapKey, throttled);
        return throttled;
    }

    /**
     * Cache API responses
     */
    cacheResponse(key, data, ttl = 300000) { // 5 minutes default
        const expirationTime = Date.now() + ttl;
        this.cache.set(key, {
            data,
            expirationTime
        });
    }

    /**
     * Get cached response
     */
    getCachedResponse(key) {
        const cached = this.cache.get(key);
        if (cached && Date.now() < cached.expirationTime) {
            return cached.data;
        }
        if (cached) {
            this.cache.delete(key);
        }
        return null;
    }

    /**
     * Clear expired cache entries
     */
    clearExpiredCache() {
        const now = Date.now();
        for (const [key, value] of this.cache.entries()) {
            if (now >= value.expirationTime) {
                this.cache.delete(key);
            }
        }
    }

    /**
     * Virtual scrolling for large lists
     */
    createVirtualScroll(container, items, itemHeight = 50, visibleCount = 10) {
        const virtualScroll = new VirtualScrollManager(container, items, itemHeight, visibleCount);
        return virtualScroll;
    }

    /**
     * Preload critical resources
     */
    preloadResources(resources) {
        resources.forEach(resource => {
            if (resource.type === 'script') {
                const link = document.createElement('link');
                link.rel = 'prefetch';
                link.href = resource.url;
                document.head.appendChild(link);
            } else if (resource.type === 'image') {
                const img = new Image();
                img.src = resource.url;
            }
        });
    }

    /**
     * Monitor performance metrics
     */
    monitorPerformance() {
        if ('PerformanceObserver' in window) {
            const observer = new PerformanceObserver((list) => {
                list.getEntries().forEach((entry) => {
                    if (entry.entryType === 'navigation') {
                        console.log('Page Load Time:', entry.loadEventEnd - entry.loadEventStart);
                    } else if (entry.entryType === 'paint') {
                        console.log(`${entry.name}:`, entry.startTime);
                    }
                });
            });

            observer.observe({ entryTypes: ['navigation', 'paint'] });
        }
    }
}

/**
 * Virtual Scroll Manager for efficient rendering of large lists
 */
class VirtualScrollManager {
    constructor(container, items, itemHeight, visibleCount) {
        this.container = container;
        this.items = items;
        this.itemHeight = itemHeight;
        this.visibleCount = visibleCount;
        this.scrollTop = 0;
        this.startIndex = 0;
        this.endIndex = visibleCount;

        this.init();
    }

    init() {
        this.container.style.height = `${this.visibleCount * this.itemHeight}px`;
        this.container.style.overflow = 'auto';
        this.container.style.position = 'relative';

        // Create viewport
        this.viewport = document.createElement('div');
        this.viewport.style.height = `${this.items.length * this.itemHeight}px`;
        this.viewport.style.position = 'relative';
        this.container.appendChild(this.viewport);

        // Create visible items container
        this.visibleContainer = document.createElement('div');
        this.visibleContainer.style.position = 'absolute';
        this.visibleContainer.style.top = '0';
        this.visibleContainer.style.width = '100%';
        this.viewport.appendChild(this.visibleContainer);

        this.container.addEventListener('scroll', () => this.onScroll());
        this.render();
    }

    onScroll() {
        this.scrollTop = this.container.scrollTop;
        const newStartIndex = Math.floor(this.scrollTop / this.itemHeight);
        const newEndIndex = Math.min(newStartIndex + this.visibleCount + 1, this.items.length);

        if (newStartIndex !== this.startIndex || newEndIndex !== this.endIndex) {
            this.startIndex = newStartIndex;
            this.endIndex = newEndIndex;
            this.render();
        }
    }

    render() {
        this.visibleContainer.innerHTML = '';
        this.visibleContainer.style.transform = `translateY(${this.startIndex * this.itemHeight}px)`;

        for (let i = this.startIndex; i < this.endIndex; i++) {
            const item = this.items[i];
            const element = this.createItemElement(item, i);
            this.visibleContainer.appendChild(element);
        }
    }

    createItemElement(item, index) {
        const element = document.createElement('div');
        element.style.height = `${this.itemHeight}px`;
        element.style.borderBottom = '1px solid #eee';
        element.style.padding = '10px';
        element.textContent = typeof item === 'string' ? item : JSON.stringify(item);
        element.dataset.index = index;
        return element;
    }

    updateItems(newItems) {
        this.items = newItems;
        this.viewport.style.height = `${this.items.length * this.itemHeight}px`;
        this.render();
    }
}

/**
 * Component Lazy Loader
 */
class ComponentLoader {
    static async loadChart(element) {
        if (!window.Chart) {
            // Dynamically load Chart.js
            await this.loadScript('https://cdn.jsdelivr.net/npm/chart.js');
        }
        // Initialize chart
        const canvas = element.querySelector('canvas');
        if (canvas) {
            new Chart(canvas, {
                type: 'line',
                data: { labels: [], datasets: [] },
                options: { responsive: true }
            });
        }
    }

    static async loadDataTable(element) {
        if (!window.DataTable) {
            // Dynamically load DataTables
            await this.loadScript('https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js');
            await this.loadStylesheet('https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css');
        }
        // Initialize DataTable
        const table = element.querySelector('table');
        if (table && window.$ && window.$.fn.DataTable) {
            $(table).DataTable({
                pageLength: 25,
                responsive: true
            });
        }
    }

    static loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    static loadStylesheet(href) {
        return new Promise((resolve, reject) => {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = href;
            link.onload = resolve;
            link.onerror = reject;
            document.head.appendChild(link);
        });
    }
}

// Initialize performance optimizer
const performanceOptimizer = new PerformanceOptimizer();

// Auto-clear expired cache every 5 minutes
setInterval(() => {
    performanceOptimizer.clearExpiredCache();
}, 300000);

// Monitor performance
performanceOptimizer.monitorPerformance();

// Export for use in other modules
window.PerformanceOptimizer = PerformanceOptimizer;
window.ComponentLoader = ComponentLoader;
window.performanceOptimizer = performanceOptimizer;
