// Main Application Controller - Orchestrates all UI components
class TradingAdvisoryApp {
    constructor() {
        this.isInitialized = false;
        this.components = {};
        
        this.init();
    }

    // Initialize application
    async init() {
        try {
            console.log('Initializing AI Trading Advisory System...');
            
            // Wait for DOM to be ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.initializeComponents());
            } else {
                this.initializeComponents();
            }
            
        } catch (error) {
            console.error('Application initialization failed:', error);
            this.showError('Failed to initialize application: ' + error.message);
        }
    }

    // Initialize all components
    initializeComponents() {
        try {
            console.log('Initializing UI components...');
            
            // Initialize toast system
            this.initializeToastSystem();
            
            // Initialize modal system
            this.initializeModalSystem();
            
            // Initialize navigation
            this.initializeNavigation();
            
            // Initialize loading system
            this.initializeLoadingSystem();
            
            // Set up global error handling
            this.setupErrorHandling();
            
            // Initialize app-specific features
            this.initializeAppFeatures();

            // Initialize theme switcher
            this.initializeTheme();
            
            this.isInitialized = true;
            console.log('Application initialized successfully');
            
            // Show welcome toast
            setTimeout(() => {
                this.showToast('AI Trading Advisory System loaded successfully', 'success');
            }, 1000);
            
        } catch (error) {
            console.error('Component initialization failed:', error);
            this.showError('Failed to initialize components: ' + error.message);
        }
    }

    // Set a default theme without a switcher
    initializeTheme() {
        document.body.classList.add('theme-dark-green');
    }

    // Initialize toast notification system
    initializeToastSystem() {
        const toastElement = document.getElementById('notificationToast');
        const toastMessage = document.getElementById('toastMessage');
        const toastClose = document.getElementById('toastClose');
        
        if (toastElement && toastMessage && toastClose) {
            // Close toast on click
            toastClose.addEventListener('click', () => {
                this.hideToast();
            });
            
            // Auto-hide toast after duration
            this.toastTimeout = null;
            
            // Expose global toast function
            window.showToast = (message, type = 'info') => {
                this.showToast(message, type);
            };
            
            window.hideToast = () => {
                this.hideToast();
            };
            
            console.log('Toast system initialized');
        }
    }

    // Show toast notification
    showToast(message, type = 'info') {
        const toastElement = document.getElementById('notificationToast');
        const toastMessage = document.getElementById('toastMessage');
        const toastIcon = toastElement?.querySelector('.toast-icon i');
        
        if (!toastElement || !toastMessage) return;
        
        // Clear existing timeout
        if (this.toastTimeout) {
            clearTimeout(this.toastTimeout);
        }
        
        // Set message
        toastMessage.textContent = message;
        
        // Set icon and type
        if (toastIcon) {
            toastIcon.className = this.getToastIcon(type);
        }
        
        const toastIconElement = toastElement.querySelector('.toast-icon');
        if (toastIconElement) {
            toastIconElement.className = `toast-icon ${type}`;
        }
        
        // Show toast
        toastElement.classList.add('show');
        
        // Auto-hide after duration
        this.toastTimeout = setTimeout(() => {
            this.hideToast();
        }, CONFIG.ui.toastDuration);
    }

    // Hide toast notification
    hideToast() {
        const toastElement = document.getElementById('notificationToast');
        if (toastElement) {
            toastElement.classList.remove('show');
        }
        
        if (this.toastTimeout) {
            clearTimeout(this.toastTimeout);
            this.toastTimeout = null;
        }
    }

    // Get toast icon based on type
    getToastIcon(type) {
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        return icons[type] || icons.info;
    }

    // Initialize modal system
    initializeModalSystem() {
        const adminModal = document.getElementById('adminModal');
        const adminBtn = document.getElementById('adminBtn');
        const modalClose = document.getElementById('modalClose');
        
        if (adminModal && adminBtn && modalClose) {
            // Open admin modal
            adminBtn.addEventListener('click', () => {
                this.showModal('adminModal');
            });
            
            // Close modal on click
            modalClose.addEventListener('click', () => {
                this.hideModal('adminModal');
            });
            
            // Close modal on overlay click
            adminModal.addEventListener('click', (e) => {
                if (e.target === adminModal) {
                    this.hideModal('adminModal');
                }
            });
            
            console.log('Modal system initialized');
        }
    }

    // Show modal
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    // Hide modal
    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    // Initialize navigation and keyboard shortcuts
    initializeNavigation() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl+Enter to send message
            if (e.ctrlKey && e.key === 'Enter') {
                const sendButton = document.getElementById('sendButton');
                if (sendButton && !sendButton.disabled) {
                    sendButton.click();
                }
            }
            
            // Escape to close modals
            if (e.key === 'Escape') {
                const activeModal = document.querySelector('.modal-overlay.active');
                if (activeModal) {
                    activeModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
                this.hideToast();
            }
            
            // Ctrl+/ for help (future feature)
            if (e.ctrlKey && e.key === '/') {
                e.preventDefault();
                this.showToast('Keyboard shortcuts: Ctrl+Enter (send), Escape (close), Ctrl+/ (help)', 'info');
            }
        });
        
        console.log('Navigation initialized');
    }

    // Initialize loading system
    initializeLoadingSystem() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        
        if (loadingOverlay) {
            // Expose global loading functions
            window.showLoading = (message = 'Processing your request...') => {
                this.showLoading(message);
            };
            
            window.hideLoading = () => {
                this.hideLoading();
            };
            
            console.log('Loading system initialized');
        }
    }

    // Show loading overlay
    showLoading(message = 'Processing your request...') {
        const loadingOverlay = document.getElementById('loadingOverlay');
        const loadingText = loadingOverlay?.querySelector('p');
        
        if (loadingOverlay) {
            if (loadingText) {
                loadingText.textContent = message;
            }
            loadingOverlay.classList.add('active');
        }
    }

    // Hide loading overlay
    hideLoading() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        if (loadingOverlay) {
            loadingOverlay.classList.remove('active');
        }
    }

    // Setup global error handling
    setupErrorHandling() {
        // Global error handler
        window.addEventListener('error', (e) => {
            console.error('Global error:', e.error);
            this.showToast('An unexpected error occurred', 'error');
        });
        
        // Promise rejection handler
        window.addEventListener('unhandledrejection', (e) => {
            console.error('Unhandled promise rejection:', e.reason);
            this.showToast('System error: ' + (e.reason?.message || 'Unknown error'), 'error');
        });
        
        console.log('Error handling initialized');
    }

    // Initialize app-specific features
    initializeAppFeatures() {
        // Focus on message input by default
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            setTimeout(() => {
                messageInput.focus();
            }, 500);
        }
        
        // Initialize responsive behavior
        this.initializeResponsive();
        
        // Set up periodic health checks
        this.startHealthChecks();
        
        console.log('App features initialized');
    }

    // Initialize responsive behavior
    initializeResponsive() {
        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
        
        // Initial resize handling
        this.handleResize();
    }

    // Handle window resize
    handleResize() {
        const width = window.innerWidth;
        
        // Mobile menu toggle logic would go here
        if (width < 768) {
            // Mobile view adjustments
            document.body.classList.add('mobile-view');
        } else {
            document.body.classList.remove('mobile-view');
        }
    }

    // Start periodic health checks
    startHealthChecks() {
        // Initial health check
        setTimeout(() => {
            if (window.systemMonitor) {
                window.systemMonitor.performStatusCheck();
            }
        }, 2000);
        
        // Show system ready message
        setTimeout(() => {
            this.showToast('System ready - All services checked', 'success');
        }, 3000);
    }

    // Show error message
    showError(message) {
        this.showToast(message, 'error');
        console.error('Application error:', message);
    }

    // Get application status
    getAppStatus() {
        return {
            initialized: this.isInitialized,
            components: Object.keys(this.components),
            version: '1.0.0',
            buildTime: new Date().toISOString(),
            userAgent: navigator.userAgent,
            viewport: {
                width: window.innerWidth,
                height: window.innerHeight
            }
        };
    }

    // Export application data
    exportAppData() {
        const data = {
            appStatus: this.getAppStatus(),
            chatStats: window.chatManager?.getConversationStats(),
            systemStatus: window.enhancedAPI?.getSystemStatus(),
            monitoringStatus: window.systemMonitor?.getMonitoringStatus(),
            timestamp: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `trading_system_data_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showToast('Application data exported successfully', 'success');
    }

    // Restart application
    restart() {
        this.showLoading('Restarting application...');
        
        setTimeout(() => {
            window.location.reload();
        }, 1000);
    }
}

// Initialize application when DOM is ready
const tradingApp = new TradingAdvisoryApp();

// Export for global use and debugging
window.tradingApp = tradingApp;

// Console welcome message
console.log(`
🚀 AI Trading Advisory System
================================
Enhanced Web Interface v1.0.0
Powered by Azure OpenAI & RL Agents

Available Commands:
- tradingApp.getAppStatus()
- tradingApp.exportAppData()
- tradingApp.restart()
- window.chatManager.exportChat()
- window.enhancedAPI.getSystemStatus()

System Status: ${tradingApp.isInitialized ? 'Ready' : 'Initializing...'}
`);

// Development helpers (only in development)
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    window.dev = {
        // Development utilities
        testToast: () => tradingApp.showToast('Test notification', 'info'),
        testError: () => tradingApp.showToast('Test error message', 'error'),
        testSuccess: () => tradingApp.showToast('Test success message', 'success'),
        testWarning: () => tradingApp.showToast('Test warning message', 'warning'),
        testLoading: () => {
            tradingApp.showLoading('Testing loading...');
            setTimeout(() => tradingApp.hideLoading(), 3000);
        },
        simulateError: () => {
            throw new Error('Simulated error for testing');
        },
        getDebugInfo: () => ({
            app: tradingApp.getAppStatus(),
            chat: window.chatManager?.getConversationStats(),
            api: window.enhancedAPI?.getSystemStatus(),
            config: CONFIG
        })
    };
    
    console.log('Development utilities available in window.dev');
}
