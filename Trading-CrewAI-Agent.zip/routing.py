"""Routing and guardrail utilities for Main Advisory Agent.

This module is intentionally lightweight so it can be unit-tested without
initializing heavy CrewAI runtime dependencies.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple


class GlobalMarketRouter:
    """Determines market scope and selective invocation mode for a query."""

    MARKET_KEYWORDS = {
        "IN": ["india", "indian", "nse", "bse", "nifty", "sensex"],
        "US": ["us", "usa", "american", "nyse", "nasdaq", "s&p", "dow", "djia"],
        "EU": ["eu", "europe", "european", "dax", "ftse", "cac", "euronext", "xetra"],
        "APAC": ["apac", "asia", "asian", "nikkei", "hang seng", "sse", "shanghai", "tokyo", "hkex"],
        "CRYPTO": ["crypto", "bitcoin", "btc", "ethereum", "eth", "altcoin", "solana"],
    }

    SYMBOL_SUFFIX_MARKET = {
        ".NS": "IN",
        ".BO": "IN",
        ".L": "EU",
        ".DE": "EU",
        ".F": "EU",
        ".PA": "EU",
        ".HK": "APAC",
        ".T": "APAC",
        ".SS": "APAC",
        ".SZ": "APAC",
    }

    SINGLE_AGENT_INTENTS = {
        "fundamental_analysis",
        "technical_analysis",
        "sentiment_analysis",
        "risk_assessment",
        "timing",
    }

    INTENT_AGENT_MAP = {
        "fundamental_analysis": ["fundamental_research"],
        "technical_analysis": ["technical_analysis"],
        "sentiment_analysis": ["sentiment_analysis"],
        "risk_assessment": ["risk_assessment"],
        "timing": ["timing_agent"],
        "strategy": ["trade_strategy_planner"],
    }

    FASTPATH_BYPASS_INTENTS = {
        "strategy",
        "general_advice",
    }

    FASTPATH_BYPASS_PHRASES = [
        "place order",
        "submit order",
        "execute trade",
        "execute order",
        "rebalance",
        "all in",
        "full position",
        "use margin",
        "leverage",
        "stop loss",
        "take profit",
    ]

    COMPLEXITY_CUES = [
        "compare",
        "portfolio",
        "allocation",
        "strategy",
        "plan",
        "across",
        "vs",
        " and ",
    ]

    @classmethod
    def detect_markets(cls, text: str, entities: List[Dict[str, Any]], default_market: str = "IN") -> List[str]:
        """Detect one or more active markets from text and extracted entities."""
        text_lower = (text or "").lower()
        detected: List[str] = []

        for market, keywords in cls.MARKET_KEYWORDS.items():
            if any(k in text_lower for k in keywords):
                detected.append(market)

        for e in entities or []:
            if e.get("type") != "stock_symbol":
                continue
            sym = str(e.get("value", "")).upper()
            matched = False
            for suffix, market in cls.SYMBOL_SUFFIX_MARKET.items():
                if sym.endswith(suffix):
                    detected.append(market)
                    matched = True
                    break
            if matched:
                continue
            # Unsuffixed symbols are most often US tickers in this system.
            if sym and sym.isalnum() and 1 <= len(sym) <= 5:
                detected.append("US")

        deduped = []
        seen = set()
        for m in detected:
            if m not in seen:
                deduped.append(m)
                seen.add(m)

        return deduped or [default_market]

    @classmethod
    def preferred_agents_for_intent(cls, intent: str) -> List[str]:
        return list(cls.INTENT_AGENT_MAP.get(intent, []))

    @classmethod
    def should_bypass_fastpath(cls, intent: str, text: str) -> Tuple[bool, str]:
        """Return bypass decision and reason for forced orchestration."""
        if intent in cls.FASTPATH_BYPASS_INTENTS:
            return True, f"intent:{intent}"

        t = (text or "").lower()
        for phrase in cls.FASTPATH_BYPASS_PHRASES:
            if phrase in t:
                return True, f"phrase:{phrase}"

        return False, ""

    @classmethod
    def invocation_mode(cls, intent: str, text: str, confidence: float) -> str:
        """Choose single-agent fast path vs orchestration based on intent and cues."""
        bypass, _reason = cls.should_bypass_fastpath(intent, text)
        if bypass:
            return "orchestrated"

        t = f" {(text or '').lower()} "
        is_complex = any(c in t for c in cls.COMPLEXITY_CUES)
        if intent in cls.SINGLE_AGENT_INTENTS and confidence >= 0.45 and not is_complex:
            return "single_agent"
        return "orchestrated"


class PortfolioActionGuard:
    """Guardrails and parsers for trade actions requiring explicit approval."""

    ACTION_KEYWORDS = [
        "buy",
        "sell",
        "rebalance",
        "place order",
        "submit order",
        "execute trade",
        "execute order",
    ]

    _APPROVE_RE = re.compile(r"^\s*(approve|confirm)\s+([a-zA-Z0-9\-]{8,})\s*$", re.IGNORECASE)
    _REJECT_RE = re.compile(r"^\s*(reject|cancel|deny)\s+([a-zA-Z0-9\-]{8,})\s*$", re.IGNORECASE)

    _ORDER_PATTERNS = [
        re.compile(
            r"\b(?P<side>buy|sell)\b\s+(?P<quantity>\d+)\s+(?:shares?\s+of\s+)?(?P<symbol>[A-Za-z][A-Za-z0-9\.\-]{0,14})\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?P<side>buy|sell)\b\s+(?P<symbol>[A-Za-z][A-Za-z0-9\.\-]{0,14})\s+(?P<quantity>\d+)\b",
            re.IGNORECASE,
        ),
    ]

    @classmethod
    def extract_decision(cls, text: str) -> Tuple[Optional[str], Optional[str]]:
        raw = (text or "").strip()
        m = cls._APPROVE_RE.match(raw)
        if m:
            return "approve", m.group(2)
        m = cls._REJECT_RE.match(raw)
        if m:
            return "reject", m.group(2)
        return None, None

    @classmethod
    def is_portfolio_action_request(cls, text: str) -> bool:
        t = (text or "").lower()
        return any(k in t for k in cls.ACTION_KEYWORDS)

    @classmethod
    def parse_order_request(
        cls,
        text: str,
        entities: List[Dict[str, Any]],
        default_market: str = "IN",
    ) -> Optional[Dict[str, Any]]:
        """Parse a buy/sell order request from text/entities.

        Returns normalized payload with side, symbol, quantity, market.
        """
        raw = text or ""
        for pattern in cls._ORDER_PATTERNS:
            m = pattern.search(raw)
            if not m:
                continue
            side = m.group("side").lower()
            symbol = m.group("symbol").upper()
            quantity = int(m.group("quantity"))
            symbol = cls._normalize_symbol(symbol, default_market)
            if quantity <= 0:
                return None
            return {
                "side": side,
                "symbol": symbol,
                "quantity": quantity,
                "market": default_market,
            }

        if not cls.is_portfolio_action_request(raw):
            return None

        side = None
        t = raw.lower()
        if "buy" in t:
            side = "buy"
        elif "sell" in t:
            side = "sell"
        if not side:
            return None

        symbol = None
        for e in entities or []:
            if e.get("type") == "stock_symbol":
                symbol = str(e.get("value", "")).upper()
                break
        if not symbol:
            return None
        symbol = cls._normalize_symbol(symbol, default_market)

        qty_match = re.search(r"\b(\d{1,6})\b", raw)
        quantity = int(qty_match.group(1)) if qty_match else 0
        if quantity <= 0:
            return None

        return {
            "side": side,
            "symbol": symbol,
            "quantity": quantity,
            "market": default_market,
        }

    @staticmethod
    def _normalize_symbol(symbol: str, default_market: str) -> str:
        s = (symbol or "").upper()
        if "." in s:
            return s
        if default_market == "IN":
            return f"{s}.NS"
        return s
