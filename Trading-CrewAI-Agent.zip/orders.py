import os
from datetime import datetime, time
from flask import Blueprint, jsonify, request, current_app
from .portfolio import _PORTFOLIO
try:
    from ..storage.paper_state import load_state, save_state  # type: ignore
except Exception:  # pragma: no cover
    load_state = None  # type: ignore
    save_state = None  # type: ignore
from .market import _LAST_PRICE

orders_bp = Blueprint('orders', __name__)

# Initialize orders and sequence from persisted state
_ORDERS = {}
_ORDER_SEQ = 1
if callable(load_state):
    _pf, _meta = load_state()  # type: ignore
    try:
        _ORDER_SEQ = int((_meta or {}).get('order_seq') or 1)
        for o in (_meta or {}).get('orders', []):
            if isinstance(o, dict):
                _ORDERS[o.get('order_id') or f"PTA-{len(_ORDERS)+1:06d}"] = o
    except Exception:
        pass


def _next_order_id() -> str:
    global _ORDER_SEQ
    oid = f"PTA-{_ORDER_SEQ:06d}"
    _ORDER_SEQ += 1
    return oid


def _preview(symbol: str, side: str, quantity: int):
    symbol = symbol.upper()
    price = float(_LAST_PRICE.get(symbol, 100.0))
    est_value = price * quantity
    fees = max(5.0, est_value * 0.0005)
    return {
        'symbol': symbol,
        'side': side,
        'quantity': quantity,
        'price': price,
        'estimated_value': est_value,
        'estimated_fees': round(fees, 2),
        'estimated_total': round(est_value + fees, 2)
    }


def _within_trading_window() -> bool:
    """Check if current local time is within PTA_TRADING_WINDOW (HH:MM-HH:MM)."""
    # DEV MODE: Always allow trading window
    return True


def _symbol_allowed(symbol: str) -> bool:
    # DEV MODE: Always allow all symbols
    return True


def _max_qty_ok(qty: int) -> bool:
    v = os.getenv('PTA_MAX_ORDER_QTY')
    if not v:
        return True
    try:
        limit = int(v)
        return qty <= limit
    except Exception:
        return True


def _normalize_live_order(adapter, raw: dict) -> dict:
    # Shoonya common fields: norenordno (order id), trantype B/S, qty, prc/avgprc, exch, tsym
    order_id = raw.get('norenordno') or raw.get('order_id') or raw.get('orderno')
    trantype = str(raw.get('trantype', '')).upper()
    side = 'buy' if trantype == 'B' else ('sell' if trantype == 'S' else raw.get('side'))
    qty = raw.get('qty') or raw.get('quantity')
    price = raw.get('avgprc') or raw.get('prc') or raw.get('price') or raw.get('lp')
    exch = raw.get('exch') or raw.get('exchange')
    tsym = raw.get('tsym') or raw.get('trading_symbol') or raw.get('ts')
    symbol = None
    try:
        if exch and tsym:
            # Map NSE|RELIANCE-EQ -> RELIANCE.NS
            base = str(tsym)
            if base.endswith('-EQ'):
                base = base[:-3]
            symbol = f"{base}.NS" if str(exch).upper().startswith('NSE') else base
    except Exception:
        pass
    status = raw.get('status') or raw.get('stat')
    if status == 'Ok':
        status = 'accepted'
    return {
        'order_id': order_id,
        'symbol': symbol or raw.get('symbol'),
        'side': side,
        'quantity': qty,
        'price': price,
        'status': status,
        'raw': raw,
    }


@orders_bp.route('/preview', methods=['POST'])
def preview():
    data = request.get_json(force=True) or {}
    symbol = str(data.get('symbol', '')).upper()
    side = str(data.get('side', '')).lower()
    qty = int(data.get('quantity', 0))
    if not symbol or side not in {'buy', 'sell'} or qty <= 0:
        return jsonify({'error': 'symbol, side in {buy|sell}, quantity>0 required'}), 400
    svc = current_app.config.get('PORTFOLIO_SERVICE')
    if svc is not None:
        try:
            return jsonify(svc.preview(symbol, side, qty))
        except Exception as e:
            return jsonify({'error': str(e)}), 400
    return jsonify(_preview(symbol, side, qty))


@orders_bp.route('/submit', methods=['POST'])
def submit():
    """Submit order with enhanced error logging for development"""
    try:
        data = request.get_json(force=True) or {}
        session_id = request.headers.get('X-Session-ID') or request.cookies.get('session')
        current_app.logger.info(f"[ORDER SUBMIT] Incoming request: {data} | session_id={session_id}")
        
        symbol = str(data.get('symbol', '')).upper()
        side = str(data.get('side', '')).lower()
        qty = int(data.get('quantity', 0))
        idem_key = data.get('idempotency_key')
        
        validation_log = {
            'symbol': symbol,
            'side': side,
            'quantity': qty,
            'idempotency_key': idem_key,
            'session_id': session_id
        }
        current_app.logger.info(f"[ORDER VALIDATION] {validation_log}")

        # Validation with detailed logging
        if not symbol:
            current_app.logger.error(f"[ORDER ERROR] Validation failed: Missing symbol | payload={data}")
            return jsonify({'error': 'symbol required'}), 400
        if side not in {'buy', 'sell'}:
            current_app.logger.error(f"[ORDER ERROR] Validation failed: Invalid side '{side}', must be 'buy' or 'sell' | payload={data}")
            return jsonify({'error': 'side must be buy or sell'}), 400
        if qty <= 0:
            current_app.logger.error(f"[ORDER ERROR] Validation failed: Invalid quantity {qty}, must be > 0 | payload={data}")
            return jsonify({'error': 'quantity must be > 0'}), 400

        # Safety limiters (apply to both PAPER and SHOONYA)
        if not _symbol_allowed(symbol):
            current_app.logger.error(f"[ORDER ERROR] Rejected: Symbol {symbol} not in whitelist | payload={data}")
            return jsonify({'error': f'symbol {symbol} not in whitelist'}), 400
        if not _max_qty_ok(qty):
            current_app.logger.error(f"[ORDER ERROR] Rejected: Quantity {qty} exceeds max limit | payload={data}")
            return jsonify({'error': f'quantity {qty} exceeds max limit'}), 400
        if not _within_trading_window():
            current_app.logger.error(f"[ORDER ERROR] Rejected: Outside trading window | payload={data}")
            return jsonify({'error': 'outside trading window'}), 400

        # Idempotency
        if idem_key and idem_key in _ORDERS:
            current_app.logger.info(f"[ORDER INFO] Duplicate order detected for idempotency key: {idem_key} | session_id={session_id}")
            return jsonify({'status': 'duplicate', 'order': _ORDERS[idem_key]}), 200

        exec_mode = str(current_app.config.get('EXECUTION_MODE', 'PAPER')).upper()
        trading_adapter = current_app.config.get('TRADING_ADAPTER')
        current_app.logger.info(f"[ORDER EXECUTION] Mode={exec_mode}, Adapter={trading_adapter is not None} | session_id={session_id}")
        
        # Shoonya live branch (optional, guarded)
        if exec_mode == 'SHOONYA' and trading_adapter is not None:
            try:
                current_app.logger.info(f"[ORDER EXECUTION] Executing live order via Shoonya adapter | payload={data}")
                order_type = str(data.get('order_type', 'MARKET')).upper()
                product = str(data.get('product', 'CNC')).upper()
                price = data.get('price')
                res = trading_adapter.place_order(symbol=symbol, side=side, quantity=qty, order_type=order_type, product=product, price=price, tag=idem_key)
                out = res
                if isinstance(res, dict) and 'raw' in res and isinstance(res['raw'], dict):
                    out = _normalize_live_order(trading_adapter, res['raw'])
                current_app.logger.info(f"[ORDER SUCCESS] Live order executed: {out} | session_id={session_id}")
                return jsonify({'status': 'accepted', 'order': out})
            except Exception as e:
                current_app.logger.error(f"[ORDER ERROR] Live order execution failed: {str(e)} | payload={data}", exc_info=True)
                return jsonify({'error': str(e)}), 400

        # PAPER via engine service
        svc = current_app.config.get('PORTFOLIO_SERVICE')
        current_app.logger.info(f"[ORDER EXECUTION] Portfolio service available: {svc is not None} | session_id={session_id}")
        if svc is not None:
            try:
                current_app.logger.info(f"[ORDER EXECUTION] Executing paper order via portfolio service | payload={data}")
                order = svc.place_order(symbol=symbol, side=side, quantity=qty, idem_key=idem_key)
                _ORDERS[order.get('idempotency_key') or order.get('order_id')] = order
                current_app.logger.info(f"[ORDER SUCCESS] Paper order executed: {order} | session_id={session_id}")
                return jsonify({'status': 'filled', 'order': order})
            except Exception as e:
                current_app.logger.error(f"[ORDER ERROR] Portfolio service order execution failed: {str(e)} | payload={data}", exc_info=True)
                return jsonify({'error': str(e)}), 400
        
        # Fallback legacy path
        current_app.logger.info(f"[ORDER EXECUTION] Using legacy order execution | payload={data}")
        price = float(_LAST_PRICE.get(symbol, 100.0))
        total_cost = price * qty
        fees = max(5.0, total_cost * 0.0005)
        total_cash = total_cost + fees
        current_app.logger.info(f"[ORDER CALC] price={price}, total_cost={total_cost}, fees={fees}, total_cash={total_cash}")
        if side == 'buy':
            if _PORTFOLIO['cash'] < total_cash:
                current_app.logger.error(f"[ORDER ERROR] Insufficient cash: available={_PORTFOLIO['cash']}, required={total_cash} | payload={data}")
                return jsonify({'error': 'insufficient cash'}), 400
            _PORTFOLIO['cash'] -= total_cash
            pos = _PORTFOLIO['positions'].get(symbol, {'qty': 0, 'avg_price': 0.0})
            new_qty = pos['qty'] + qty
            new_avg = (pos['avg_price'] * pos['qty'] + price * qty) / new_qty if new_qty else 0.0
            _PORTFOLIO['positions'][symbol] = {'qty': new_qty, 'avg_price': new_avg}
        else:
            pos = _PORTFOLIO['positions'].get(symbol, {'qty': 0, 'avg_price': 0.0})
            if pos['qty'] < qty:
                current_app.logger.error(f"[ORDER ERROR] Insufficient quantity: available={pos['qty']}, required={qty} | payload={data}")
                return jsonify({'error': 'insufficient quantity'}), 400
            pos['qty'] -= qty
            _PORTFOLIO['cash'] += price * qty - fees
            if pos['qty'] == 0:
                _PORTFOLIO['positions'].pop(symbol, None)
            else:
                _PORTFOLIO['positions'][symbol] = pos
        order_id = _next_order_id()
        order = {'order_id': order_id, 'symbol': symbol, 'side': side, 'quantity': qty, 'price': price, 'status': 'filled', 'timestamp': datetime.utcnow().isoformat()}
        _ORDERS[idem_key or order_id] = order
        if callable(save_state):
            try:
                unique_orders = []
                seen_ids = set()
                for v in _ORDERS.values():
                    oid = v.get('order_id') if isinstance(v, dict) else None
                    if oid and oid not in seen_ids:
                        unique_orders.append(v)
                        seen_ids.add(oid)
                save_state(_PORTFOLIO, unique_orders, _ORDER_SEQ)
            except Exception as e:
                current_app.logger.error(f"[ORDER ERROR] Failed to save state: {str(e)} | payload={data}")
        current_app.logger.info(f"[ORDER SUCCESS] Legacy order executed: {order} | session_id={session_id}")
        return jsonify({'status': 'filled', 'order': order})
    except Exception as e:
        current_app.logger.error(f"[ORDER ERROR] Unexpected error in order submission: {str(e)} | payload={request.get_json(force=True)}", exc_info=True)
        return jsonify({'error': f'Internal server error: {str(e)}'}), 500


@orders_bp.route('/orders/live', methods=['GET'])
def list_orders_live():
    exec_mode = str(current_app.config.get('EXECUTION_MODE', 'PAPER')).upper()
    trading_adapter = current_app.config.get('TRADING_ADAPTER')
    if exec_mode != 'SHOONYA' or trading_adapter is None:
        return jsonify({'error': 'live trading not enabled'}), 400
    try:
        raw = trading_adapter.list_orders()
        if isinstance(raw, list):
            return jsonify([_normalize_live_order(trading_adapter, r) if isinstance(r, dict) else r for r in raw])
        return jsonify([])
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@orders_bp.route('/cancel', methods=['POST'])
def cancel_live_order():
    exec_mode = str(current_app.config.get('EXECUTION_MODE', 'PAPER')).upper()
    trading_adapter = current_app.config.get('TRADING_ADAPTER')
    data = request.get_json(force=True) or {}
    order_id = str(data.get('order_id', '')).strip()
    if not order_id:
        return jsonify({'error': 'order_id required'}), 400
    if exec_mode != 'SHOONYA' or trading_adapter is None:
        return jsonify({'error': 'live trading not enabled'}), 400
    try:
        res = trading_adapter.cancel_order(order_id)
        # Best-effort normalization
        raw = res.get('raw') if isinstance(res, dict) else None
        out = _normalize_live_order(trading_adapter, raw) if isinstance(raw, dict) else res
        return jsonify({'status': 'cancelled', 'order': out})
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@orders_bp.route('/orders', methods=['GET'])
def list_orders():
    svc = current_app.config.get('PORTFOLIO_SERVICE')
    if svc is not None:
        try:
            return jsonify(svc.engine.orders())
        except Exception:
            pass
    return jsonify(list(_ORDERS.values()))
