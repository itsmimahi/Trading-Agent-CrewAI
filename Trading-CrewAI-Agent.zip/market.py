from flask import Blueprint, jsonify, request, current_app
import requests
from datetime import datetime

market_bp = Blueprint('market', __name__)

# Minimal in-memory cache for last prices
_LAST_PRICE = {}

# Default realistic prices for Indian market indices and popular stocks
_DEFAULT_PRICES = {
    'NIFTY50': 19800.0,
    'NIFTY': 19800.0,
    'SENSEX': 66500.0,
    'BANKNIFTY': 44200.0,
    'RELIANCE.NS': 2850.0,
    'TCS.NS': 3580.0,
    'INFY.NS': 1720.0,
    'HDFCBANK.NS': 1580.0,
    'ICICIBANK.NS': 1150.0,
    'ITC.NS': 460.0,
    'SBIN.NS': 820.0,
    'BHARTIARTL.NS': 1520.0,
    'ASIANPAINT.NS': 3200.0,
    'MARUTI.NS': 11200.0
}

def _fetch_yahoo_price(symbol: str) -> float:
    """Fetch price from Yahoo Finance as fallback"""
    try:
        # Convert Indian symbols for Yahoo Finance
        yahoo_symbol = symbol
        if '.NS' not in symbol and symbol in ['NIFTY50', 'NIFTY']:
            yahoo_symbol = '^NSEI'
        elif '.NS' not in symbol and symbol == 'SENSEX':
            yahoo_symbol = '^BSESN'
        elif '.NS' not in symbol and symbol == 'BANKNIFTY':
            yahoo_symbol = '^NSEBANK'
        
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{yahoo_symbol}"
        response = requests.get(url, timeout=5)
        data = response.json()
        
        if 'chart' in data and 'result' in data['chart'] and data['chart']['result']:
            result = data['chart']['result'][0]
            if 'meta' in result and 'regularMarketPrice' in result['meta']:
                return float(result['meta']['regularMarketPrice'])
    except Exception:
        pass
    return None

@market_bp.route('/last_price/<symbol>', methods=['GET'])
def last_price(symbol: str):
    symbol = symbol.upper()
    price = _LAST_PRICE.get(symbol)
    source = "cache"
    
    if price is None:
        # Try adapter polling if configured
        try:
            adapter = current_app.config.get('MARKET_ADAPTER')
            if adapter is not None:
                current_app.logger.info(f"Attempting to fetch {symbol} price from market adapter")
                polled = adapter.poll_price(symbol)
                if polled is not None:
                    price = float(polled)
                    _LAST_PRICE[symbol] = price
                    source = "adapter"
                    current_app.logger.info(f"Got {symbol} price from adapter: {price}")
        except Exception as e:
            current_app.logger.warning(f"Adapter price fetch failed for {symbol}: {e}")
    
    if price is None:
        # Try Yahoo Finance as fallback
        try:
            current_app.logger.info(f"Attempting to fetch {symbol} price from Yahoo Finance")
            yahoo_price = _fetch_yahoo_price(symbol)
            if yahoo_price is not None:
                price = yahoo_price
                _LAST_PRICE[symbol] = price
                source = "yahoo"
                current_app.logger.info(f"Got {symbol} price from Yahoo Finance: {price}")
        except Exception as e:
            current_app.logger.warning(f"Yahoo Finance price fetch failed for {symbol}: {e}")
    
    if price is None:
        # Use realistic default prices
        price = _DEFAULT_PRICES.get(symbol, 100.0)
        _LAST_PRICE[symbol] = price
        source = "default"
        current_app.logger.info(f"Using default price for {symbol}: {price}")
    
    return jsonify({
        'symbol': symbol,
        'last_price': price,
        'source': source,
        'timestamp': datetime.now().isoformat()
    })

@market_bp.route('/update_price', methods=['POST'])
def update_price():
    data = request.get_json(force=True) or {}
    symbol = str(data.get('symbol', '')).upper()
    price = data.get('price')
    if not symbol or price is None:
        return jsonify({'error': 'symbol and price required'}), 400
    try:
        price = float(price)
    except Exception:
        return jsonify({'error': 'invalid price'}), 400
    _LAST_PRICE[symbol] = price
    return jsonify({'status': 'ok', 'symbol': symbol, 'last_price': price})
