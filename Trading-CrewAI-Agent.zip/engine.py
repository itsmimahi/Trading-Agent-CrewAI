from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timezone

from ..storage.paper_state import load_state, save_state


@dataclass
class FeeModel:
    brokerage_min: float = 5.0            # INR
    brokerage_bps: float = 0.0005         # 0.05%
    slippage_bps: float = 0.0002          # 0.02%

    def fees(self, notional: float) -> float:
        return max(self.brokerage_min, notional * self.brokerage_bps)

    def apply_slippage(self, side: str, price: float) -> float:
        # BUY pays up, SELL receives less
        slip = price * self.slippage_bps
        return price + slip if side.lower() == 'buy' else price - slip


class PortfolioEngine:
    """Stateful portfolio engine backed by paper_state storage."""

    def __init__(self, fee_model: Optional[FeeModel] = None) -> None:
        self.fees = fee_model or FeeModel()
        self._portfolio, meta = load_state()
        self._orders: List[Dict[str, Any]] = list(meta.get('orders', []))
        self._order_seq: int = int(meta.get('order_seq', 1))

    # ---------- helpers ----------
    def _next_order_id(self) -> str:
        oid = f"PTA-{self._order_seq:06d}"
        self._order_seq += 1
        return oid

    def _persist(self) -> None:
        save_state(self._portfolio, self._orders, self._order_seq)

    # ---------- queries ----------
    def holdings(self) -> Tuple[float, Dict[str, Dict[str, float]]]:
        cash = float(self._portfolio.get('cash', 0.0))
        positions = dict(self._portfolio.get('positions', {}))
        return cash, positions

    def orders(self) -> List[Dict[str, Any]]:
        return list(self._orders)

    def margins(self) -> Dict[str, float]:
        cash, _ = self.holdings()
        return {'available': cash, 'used': 0.0, 'net': cash}

    def metrics(self, get_last_price: Optional[callable] = None) -> Dict[str, Any]:
        cash, positions = self.holdings()
        total_cost_basis = 0.0
        unrealized = 0.0
        total_pos_val = 0.0
        for sym, pos in positions.items():
            qty = int(pos.get('qty', 0))
            avg = float(pos.get('avg_price', 0.0))
            total_cost_basis += qty * avg
            lp = None
            if get_last_price:
                try:
                    lp = get_last_price(sym)
                except Exception:
                    lp = None
            lp = float(lp) if lp is not None else avg
            total_pos_val += qty * lp
            unrealized += qty * (lp - avg)
        total_value = cash + total_pos_val
        return {
            'cash': round(cash, 2),
            'positions_count': len(positions),
            'cost_basis': round(total_cost_basis, 2),
            'unrealized_pnl': round(unrealized, 2),
            'total_value_est': round(total_value, 2),
            'as_of': datetime.now(timezone.utc).isoformat(),
        }

    # ---------- trading ----------
    def preview(self, symbol: str, side: str, quantity: int, last_price: float) -> Dict[str, Any]:
        side = side.lower()
        px_exec = self.fees.apply_slippage(side, float(last_price))
        notional = px_exec * quantity
        fees = self.fees.fees(notional)
        return {
            'symbol': symbol.upper(),
            'side': side,
            'quantity': quantity,
            'price': round(px_exec, 2),
            'estimated_value': round(notional, 2),
            'estimated_fees': round(fees, 2),
            'estimated_total': round(notional + fees, 2),
        }

    def place_order(self, *, symbol: str, side: str, quantity: int, last_price: float, idem_key: Optional[str] = None) -> Dict[str, Any]:
        side = side.lower()
        symbol = symbol.upper()
        px_exec = self.fees.apply_slippage(side, float(last_price))
        notional = px_exec * quantity
        fees = self.fees.fees(notional)

        cash = float(self._portfolio.get('cash', 0.0))
        positions = self._portfolio.setdefault('positions', {})
        pos = positions.get(symbol, {'qty': 0, 'avg_price': 0.0})

        if side == 'buy':
            total_cash = notional + fees
            if cash < total_cash:
                raise ValueError('insufficient cash')
            cash -= total_cash
            new_qty = int(pos['qty']) + quantity
            new_avg = ((float(pos['avg_price']) * int(pos['qty'])) + px_exec * quantity) / new_qty if new_qty else 0.0
            positions[symbol] = {'qty': new_qty, 'avg_price': new_avg}
        else:  # sell
            if int(pos.get('qty', 0)) < quantity:
                raise ValueError('insufficient quantity')
            pos_qty = int(pos['qty']) - quantity
            cash += (notional - fees)
            if pos_qty == 0:
                positions.pop(symbol, None)
            else:
                positions[symbol] = {'qty': pos_qty, 'avg_price': float(pos['avg_price'])}

        self._portfolio['cash'] = cash

        oid = idem_key or self._next_order_id()
        order = {
            'order_id': oid if idem_key else oid,
            'symbol': symbol,
            'side': side,
            'quantity': quantity,
            'price': round(px_exec, 2),
            'fees': round(fees, 2),
            'idempotency_key': idem_key,
            'status': 'filled',
            'timestamp': datetime.utcnow().isoformat(),
        }
        # store with canonical order_id regardless of idem key used
        self._orders.append(order)
        self._persist()
        return order
