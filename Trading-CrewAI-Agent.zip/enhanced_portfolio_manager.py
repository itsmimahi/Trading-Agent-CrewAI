"""
Enhanced Portfolio Manager Agent using CrewAI Framework - Hybrid Plus Approach
Combines quantitative portfolio optimization with LLM reasoning for intelligent portfolio management.
"""



import warnings
warnings.filterwarnings("ignore")

import asyncio
import json
import logging
import os
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from pypfopt import EfficientFrontier, risk_models, expected_returns
import riskfolio as rp
from dataclasses import dataclass

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from config.settings import get_settings
from crewai import Task, Crew, Process
# Import MarketDataCollector from the data.collectors package
from data.collectors.market_data import MarketDataCollector
from integration.event_bus import make_default_event_bus
from .universal_portfolio_manager import get_portfolio_manager

@dataclass
class PortfolioMetrics:
    """Portfolio metrics structure"""
    total_value: float
    total_return: float
    volatility: float
    sharpe_ratio: float
    max_drawdown: float
    beta: float
    alpha: float
    var_95: float
    expected_return: float
    risk_score: float

@dataclass
class AssetAllocation:
    """Asset allocation structure"""
    symbol: str
    weight: float
    target_weight: float
    current_value: float
    expected_return: float
    volatility: float
    contribution_to_risk: float

class EnhancedPortfolioManager(EnhancedBaseAgent):
    # Shared MarketDataCollector instance
    _market_data_collector: Optional[MarketDataCollector] = None

    @classmethod
    def get_market_data_collector(cls):
        if cls._market_data_collector is None:
            cls._market_data_collector = MarketDataCollector()
        return cls._market_data_collector
    """
    Enhanced Portfolio Manager Agent using CrewAI Framework with Hybrid Plus approach.
    Combines quantitative portfolio optimization with LLM reasoning for intelligent portfolio management.
    """
    
    memory = None

    async def _store_analysis_in_memory(self, analysis: dict):
        """Async stub for compatibility. Optionally store analysis in memory."""
        # Implement actual memory storage if needed
        return None


    async def analyze(self, portfolio: dict, market_data: dict = None) -> dict:
        """
        Main analysis method for the portfolio manager agent.
        """
        # Example: perform portfolio analysis and return summary
        # This could call optimize_portfolio or another main method
        return await self.optimize_portfolio(
            symbols=list(portfolio.keys()),
            investment_amount=sum(asset['current_value'] for asset in portfolio.values()),
            current_portfolio=portfolio
        )

    async def mathematical_analysis(self, portfolio: dict, market_data: dict = None) -> dict:
        """
        Perform mathematical/quantitative analysis for the portfolio.
        """
        # Example: calculate portfolio metrics (returns, volatility, Sharpe, etc.)
        return await self._calculate_portfolio_metrics(portfolio, market_data=market_data)
    """
    Enhanced Portfolio Manager Agent with Hybrid Plus approach.
    Combines quantitative portfolio optimization with LLM reasoning for intelligent portfolio management.
    """
    
    def __init__(self, name: str = "EnhancedPortfolioManager", description: str = "Portfolio Manager Agent for advanced portfolio optimization and management", role: str = "Portfolio Management Specialist", goal: str = "Provide intelligent portfolio optimization combining quantitative methods with strategic insights", backstory: str = "Expert portfolio manager with deep knowledge of modern portfolio theory and behavioral finance", capabilities: Optional[List[Any]] = None, **kwargs):
        super().__init__(name=name, description=description, role=role, goal=goal, backstory=backstory, capabilities=capabilities, **kwargs)
        
        # Initialize portfolio management client
        self.portfolio_manager = get_portfolio_manager(name)
        
        # Portfolio optimization parameters
        self.risk_free_rate = 0.02
        self.target_return = None
        self.max_volatility = None
        self.rebalance_threshold = 0.05
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.RISK_ASSESSMENT,
                AgentCapability.PATTERN_RECOGNITION,
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.CONTEXTUAL_REASONING
            ]
        
        super().__init__(name=name, description=description, capabilities=capabilities, role=role, goal=goal, backstory=backstory, **kwargs)

        self.settings = get_settings()
        self.risk_free_rate = 0.065  # 6.5% - Indian govt bond yield
        self.market_benchmark = '^NSEI'  # Nifty 50 as benchmark
        # Constraint knobs (env or settings)
        try:
            self.max_weight = float(os.environ.get('MAX_POSITION_SIZE', getattr(self.settings, 'MAX_POSITION_SIZE', 0.20)))
        except Exception:
            self.max_weight = 0.20
        try:
            self.cash_buffer_pct = float(os.environ.get('CASH_BUFFER_PCT', getattr(self.settings, 'CASH_BUFFER_PCT', 0.02)))
        except Exception:
            self.cash_buffer_pct = 0.02
        # Rebalancing knobs
        try:
            self.rebalance_band = float(os.environ.get('REBALANCE_BAND_PCT', getattr(self.settings, 'REBALANCE_BAND_PCT', 0.05)))
        except Exception:
            self.rebalance_band = 0.05
        try:
            self.min_trade_weight = float(os.environ.get('MIN_TRADE_WEIGHT_PCT', getattr(self.settings, 'MIN_TRADE_WEIGHT_PCT', 0.01)))
        except Exception:
            self.min_trade_weight = 0.01
        try:
            self.turnover_cap = float(os.environ.get('TURNOVER_CAP_PCT', getattr(self.settings, 'TURNOVER_CAP_PCT', 0.30)))
        except Exception:
            self.turnover_cap = 0.30
        try:
            self.tx_cost_bps = float(os.environ.get('TX_COST_BPS', getattr(self.settings, 'TX_COST_BPS', 5)))
        except Exception:
            self.tx_cost_bps = 5.0

        # Event bus for approvals (optional)
        try:
            self.event_bus = make_default_event_bus()
        except Exception as _:
            self.event_bus = None

        # Initialize specialized tools
        self._initialize_portfolio_tools()

        # Portfolio optimization prompt template
        self.portfolio_optimization_prompt = """
        You are an expert portfolio manager with access to comprehensive portfolio analytics and optimization data.
        
        Current Portfolio Analysis:
        {portfolio_analysis}
        
        Optimization Results:
        {optimization_results}
        
        Risk Assessment:
        {risk_assessment}
        
        Market Context:
        {market_context}
        
        Performance Analytics:
        {performance_analytics}
        
        Based on this quantitative analysis, provide:
        1. Portfolio Assessment - Overall portfolio health and positioning
        2. Optimization Recommendations - Specific rebalancing suggestions
        3. Risk Management Strategy - How to manage portfolio risks
        4. Strategic Allocation - Long-term asset allocation strategy
        5. Tactical Adjustments - Short-term positioning recommendations
        6. Performance Enhancement - Ways to improve risk-adjusted returns
        
        Consider:
        - Current market regime and cycle
        - Correlation changes and diversification
        - Liquidity and implementation constraints
        - Tax efficiency and transaction costs
        - Client risk tolerance and objectives
        - Behavioral biases and market sentiment
        
        Provide actionable portfolio management insights that combine quantitative rigor with strategic thinking.
        """

    def _initialize_portfolio_tools(self):
        """Initialize portfolio management specific tools"""
        tools = [
            AgentTool(
                name="optimize_portfolio",
                description="Optimize portfolio allocation using modern portfolio theory",
                function=self._optimize_portfolio,
                parameters={"objective": "max_sharpe", "constraints": ["long_only", "max_weight"]}
            ),
            AgentTool(
                name="calculate_portfolio_metrics",
                description="Calculate comprehensive portfolio performance metrics",
                function=self._calculate_portfolio_metrics,
                parameters={"include_risk_metrics": True, "benchmark_comparison": True}
            ),
            AgentTool(
                name="rebalancing_analysis",
                description="Analyze portfolio rebalancing needs and recommendations",
                function=self._analyze_rebalancing,
                parameters={"tolerance_bands": [0.05, 0.10], "transaction_costs": True}
            ),
            AgentTool(
                name="risk_budgeting",
                description="Analyze risk contribution and budgeting across assets",
                function=self._analyze_risk_budgeting,
                parameters={"component_var": True, "marginal_risk": True}
            ),
            AgentTool(
                name="scenario_analysis",
                description="Perform scenario analysis and stress testing",
                function=self._perform_scenario_analysis,
                parameters={"scenarios": ["bull_market", "bear_market", "high_volatility"]}
            )
        ]
        
        for tool in tools:
            self.tools.append(tool)

    def _perform_scenario_analysis(self, symbols: List[str], scenarios: List[str]) -> Dict[str, Any]:
        """Perform scenario analysis and stress testing for portfolio optimization"""
        try:
            results = {}
            for scenario in scenarios:
                if scenario == "bull_market":
                    # Simulate bullish market conditions
                    returns_adjustment = 0.15  # 15% up
                    volatility_adjustment = 0.8  # 20% lower volatility
                elif scenario == "bear_market":
                    # Simulate bearish market conditions
                    returns_adjustment = -0.20  # 20% down
                    volatility_adjustment = 1.5  # 50% higher volatility
                elif scenario == "high_volatility":
                    # Simulate high volatility conditions
                    returns_adjustment = 0
                    volatility_adjustment = 2.0  # Double volatility
                else:
                    continue
                
                # Calculate scenario metrics
                scenario_results = {
                    "expected_return": returns_adjustment,
                    "volatility_multiplier": volatility_adjustment,
                    "risk_metrics": {
                        "var_95": self._calculate_var(symbols, confidence=0.95, adjustment=volatility_adjustment),
                        "max_drawdown": self._estimate_max_drawdown(volatility_adjustment),
                    },
                    "stress_test": {
                        "portfolio_impact": returns_adjustment * 100,  # as percentage
                        "risk_tolerance_breach": abs(returns_adjustment) > 0.25,
                    }
                }
                
                results[scenario] = scenario_results
            
            return {
                "scenario_analysis": results,
                "summary": {
                    "worst_case_return": min(r["expected_return"] for r in results.values()),
                    "highest_volatility": max(r["volatility_multiplier"] for r in results.values()),
                    "risk_breaches": sum(1 for r in results.values() if r["stress_test"]["risk_tolerance_breach"])
                },
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in scenario analysis: {e}")
            return {
                "error": str(e),
                "scenario_analysis": {},
                "summary": {"error": "Analysis failed"}
            }
    
    def _calculate_var(self, symbols: List[str], confidence: float = 0.95, adjustment: float = 1.0) -> float:
        """Calculate Value at Risk with adjustments for scenario analysis"""
        try:
            # Simplified VaR calculation for demonstration
            # In production, use actual historical data and proper VaR calculation
            base_var = 0.1  # 10% base VaR
            return base_var * adjustment
        except Exception:
            return 0.15  # Default to 15% VaR if calculation fails
    
    def _estimate_max_drawdown(self, volatility_multiplier: float) -> float:
        """Estimate maximum drawdown under different volatility conditions"""
        try:
            # Simplified estimation
            base_drawdown = 0.2  # 20% base max drawdown
            return base_drawdown * volatility_multiplier
        except Exception:
            return 0.25  # Default to 25% max drawdown if estimation fails

    async def optimize_portfolio(self, 
                               symbols: List[str], 
                               investment_amount: float,
                               risk_tolerance: str = "moderate", 
                               investment_horizon: str = "long_term",
                               current_portfolio: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Optimize portfolio allocation using CrewAI Hybrid Plus approach.
        
        Args:
            symbols: List of stock symbols to include
            investment_amount: Total amount to invest
            risk_tolerance: 'conservative', 'moderate', 'aggressive'
            investment_horizon: 'short_term', 'medium_term', 'long_term'
            current_portfolio: Optional current portfolio holdings
            
        Returns:
            Dict containing comprehensive portfolio optimization results
        """
        try:
            if not symbols:
                return self._get_default_optimization_result([], investment_amount)
                
            self.logger.info(f"Starting CrewAI enhanced portfolio optimization for {len(symbols)} symbols")
            
            # Step 1: Quantitative Portfolio Analysis
            portfolio_analysis = await self._analyze_portfolio_universe(symbols)
            self.logger.info(f"portfolio_analysis type: {type(portfolio_analysis)}, value: {repr(portfolio_analysis)[:300]}")
            if portfolio_analysis is None:
                self.logger.error("_analyze_portfolio_universe returned None")
                return self._get_default_optimization_result(symbols, investment_amount)
            if not portfolio_analysis.get('assets'):
                self.logger.warning("No valid portfolio analysis data available")
                return self._get_default_optimization_result(symbols, investment_amount)

            # Step 2: Mathematical Optimization
            returns_data = await self._get_returns_covariance_data(symbols)
            returns_df = returns_data.get("returns")
            if returns_df is None or returns_df.empty or len(returns_df.columns) < 2:
                self.logger.error("Not enough valid data for optimization after filling NaNs.")
                return self._get_default_optimization_result(symbols, investment_amount)
            # Always proceed with all columns in returns_df
            optimization_results = await self._perform_mathematical_optimization(
                list(returns_df.columns), investment_amount, risk_tolerance, investment_horizon
            )
            self.logger.info(f"optimization_results type: {type(optimization_results)}, value: {repr(optimization_results)[:300]}")
            if optimization_results is None:
                self.logger.error("_perform_mathematical_optimization returned None")
                return self._get_default_optimization_result(list(returns_df.columns), investment_amount)
            if not optimization_results:
                self.logger.warning("Mathematical optimization failed")
                return self._get_default_optimization_result(list(returns_df.columns), investment_amount)

            # Step 3: Risk Assessment
            risk_assessment = await self._assess_portfolio_risk(optimization_results)
            self.logger.info(f"risk_assessment type: {type(risk_assessment)}, value: {repr(risk_assessment)[:300]}")
            if risk_assessment is None:
                self.logger.error("_assess_portfolio_risk returned None")
                return self._get_default_optimization_result(symbols, investment_amount)

            # Step 4: Market Context Analysis
            market_context = await self._analyze_market_context_for_portfolio()
            self.logger.info(f"market_context type: {type(market_context)}, value: {repr(market_context)[:300]}")
            if market_context is None:
                self.logger.error("_analyze_market_context_for_portfolio returned None")
                return self._get_default_optimization_result(symbols, investment_amount)

            # Step 5: Performance Analytics
            performance_analytics = await self._analyze_expected_performance(optimization_results)
            self.logger.info(f"performance_analytics type: {type(performance_analytics)}, value: {repr(performance_analytics)[:300]}")
            if performance_analytics is None:
                self.logger.error("_analyze_expected_performance returned None")
                return self._get_default_optimization_result(symbols, investment_amount)

            # Step 6: CrewAI-based Portfolio Optimization
            crewai_analysis = await self._get_llm_portfolio_analysis(
                portfolio_analysis=portfolio_analysis,
                optimization_results=optimization_results,
                risk_assessment=risk_assessment,
                market_context=market_context,
                performance_analytics=performance_analytics
            )
            self.logger.info(f"crewai_analysis type: {type(crewai_analysis)}, value: {repr(crewai_analysis)[:300]}")
            if crewai_analysis is None:
                self.logger.error("_get_llm_portfolio_analysis returned None")
                return self._get_default_optimization_result(symbols, investment_amount)
            
            # Step 7: Combine quantitative and qualitative analysis
            final_allocation, allocation_audit = self._generate_final_allocation(optimization_results, crewai_analysis, current_portfolio)

            comprehensive_optimization = {
                "symbols": symbols,
                "investment_amount": investment_amount,
                "risk_tolerance": risk_tolerance,
                "investment_horizon": investment_horizon,
                "timestamp": datetime.now().isoformat(),
                "portfolio_analysis": portfolio_analysis,
                "optimization_results": optimization_results,
                "risk_assessment": risk_assessment,
                "market_context": market_context,
                "performance_analytics": performance_analytics,
                "crewai_analysis": crewai_analysis,
                "recommended_allocation": final_allocation,
                "allocation_audit": allocation_audit,
                "implementation_plan": self._create_implementation_plan(optimization_results, current_portfolio)
            }

            # Step 8: Request MAA approval for implementation plan if rebalancing is needed
            try:
                impl = comprehensive_optimization.get("implementation_plan") or {}
                if impl.get("rebalancing_needed"):
                    maa_approval = await self._request_maa_approval(
                        symbols=symbols,
                        investment_amount=investment_amount,
                        implementation_plan=impl,
                        allocation_audit=allocation_audit,
                        context={
                            "risk_assessment": risk_assessment,
                            "performance_analytics": performance_analytics,
                            "market_context": market_context,
                            "timestamp": datetime.now().isoformat(),
                        },
                    )
                else:
                    maa_approval = {"required": False, "approved": None, "reason": "No rebalancing required"}
            except Exception as e:
                self.logger.warning(f"MAA approval flow error: {e}")
                maa_approval = {"required": True, "approved": None, "error": str(e)}

            comprehensive_optimization["maa_approval"] = maa_approval
            
            # Store in memory for learning
            await self._store_analysis_in_memory(comprehensive_optimization)
            
            return comprehensive_optimization
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI portfolio optimization: {str(e)}")
            return self._get_default_optimization_result(symbols, investment_amount)

    async def _analyze_portfolio_universe(self, symbols: List[str]) -> Dict[str, Any]:
        """Analyze the universe of assets for portfolio construction"""
        try:
            analysis = {}

            # Get historical data for all symbols
            asset_data = {}
            for symbol in symbols:
                data = await self._get_historical_data(symbol, period="2y")
                if data is None:
                    self.logger.error(f"_get_historical_data returned None for symbol: {symbol}")
                elif data.empty:
                    self.logger.warning(f"_get_historical_data returned empty DataFrame for symbol: {symbol}")
                else:
                    returns = data['Close'].pct_change().dropna()
                    asset_data[symbol] = {
                        "returns": returns,
                        "volatility": returns.std() * np.sqrt(252),
                        "expected_return": returns.mean() * 252,
                        "skewness": returns.skew(),
                        "kurtosis": returns.kurtosis()
                    }
                    self.logger.info(f"Fetched and processed data for {symbol}: {len(returns)} return points")

            if not asset_data:
                self.logger.error("No valid asset data found for any symbol in portfolio universe.")

            # Calculate correlation matrix
            if len(asset_data) > 1:
                returns_df = pd.DataFrame({symbol: data["returns"] for symbol, data in asset_data.items()})
                correlation_matrix = returns_df.corr()
                
                analysis["correlation_matrix"] = correlation_matrix.to_dict()
                analysis["average_correlation"] = correlation_matrix.mean().mean()
                analysis["diversification_ratio"] = self._calculate_diversification_ratio(returns_df)
            
            # Individual asset analysis
            analysis["assets"] = {}
            for symbol, data in asset_data.items():
                analysis["assets"][symbol] = {
                    "expected_return": float(data["expected_return"]),
                    "volatility": float(data["volatility"]),
                    "sharpe_ratio": float(data["expected_return"] / data["volatility"]) if data["volatility"] > 0 else 0,
                    "skewness": float(data["skewness"]),
                    "kurtosis": float(data["kurtosis"])
                }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error analyzing portfolio universe: {str(e)}")
            return {}

    async def _get_returns_covariance_data(self, symbols: List[str]) -> Dict[str, Any]:
        """Get historical returns and covariance data for portfolio optimization"""
        try:
            # Get historical data for all symbols
            returns_dict = {}
            for symbol in symbols:
                data = await self._get_historical_data(symbol, period="1y")
                if data is not None and not data.empty:
                    returns_dict[symbol] = data['Close'].pct_change().dropna()

            if not returns_dict:
                self.logger.warning("No valid returns data found for any symbols")
                return {
                    "returns": pd.DataFrame(),
                    "covariance": pd.DataFrame(),
                    "expected_returns": {},
                    "valid_symbols": []
                }

            # Create returns DataFrame
            returns_df = pd.DataFrame(returns_dict)
            self.logger.info(f"Raw returns DataFrame before filling NaNs:\n{returns_df.head(10)}")
            # Fill missing values: forward fill, then backward fill, then zero
            returns_df = returns_df.ffill().bfill().fillna(0)
            self.logger.info(f"Returns DataFrame after filling NaNs:\n{returns_df.head(10)}")
            self.logger.info(f"Returns DataFrame shape after filling NaNs: {returns_df.shape}")
            self.logger.info(f"Returns DataFrame columns: {list(returns_df.columns)}")
            self.logger.info(f"Returns DataFrame summary:\n{returns_df.describe(include='all')}")
            if returns_df.empty or len(returns_df.columns) < 2:
                self.logger.error("Returns DataFrame is empty or has less than 2 columns after filling NaNs. Aborting optimization.")
                return {
                    "returns": pd.DataFrame(),
                    "covariance": pd.DataFrame(),
                    "expected_returns": {}
                }

            # Calculate expected returns and covariance
            expected_returns = returns_df.mean() * 252  # Annualized returns
            covariance_matrix = returns_df.cov() * 252  # Annualized covariance
            self.logger.info(f"Covariance matrix:\n{covariance_matrix}")
            return {
                "returns": returns_df,
                "covariance": covariance_matrix,
                "expected_returns": expected_returns.to_dict()
            }
            
        except Exception as e:
            self.logger.error(f"Error getting returns and covariance data: {str(e)}")
            return {
                "returns": pd.Series(),
                "covariance": pd.DataFrame(),
                "expected_returns": {},
                "valid_symbols": []
            }

    async def _perform_mathematical_optimization(self, 
                                               symbols: List[str], 
                                               investment_amount: float,
                                               risk_tolerance: str, 
                                               investment_horizon: str) -> Dict[str, Any]:
        """Perform portfolio optimization using PyPortfolioOpt and Riskfolio-Lib"""
        try:
            # Get expected returns and covariance matrix
            returns_data = await self._get_returns_covariance_data(symbols)
            returns_df = returns_data.get("returns")
            if returns_df is None or returns_df.empty or len(returns_df.columns) < 2:
                self.logger.error("Not enough valid data for optimization in _perform_mathematical_optimization.")
                return self._get_equal_weight_portfolio(symbols, investment_amount)
            # Use PyPortfolioOpt for max Sharpe ratio
            try:
                mu = expected_returns.mean_historical_return(returns_df)
                S = risk_models.sample_cov(returns_df)
                ef = EfficientFrontier(mu, S)
                weights = ef.max_sharpe()
                cleaned_weights = ef.clean_weights()
                # Enforce max weight and cash buffer
                # Clip weights and renormalize to (1 - cash_buffer_pct)
                clipped = {sym: max(0.0, min(float(w), self.max_weight)) for sym, w in cleaned_weights.items()}
                total = sum(clipped.values())
                scale = (1.0 - max(0.0, min(self.cash_buffer_pct, 0.5))) / total if total > 0 else 0.0
                adjusted = {sym: w * scale for sym, w in clipped.items()}
                allocation = {}
                for symbol, weight in adjusted.items():
                    if weight > 0.001:
                        allocation[symbol] = {
                            "weight": float(weight),
                            "amount": float(weight * investment_amount),
                            "expected_return": float(mu.get(symbol, 0.0)),
                            "contribution_to_return": float(weight * float(mu.get(symbol, 0.0)))
                        }
                perf = ef.portfolio_performance()
                return {
                    "optimization_successful": True,
                    "allocation": allocation,
                    "portfolio_metrics": {
                        "expected_return": float(perf[0]),
                        "volatility": float(perf[1]),
                        "sharpe_ratio": float(perf[2]),
                        "risk_tolerance": risk_tolerance,
                        "investment_horizon": investment_horizon
                    }
                }
            except Exception as e:
                self.logger.warning(f"PyPortfolioOpt failed: {e}, trying Riskfolio-Lib.")
                # Fallback to Riskfolio-Lib
                try:
                    port = rp.Portfolio(returns=returns_df)
                    model = 'Classic'
                    rm = 'MV'
                    obj = 'Sharpe'
                    hist = True
                    w_riskfolio = port.optimization(model=model, rm=rm, obj=obj, rf=0, l=0, hist=hist)
                    allocation = {}
                    for symbol in w_riskfolio.index:
                        weight = w_riskfolio.loc[symbol].values[0]
                        if weight > 0.01:
                            allocation[symbol] = {
                                "weight": float(weight),
                                "amount": float(weight * investment_amount),
                                # Riskfolio does not directly return expected return, so use mean
                                "expected_return": float(returns_df[symbol].mean() * 252),
                                "contribution_to_return": float(weight * returns_df[symbol].mean() * 252)
                            }
                    # Estimate portfolio metrics
                    port_return = sum(allocation[s]["contribution_to_return"] for s in allocation)
                    port_vol = float(np.sqrt(np.dot(w_riskfolio.values.T, np.dot(returns_df.cov().values * 252, w_riskfolio.values))))
                    port_sharpe = port_return / port_vol if port_vol > 0 else 0
                    return {
                        "optimization_successful": True,
                        "allocation": allocation,
                        "portfolio_metrics": {
                            "expected_return": float(port_return),
                            "volatility": float(port_vol),
                            "sharpe_ratio": float(port_sharpe),
                            "risk_tolerance": risk_tolerance,
                            "investment_horizon": investment_horizon
                        }
                    }
                except Exception as e2:
                    self.logger.error(f"Riskfolio-Lib optimization failed: {e2}")
                    return self._get_equal_weight_portfolio(symbols, investment_amount)
        except Exception as e:
            self.logger.error(f"Error in mathematical optimization: {str(e)}")
            return self._get_equal_weight_portfolio(symbols, investment_amount)

    async def _assess_portfolio_risk(self, optimization_results: Dict) -> Dict[str, Any]:
        """Assess portfolio risk characteristics"""
        try:
            if not optimization_results.get("optimization_successful", False):
                return {}
            
            allocation = optimization_results["allocation"]
            portfolio_metrics = optimization_results["portfolio_metrics"]
            
            # Risk concentration analysis
            weights = [data["weight"] for data in allocation.values()]
            hhi = sum(w**2 for w in weights)  # Herfindahl-Hirschman Index
            
            # Risk assessment
            risk_assessment = {
                "concentration_risk": float(hhi),
                "diversification_level": "HIGH" if hhi < 0.2 else "MODERATE" if hhi < 0.4 else "LOW",
                "volatility_level": self._classify_volatility(portfolio_metrics["volatility"]),
                "risk_score": self._calculate_portfolio_risk_score(portfolio_metrics),
                "major_risks": self._identify_major_risks(allocation)
            }
            
            return risk_assessment
            
        except Exception as e:
            self.logger.error(f"Error assessing portfolio risk: {str(e)}")
            return {}

    async def _analyze_market_context_for_portfolio(self) -> Dict[str, Any]:
        """Analyze market context relevant to portfolio construction"""
        try:
            # Get market data
            market_data = await self._get_historical_data(self.market_benchmark, period="1y")
            
            if market_data is None or market_data.empty:
                return {}
            
            # Calculate market metrics
            market_returns = market_data['Close'].pct_change().dropna()
            current_volatility = market_returns.rolling(30).std().iloc[-1] * np.sqrt(252)
            
            # Market regime analysis
            recent_performance = (market_data['Close'].iloc[-1] / market_data['Close'].iloc[-63] - 1) * 100
            
            context = {
                "market_volatility": float(current_volatility),
                "market_trend": "BULLISH" if recent_performance > 5 else "BEARISH" if recent_performance < -5 else "NEUTRAL",
                "volatility_regime": "HIGH" if current_volatility > 0.25 else "MODERATE" if current_volatility > 0.15 else "LOW",
                "market_phase": self._determine_market_phase(market_returns),
                "recommended_strategy": self._recommend_strategy_for_market(current_volatility, recent_performance)
            }
            
            return context
            
        except Exception as e:
            self.logger.error(f"Error analyzing market context: {str(e)}")
            return {}

    async def _analyze_expected_performance(self, optimization_results: Optional[Dict]) -> Dict[str, Any]:
        """Analyze expected portfolio performance"""
        if not optimization_results:
            return {
                "expected_return": 0.0,
                "volatility": 0.0,
                "sharpe_ratio": 0.0,
                "performance_rating": "UNKNOWN",
                "confidence_score": 0.0,
                "timestamp": datetime.now().isoformat()
            }
        try:
            if not optimization_results.get("optimization_successful", False):
                return {}
            
            metrics = optimization_results["portfolio_metrics"]
            
            # Performance projections
            annual_return = metrics["expected_return"]
            annual_volatility = metrics["volatility"]
            
            # Monte Carlo simulation (simplified)
            scenarios = self._generate_performance_scenarios(annual_return, annual_volatility)

            # Benchmark tracking error and info ratio (best-effort)
            te = None
            ir = None
            bench_corr = None
            try:
                allocation = optimization_results.get("allocation", {})
                te, ir, bench_corr = await self._compute_tracking_error_and_ir(allocation, period="1y")
            except Exception as e:
                self.logger.debug(f"TE/IR computation failed: {e}")
            # Publish benchmark metrics to performance collector via EventBus
            try:
                if self.event_bus and (te is not None or ir is not None or bench_corr is not None):
                    message = {
                        "type": "performance.benchmark_metrics.v1",
                        "timestamp": datetime.now().isoformat(),
                        "agent": "PortfolioManager",
                        "data": {
                            "tracking_error": float(te) if te is not None else None,
                            "information_ratio": float(ir) if ir is not None else None,
                            "benchmark_correlation": float(bench_corr) if bench_corr is not None else None,
                            "source": "PM",
                            "symbols": list((allocation or {}).keys()),
                        },
                    }
                    self.event_bus.publish("performance:benchmark_metrics", message)
            except Exception as e:
                self.logger.debug(f"Failed to publish benchmark metrics: {e}")
            
            analytics = {
                "expected_annual_return": float(annual_return),
                "expected_annual_volatility": float(annual_volatility),
                "probability_of_positive_return": float(scenarios["prob_positive"]),
                "expected_worst_case": float(scenarios["worst_case"]),
                "expected_best_case": float(scenarios["best_case"]),
                "value_at_risk_5": float(scenarios["var_5"]),
                "tracking_error": float(te) if te is not None else None,
                "information_ratio": float(ir) if ir is not None else None,
                "benchmark_correlation": float(bench_corr) if bench_corr is not None else None,
                "performance_rating": self._rate_expected_performance(annual_return, annual_volatility, metrics["sharpe_ratio"])
            }
            
            return analytics
            
        except Exception as e:
            self.logger.error(f"Error analyzing expected performance: {str(e)}")
            return {}

    async def _get_llm_portfolio_analysis(self, **kwargs) -> Dict[str, Any]:
        """Get CrewAI-based portfolio analysis and recommendations"""
        try:
            # Format the prompt with all the quantitative data
            portfolio_analysis_prompt = f"""
            You are an expert portfolio manager with access to comprehensive portfolio analytics and optimization data.
            
            Current Portfolio Analysis:
            {kwargs.get('portfolio_analysis', {})}
            
            Optimization Results:
            {kwargs.get('optimization_results', {})}
            
            Risk Assessment:
            {kwargs.get('risk_assessment', {})}
            
            Market Context:
            {kwargs.get('market_context', {})}
            
            Performance Analytics:
            {kwargs.get('performance_analytics', {})}
            
            Based on this quantitative analysis, provide:
            1. Portfolio Assessment - Overall portfolio health and positioning
            2. Optimization Recommendations - Specific rebalancing suggestions
            3. Risk Management Strategy - How to manage portfolio risks
            4. Strategic Allocation - Long-term asset allocation strategy
            5. Tactical Adjustments - Short-term positioning recommendations
            6. Performance Enhancement - Ways to improve risk-adjusted returns
            
            Consider:
            - Current market regime and cycle
            - Correlation changes and diversification
            - Liquidity and implementation constraints
            - Tax efficiency and transaction costs
            - Client risk tolerance and objectives
            - Behavioral biases and market sentiment
            
            Provide actionable portfolio management insights that combine quantitative rigor with strategic thinking.
            
                        IMPORTANT OUTPUT FORMAT:
                        - First, return a single JSON object only, no prose before it. Use this schema:
                            {{
                                "summary": string,
                                "recommendations": [
                                    {{"type": "set_target", "symbol": "TICKER", "target_weight": 0.0}},
                                    {{"type": "adjust_weight", "symbol": "TICKER", "delta_pct": -0.05}}
                                ],
                                "risk_notes": [string],
                                "tactical": [string]
                            }}
                        - If you cannot produce JSON, then provide your best plain-text analysis.
            """
            
            # Use CrewAI agent for analysis
            task = Task(
                description=portfolio_analysis_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive portfolio analysis with actionable insights"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            # Run blocking kickoff in a thread to avoid blocking the event loop
            result = await asyncio.to_thread(crew.kickoff)
            
            # Parse the response preferring JSON, fallback to section parser
            analysis = self._parse_llm_structured_response(str(result))
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI portfolio analysis: {str(e)}")
            return {"error": str(e)}

    def _parse_llm_portfolio_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response into structured portfolio analysis"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            # Split response into sections
            sections = response.split('\n\n')
            parsed_analysis = {
                "portfolio_assessment": "",
                "optimization_recommendations": [],
                "risk_management_strategy": "",
                "strategic_allocation": "",
                "tactical_adjustments": [],
                "performance_enhancement": []
            }
            current_section = None
            for section in sections:
                if "Portfolio Assessment" in section:
                    current_section = "portfolio_assessment"
                elif "Optimization Recommendations" in section:
                    current_section = "optimization_recommendations"
                elif "Risk Management Strategy" in section:
                    current_section = "risk_management_strategy"
                elif "Strategic Allocation" in section:
                    current_section = "strategic_allocation"
                elif "Tactical Adjustments" in section:
                    current_section = "tactical_adjustments"
                elif "Performance Enhancement" in section:
                    current_section = "performance_enhancement"
                elif current_section and section.strip():
                    if current_section in ["portfolio_assessment", "risk_management_strategy", "strategic_allocation"]:
                        parsed_analysis[current_section] = section.strip()
                    elif current_section in ["optimization_recommendations", "tactical_adjustments", "performance_enhancement"]:
                        parsed_analysis[current_section].append(section.strip())
            
            return parsed_analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing LLM response: {str(e)}")
            return {"raw_response": response}

    def _parse_crewai_portfolio_response(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI response into structured portfolio analysis"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Split response into sections
            sections = response.split('\n\n')
            parsed_analysis = {
                "portfolio_assessment": "",
                "optimization_recommendations": [],
                "risk_management_strategy": "",
                "strategic_allocation": "",
                "tactical_adjustments": [],
                "performance_enhancement": []
            }
            
            current_section = None
            for section in sections:
                if "Portfolio Assessment" in section:
                    current_section = "portfolio_assessment"
                elif "Optimization Recommendations" in section:
                    current_section = "optimization_recommendations"
                elif "Risk Management Strategy" in section:
                    current_section = "risk_management_strategy"
                elif "Strategic Allocation" in section:
                    current_section = "strategic_allocation"
                elif "Tactical Adjustments" in section:
                    current_section = "tactical_adjustments"
                elif "Performance Enhancement" in section:
                    current_section = "performance_enhancement"
                elif current_section and section.strip():
                    if current_section in ["portfolio_assessment", "risk_management_strategy", "strategic_allocation"]:
                        parsed_analysis[current_section] = section.strip()
                    elif current_section in ["optimization_recommendations", "tactical_adjustments", "performance_enhancement"]:
                        parsed_analysis[current_section].append(section.strip())
            
            return parsed_analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI response: {str(e)}")
            return {"raw_response": response}

    def _parse_llm_structured_response(self, response: str) -> Dict[str, Any]:
        """Try to parse JSON from LLM output; fallback to section parser.
        Expected JSON keys: summary:str, recommendations:list, risk_notes:list, tactical:list
        """
        try:
            text = response if isinstance(response, str) else str(response)
            # Attempt direct JSON parsing
            try:
                obj = json.loads(text)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                pass
            # Try to extract the first JSON object from the text
            start = text.find('{')
            end = text.rfind('}')
            if start != -1 and end != -1 and end > start:
                snippet = text[start:end+1]
                try:
                    obj = json.loads(snippet)
                    if isinstance(obj, dict):
                        return obj
                except Exception:
                    pass
            # Fallback to heuristic section parser
            return self._parse_crewai_portfolio_response(text)
        except Exception as e:
            self.logger.error(f"Error parsing structured LLM response: {e}")
            return self._parse_crewai_portfolio_response(str(response))

    def _generate_final_allocation(self, optimization_results: Dict, crewai_analysis: Dict, current_portfolio: Optional[Dict] = None) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Generate final recommended allocation combining quantitative and qualitative insights"""
        try:
            if not optimization_results.get("optimization_successful", False):
                return {}, {}
            
            base_allocation = optimization_results["allocation"]
            
            # Apply CrewAI insights to adjust allocation
            final_allocation = {k: v.copy() for k, v in base_allocation.items()}
            notional = sum(d["amount"] for d in base_allocation.values()) or 0.0
            base_weights = {s: d.get("weight", 0.0) for s, d in base_allocation.items()}

            # Prefer structured recommendations if available
            recs_struct = crewai_analysis.get("recommendations") if isinstance(crewai_analysis, dict) else None
            llm_weights: Dict[str, float] = {}
            if isinstance(recs_struct, list) and recs_struct:
                # Build current weights map
                current_w = {s: final_allocation[s]["weight"] for s in final_allocation}
                target_w = current_w.copy()
                for rec in recs_struct:
                    try:
                        rtype = str(rec.get("type", "")).lower()
                        sym = rec.get("symbol")
                        if not sym or sym not in target_w:
                            continue
                        if rtype == "set_target":
                            tw = float(rec.get("target_weight"))
                            if tw >= 0:
                                target_w[sym] = min(self.max_weight, tw)
                        elif rtype == "adjust_weight":
                            dp = float(rec.get("delta_pct"))  # e.g., 0.05 = +5%
                            target_w[sym] = min(self.max_weight, max(0.0, target_w[sym] * (1.0 + dp)))
                    except Exception:
                        continue
                # Normalize to 1 - cash buffer
                tot = sum(target_w.values())
                scale = (1.0 - max(0.0, min(self.cash_buffer_pct, 0.5))) / tot if tot > 0 else 0.0
                for s in final_allocation:
                    fw = target_w[s] * scale
                    final_allocation[s]["final_weight"] = fw
                    final_allocation[s]["final_amount"] = fw * notional
                    llm_weights[s] = fw
            else:
                # Fallback to heuristic text-based tweaks
                recommendations = crewai_analysis.get("optimization_recommendations", []) if isinstance(crewai_analysis, dict) else []
                for symbol, data in final_allocation.items():
                    adjustment_factor = 1.0
                    for rec in recommendations:
                        try:
                            rec_l = str(rec).lower()
                            if symbol.lower() in rec_l:
                                if "increase" in rec_l or "+" in rec_l:
                                    adjustment_factor *= 1.1
                                elif "decrease" in rec_l or "-" in rec_l:
                                    adjustment_factor *= 0.9
                        except Exception:
                            continue
                    data["final_weight"] = min(self.max_weight, max(0.0, data["weight"] * adjustment_factor))
                    data["final_amount"] = data["final_weight"] * notional
                    llm_weights[symbol] = data["final_weight"]
                # Normalize weights to sum to (1 - cash buffer)
                total_weight = sum(d.get("final_weight", 0.0) for d in final_allocation.values())
                scale = (1.0 - max(0.0, min(self.cash_buffer_pct, 0.5))) / total_weight if total_weight > 0 else 0.0
                for data in final_allocation.values():
                    data["final_weight"] *= scale
                    data["final_amount"] = data["final_weight"] * notional

            # Enforce turnover cap at allocation stage if current portfolio is provided
            audit: Dict[str, Any] = {
                "recommendations": recs_struct if isinstance(recs_struct, list) else [],
                "params": {
                    "max_weight": self.max_weight,
                    "cash_buffer_pct": self.cash_buffer_pct,
                    "turnover_cap": self.turnover_cap
                },
                "symbols": {}
            }

            if current_portfolio:
                # Build current weights from portfolio; use provided weight or derive from current_value
                cur_weights: Dict[str, float] = {}
                total_cv = 0.0
                for sym, info in current_portfolio.items():
                    w = info.get("weight")
                    if w is None:
                        try:
                            cv = float(info.get("current_value", 0.0))
                        except Exception:
                            cv = 0.0
                        total_cv += cv
                        cur_weights[sym] = cv  # temporarily store value; normalize later
                    else:
                        cur_weights[sym] = float(w)
                # If any are values, convert to weights
                if total_cv > 0:
                    for sym, v in list(cur_weights.items()):
                        if v > 0 and v <= total_cv:  # crude check: likely a value not a weight
                            cur_weights[sym] = v / total_cv
                # Normalize current weights to same budget as target
                target_budget = sum(d.get("final_weight", 0.0) for d in final_allocation.values())
                cur_sum = sum(cur_weights.values())
                if cur_sum > 0 and target_budget > 0:
                    scale_cur = target_budget / cur_sum
                    for sym in list(cur_weights.keys()):
                        cur_weights[sym] *= scale_cur
                # Union of symbols
                all_syms = set(cur_weights.keys()) | set(final_allocation.keys())
                # Collect target weights
                target_weights = {s: final_allocation.get(s, {}).get("final_weight", 0.0) for s in all_syms}
                # Pre-cap turnover and audit per symbol
                total_turnover_pre = 0.0
                for s in all_syms:
                    cw = float(cur_weights.get(s, 0.0))
                    tw = float(target_weights.get(s, 0.0))
                    total_turnover_pre += abs(tw - cw)
                    audit["symbols"][s] = {
                        "current_weight": cw,
                        "base_weight": float(base_weights.get(s, 0.0)),
                        "llm_weight": float(llm_weights.get(s, tw)),
                        "pre_cap_weight": tw,
                    }
                turnover_capped = False
                if total_turnover_pre > self.turnover_cap and total_turnover_pre > 0:
                    turnover_capped = True
                    factor = self.turnover_cap / total_turnover_pre
                    # Blend towards current weights
                    for s in all_syms:
                        cw = float(cur_weights.get(s, 0.0))
                        tw = float(target_weights.get(s, 0.0))
                        new_w = cw + (tw - cw) * factor
                        # Clip to constraints
                        new_w = max(0.0, min(self.max_weight, new_w))
                        target_weights[s] = new_w
                    # Renormalize to target budget
                    tsum = sum(target_weights.values())
                    renorm = (target_budget / tsum) if tsum > 0 else 0.0
                    for s in target_weights:
                        target_weights[s] *= renorm
                # Apply final weights back to allocation and finish audit
                for s in all_syms:
                    fw = float(target_weights.get(s, 0.0))
                    if s not in final_allocation:
                        final_allocation[s] = {
                            "weight": 0.0,
                            "amount": 0.0,
                            "expected_return": 0.0,
                            "contribution_to_return": 0.0
                        }
                    final_allocation[s]["final_weight"] = fw
                    final_allocation[s]["final_amount"] = fw * notional
                    cw = float(cur_weights.get(s, 0.0))
                    audit["symbols"][s]["final_weight"] = fw
                    audit["symbols"][s]["delta_from_current"] = fw - cw
                audit["total_turnover_pre_cap"] = float(total_turnover_pre)
                # Recompute final turnover
                audit["total_turnover_final"] = float(sum(abs(audit["symbols"][s]["final_weight"] - audit["symbols"][s]["current_weight"]) for s in all_syms))
                audit["turnover_capped"] = turnover_capped
            else:
                # No current portfolio; still record audit for transparency
                for s, d in final_allocation.items():
                    audit["symbols"][s] = {
                        "current_weight": None,
                        "base_weight": float(base_weights.get(s, 0.0)),
                        "llm_weight": float(llm_weights.get(s, d.get("final_weight", 0.0))),
                        "final_weight": float(d.get("final_weight", 0.0)),
                        "delta_from_current": None
                    }
                audit["total_turnover_pre_cap"] = None
                audit["total_turnover_final"] = None
                audit["turnover_capped"] = False

            # Emit audit log for explainability
            try:
                self.logger.info("PM Allocation Audit: " + json.dumps(audit))
            except Exception:
                pass

            return final_allocation, audit
            
        except Exception as e:
            self.logger.error(f"Error generating final allocation: {str(e)}")
            return optimization_results.get("allocation", {}), {}

    def _create_implementation_plan(self, optimization_results: Dict, current_portfolio: Optional[Dict]) -> Dict[str, Any]:
        """Create detailed implementation plan for portfolio changes"""
        try:
            if not optimization_results.get("optimization_successful", False):
                return {}
            
            target_allocation = optimization_results["allocation"]
            
            implementation_plan = {
                "rebalancing_needed": False,
                "transactions": [],
                "estimated_costs": 0.0,
                "implementation_priority": "LOW",
                "params": {
                    "rebalance_band": self.rebalance_band,
                    "turnover_cap": self.turnover_cap,
                    "tx_cost_bps": self.tx_cost_bps,
                    "min_trade_weight": self.min_trade_weight
                }
            }
            
            if current_portfolio:
                # Compare current vs target allocation
                for symbol, target_data in target_allocation.items():
                    current_weight = current_portfolio.get(symbol, {}).get("weight", 0)
                    target_weight = target_data["weight"]
                    
                    weight_diff = target_weight - current_weight
                    
                    if abs(weight_diff) >= self.min_trade_weight and abs(weight_diff) >= self.rebalance_band:
                        implementation_plan["rebalancing_needed"] = True
                        implementation_plan["transactions"].append({
                            "symbol": symbol,
                            "action": "BUY" if weight_diff > 0 else "SELL",
                            "weight_change": abs(weight_diff),
                            "amount_change": abs(weight_diff) * sum(d["amount"] for d in target_allocation.values())
                        })
                
                # Set implementation priority
                total_changes = sum(abs(t["weight_change"]) for t in implementation_plan["transactions"])
                if total_changes > 0.3:
                    implementation_plan["implementation_priority"] = "HIGH"
                elif total_changes > 0.15:
                    implementation_plan["implementation_priority"] = "MEDIUM"

                # Turnover cap handling (best-effort trim)
                if total_changes > self.turnover_cap and implementation_plan["transactions"]:
                    implementation_plan["turnover_capped"] = True
                    # Sort by largest deviations and keep until cap
                    txs = sorted(implementation_plan["transactions"], key=lambda x: x["weight_change"], reverse=True)
                    kept = []
                    acc = 0.0
                    for tx in txs:
                        if acc + tx["weight_change"] <= self.turnover_cap:
                            kept.append(tx)
                            acc += tx["weight_change"]
                    implementation_plan["transactions"] = kept
                    total_changes = acc
                
                # Estimate costs
                try:
                    notional = sum(d["amount"] for d in target_allocation.values())
                    bps = self.tx_cost_bps / 10000.0
                    implementation_plan["estimated_costs"] = float(total_changes * notional * bps)
                except Exception:
                    implementation_plan["estimated_costs"] = 0.0
            
            return implementation_plan
            
        except Exception as e:
            self.logger.error(f"Error creating implementation plan: {str(e)}")
            return {}

    async def _request_maa_approval(
        self,
        *,
        symbols: List[str],
        investment_amount: float,
        implementation_plan: Dict[str, Any],
        allocation_audit: Dict[str, Any],
        context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Send implementation plan to Main Advisory Agent (MAA) for approval via EventBus.
        Returns an approval decision payload.
        """
        try:
            if not self.event_bus:
                self.logger.info("No EventBus configured (REDIS_URL missing); skipping MAA approval request")
                return {"required": True, "approved": None, "status": "skipped_no_bus"}
            stream = os.environ.get("MAA_APPROVAL_STREAM", "maa.approval.request.v1")
            timeout_ms = int(os.environ.get("MAA_APPROVAL_TIMEOUT_MS", "15000"))
            payload = {
                "type": "portfolio.rebalance.plan.v1",
                "requested_by": self.name,
                "symbols": symbols,
                "investment_amount": investment_amount,
                "implementation_plan": implementation_plan,
                "allocation_audit": allocation_audit,
                "context": context,
                "timestamp": datetime.now().isoformat(),
            }
            # Use request-reply pattern
            try:
                resp = await self.event_bus.request(stream, payload, timeout_ms=timeout_ms)
                # Expected resp: { approved: bool, approver: str, reason: str, conditions: [...], correlation_id: ... }
                decision = {
                    "required": True,
                    "approved": bool(resp.get("approved")) if isinstance(resp, dict) else None,
                    "approver": resp.get("approver") if isinstance(resp, dict) else None,
                    "reason": resp.get("reason") if isinstance(resp, dict) else None,
                    "conditions": resp.get("conditions") if isinstance(resp, dict) else None,
                    "correlation_id": resp.get("correlation_id") if isinstance(resp, dict) else None,
                }
                self.logger.info(f"MAA approval decision: {decision}")
                return decision
            except TimeoutError as te:
                self.logger.warning(f"MAA approval request timed out: {te}")
                return {"required": True, "approved": None, "status": "timeout"}
        except Exception as e:
            self.logger.error(f"MAA approval request failed: {e}")
            return {"required": True, "approved": None, "error": str(e)}

    # Helper methods
    def _calculate_diversification_ratio(self, returns_df: pd.DataFrame) -> float:
        """Calculate diversification ratio"""
        try:
            individual_vol = returns_df.std().mean()
            portfolio_vol = returns_df.mean(axis=1).std()
            return individual_vol / portfolio_vol if portfolio_vol > 0 else 1.0
        except:
            return 1.0

    def _classify_volatility(self, volatility: float) -> str:
        """Classify volatility level"""
        if volatility > 0.3:
            return "HIGH"
        elif volatility > 0.2:
            return "MODERATE"
        else:
            return "LOW"

    def _calculate_portfolio_risk_score(self, metrics: Dict) -> float:
        """Calculate portfolio risk score (0-100)"""
        volatility = metrics.get("volatility", 0.2)
        sharpe_ratio = metrics.get("sharpe_ratio", 0.5)
        
        # Higher volatility = higher risk, lower Sharpe = higher risk
        risk_score = min(100, max(0, volatility * 300 - sharpe_ratio * 20))
        return risk_score

    def _identify_major_risks(self, allocation: Dict) -> List[str]:
        """Identify major portfolio risks"""
        risks = []
        
        # Concentration risk
        max_weight = max(data["weight"] for data in allocation.values())
        if max_weight > 0.3:
            risks.append("High concentration risk")
        
        # Sector concentration (simplified)
        if len(allocation) < 5:
            risks.append("Limited diversification")
        
        return risks

    def _determine_market_phase(self, returns: pd.Series) -> str:
        """Determine current market phase"""
        recent_trend = returns.tail(60).mean()
        volatility = returns.tail(60).std()
        
        if recent_trend > 0.001 and volatility < 0.02:
            return "BULL_MARKET"
        elif recent_trend < -0.001 and volatility > 0.02:
            return "BEAR_MARKET"
        else:
            return "SIDEWAYS_MARKET"

    def _recommend_strategy_for_market(self, volatility: float, performance: float) -> str:
        """Recommend strategy based on market conditions"""
        if volatility > 0.25:
            return "DEFENSIVE"
        elif performance > 10:
            return "MOMENTUM"
        else:
            return "BALANCED"

    def _generate_performance_scenarios(self, annual_return: float, annual_volatility: float) -> Dict[str, float]:
        """Generate performance scenarios using Monte Carlo simulation"""
        np.random.seed(42)  # For reproducibility
        
        # Simple Monte Carlo simulation
        scenarios = np.random.normal(annual_return, annual_volatility, 1000)
        
        return {
            "prob_positive": float(np.mean(scenarios > 0)),
            "worst_case": float(np.percentile(scenarios, 5)),
            "best_case": float(np.percentile(scenarios, 95)),
            "var_5": float(np.percentile(scenarios, 5))
        }

    def _rate_expected_performance(self, return_: float, volatility: float, sharpe: float) -> str:
        """Rate expected performance"""
        if sharpe > 1.5:
            return "EXCELLENT"
        elif sharpe > 1.0:
            return "GOOD"
        elif sharpe > 0.5:
            return "FAIR"
        else:
            return "POOR"

    async def _compute_tracking_error_and_ir(self, allocation: Dict[str, Dict[str, float]], period: str = "1y") -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """Compute tracking error, information ratio, and benchmark correlation for the current allocation.
        Returns (TE, IR, corr) annualized.
        """
        try:
            if not allocation:
                return None, None, None
            symbols = list(allocation.keys())
            # Build returns DataFrame for symbols
            returns_data: Dict[str, pd.Series] = {}
            for sym in symbols:
                df = await self._get_historical_data(sym, period=period)
                if df is not None and not df.empty:
                    returns_data[sym] = df['Close'].pct_change().dropna()
            if len(returns_data) < 2:
                return None, None, None
            returns_df = pd.DataFrame(returns_data).dropna(how='all')
            # Align benchmark returns
            bench_df = await self._get_historical_data(self.market_benchmark, period=period)
            if bench_df is None or bench_df.empty:
                return None, None, None
            bench_ret = bench_df['Close'].pct_change().dropna()
            # Align on common dates
            idx = returns_df.index.intersection(bench_ret.index)
            if len(idx) < 20:
                return None, None, None
            R = returns_df.loc[idx].fillna(0.0)
            b = bench_ret.loc[idx]
            # Build weight vector (use final_weight if present)
            weights = np.array([
                float(allocation[s].get('final_weight', allocation[s].get('weight', 0.0))) for s in R.columns
            ])
            if weights.sum() <= 0:
                return None, None, None
            # Normalize weights to 1 - cash buffer approx
            w = weights / weights.sum()
            port = np.dot(R.values, w)
            active = port - b.values
            te = float(np.std(active) * np.sqrt(252))
            ir = None
            try:
                ar = (np.mean(port) - np.mean(b.values)) * np.sqrt(252)
                ir = float(ar / te) if te > 0 else None
            except Exception:
                ir = None
            # Correlation
            try:
                corr = float(np.corrcoef(port, b.values)[0, 1])
            except Exception:
                corr = None
            return te, ir, corr
        except Exception as e:
            self.logger.debug(f"tracking error calc failed: {e}")
            return None, None, None

    # (Removed duplicate _get_returns_covariance_data; canonical version is defined earlier)

    async def _get_historical_data(self, symbol: str, period: str = "1y") -> Optional[pd.DataFrame]:
        """Get historical data for analysis using MarketDataCollector."""
        try:
            collector = self.get_market_data_collector()
            # get_stock_data returns a list of MarketData objects
            market_data_list = await collector.get_stock_data(symbol, period)
            if not market_data_list:
                self.logger.warning(f"No market data returned for {symbol} with period {period} from MarketDataCollector.")
                return None
            # Convert list of MarketData to DataFrame
            df = pd.DataFrame([
                {
                    'Date': md.timestamp,
                    'Open': md.open,
                    'High': md.high,
                    'Low': md.low,
                    'Close': md.close,
                    'Volume': md.volume,
                    'Adj Close': md.adj_close
                }
                for md in market_data_list
            ])
            if df.empty:
                self.logger.warning(f"Converted DataFrame is empty for {symbol}.")
                return None
            df.set_index('Date', inplace=True)
            self.logger.info(f"Fetched {df.shape[0]} rows of historical data for {symbol} from MarketDataCollector.")
            return df
        except Exception as e:
            self.logger.error(f"Error getting historical data for {symbol} from MarketDataCollector: {str(e)}")
            return None

    def _get_default_optimization_result(self, symbols: List[str], investment_amount: float) -> Dict[str, Any]:
        """Return default optimization result when optimization fails, with guards for empty inputs."""
        if not symbols:
            return {
                "symbols": [],
                "investment_amount": investment_amount,
                "timestamp": datetime.now().isoformat(),
                "error": "No symbols provided for optimization",
                "recommended_allocation": {}
            }
        equal_weight = 1.0 / max(1, len(symbols))
        return {
            "symbols": symbols,
            "investment_amount": investment_amount,
            "timestamp": datetime.now().isoformat(),
            "error": "Unable to perform optimization due to data limitations",
            "recommended_allocation": {
                symbol: {
                    "weight": equal_weight,
                    "amount": equal_weight * investment_amount
                } for symbol in symbols
            }
        }

    # Additional tool methods
    async def _optimize_portfolio(self, symbols: List[str], **kwargs) -> Dict[str, Any]:
        """Tool wrapper for portfolio optimization"""
        return await self._perform_mathematical_optimization(symbols, 100000, "moderate", "long_term")

    async def _calculate_portfolio_metrics(self, portfolio: Dict, **kwargs) -> Dict[str, Any]:
        """Calculate comprehensive portfolio metrics"""
        # Placeholder implementation
        return {
            "total_return": 0.12,
            "volatility": 0.18,
            "sharpe_ratio": 0.67,
            "max_drawdown": -0.15,
            "beta": 0.95,
            "alpha": 0.02
        }

    async def _analyze_rebalancing(self, current_portfolio: Dict, target_portfolio: Dict, **kwargs) -> Dict[str, Any]:
        """Analyze rebalancing needs"""
        return {
            "rebalancing_needed": True,
            "total_deviation": 0.12,
            "transactions_needed": 3,
            "estimated_costs": 0.005
        }

    async def _analyze_risk_budgeting(self, portfolio: Dict, **kwargs) -> Dict[str, Any]:
        """Analyze risk budgeting and contribution"""
        return {
            "risk_contributions": {},
            "concentration_risk": 0.25,
            "diversification_ratio": 0.8
        }

    def _get_equal_weight_portfolio(self, symbols: List[str], investment_amount: float) -> Dict[str, Any]:
        """Fallback to equal-weight portfolio with optimizer-compatible schema."""
        if not symbols:
            return {"optimization_successful": False, "allocation": {}, "portfolio_metrics": {}}
        num_symbols = len(symbols)
        weight_per_symbol = 1.0 / num_symbols
        allocation: Dict[str, Dict[str, float]] = {}
        for symbol in symbols:
            allocation[symbol] = {
                "weight": weight_per_symbol,
                "amount": weight_per_symbol * investment_amount,
                "expected_return": 0.10 / max(1, num_symbols),
                "contribution_to_return": weight_per_symbol * (0.10 / max(1, num_symbols))
            }
        expected_portfolio_return = 0.10
        expected_portfolio_risk = 0.15
        sharpe_ratio = expected_portfolio_return / expected_portfolio_risk if expected_portfolio_risk > 0 else 0.0
        return {
            "optimization_successful": True,
            "allocation": allocation,
            "portfolio_metrics": {
                "expected_return": expected_portfolio_return,
                "volatility": expected_portfolio_risk,
                "sharpe_ratio": sharpe_ratio,
                "risk_tolerance": "fallback",
                "investment_horizon": "fallback"
            }
        }

# # Export the enhanced portfolio manager
# enhanced_portfolio_manager = EnhancedPortfolioManager()

# async def _perform_scenario_analysis(self, portfolio: Dict, scenarios: List[str], **kwargs) -> Dict[str, Any]:
#     """Perform scenario analysis"""
#     return {
#         "bull_market": {"expected_return": 0.25, "probability": 0.3},
#         "bear_market": {"expected_return": -0.15, "probability": 0.2},
#         "normal_market": {"expected_return": 0.12, "probability": 0.5}
#     }
