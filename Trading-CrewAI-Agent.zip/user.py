"""
Database initialization for the Main Advisory Agent.
"""

try:
    from flask_sqlalchemy import SQLAlchemy
    # Initialize SQLAlchemy instance
    db = SQLAlchemy()
except ImportError:
    print("⚠️  Warning: flask_sqlalchemy not installed. Database functionality disabled.")
    # Create a mock db object for when SQLAlchemy is not available
    class MockDB:
        def init_app(self, app):
            pass
        def create_all(self):
            pass
    db = MockDB()
