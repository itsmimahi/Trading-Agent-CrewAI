import os
import threading
import time
from typing import Optional, Dict, Any

from .base import MarketDataAdapter

try:
    from kiteconnect import KiteConnect, KiteTicker  # type: ignore
except Exception:
    KiteConnect = None  # type: ignore
    KiteTicker = None  # type: ignore


class ZerodhaAdapter(MarketDataAdapter):
    name = "ZERODHA"

    def __init__(self) -> None:
        self.api_key = os.getenv("ZERODHA_API_KEY", "Z_API_KEY_PLACEHOLDER")
        self.api_secret = os.getenv("ZERODHA_API_SECRET", "Z_API_SECRET_PLACEHOLDER")
        self.access_token = os.getenv("ZERODHA_ACCESS_TOKEN", "Z_ACCESS_TOKEN_PLACEHOLDER")
        self.instruments_csv = os.getenv("ZERODHA_INSTRUMENTS_CSV")
        self._kite = None
        self._ticker = None
        self._ws_connected = False
        self._last_ticks: Dict[str, float] = {}
        self._lock = threading.Lock()
        self._token_map = {}
        self._desired_tokens = set()
        self._load_instruments()
        # Lazy client init
        if KiteConnect and self.api_key and self.access_token:
            try:
                kc = KiteConnect(api_key=self.api_key)
                kc.set_access_token(self.access_token)
                self._kite = kc
            except Exception:
                self._kite = None

    def info(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "ws": bool(self._ws_connected),
            "rest": bool(self._kite is not None),
        }

    # Map Yahoo symbol to Zerodha tradingsymbol or instrument token
    def _map_symbol(self, symbol: str) -> Dict[str, Any]:
        # Simplified mapping: RELIANCE.NS -> NSE:RELIANCE
        if symbol.endswith(".NS"):
            ts = symbol[:-3]
            return {"exchange": "NSE", "tradingsymbol": ts}
        # Fallback: assume NSE
        return {"exchange": "NSE", "tradingsymbol": symbol}

    def _load_instruments(self) -> None:
        path = self.instruments_csv
        if not path:
            return
        try:
            import csv
            with open(path, newline="", encoding="utf-8") as f:
                r = csv.DictReader(f)
                for row in r:
                    # Zerodha CSV columns typically include instrument_token, tradingsymbol, exchange
                    try:
                        if (row.get("exchange") == "NSE") and row.get("tradingsymbol") and row.get("instrument_token"):
                            ts = row["tradingsymbol"].strip().upper()
                            token = int(row["instrument_token"])  # type: ignore[arg-type]
                            self._token_map[ts] = token
                    except Exception:
                        continue
        except Exception:
            # Non-fatal
            pass

    def add_subscription_symbols(self, symbols: list[str]) -> list[str]:
        """Map Yahoo symbols to instrument tokens and add to desired subscription set.
        Returns list of symbols that were successfully mapped.
        """
        added: list[str] = []
        for s in symbols:
            try:
                m = self._map_symbol(s)
                ts = str(m["tradingsymbol"]).upper()
                if ts in self._token_map:
                    token = self._token_map[ts]
                    self._desired_tokens.add(token)
                    added.append(s)
            except Exception:
                continue
        # If WS already connected, attempt live subscribe
        try:
            if self._ws_connected and self._ticker and hasattr(self._ticker, 'subscribe'):
                tokens = list(self._desired_tokens)
                if tokens:
                    self._ticker.subscribe(tokens)
                    self._ticker.set_mode(self._ticker.MODE_LTP, tokens)
        except Exception:
            pass
        return added

    def poll_price(self, symbol: str) -> Optional[float]:
        # Prefer last WS tick if available
        with self._lock:
            if symbol in self._last_ticks:
                return self._last_ticks[symbol]
        if not self._kite:
            return None
        try:
            m = self._map_symbol(symbol)
            tradingsymbol = m["tradingsymbol"]
            exchange = m["exchange"]
            # ltp expects dictionary like {"NSE:RELIANCE": value}
            key = f"{exchange}:{tradingsymbol}"
            data = self._kite.ltp([key])  # type: ignore[attr-defined]
            if key in data and "last_price" in data[key]:
                return float(data[key]["last_price"])  # type: ignore[index]
        except Exception:
            return None
        return None

    def ws_connect(self) -> bool:
        if not (KiteTicker and self.api_key and self.access_token):
            self._ws_connected = False
            return False
        try:
            ticker = KiteTicker(self.api_key, self.access_token)
            self._ticker = ticker

            def on_ticks(ws, ticks):
                with self._lock:
                    for t in ticks or []:
                        # Zerodha ticks usually have instrument_token and last_price
                        lp = t.get("last_price")
                        tradingsymbol = t.get("tradingsymbol")
                        if lp and tradingsymbol:
                            # Store under Yahoo-like .NS if possible
                            sym = f"{tradingsymbol}.NS"
                            self._last_ticks[sym] = float(lp)

            def on_connect(ws, response):
                self._ws_connected = True
                # Subscribe to desired tokens if available
                try:
                    tokens = list(self._desired_tokens)
                    if tokens:
                        ws.subscribe(tokens)
                        ws.set_mode(ws.MODE_LTP, tokens)
                except Exception:
                    pass

            def on_close(ws, code, reason):
                self._ws_connected = False

            def on_error(ws, code, reason):
                self._ws_connected = False

            ticker.on_ticks = on_ticks
            ticker.on_connect = on_connect
            ticker.on_close = on_close
            ticker.on_error = on_error

            # Run in a thread so our API process stays responsive
            th = threading.Thread(target=lambda: self._safe_ws_run(ticker), daemon=True)
            th.start()
            return True
        except Exception:
            self._ws_connected = False
            return False

    def _safe_ws_run(self, ticker):
        try:
            ticker.connect(threaded=False)
        except Exception:
            self._ws_connected = False

    def close(self) -> None:
        try:
            if self._ticker:
                self._ticker.close()
        except Exception:
            pass
