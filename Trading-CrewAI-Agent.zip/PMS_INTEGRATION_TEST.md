# Portfolio Management System - Test Script

## Test the complete PMS integration with the launcher

**Test Steps:**

1. **Stop any running services**
```powershell
python launcher.py stop
```

2. **Start all services with the enhanced launcher**
```powershell
python launcher.py start
```

Expected output should show:
- PTA API on port 8090
- PTA WebSocket on port 8091  
- Portfolio settings (starting cash ₹50,000, fees, etc.)
- Event Bus status (Redis)

3. **Check health status**
```powershell
python launcher.py health
```

Should show all ports open including PTA WebSocket 8091.

4. **Test portfolio endpoints**
```powershell
# Portfolio holdings (should show ₹50,000 cash initially)
Invoke-RestMethod "http://localhost:8090/portfolio/holdings"

# Portfolio metrics (should show starting values)
Invoke-RestMethod "http://localhost:8090/portfolio/metrics"

# Set a stock price
Invoke-RestMethod -Method POST -Uri "http://localhost:8090/market/update_price" -ContentType 'application/json' -Body (@{ symbol='RELIANCE.NS'; price=2500 } | ConvertTo-Json)

# Preview an order (should show realistic fees)
Invoke-RestMethod -Method POST -Uri "http://localhost:8090/orders/preview" -ContentType 'application/json' -Body (@{ symbol='RELIANCE.NS'; side='buy'; quantity=10 } | ConvertTo-Json)

# Submit the order (should emit events if Redis is running)
Invoke-RestMethod -Method POST -Uri "http://localhost:8090/orders/submit" -ContentType 'application/json' -Body (@{ symbol='RELIANCE.NS'; side='buy'; quantity=10 } | ConvertTo-Json)

# Check updated holdings and metrics
Invoke-RestMethod "http://localhost:8090/portfolio/holdings"
Invoke-RestMethod "http://localhost:8090/portfolio/metrics"
```

5. **Test WebSocket (optional)**
```javascript
// In browser console or Node.js
const ws = new WebSocket('ws://localhost:8091');
ws.onopen = () => console.log('Connected to portfolio WebSocket');
ws.onmessage = (event) => console.log('Portfolio update:', JSON.parse(event.data));
// Should receive initial_state and then portfolio_update events
```

## Expected Results

**Initial Holdings:**
```json
{
  "cash": 50000.0,
  "holdings": []
}
```

**Order Preview (10 RELIANCE @ ₹2500):**
```json
{
  "symbol": "RELIANCE.NS",
  "side": "buy", 
  "quantity": 10,
  "price": 2500.5,  // with slippage
  "estimated_value": 25005.0,
  "estimated_fees": 12.5,  // max(₹5, 0.05% of ₹25005)
  "estimated_total": 25017.5
}
```

**After Order (Holdings):**
```json
{
  "cash": 24982.5,  // 50000 - 25017.5
  "holdings": [
    {
      "symbol": "RELIANCE.NS",
      "quantity": 10,
      "avg_price": 2500.5
    }
  ]
}
```

**Metrics with Unrealized P&L:**
```json
{
  "cash": 24982.5,
  "positions_count": 1,
  "cost_basis": 25005.0,
  "unrealized_pnl": -5.0,  // based on current vs avg price
  "total_value_est": 49977.5,
  "as_of": "2025-08-24T..."
}
```

## Troubleshooting

**If WebSocket doesn't start:**
- Check Redis is running: `docker ps | grep redis`
- Check REDIS_URL in environment: should be `redis://localhost:6379/0`

**If order fails:**
- Check PTA_SYMBOL_WHITELIST includes your symbol
- Check PTA_TRADING_WINDOW (default 09:15-15:30)
- Check PTA_MAX_ORDER_QTY limit

**If fees look wrong:**
- Check PTA_BROKERAGE_MIN (₹5), PTA_BROKERAGE_BPS (0.05%), PTA_SLIPPAGE_BPS (0.02%)

All environment variables are now properly configured in the enhanced launcher! 🎯
