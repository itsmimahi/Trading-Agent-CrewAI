"""
RL EventBus Worker
Consumes Redis Streams for RL-related A2A messages and replies.
Run this process when REDIS_URL is set to enable advisory↔RL communication without HTTP.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from typing import Any, Dict

# Ensure project root is on sys.path so we can import integration.event_bus
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

try:
    from integration.event_bus import RedisStreamsEventBus
except Exception as e:  # pragma: no cover
    raise RuntimeError(f"Cannot import EventBus. Ensure project root is on PYTHONPATH. Details: {e}")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
log = logging.getLogger("RLBusWorker")


class RLBusWorker:
    """Minimal RL worker that handles common RL integration messages over Redis Streams.
    NOTE: This worker provides basic functionality. Heavy tasks like full strategy
    simulation/backtesting remain exposed via the Flask API unless extended here.
    """

    def __init__(self, *, bus: RedisStreamsEventBus):
        self.bus = bus
        # In-memory state for demo purposes; replace with real storage/logic as needed
        self._feedback_log: list[Dict[str, Any]] = []
        self._regime_log: list[Dict[str, Any]] = []
        self._last_weight_update: Dict[str, Any] | None = None
        self._last_insights: Dict[str, Any] | None = None

    def start(self) -> None:
        # Streams are relative to prefix 'a2a:' inside EventBus
        # Requests to RL
        self.bus.start_consumer(
            stream="rl:performance_feedback",
            group="rl-worker-group",
            consumer_name=None,
            handler=self._handle_performance_feedback,
            concurrency=1,
        )
        self.bus.start_consumer(
            stream="rl:regime_change",
            group="rl-worker-group",
            consumer_name=None,
            handler=self._handle_regime_change,
            concurrency=1,
        )
        self.bus.start_consumer(
            stream="rl:get_weight_updates",
            group="rl-worker-group",
            consumer_name=None,
            handler=self._handle_get_weight_updates,
            concurrency=1,
        )
        self.bus.start_consumer(
            stream="rl:get_learning_insights",
            group="rl-worker-group",
            consumer_name=None,
            handler=self._handle_get_learning_insights,
            concurrency=1,
        )
        # Optional: placeholder for validation; currently replies with Not Implemented
        self.bus.start_consumer(
            stream="rl:validate_strategy",
            group="rl-worker-group",
            consumer_name=None,
            handler=self._handle_validate_strategy_placeholder,
            concurrency=1,
        )
        log.info("RLBusWorker started. Listening on a2a:rl:* streams")

    # Handlers
    def _handle_performance_feedback(self, msg: Dict[str, Any]):
        payload = msg.get("data") or msg
        self._feedback_log.append(payload)
        # You can process and update internal weight suggestions here
        reply_to = msg.get("reply_to")
        corr = msg.get("correlation_id")
        if reply_to:
            self.bus.publish(reply_to, {"ok": True, "received": True, "correlation_id": corr})

    def _handle_regime_change(self, msg: Dict[str, Any]):
        payload = msg.get("regime_data") or msg.get("data") or msg
        self._regime_log.append(payload)
        reply_to = msg.get("reply_to")
        corr = msg.get("correlation_id")
        if reply_to:
            self.bus.publish(reply_to, {"ok": True, "received": True, "correlation_id": corr})

    def _handle_get_weight_updates(self, msg: Dict[str, Any]):
        # Return last cached weight updates if any
        data = self._last_weight_update or {"has_updates": False}
        reply_to = msg.get("reply_to")
        corr = msg.get("correlation_id")
        if reply_to:
            self.bus.publish(reply_to, {**data, "correlation_id": corr})

    def _handle_get_learning_insights(self, msg: Dict[str, Any]):
        insights = self._last_insights or {
            "insights": {"note": "No insights yet"},
        }
        reply_to = msg.get("reply_to")
        corr = msg.get("correlation_id")
        if reply_to:
            self.bus.publish(reply_to, {**insights, "correlation_id": corr})

    def _handle_validate_strategy_placeholder(self, msg: Dict[str, Any]):
        # Placeholder: advise caller to use HTTP endpoint until implemented here
        reply_to = msg.get("reply_to")
        corr = msg.get("correlation_id")
        if reply_to:
            self.bus.publish(
                reply_to,
                {
                    "success": False,
                    "error": "validate_strategy not implemented in RLBusWorker; use HTTP RL API for now",
                    "correlation_id": corr,
                },
            )


async def main():
    # Create EventBus using REDIS_URL; will raise if not set/invalid
    bus = RedisStreamsEventBus()
    worker = RLBusWorker(bus=bus)
    worker.start()
    try:
        while True:
            await asyncio.sleep(60)
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        await bus.stop()


if __name__ == "__main__":
    asyncio.run(main())
