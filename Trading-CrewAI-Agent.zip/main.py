import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import logging
from logging.handlers import RotatingFileHandler

# Ensure UTF-8 for stdout/stderr and environment to avoid Windows encoding issues
try:
    os.environ.setdefault('PYTHONIOENCODING', 'utf-8')
    sys.stdout.reconfigure(encoding='utf-8')  # type: ignore[attr-defined]
    sys.stderr.reconfigure(encoding='utf-8')  # type: ignore[attr-defined]
except Exception:
    pass

class _AsciiSanitizer(logging.Filter):
    """Sanitize log records to be ASCII-safe for Windows consoles."""
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            if isinstance(record.msg, str):
                record.msg = record.msg.encode('ascii', errors='replace').decode('ascii')
            if record.args:
                safe_args = []
                for a in record.args:
                    if isinstance(a, str):
                        safe_args.append(a.encode('ascii', errors='replace').decode('ascii'))
                    else:
                        safe_args.append(a)
                record.args = tuple(safe_args)
        except Exception:
            pass
        return True

# ── Central logging setup + ASCII sanitizer for Windows consoles ───────────
try:
    from config.logging_config import setup_logging as _setup_logging  # noqa: E402
    _setup_logging()
except Exception:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)-8s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

# Attach ASCII sanitizer to all existing handlers so Windows consoles don't crash
try:
    _sanitizer = _AsciiSanitizer()
    for _h in logging.getLogger().handlers:
        _h.addFilter(_sanitizer)
except Exception:
    pass

from flask import Flask, send_from_directory
from flask_cors import CORS
from user import db
from user_routes import user_bp
from advisory import advisory_bp
from conversation_routes import conversation_bp
from approvals import approvals_bp, create_ui_approval
from agents.enhanced_risk_agent import EnhancedRiskAgent
from integration.event_bus import make_default_event_bus
import asyncio
import json
import threading

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app, origins="*")

app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(advisory_bp, url_prefix='/api/advisory')
app.register_blueprint(conversation_bp, url_prefix='/api/conversation')
app.register_blueprint(approvals_bp)

# Database configuration
database_dir = os.path.join(os.path.dirname(__file__), 'database')
os.makedirs(database_dir, exist_ok=True)  # Ensure database directory exists

app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(database_dir, 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

try:
    db.init_app(app)
    with app.app_context():
        db.create_all()
    # ASCII-only to avoid UnicodeEncodeError on Windows consoles
    print("Database initialized successfully")
except Exception as e:
    print(f"Database initialization failed: {e}")
    print("Continuing without database functionality")

# Health check endpoint for monitoring
@app.route('/health')
def health_check():
    """System health check endpoint"""
    return {
        'status': 'healthy',
        'service': 'main_advisory_agent',
        'port': 8000,
        'endpoints': {
            'user': '/api/user/',
            'advisory': '/api/advisory/',
            'conversation': '/api/conversation/'
        }
    }

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    # ASCII-only startup messages
    print("Starting Main Advisory Agent API...")
    print("API will be available at: http://localhost:8000")
    # Start Redis consumer for approval requests in background (if REDIS_URL provided)
    bus = None
    try:
        bus = make_default_event_bus()
    except Exception as e:
        logging.getLogger(__name__).warning(f"EventBus unavailable: {e}")

    if bus:
        stream_name = os.environ.get("MAA_APPROVAL_STREAM", "maa.approval.request.v1")
        group = os.environ.get("MAA_APPROVAL_GROUP", "maa")

        async def approval_handler(payload: dict):
            try:
                # Rich policy with risk, budget, and UI confirmations
                impl = payload.get("implementation_plan") or {}
                audit = payload.get("allocation_audit") or {}
                ctx = payload.get("context") or {}
                risk = ctx.get("risk_assessment") or {}
                perf = ctx.get("performance_analytics") or {}
                mkt = ctx.get("market_context") or {}

                # Inputs
                priority = str(impl.get("implementation_priority", "LOW")).upper()
                total_turnover = float(audit.get("total_turnover_final") or audit.get("total_turnover_pre_cap") or 0.0)
                params = impl.get("params") or {}
                cap = float(params.get("turnover_cap", 0.30))
                est_costs = float(impl.get("estimated_costs", 0.0) or 0.0)
                notional = float(payload.get("investment_amount", 0.0) or 0.0)
                cost_bps = (est_costs / notional * 10000.0) if notional > 0 else 0.0
                risk_score = float(risk.get("risk_score", 0.0) or 0.0)
                vol_level = str(risk.get("volatility_level", "")).upper() or str(mkt.get("volatility_regime", "")).upper()
                diversification = str(risk.get("diversification_level", "")).upper()
                te = perf.get("tracking_error")
                ir = perf.get("information_ratio")

                # Config knobs
                MAX_COST_BPS = float(os.environ.get("MAA_MAX_COST_BPS", "35"))
                SOFT_COST_BPS = float(os.environ.get("MAA_SOFT_COST_BPS", "15"))
                NEAR_CAP_FACTOR = float(os.environ.get("MAA_TURNOVER_NEAR_CAP_FACTOR", "0.90"))
                RISK_SCORE_MAX = float(os.environ.get("MAA_RISK_SCORE_MAX", "75"))
                REQUIRE_UI_FOR_HIGH_COST = os.environ.get("MAA_REQUIRE_UI_FOR_HIGH_COST", "1") in ("1", "true", "True")

                policies_applied = []
                required_signoffs = []
                decision = {
                    "approved": None,  # pending until finalized
                    "approver": "MAA-Policy",
                    "reason": "",
                    "conditions": [],
                    "policies_applied": policies_applied,
                    "required_signoffs": required_signoffs,
                    "correlation_id": payload.get("correlation_id"),
                }

                # Hard blocks
                if total_turnover and cap and total_turnover > cap * 1.20:
                    decision.update({"approved": False, "reason": f"Turnover {total_turnover:.2f} > 1.2x cap {cap:.2f}"})
                    policies_applied.append("hard_turnover_cap")
                if decision["approved"] is not False and cost_bps > MAX_COST_BPS:
                    decision.update({"approved": False, "reason": f"Costs {cost_bps:.1f} bps exceed max {MAX_COST_BPS:.1f} bps"})
                    policies_applied.append("hard_cost_cap")

                # Risk guardrails
                if decision["approved"] is not False and risk_score > RISK_SCORE_MAX:
                    policies_applied.append("risk_score_guardrail")
                    required_signoffs.append("RiskAgent")
                if decision["approved"] is not False and diversification == "LOW":
                    policies_applied.append("diversification_guardrail")
                    required_signoffs.append("RiskAgent")
                if decision["approved"] is not False and vol_level == "HIGH" and priority in ("LOW", "MEDIUM"):
                    policies_applied.append("high_vol_deferral")
                    decision.update({"approved": False, "reason": "High volatility; low/medium priority deferred"})

                # Budget windows (soft)
                if decision["approved"] is not False:
                    daily_budget_bps = float(os.environ.get("MAA_DAILY_BUDGET_BPS", "20"))
                    if cost_bps > daily_budget_bps and priority != "HIGH":
                        policies_applied.append("budget_window_soft")
                        decision.update({"approved": False, "reason": f"Costs {cost_bps:.1f} bps exceed daily budget {daily_budget_bps:.1f} bps"})

                # Tracking error/IR heuristics (soft)
                if decision["approved"] is not False and te is not None and te > float(os.environ.get("MAA_MAX_TE", "0.20")):
                    policies_applied.append("te_guardrail")
                    required_signoffs.append("RiskAgent")
                if decision["approved"] is not False and ir is not None and ir < float(os.environ.get("MAA_MIN_IR", "0.0")):
                    policies_applied.append("ir_guardrail")
                    required_signoffs.append("RiskAgent")

                # Near turnover cap -> require UI confirmation
                if decision["approved"] is not False and total_turnover and cap and total_turnover >= cap * NEAR_CAP_FACTOR:
                    policies_applied.append("near_turnover_cap")
                    required_signoffs.append("UI")
                # High cost but under hard cap -> UI
                if decision["approved"] is not False and REQUIRE_UI_FOR_HIGH_COST and cost_bps > SOFT_COST_BPS:
                    policies_applied.append("high_cost_ui")
                    required_signoffs.append("UI")

                # Risk Agent consult if required
                if decision["approved"] is not False and "RiskAgent" in required_signoffs:
                    try:
                        # Real risk evaluation using EnhancedRiskAgent across symbols
                        ra = EnhancedRiskAgent()
                        # Aggregate a composite risk view: take worst-case metrics across symbols in audit
                        worst_risk = {"risk_score": 0.0}
                        for sym in (audit.get("symbols") or {}).keys():
                            try:
                                r = await ra._calculate_comprehensive_risk_metrics(sym)
                                rs = float(r.get("risk_score", 0.0) or 0.0)
                                if rs > float(worst_risk.get("risk_score", 0.0)):
                                    worst_risk = r
                            except Exception:
                                continue
                        rs = float(worst_risk.get("risk_score", 0.0) or 0.0)
                        if rs > RISK_SCORE_MAX:
                            decision.update({"approved": False, "reason": f"RiskAgent: risk_score {rs:.1f} > {RISK_SCORE_MAX:.1f}"})
                            policies_applied.append("risk_agent_block")
                        else:
                            policies_applied.append("risk_agent_ok")
                    except Exception as e:
                        logging.getLogger(__name__).warning(f"Risk analysis failed: {e}")
                        decision.setdefault("status", "risk_unavailable")

                # UI confirmation if required
                if decision["approved"] is not False and "UI" in required_signoffs:
                    try:
                        ui = create_ui_approval(
                            summary=f"Rebalance {priority} with est {cost_bps:.1f} bps, turnover {total_turnover:.2f}/{cap:.2f}",
                            payload={
                                "implementation_plan": impl,
                                "allocation_audit": audit,
                            },
                            correlation_id=payload.get("correlation_id"),
                            reply_to=payload.get("reply_to"),
                        )
                        decision.setdefault("status", "ui_pending")
                        decision.setdefault("conditions", []).append(f"UI approval pending id={ui.get('id')}")
                        policies_applied.append("ui_pending")
                    except Exception as e:
                        logging.getLogger(__name__).warning(f"UI approval creation failed: {e}")
                        decision.setdefault("status", "ui_unavailable")

                # If no explicit block set, and no outstanding pending statuses, decide approve/deny
                if decision["approved"] is None:
                    if decision.get("status") in ("risk_pending", "ui_pending"):
                        decision["reason"] = "Pending external approval"
                    else:
                        # Default policy by priority and budgets
                        decision["approved"] = priority in ("HIGH",)
                        decision["reason"] = "Default approve for HIGH priority" if decision["approved"] else "Default defer"

                # Ensure conditions list consistent
                if "RiskAgent" in required_signoffs:
                    decision["conditions"].append("Risk Agent must sign-off")
                if "UI" in required_signoffs:
                    decision["conditions"].append("UI confirmation required")

                # Reply to caller's reply_to stream
                reply_to = payload.get("reply_to")
                if reply_to:
                    bus.publish(reply_to, decision)
            except Exception as e:
                logging.getLogger(__name__).exception(f"Approval handler failed: {e}")

        # Start approval consumer in background thread
        def run_bus_consumer():
            try:
                async def _main():
                    bus.start_consumer(
                        stream=stream_name,
                        group=group,
                        consumer_name=None,
                        handler=approval_handler,
                        auto_ack=True,
                        max_retries=3,
                        concurrency=1,
                        block_ms=5000,
                    )
                    logging.getLogger(__name__).info("MAA approval consumer started (Redis Streams)")
                    # Keep the loop alive
                    await asyncio.Event().wait()

                asyncio.run(_main())
            except Exception as e:
                logging.getLogger(__name__).exception(f"MAA bus consumer thread failed: {e}")

        t = threading.Thread(target=run_bus_consumer, name="maa-approval-consumer", daemon=True)
        t.start()

    # Run Flask app without debug/reloader
    app.run(host='0.0.0.0', port=8000, debug=False, threaded=True, use_reloader=False)
