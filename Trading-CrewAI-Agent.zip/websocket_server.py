"""
WebSocket endpoint for real-time portfolio updates.
Streams portfolio changes (orders, positions, valuation) to connected UI clients.
"""
import asyncio
import json
import logging
import os
import sys
import pathlib
from typing import Dict, Any, Set
from datetime import datetime

try:
    import websockets
    # Remove deprecated import
except Exception:
    websockets = None

# Fix import path for event_bus
try:
    from integration.event_bus import make_default_event_bus
except ImportError:
    # When run as a script, add project root to sys.path
    ROOT_DIR = pathlib.Path(__file__).resolve().parents[1]
    if str(ROOT_DIR) not in sys.path:
        sys.path.append(str(ROOT_DIR))
    try:
        from integration.event_bus import make_default_event_bus
    except ImportError:
        # If still failing, create a mock function
        def make_default_event_bus():
            return None
        make_default_event_bus = make_default_event_bus


class PortfolioWebSocketServer:
    def __init__(self, host: str = "localhost", port: int = 8091):
        self.host = host
        self.port = port
        self.clients: Set[Any] = set()  # WebSocket clients
        self.bus = make_default_event_bus()
        self.logger = logging.getLogger("PortfolioWS")
        
    async def register_client(self, websocket):
        self.clients.add(websocket)
        self.logger.info(f"Client connected: {websocket.remote_address}")
        # Send current portfolio state on connect
        try:
            # Get current state via HTTP to portfolio service
            import requests
            base_url = os.getenv("PTA_BASE_URL", "http://localhost:8090")
            holdings = requests.get(f"{base_url}/portfolio/holdings", timeout=5).json()
            metrics = requests.get(f"{base_url}/portfolio/metrics", timeout=5).json()
            await websocket.send(json.dumps({
                "type": "initial_state",
                "holdings": holdings,
                "metrics": metrics,
                "timestamp": datetime.utcnow().isoformat()
            }))
        except Exception as e:
            self.logger.warning(f"Failed to send initial state: {e}")
    
    async def unregister_client(self, websocket):
        self.clients.discard(websocket)
        self.logger.info(f"Client disconnected: {websocket.remote_address}")
    
    async def broadcast(self, message: Dict[str, Any]):
        if not self.clients:
            return
        message_str = json.dumps(message)
        disconnected = set()
        for client in self.clients:
            try:
                await client.send(message_str)
            except Exception:
                disconnected.add(client)
        # Clean up disconnected clients
        for client in disconnected:
            self.clients.discard(client)
    
    async def handle_client(self, websocket, path: str):
        await self.register_client(websocket)
        try:
            async for message in websocket:
                # Echo or handle client messages if needed
                try:
                    data = json.loads(message)
                    if data.get("type") == "ping":
                        await websocket.send(json.dumps({"type": "pong"}))
                except Exception:
                    pass
        except Exception as e:
            self.logger.debug(f"Client handler error: {e}")
        finally:
            await self.unregister_client(websocket)
    
    async def event_consumer(self):
        """Consume portfolio events from Redis and broadcast to WebSocket clients."""
        if not self.bus:
            self.logger.warning("No event bus configured, portfolio events will not be streamed")
            return
            
        try:
            # Start consumer for portfolio events
            await self.bus.start_consumer(
                stream="portfolio.updates",
                group="portfolio_ws",
                consumer_name="ws_broadcaster",
                handler=self.handle_portfolio_event,
                auto_ack=True
            )
        except Exception as e:
            self.logger.error(f"Event consumer failed: {e}")
    
    async def handle_portfolio_event(self, event: Dict[str, Any]):
        """Handle portfolio events and broadcast to WebSocket clients."""
        try:
            # Transform event for WebSocket broadcast
            ws_message = {
                "type": "portfolio_update",
                "event": event,
                "timestamp": datetime.utcnow().isoformat()
            }
            await self.broadcast(ws_message)
        except Exception as e:
            self.logger.error(f"Failed to handle portfolio event: {e}")
    
    async def start(self):
        """Start the WebSocket server and event consumer."""
        if websockets is None:
            self.logger.error("websockets library not available")
            return
            
        self.logger.info(f"Starting portfolio WebSocket server on {self.host}:{self.port}")
        
        # Start WebSocket server
        server = await websockets.serve(
            self.handle_client,
            self.host,
            self.port
        )
        
        # Start event consumer in background
        if self.bus:
            asyncio.create_task(self.event_consumer())
        
        # Keep server running
        await server.wait_closed()


async def main():
    """Standalone server entry point."""
    try:
        import pathlib as _pl, importlib.util as _ilu
        _lc = _pl.Path(__file__).resolve().parents[1] / "config" / "logging_config.py"
        _spec = _ilu.spec_from_file_location("logging_config", str(_lc))
        _lmod = _ilu.module_from_spec(_spec)  # type: ignore[arg-type]
        _spec.loader.exec_module(_lmod)  # type: ignore[union-attr]
        _lmod.setup_logging()
    except Exception:
        logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)-8s] %(name)s — %(message)s")
    server = PortfolioWebSocketServer()
    await server.start()


if __name__ == "__main__":
    # Clear previous session logs
    try:
        log_files = ['logs/pta_websocket.log', '../logs/pta_websocket.log']
        for log_file in log_files:
            try:
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write('')  # Clear the log file
            except (FileNotFoundError, OSError):
                pass  # File doesn't exist or can't be accessed
    except Exception:
        pass
    
    asyncio.run(main())
