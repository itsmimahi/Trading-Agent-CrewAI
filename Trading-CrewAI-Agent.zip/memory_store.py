"""
Phase 5 — AdvisoryMemoryStore (LanceDB Hierarchical Memory)
=============================================================
Persistent, vector-searchable memory with hierarchical scopes for all
advisory-system components.

Scope hierarchy (mirrors the system architecture plan):

    CONVERSATION  /conversation/{conv_id}/
        messages, entities, intent context, task plans

    MARKET        /market/{market}/
        data-cache, analysis-history, symbols-universe
        market = IN | US | EU | APAC | CRYPTO

    SHARED        /shared/{topic}/
        macro, patterns, strategies, rl-learnings, user-profile

    PORTFOLIO     /portfolio/{section}/
        current-holdings, performance-metrics, trade-history

Composite recall scoring
────────────────────────
    score = 0.5 × semantic_similarity
          + 0.3 × recency               (7-day exponential decay)
          + 0.2 × importance            (caller-supplied 0–1 float)

Embedder
────────
Default: deterministic hash-based 384-dim unit vector (fast, offline,
         suitable for tests and cold-start).
Custom:  inject any ``Callable[[str], List[float]]`` at construction
         time, e.g. a sentence_transformers wrapper.

Usage
─────
    store = AdvisoryMemoryStore(db_path=".advisory_memory")
    entry_id = store.remember(
        scope="MARKET", sub_scope="IN",
        text="NIFTY breaks above 22 000; bullish momentum",
        importance=0.8,
    )
    hits = store.recall(
        scope="MARKET", sub_scope="IN",
        query="Indian market technical breakout",
        k=5,
    )
"""

from __future__ import annotations

import json
import logging
import math
import os
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pyarrow as pa

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

VECTOR_DIM: int = 384          # must match the embedder's output dimension
TABLE_NAME: str = "advisory_memory"
TEXT_MAX_CHARS: int = 4_000    # cap per-entry text to avoid huge rows
RECENCY_HALF_LIFE_DAYS: float = 7.0  # recency score halves every 7 days


# ─────────────────────────────────────────────────────────────────────────────
# Default offline embedder
# ─────────────────────────────────────────────────────────────────────────────

def _hash_embed(text: str, dim: int = VECTOR_DIM) -> List[float]:
    """
    Deterministic, hash-based unit vector embedding.

    Suitable for offline tests and cold-start scenarios where a real
    transformer model is not available.  Semantically opaque — do NOT
    use in production where recall quality matters.
    """
    import hashlib
    seed = int(hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest(), 16) % (2 ** 32)
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    norm = float(np.linalg.norm(vec))
    return (vec / max(norm, 1e-8)).tolist()


def make_sentence_transformer_embedder(
    model_name_or_path: str = "sentence-transformers/all-MiniLM-L2-v2",
) -> Callable[[str], List[float]]:
    """
    Return a sentence_transformers-based embedder function.

    Lazy-loads the model on first call to avoid import-time cost.

    Args:
        model_name_or_path: HuggingFace model name or local path.

    Returns:
        Callable that maps a text string to a 384-dim float list.
    """
    _model = None

    def _embed(text: str) -> List[float]:
        nonlocal _model
        if _model is None:
            from sentence_transformers import SentenceTransformer  # noqa: F401
            _model = SentenceTransformer(model_name_or_path)
        vec = _model.encode(text, normalize_embeddings=True)
        return vec.tolist()

    return _embed


# ─────────────────────────────────────────────────────────────────────────────
# Memory store
# ─────────────────────────────────────────────────────────────────────────────

class AdvisoryMemoryStore:
    """
    LanceDB-backed hierarchical memory for the advisory system.

    All entries live in a single LanceDB table (``advisory_memory``) and
    are distinguished by ``scope`` + ``sub_scope`` fields.  Vector ANN
    search is used for semantic recall; post-retrieval composite scoring
    re-ranks results by recency and importance.

    Thread-safety: LanceDB performs file-level locking; concurrent reads
    are safe.  Concurrent writes from multiple processes may cause
    contention — use separate ``db_path`` per process if needed.
    """

    def __init__(
        self,
        db_path: str | Path = ".advisory_memory",
        embedder_fn: Optional[Callable[[str], List[float]]] = None,
    ) -> None:
        """
        Args:
            db_path: Directory path for the LanceDB database files.
            embedder_fn: Text-to-vector function.  Defaults to the fast
                         offline hash embedder (not semantically meaningful).
        """
        import lancedb  # noqa: F401
        self._db_path = str(db_path)
        self._embedder_fn: Callable[[str], List[float]] = embedder_fn or _hash_embed
        self._db = lancedb.connect(self._db_path)
        self._table = self._init_table()
        logger.info("AdvisoryMemoryStore | db=%s | table=%s", self._db_path, TABLE_NAME)

    # ── Schema & table init ───────────────────────────────────────────────────

    @staticmethod
    def _schema() -> pa.Schema:
        return pa.schema([
            pa.field("id",            pa.utf8()),
            pa.field("scope",         pa.utf8()),
            pa.field("sub_scope",     pa.utf8()),
            pa.field("text",          pa.utf8()),
            pa.field("vector",        pa.list_(pa.float32(), VECTOR_DIM)),
            pa.field("importance",    pa.float32()),
            pa.field("created_at",    pa.float64()),
            pa.field("metadata_json", pa.utf8()),
        ])

    def _init_table(self):
        """Open existing table or create with the advisory schema."""
        try:
            if TABLE_NAME in self._db.table_names():
                return self._db.open_table(TABLE_NAME)
            return self._db.create_table(TABLE_NAME, schema=self._schema())
        except Exception as exc:
            logger.error("AdvisoryMemoryStore._init_table | err=%s", exc)
            raise

    # ── Write ─────────────────────────────────────────────────────────────────

    def remember(
        self,
        scope: str,
        sub_scope: str,
        text: str,
        importance: float = 0.5,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Embed *text* and persist it in the given scope.

        Args:
            scope:      Tier (e.g. ``"MARKET"``, ``"CONVERSATION"``).
            sub_scope:  Sub-namespace (e.g. ``"IN"``, ``"conv-abc123"``).
            text:       Content to remember (capped at TEXT_MAX_CHARS).
            importance: Scalar 0–1 weighting for composite recall scoring.
            metadata:   Optional dict stored as JSON alongside the entry.

        Returns:
            The UUID string of the new entry.
        """
        entry_id = str(uuid.uuid4())
        truncated = text[:TEXT_MAX_CHARS]
        try:
            vector = self._embedder_fn(truncated)
        except Exception as exc:
            logger.warning("AdvisoryMemoryStore.remember | embed_err=%s | using hash", exc)
            vector = _hash_embed(truncated)

        row = {
            "id":            entry_id,
            "scope":         scope,
            "sub_scope":     sub_scope,
            "text":          truncated,
            "vector":        vector,
            "importance":    float(max(0.0, min(1.0, importance))),
            "created_at":    time.time(),
            "metadata_json": json.dumps(metadata or {}),
        }
        try:
            self._table.add([row])
            logger.debug(
                "AdvisoryMemoryStore.remember | scope=%s/%s | id=%s | len=%d",
                scope, sub_scope, entry_id, len(truncated),
            )
        except Exception as exc:
            logger.error("AdvisoryMemoryStore.remember | write_err=%s", exc)
        return entry_id

    # ── Read — semantic recall ────────────────────────────────────────────────

    def recall(
        self,
        scope: str,
        sub_scope: str,
        query: str,
        k: int = 5,
        min_score: float = 0.2,
    ) -> List[str]:
        """
        Return the top-*k* entries most relevant to *query* in a scope.

        Entries are scored by:
            0.5 × semantic_similarity  (1 − cosine_distance)
          + 0.3 × recency              (exponential decay over 7 days)
          + 0.2 × importance

        Entries below *min_score* are excluded.

        Args:
            scope:      Tier to search.
            sub_scope:  Sub-namespace to filter.
            query:      Query text (will be embedded).
            k:          Maximum number of results.
            min_score:  Minimum composite score threshold (0–1).

        Returns:
            List of text strings, best-first.
        """
        try:
            query_vec = self._embedder_fn(query)
        except Exception as exc:
            logger.warning("AdvisoryMemoryStore.recall | embed_err=%s", exc)
            query_vec = _hash_embed(query)

        try:
            raw = (
                self._table
                .search(query_vec, vector_column_name="vector")
                .where(f"scope = '{scope}' AND sub_scope = '{sub_scope}'")
                .limit(k * 3)  # over-fetch; re-rank after composite scoring
                .to_list()
            )
        except Exception as exc:
            logger.debug("AdvisoryMemoryStore.recall | search_err=%s", exc)
            return []

        return self._rerank(raw, k=k, min_score=min_score)

    # ── Read — recent entries ─────────────────────────────────────────────────

    def get_recent(
        self,
        scope: str,
        sub_scope: str,
        n: int = 10,
    ) -> List[str]:
        """
        Return the *n* most recently stored entries in a scope,
        without semantic search.

        Args:
            scope:     Tier to query.
            sub_scope: Sub-namespace to filter.
            n:         Maximum number of entries to return.

        Returns:
            List of text strings, newest-first.
        """
        try:
            import pandas as pd  # noqa: F401
            df = self._table.to_pandas()
            mask = (df["scope"] == scope) & (df["sub_scope"] == sub_scope)
            filtered = df[mask].sort_values("created_at", ascending=False).head(n)
            return filtered["text"].tolist()
        except Exception as exc:
            logger.debug("AdvisoryMemoryStore.get_recent | err=%s", exc)
            return []

    # ── Utility ───────────────────────────────────────────────────────────────

    def entry_count(
        self,
        scope: Optional[str] = None,
        sub_scope: Optional[str] = None,
    ) -> int:
        """Return number of entries matching optional scope/sub_scope filter."""
        try:
            import pandas as pd  # noqa: F401
            df = self._table.to_pandas()
            if scope:
                df = df[df["scope"] == scope]
            if sub_scope:
                df = df[df["sub_scope"] == sub_scope]
            return len(df)
        except Exception:
            return 0

    def clear_scope(self, scope: str, sub_scope: Optional[str] = None) -> None:
        """
        Delete all entries matching *scope* (and optionally *sub_scope*).

        Args:
            scope:     Tier to clear.
            sub_scope: If given, only entries with this sub-namespace are
                       deleted.  If omitted, the entire scope is cleared.
        """
        try:
            predicate = f"scope = '{scope}'"
            if sub_scope:
                predicate += f" AND sub_scope = '{sub_scope}'"
            self._table.delete(predicate)
            logger.info(
                "AdvisoryMemoryStore.clear_scope | scope=%s | sub_scope=%s",
                scope, sub_scope or "*",
            )
        except Exception as exc:
            logger.debug("AdvisoryMemoryStore.clear_scope | err=%s", exc)

    def close(self) -> None:
        """No-op — LanceDB handles connection lifecycle automatically."""
        pass

    # ── Internal ──────────────────────────────────────────────────────────────

    def _rerank(
        self,
        raw: List[Dict[str, Any]],
        k: int,
        min_score: float,
    ) -> List[str]:
        """Composite re-rank: semantic + recency + importance."""
        now = time.time()
        half_life_s = RECENCY_HALF_LIFE_DAYS * 24 * 3600
        scored: List[Tuple[float, str]] = []

        for r in raw:
            # Semantic: LanceDB returns L2 distance (lower = better)
            dist = float(r.get("_distance", 1.0))
            semantic = max(0.0, 1.0 - dist / 2.0)  # normalise to [0, 1]

            # Recency: exponential decay
            age_s = max(0.0, now - float(r.get("created_at", now)))
            recency = math.exp(-age_s / half_life_s)

            importance = float(r.get("importance", 0.5))

            score = 0.5 * semantic + 0.3 * recency + 0.2 * importance
            if score >= min_score:
                scored.append((score, r["text"]))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [text for _, text in scored[:k]]


# ─────────────────────────────────────────────────────────────────────────────
# Named scope constants (avoid magic strings in call sites)
# ─────────────────────────────────────────────────────────────────────────────

class MemoryScope:
    """String constants for the top-level memory scope tiers."""
    CONVERSATION = "CONVERSATION"
    MARKET       = "MARKET"
    SHARED       = "SHARED"
    PORTFOLIO    = "PORTFOLIO"


class MemorySubScope:
    """Helpers for building sub_scope strings."""

    # Market sub-scopes
    MARKET_DATA_CACHE      = "{market}:data-cache"
    MARKET_ANALYSIS        = "{market}:analysis-history"
    MARKET_SYMBOLS         = "{market}:symbols-universe"

    # Shared sub-scopes
    SHARED_MACRO           = "macro"
    SHARED_PATTERNS        = "patterns"
    SHARED_STRATEGIES      = "strategies"
    SHARED_RL_LEARNINGS    = "rl-learnings"
    SHARED_USER_PROFILE    = "user-profile"

    # Portfolio sub-scopes
    PORTFOLIO_HOLDINGS     = "current-holdings"
    PORTFOLIO_PERFORMANCE  = "performance-metrics"
    PORTFOLIO_TRADE_HIST   = "trade-history"

    @staticmethod
    def market_analysis(market: str) -> str:
        return f"{market}:analysis-history"

    @staticmethod
    def market_data_cache(market: str) -> str:
        return f"{market}:data-cache"

    @staticmethod
    def conversation(conv_id: str) -> str:
        return f"conv:{conv_id}"

    @staticmethod
    def conversation_plans(conv_id: str) -> str:
        return f"conv:{conv_id}:plans"
