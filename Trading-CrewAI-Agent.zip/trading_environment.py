"""
Trading Environment for Reinforcement Learning Agent
Implements a Gym-compatible environment for stock trading simulation.
"""

import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
import yfinance as yf
import sys
import os
import talib as ta
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


class TradingEnvironment(gym.Env):
    """
    A trading environment for reinforcement learning.
    
    The environment simulates stock trading with realistic constraints,
    transaction costs, and risk management features.
    """
    
    def __init__(self, 
                 symbol: str = "AAPL",
                 initial_balance: float = 100000.0,
                 start_date: str = "2020-01-01",
                 end_date: str = "2023-12-31",
                 lookback_window: int = 20,
                 transaction_cost: float = 0.001,
                 max_position_size: float = 0.1,
                 max_drawdown_threshold: float = 0.2):
        """
        Initialize the trading environment.
        
        Args:
            symbol: Stock symbol to trade
            initial_balance: Starting cash balance
            start_date: Start date for historical data
            end_date: End date for historical data
            lookback_window: Number of previous days to include in state
            transaction_cost: Transaction cost as percentage of trade value
            max_position_size: Maximum position size as percentage of portfolio
            max_drawdown_threshold: Maximum allowed drawdown before penalty
        """
        super().__init__()
        
        # Environment parameters
        self.symbol = symbol
        self.initial_balance = initial_balance
        self.lookback_window = lookback_window
        self.transaction_cost = transaction_cost
        self.max_position_size = max_position_size
        self.max_drawdown_threshold = max_drawdown_threshold
        
        # Load and prepare data
        self.data = self._load_data(symbol, start_date, end_date)
        self.data_length = len(self.data)
        # Define the feature columns used for observations (keep in sync with _add_technical_indicators)
        self.feature_columns: List[str] = [
            'Open', 'High', 'Low', 'Close', 'Volume',
            'SMA_5', 'SMA_10', 'SMA_20', 'EMA_12', 'EMA_26',
            'RSI', 'MACD', 'MACD_signal', 'MACD_histogram',
            'BB_upper', 'BB_middle', 'BB_lower', 'BB_width',
            'ATR', 'Volume_SMA', 'Price_Change', 'Price_Change_5d'
        ]
        
        # Define action space: 0=Hold, 1=Buy, 2=Sell, 3=Close Position
        self.action_space = spaces.Discrete(4)
        
        # Define observation space
        self.observation_space = self._create_observation_space()
        
        # Initialize state variables
        self.reset()
    
    def _load_data(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        """Load and prepare historical market data with technical indicators."""
        try:
            # Download data from Yahoo Finance
            ticker = yf.Ticker(symbol)
            data = ticker.history(start=start_date, end=end_date)
            
            if data.empty:
                raise ValueError(f"No data found for symbol {symbol}")
            
            # Calculate technical indicators
            data = self._add_technical_indicators(data)
            
            # Forward fill any NaN values
            data = data.fillna(method='ffill').fillna(method='bfill')
            
            return data
            
        except Exception as e:
            print(f"Error loading data for {symbol}: {e}")
            
    
    def _add_technical_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        """Add technical indicators to the data using TA-Lib functions."""
        # Ensure float dtype for TA-Lib
        close = data['Close'].astype(float).values
        high = data['High'].astype(float).values
        low = data['Low'].astype(float).values
        volume = data['Volume'].astype(float).values

        # Simple and Exponential MAs
        data['SMA_5'] = ta.SMA(close, timeperiod=5)
        data['SMA_10'] = ta.SMA(close, timeperiod=10)
        data['SMA_20'] = ta.SMA(close, timeperiod=20)
        data['EMA_12'] = ta.EMA(close, timeperiod=12)
        data['EMA_26'] = ta.EMA(close, timeperiod=26)

        # RSI(14)
        data['RSI'] = ta.RSI(close, timeperiod=14)

        # MACD (12,26,9)
        macd, macd_signal, macd_hist = ta.MACD(close, fastperiod=12, slowperiod=26, signalperiod=9)
        data['MACD'] = macd
        data['MACD_signal'] = macd_signal
        data['MACD_histogram'] = macd_hist

        # Bollinger Bands (20, 2)
        bb_upper, bb_middle, bb_lower = ta.BBANDS(close, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
        data['BB_upper'] = bb_upper
        data['BB_middle'] = bb_middle
        data['BB_lower'] = bb_lower
        # Avoid division by zero in width
        with np.errstate(divide='ignore', invalid='ignore'):
            data['BB_width'] = (data['BB_upper'] - data['BB_lower']) / data['BB_middle']

        # ATR(14)
        data['ATR'] = ta.ATR(high, low, close, timeperiod=14)

        # Volume SMA(20)
        data['Volume_SMA'] = pd.Series(volume, index=data.index).rolling(window=20, min_periods=1).mean()

        # Price change and returns
        data['Price_Change'] = pd.Series(close, index=data.index).pct_change()
        data['Price_Change_5d'] = pd.Series(close, index=data.index).pct_change(periods=5)

        return data
    
    def _create_observation_space(self) -> spaces.Box:
        """Create the observation space for the environment."""
        # Features per timestep: OHLCV + technical indicators (see self.feature_columns)
        features_per_timestep = len(self.feature_columns)
        # Total features: lookback_window * features_per_timestep + portfolio_features
        portfolio_features = 6  # cash, portfolio_value, position, avg_price, unrealized_pnl, drawdown
        total_features = self.lookback_window * features_per_timestep + portfolio_features

        # All features normalized to [0, 1] or [-1, 1]
        return spaces.Box(low=-10, high=10, shape=(total_features,), dtype=np.float32)
    
    def _get_observation(self) -> np.ndarray:
        """Get the current observation (state) for the agent."""
        if self.current_step < self.lookback_window:
            # Pad with zeros if not enough history
            start_idx = 0
            padding = self.lookback_window - self.current_step - 1
        else:
            start_idx = self.current_step - self.lookback_window + 1
            padding = 0
        
        end_idx = self.current_step + 1
        
        # Get historical data
        hist_data = self.data.iloc[start_idx:end_idx]
        
        # Normalize features
        features = []
        for col in self.feature_columns:
            if col in hist_data.columns:
                values = hist_data[col].values
                # Simple normalization (can be improved)
                if col == 'Volume' or col == 'Volume_SMA':
                    values = values / 1e6  # Scale volume
                elif col in ['Open', 'High', 'Low', 'Close', 'SMA_5', 'SMA_10', 'SMA_20', 'EMA_12', 'EMA_26', 'BB_upper', 'BB_middle', 'BB_lower']:
                    values = values / hist_data['Close'].iloc[-1]  # Normalize by current price
                elif col == 'RSI':
                    values = (values - 50) / 50  # Normalize RSI to [-1, 1]
                elif col in ['Price_Change', 'Price_Change_5d']:
                    values = np.clip(values * 100, -10, 10)  # Scale percentage changes
                
                features.extend(values)
            else:
                # Fill missing columns with zeros
                features.extend([0.0] * len(hist_data))
        
        # Pad with zeros if necessary
        if padding > 0:
            features = [0.0] * (padding * len(self.feature_columns)) + features
        
        # Add portfolio state
        current_price = self.data.iloc[self.current_step]['Close']
        portfolio_features = [
            self.balance / self.initial_balance,  # Normalized cash
            self.portfolio_value / self.initial_balance,  # Normalized portfolio value
            self.position / 1000,  # Normalized position (assuming max 1000 shares)
            (self.avg_buy_price / current_price) if self.avg_buy_price > 0 else 0,  # Normalized avg buy price
            self.unrealized_pnl / self.initial_balance,  # Normalized unrealized P&L
            self.max_drawdown  # Drawdown as percentage
        ]
        
        features.extend(portfolio_features)
        
        return np.array(features, dtype=np.float32)
    
    def _calculate_reward(self, action: int, prev_portfolio_value: float) -> float:
        """Calculate the reward for the current step."""
        current_price = self.data.iloc[self.current_step]['Close']
        
        # Update portfolio value
        self.portfolio_value = self.balance + self.position * current_price
        
        # Calculate unrealized P&L
        if self.position > 0 and self.avg_buy_price > 0:
            self.unrealized_pnl = self.position * (current_price - self.avg_buy_price)
        else:
            self.unrealized_pnl = 0
        
        # Update max portfolio value and drawdown
        if self.portfolio_value > self.max_portfolio_value:
            self.max_portfolio_value = self.portfolio_value
        
        self.max_drawdown = (self.max_portfolio_value - self.portfolio_value) / self.max_portfolio_value
        
        # Calculate reward components
        reward = 0.0
        
        # 1. Portfolio value change reward
        portfolio_change = (self.portfolio_value - prev_portfolio_value) / prev_portfolio_value
        reward += portfolio_change * 100  # Scale the reward
        
        # 2. Realized P&L reward (when closing positions)
        if action in [2, 3] and hasattr(self, '_last_realized_pnl'):  # Sell or Close
            realized_pnl_reward = self._last_realized_pnl / self.initial_balance * 100
            reward += realized_pnl_reward
        
        # 3. Drawdown penalty
        if self.max_drawdown > self.max_drawdown_threshold:
            reward -= (self.max_drawdown - self.max_drawdown_threshold) * 100
        
        # 4. Transaction cost penalty
        if action in [1, 2, 3]:  # Any trading action
            reward -= self.transaction_cost * 10  # Small penalty for trading
        
        # 5. Risk-adjusted return (Sharpe-like component)
        if len(self.portfolio_history) > 1:
            returns = np.diff(self.portfolio_history) / self.portfolio_history[:-1]
            if len(returns) > 5:  # Need some history
                sharpe_approx = np.mean(returns) / (np.std(returns) + 1e-8)
                reward += sharpe_approx * 0.1
        
        # 6. Benchmark outperformance (simplified)
        if len(self.portfolio_history) > 20:  # Weekly comparison
            portfolio_return = (self.portfolio_value / self.portfolio_history[-20]) - 1
            # Assume 7% annual benchmark return (simplified)
            benchmark_return = 0.07 * (20 / 252)  # 20 days out of 252 trading days
            if portfolio_return > benchmark_return:
                reward += (portfolio_return - benchmark_return) * 50
        
        return reward
    
    def _execute_action(self, action: int) -> float:
        """Execute the given action and return transaction cost."""
        current_price = self.data.iloc[self.current_step]['Close']
        transaction_cost = 0.0
        self._last_realized_pnl = 0.0
        
        if action == 0:  # Hold
            pass
        
        elif action == 1:  # Buy
            # Calculate position size (10% of current portfolio value)
            position_value = self.portfolio_value * 0.1
            shares_to_buy = int(position_value / current_price)
            
            # Check if we have enough cash and don't exceed position limits
            cost = shares_to_buy * current_price
            max_position_value = self.portfolio_value * self.max_position_size
            
            if cost <= self.balance and (self.position * current_price + cost) <= max_position_value:
                transaction_cost = cost * self.transaction_cost
                self.balance -= (cost + transaction_cost)
                
                # Update average buy price
                if self.position > 0:
                    total_cost = self.position * self.avg_buy_price + cost
                    total_shares = self.position + shares_to_buy
                    self.avg_buy_price = total_cost / total_shares
                else:
                    self.avg_buy_price = current_price
                
                self.position += shares_to_buy
                self.trades_count += 1
        
        elif action == 2:  # Sell (50% of position)
            if self.position > 0:
                shares_to_sell = max(1, int(self.position * 0.5))
                revenue = shares_to_sell * current_price
                transaction_cost = revenue * self.transaction_cost
                
                self.balance += (revenue - transaction_cost)
                self.position -= shares_to_sell
                
                # Calculate realized P&L
                if self.avg_buy_price > 0:
                    self._last_realized_pnl = shares_to_sell * (current_price - self.avg_buy_price)
                
                self.trades_count += 1
                
                # Reset avg buy price if position is closed
                if self.position == 0:
                    self.avg_buy_price = 0
        
        elif action == 3:  # Close Position
            if self.position > 0:
                revenue = self.position * current_price
                transaction_cost = revenue * self.transaction_cost
                
                self.balance += (revenue - transaction_cost)
                
                # Calculate realized P&L
                if self.avg_buy_price > 0:
                    self._last_realized_pnl = self.position * (current_price - self.avg_buy_price)
                
                self.position = 0
                self.avg_buy_price = 0
                self.trades_count += 1
        
        return transaction_cost
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """Execute one step in the environment."""
        # Store previous portfolio value for reward calculation
        prev_portfolio_value = self.portfolio_value
        
        # Execute action
        transaction_cost = self._execute_action(action)
        
        # Move to next time step
        self.current_step += 1
        
        # Calculate reward
        reward = self._calculate_reward(action, prev_portfolio_value)
        
        # Update history
        self.portfolio_history.append(self.portfolio_value)
        self.action_history.append(action)
        
        # Check if episode is done
        done = (self.current_step >= self.data_length - 1) or (self.portfolio_value <= self.initial_balance * 0.1)
        
        # Get new observation
        observation = self._get_observation()
        
        # Info dictionary
        info = {
            'portfolio_value': self.portfolio_value,
            'balance': self.balance,
            'position': self.position,
            'unrealized_pnl': self.unrealized_pnl,
            'max_drawdown': self.max_drawdown,
            'trades_count': self.trades_count,
            'transaction_cost': transaction_cost,
            'current_price': self.data.iloc[self.current_step]['Close'] if not done else self.data.iloc[self.current_step-1]['Close']
        }
        
        return observation, reward, done, False, info
    
    def reset(self, seed: Optional[int] = None) -> Tuple[np.ndarray, Dict]:
        """Reset the environment to initial state."""
        super().reset(seed=seed)
        
        # Reset portfolio state
        self.balance = self.initial_balance
        self.position = 0  # Number of shares
        self.avg_buy_price = 0
        self.portfolio_value = self.initial_balance
        self.max_portfolio_value = self.initial_balance
        self.max_drawdown = 0
        self.unrealized_pnl = 0
        self.trades_count = 0
        
        # Reset episode state
        self.current_step = self.lookback_window  # Start after lookback window
        self.portfolio_history = [self.initial_balance]
        self.action_history = []
        
        # Get initial observation
        observation = self._get_observation()
        
        info = {
            'portfolio_value': self.portfolio_value,
            'balance': self.balance,
            'position': self.position
        }
        
        return observation, info
    
    def render(self, mode: str = 'human') -> None:
        """Render the environment (optional)."""
        if mode == 'human':
            current_price = self.data.iloc[self.current_step]['Close']
            print(f"Step: {self.current_step}")
            print(f"Price: ${current_price:.2f}")
            print(f"Portfolio Value: ${self.portfolio_value:.2f}")
            print(f"Cash: ${self.balance:.2f}")
            print(f"Position: {self.position} shares")
            print(f"Unrealized P&L: ${self.unrealized_pnl:.2f}")
            print(f"Max Drawdown: {self.max_drawdown:.2%}")
            print("-" * 40)
    
    def get_portfolio_stats(self) -> Dict[str, float]:
        """Calculate portfolio performance statistics."""
        if len(self.portfolio_history) < 2:
            return {}
        
        portfolio_values = np.array(self.portfolio_history)
        returns = np.diff(portfolio_values) / portfolio_values[:-1]
        
        # Calculate statistics
        total_return = (portfolio_values[-1] / portfolio_values[0]) - 1
        annualized_return = (1 + total_return) ** (252 / len(portfolio_values)) - 1
        volatility = np.std(returns) * np.sqrt(252)
        sharpe_ratio = (annualized_return - 0.02) / volatility if volatility > 0 else 0  # Assume 2% risk-free rate
        
        # Max drawdown
        peak = np.maximum.accumulate(portfolio_values)
        drawdown = (peak - portfolio_values) / peak
        max_drawdown = np.max(drawdown)
        
        # Win rate
        winning_trades = sum(1 for i in range(1, len(portfolio_values)) if portfolio_values[i] > portfolio_values[i-1])
        win_rate = winning_trades / (len(portfolio_values) - 1) if len(portfolio_values) > 1 else 0
        
        return {
            'total_return': total_return,
            'annualized_return': annualized_return,
            'volatility': volatility,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'total_trades': self.trades_count,
            'final_portfolio_value': portfolio_values[-1]
        }

