"""
Conversation Service
Advanced conversation management and context tracking service.
"""

import json
import pickle
import os
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from dataclasses import asdict

from conversation import (
    ConversationContext, ConversationState, MessageType, 
    conversation_manager, ExtractedEntity
)
try:
    from user import db  # SQLAlchemy instance
    from flask_sqlalchemy import SQLAlchemy  # type: ignore
    _DB_AVAILABLE = isinstance(db, SQLAlchemy)
except Exception:
    db = None  # type: ignore
    _DB_AVAILABLE = False

if _DB_AVAILABLE:
    from flask_sqlalchemy import SQLAlchemy  # type: ignore
    from sqlalchemy import Column, String, Text, DateTime  # type: ignore
    from sqlalchemy.orm import declarative_base  # type: ignore
    try:
        Base = db.Model  # type: ignore
    except Exception:
        Base = object  # fallback

    class ConversationRecord(db.Model):  # type: ignore
        __tablename__ = 'conversations'
        conversation_id = db.Column(db.String(64), primary_key=True)
        data_json = db.Column(db.Text, nullable=False)
        created_at = db.Column(db.DateTime, nullable=False)
        updated_at = db.Column(db.DateTime, nullable=False)


class ConversationPersistence:
    """Handles persistence of conversation data."""
    
    def __init__(self, storage_dir: str = "conversation_storage"):
        self.storage_dir = storage_dir
        self._ensure_storage_dir()
    
    def _ensure_storage_dir(self):
        """Ensure storage directory exists."""
        if not os.path.exists(self.storage_dir):
            os.makedirs(self.storage_dir)
    
    def save_conversation(self, context: ConversationContext) -> bool:
        """Save conversation to persistent storage (SQLite preferred, JSON fallback)."""
        try:
            data = context.to_dict()
            if _DB_AVAILABLE:
                # Upsert by conversation_id
                try:
                    rec = ConversationRecord.query.get(context.conversation_id)  # type: ignore
                except Exception:
                    rec = None
                now = datetime.now()
                if rec is None:
                    rec = ConversationRecord(  # type: ignore
                        conversation_id=context.conversation_id,
                        data_json=json.dumps(data),
                        created_at=now,
                        updated_at=now,
                    )
                    db.session.add(rec)  # type: ignore
                else:
                    rec.data_json = json.dumps(data)
                    rec.updated_at = now
                db.session.commit()  # type: ignore
                return True
            # Fallback to JSON file
            file_path = os.path.join(self.storage_dir, f"{context.conversation_id}.json")
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving conversation {context.conversation_id}: {e}")
            return False
    
    def load_conversation(self, conversation_id: str) -> Optional[ConversationContext]:
        """Load conversation from persistent storage (SQLite preferred, JSON fallback)."""
        try:
            data = None
            if _DB_AVAILABLE:
                try:
                    rec = ConversationRecord.query.get(conversation_id)  # type: ignore
                    if rec:
                        data = json.loads(rec.data_json)
                except Exception:
                    data = None
            if data is None:
                file_path = os.path.join(self.storage_dir, f"{conversation_id}.json")
                if not os.path.exists(file_path):
                    return None
                with open(file_path, 'r') as f:
                    data = json.load(f)
            context = ConversationContext()
            context.from_dict(data)
            return context
        except Exception as e:
            print(f"Error loading conversation {conversation_id}: {e}")
            return None
    
    def delete_conversation(self, conversation_id: str) -> bool:
        """Delete conversation from persistent storage (SQLite preferred, JSON fallback)."""
        try:
            if _DB_AVAILABLE:
                try:
                    rec = ConversationRecord.query.get(conversation_id)  # type: ignore
                    if rec:
                        db.session.delete(rec)  # type: ignore
                        db.session.commit()  # type: ignore
                        return True
                except Exception:
                    pass
            file_path = os.path.join(self.storage_dir, f"{conversation_id}.json")
            if os.path.exists(file_path):
                os.remove(file_path)
            return True
        except Exception as e:
            print(f"Error deleting conversation {conversation_id}: {e}")
            return False
    
    def list_conversations(self) -> List[str]:
        """List all stored conversation IDs (SQLite preferred, JSON fallback)."""
        try:
            if _DB_AVAILABLE:
                try:
                    rows = ConversationRecord.query.with_entities(ConversationRecord.conversation_id).all()  # type: ignore
                    return [r[0] if isinstance(r, tuple) else getattr(r, 'conversation_id', '') for r in rows]
                except Exception:
                    pass
            files = [f for f in os.listdir(self.storage_dir) if f.endswith('.json')]
            return [f[:-5] for f in files]
        except Exception as e:
            print(f"Error listing conversations: {e}")
            return []


class ConversationAnalytics:
    """Provides analytics and insights on conversation patterns."""
    
    @staticmethod
    def analyze_conversation(context: ConversationContext) -> Dict[str, Any]:
        """Analyze a conversation and provide insights."""
        user_messages = context.get_messages_by_type(MessageType.USER_INPUT)
        agent_messages = context.get_messages_by_type(MessageType.AGENT_RESPONSE)
        
        # Basic metrics
        total_messages = len(context.messages)
        conversation_duration = (context.last_updated - context.created_at).total_seconds() / 60  # minutes
        
        # Entity analysis
        entity_types = {}
        for entity in context.extracted_entities:
            entity_types[entity.entity_type] = entity_types.get(entity.entity_type, 0) + 1
        
        # Task analysis
        completed_tasks = context.get_completed_tasks()
        task_agents = {}
        for task in completed_tasks:
            task_agents[task.agent_id] = task_agents.get(task.agent_id, 0) + 1
        
        # Message length analysis
        user_msg_lengths = [len(msg.content) for msg in user_messages]
        agent_msg_lengths = [len(msg.content) for msg in agent_messages]
        
        return {
            "conversation_id": context.conversation_id,
            "metrics": {
                "total_messages": total_messages,
                "user_messages": len(user_messages),
                "agent_messages": len(agent_messages),
                "duration_minutes": round(conversation_duration, 2),
                "messages_per_minute": round(total_messages / max(conversation_duration, 1), 2)
            },
            "entities": {
                "total_entities": len(context.extracted_entities),
                "entity_types": entity_types,
                "unique_entity_types": len(entity_types)
            },
            "tasks": {
                "total_delegated": len(context.delegated_tasks),
                "completed_tasks": len(completed_tasks),
                "completion_rate": len(completed_tasks) / max(len(context.delegated_tasks), 1),
                "agents_used": task_agents,
                "unique_agents": len(task_agents)
            },
            "message_analysis": {
                "avg_user_message_length": sum(user_msg_lengths) / max(len(user_msg_lengths), 1),
                "avg_agent_message_length": sum(agent_msg_lengths) / max(len(agent_msg_lengths), 1),
                "longest_user_message": max(user_msg_lengths) if user_msg_lengths else 0,
                "longest_agent_message": max(agent_msg_lengths) if agent_msg_lengths else 0
            },
            "state_info": {
                "current_state": context.state.value,
                "inferred_intent": context.inferred_intent,
                "has_user_profile": bool(context.user_profile.user_id or context.user_profile.risk_tolerance)
            }
        }
    
    @staticmethod
    def get_conversation_summary(context: ConversationContext) -> str:
        """Generate a natural language summary of the conversation."""
        analysis = ConversationAnalytics.analyze_conversation(context)
        
        summary_parts = []
        
        # Basic info
        summary_parts.append(f"Conversation lasted {analysis['metrics']['duration_minutes']} minutes with {analysis['metrics']['total_messages']} messages exchanged.")
        
        # Entity mentions
        if analysis['entities']['total_entities'] > 0:
            entity_types = list(analysis['entities']['entity_types'].keys())
            summary_parts.append(f"Discussion involved {', '.join(entity_types)} with {analysis['entities']['total_entities']} total mentions.")
        
        # Agent usage
        if analysis['tasks']['completed_tasks'] > 0:
            agents_used = list(analysis['tasks']['agents_used'].keys())
            summary_parts.append(f"Consulted {analysis['tasks']['unique_agents']} specialized agents: {', '.join(agents_used)}.")
        
        # Intent
        if context.inferred_intent:
            summary_parts.append(f"Primary intent identified as: {context.inferred_intent}.")
        
        return " ".join(summary_parts)


class ConversationContextEnhancer:
    """Enhances conversation context with additional intelligence."""
    
    @staticmethod
    def suggest_follow_up_questions(context: ConversationContext) -> List[str]:
        """Suggest relevant follow-up questions based on conversation context."""
        suggestions = []
        
        # Based on extracted entities
        stock_entities = context.get_entities_by_type("stock_symbol")
        company_entities = context.get_entities_by_type("company_name")
        
        if stock_entities or company_entities:
            suggestions.extend([
                "Would you like a technical analysis of this stock?",
                "Should we look at the fundamental metrics?",
                "Are you interested in the risk assessment?",
                "What's your investment timeline for this position?"
            ])
        
        # Based on inferred intent
        if context.inferred_intent:
            intent = context.inferred_intent.lower()
            
            if "fundamental" in intent:
                suggestions.extend([
                    "Would you like to see how this compares to industry peers?",
                    "Should we analyze the company's growth prospects?",
                    "Are you interested in dividend analysis?"
                ])
            
            elif "technical" in intent:
                suggestions.extend([
                    "Would you like to see different timeframe analysis?",
                    "Should we look at volume patterns?",
                    "Are you interested in momentum indicators?"
                ])
            
            elif "risk" in intent:
                suggestions.extend([
                    "Would you like portfolio diversification suggestions?",
                    "Should we run scenario analysis?",
                    "Are you interested in hedging strategies?"
                ])
        
        # Based on user profile
        if context.user_profile.risk_tolerance:
            if context.user_profile.risk_tolerance == "conservative":
                suggestions.append("Would you like to see some low-risk investment options?")
            elif context.user_profile.risk_tolerance == "aggressive":
                suggestions.append("Are you interested in higher-growth opportunities?")
        
        # Remove duplicates and limit
        return list(set(suggestions))[:5]
    
    @staticmethod
    def identify_information_gaps(context: ConversationContext) -> List[str]:
        """Identify missing information that could improve recommendations."""
        gaps = []
        
        # User profile gaps
        if not context.user_profile.risk_tolerance:
            gaps.append("risk_tolerance")
        
        if not context.user_profile.investment_goals:
            gaps.append("investment_goals")
        
        if not context.user_profile.time_horizon:
            gaps.append("time_horizon")
        
        if not context.user_profile.experience_level:
            gaps.append("experience_level")
        
        # Context gaps based on entities
        stock_entities = context.get_entities_by_type("stock_symbol")
        if stock_entities and not context.get_entities_by_type("time_period"):
            gaps.append("time_period")
        
        # Task completion gaps
        completed_tasks = context.get_completed_tasks()
        if context.inferred_intent and "analysis" in context.inferred_intent.lower():
            expected_agents = ["fundamental_research", "technical_analysis", "sentiment_analysis"]
            completed_agents = [task.agent_id for task in completed_tasks]
            
            for agent in expected_agents:
                if agent not in completed_agents:
                    gaps.append(f"missing_{agent}")
        
        return gaps
    
    @staticmethod
    def generate_clarifying_questions(gaps: List[str]) -> List[str]:
        """Generate clarifying questions based on identified information gaps."""
        questions = []
        
        gap_to_question = {
            "risk_tolerance": "What's your risk tolerance? (Conservative, Moderate, or Aggressive)",
            "investment_goals": "What are your primary investment goals? (Growth, Income, Retirement, etc.)",
            "time_horizon": "What's your investment time horizon? (Short-term, Medium-term, or Long-term)",
            "experience_level": "What's your investment experience level? (Beginner, Intermediate, or Advanced)",
            "time_period": "What time period are you interested in analyzing?",
            "missing_fundamental_research": "Would you like me to analyze the fundamental metrics?",
            "missing_technical_analysis": "Should I perform a technical analysis of the charts?",
            "missing_sentiment_analysis": "Are you interested in the current market sentiment?"
        }
        
        for gap in gaps:
            if gap in gap_to_question:
                questions.append(gap_to_question[gap])
        
        return questions


class ConversationService:
    """Main conversation service orchestrating all conversation management functionality."""
    
    def __init__(self):
        self.persistence = ConversationPersistence()
        self.analytics = ConversationAnalytics()
        self.enhancer = ConversationContextEnhancer()
    
    def get_or_create_conversation(self, conversation_id: Optional[str] = None) -> ConversationContext:
        """Get existing conversation or create new one."""
        if conversation_id:
            # Try to get from memory first
            context = conversation_manager.get_conversation(conversation_id)
            if context:
                return context
            
            # Try to load from persistent storage
            context = self.persistence.load_conversation(conversation_id)
            if context:
                # Add back to memory
                conversation_manager._conversations[conversation_id] = context
                return context
        
        # Create new conversation
        context = conversation_manager.create_conversation(conversation_id)
        self.persistence.save_conversation(context)
        return context
    
    def save_conversation(self, context: ConversationContext) -> bool:
        """Save conversation to persistent storage."""
        return self.persistence.save_conversation(context)
    
    def delete_conversation(self, conversation_id: str) -> bool:
        """Delete conversation from memory and storage."""
        # Remove from memory
        conversation_manager.delete_conversation(conversation_id)
        
        # Remove from storage
        return self.persistence.delete_conversation(conversation_id)
    
    def get_conversation_analytics(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        """Get analytics for a conversation."""
        context = self.get_or_create_conversation(conversation_id)
        if not context:
            return None
        
        return self.analytics.analyze_conversation(context)
    
    def get_conversation_summary(self, conversation_id: str) -> Optional[str]:
        """Get natural language summary of conversation."""
        context = self.get_or_create_conversation(conversation_id)
        if not context:
            return None
        
        return self.analytics.get_conversation_summary(context)
    
    def suggest_follow_ups(self, conversation_id: str) -> List[str]:
        """Suggest follow-up questions for a conversation."""
        context = self.get_or_create_conversation(conversation_id)
        if not context:
            return []
        
        return self.enhancer.suggest_follow_up_questions(context)
    
    def get_clarifying_questions(self, conversation_id: str) -> List[str]:
        """Get clarifying questions to improve conversation quality."""
        context = self.get_or_create_conversation(conversation_id)
        if not context:
            return []
        
        gaps = self.enhancer.identify_information_gaps(context)
        return self.enhancer.generate_clarifying_questions(gaps)

    def get_conversation_history(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        """Return full conversation context as dict."""
        ctx = self.get_or_create_conversation(conversation_id)
        return ctx.to_dict() if ctx else None

    def get_active_contexts(self) -> List[Dict[str, Any]]:
        """List summaries of active conversations."""
        contexts = conversation_manager.get_active_conversations()
        return [c.get_conversation_summary() for c in contexts]
    
    def update_conversation_context(self, conversation_id: str, updates: Dict[str, Any]) -> bool:
        """Update conversation context with new information."""
        try:
            context = self.get_or_create_conversation(conversation_id)
            
            # Update user profile
            if 'user_profile' in updates:
                context.update_user_profile(**updates['user_profile'])
            
            # Update context data
            if 'context_data' in updates:
                for key, value in updates['context_data'].items():
                    context.set_context_data(key, value)
            
            # Add entities
            if 'entities' in updates:
                for entity in updates['entities']:
                    context.add_extracted_entity(
                        entity['type'], 
                        entity['value'], 
                        entity.get('confidence', 0.5),
                        entity.get('source_message_id', '')
                    )
            
            # Save updated context
            self.save_conversation(context)
            return True
            
        except Exception as e:
            print(f"Error updating conversation context: {e}")
            return False
    
    def cleanup_old_conversations(self, days_old: int = 30) -> int:
        """Clean up conversations older than specified days."""
        cutoff_date = datetime.now() - timedelta(days=days_old)
        cleaned_count = 0
        
        try:
            conversation_ids = self.persistence.list_conversations()
            
            for conv_id in conversation_ids:
                context = self.persistence.load_conversation(conv_id)
                if context and context.last_updated < cutoff_date:
                    self.delete_conversation(conv_id)
                    cleaned_count += 1
            
            return cleaned_count
            
        except Exception as e:
            print(f"Error during cleanup: {e}")
            return 0
    
    def export_conversation(self, conversation_id: str, format: str = "json") -> Optional[str]:
        """Export conversation in specified format."""
        context = self.get_or_create_conversation(conversation_id)
        if not context:
            return None
        
        if format.lower() == "json":
            return json.dumps(context.to_dict(), indent=2)
        
        elif format.lower() == "text":
            # Generate human-readable text format
            lines = []
            lines.append(f"Conversation ID: {context.conversation_id}")
            lines.append(f"Created: {context.created_at}")
            lines.append(f"Last Updated: {context.last_updated}")
            lines.append(f"State: {context.state.value}")
            lines.append(f"Intent: {context.inferred_intent or 'Not determined'}")
            lines.append("")
            
            lines.append("Messages:")
            for msg in context.messages:
                sender = "User" if msg.message_type == MessageType.USER_INPUT else "Agent"
                lines.append(f"[{msg.timestamp}] {sender}: {msg.content}")
            
            lines.append("")
            lines.append("Extracted Entities:")
            for entity in context.extracted_entities:
                lines.append(f"- {entity.entity_type}: {entity.value} (confidence: {entity.confidence})")
            
            return "\n".join(lines)
        
        return None


# Global service instance
conversation_service = ConversationService()

