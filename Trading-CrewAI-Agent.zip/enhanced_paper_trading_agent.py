"""
Enhanced Paper Trading Agent using CrewAI Framework - Hybrid Plus Approach
Simulate trades issued by the system and track virtual investments with Portfolio Management System
"""

import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass

# Portfolio Management System integration
try:
    from .paper_trading_portfolio_adapter import get_paper_trading_adapter, migrate_to_portfolio_system
    PMS_AVAILABLE = True
except ImportError:
    PMS_AVAILABLE = False

# Backtrader imports (fallback for legacy support)
try:
    import backtrader as bt
    from backtrader import Strategy, DataFeed
    BACKTRADER_AVAILABLE = True
except ImportError:
    BACKTRADER_AVAILABLE = False
    bt = None

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from config.settings import config
from crewai import Task, Crew, Process

logger = logging.getLogger(__name__)

# Ensure Backtrader is imported
try:
    import backtrader as bt
except ImportError:
    bt = None
    raise ImportError("The 'backtrader' package is required for paper trading simulation. Please install it with 'pip install backtrader'.")

class BacktraderStrategy(bt.Strategy):
    """Custom Backtrader strategy for paper trading simulation"""
    
    params = (
        ('entry_price', 100.0),
        ('target_price', 105.0),
        ('stop_loss', 95.0),
        ('position_size', 0.05),
        ('commission', 0.001),
        ('slippage', 0.0005),
    )
    
    def __init__(self):
        self.order = None
        self.buyprice = None
        self.buycomm = None
        self.position_opened = False
        
    def log(self, txt, dt=None):
        dt = dt or self.datas[0].datetime.date(0)
        print(f'{dt.isoformat()}, {txt}')
    
    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(f'BUY EXECUTED, Price: {order.executed.price:.2f}, Cost: {order.executed.value:.2f}, Comm: {order.executed.comm:.2f}')
                self.buyprice = order.executed.price
                self.buycomm = order.executed.comm
            else:
                self.log(f'SELL EXECUTED, Price: {order.executed.price:.2f}, Cost: {order.executed.value:.2f}, Comm: {order.executed.comm:.2f}')
            
            self.bar_executed = len(self)
        
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')
        
        self.order = None
    
    def notify_trade(self, trade):
        if not trade.isclosed:
            return
        
        self.log(f'OPERATION PROFIT, GROSS: {trade.pnl:.2f}, NET: {trade.pnlcomm:.2f}')
    
    def next(self):
        if not self.position_opened:
            # Open position based on strategy signals
            if self.data.close[0] <= self.params.entry_price:
                size = int(self.broker.getcash() * self.params.position_size / self.data.close[0])
                self.order = self.buy(size=size)
                self.position_opened = True
        else:
            # Check exit conditions
            if (self.data.close[0] >= self.params.target_price or 
                self.data.close[0] <= self.params.stop_loss):
                self.order = self.sell()

class EnhancedPaperTradingAgent(EnhancedBaseAgent):
    """
    Enhanced Paper Trading Agent using CrewAI Framework with Hybrid Plus Approach
    
    Mathematical Core: P&L calculations, performance metrics, risk analysis
    LLM Reasoning: Trade analysis, strategy evaluation, performance insights
    Tools: Trade ledger manager, real-time price fetcher, virtual wallet simulator, Backtrader integration
    Memory: Trade history, performance tracking, strategy success rates
    Knowledge Base: Trading strategies, risk management, performance benchmarks
    """
    
    def __init__(self, name: str = "EnhancedPaperTradingAgent", description: str = "Paper Trading Agent for simulating trades and tracking virtual investments", role: str = "Paper Trading Specialist", goal: str = "Execute virtual trades and track portfolio performance with realistic simulation", backstory: str = "Expert in paper trading and portfolio simulation with deep knowledge of market dynamics and risk management", capabilities: Optional[List[Any]] = None, weight: float = 0.20, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        super().__init__(name=name, description=description, role=role, goal=goal, backstory=backstory, capabilities=capabilities, weight=weight, use_llm=use_llm, use_memory=use_memory, use_knowledge_base=use_knowledge_base, **kwargs)
        
        # Initialize portfolio adapter (preferred over backtrader)
        if PMS_AVAILABLE:
            self.portfolio_adapter = get_paper_trading_adapter(name)
            self.use_pms = True
            logger.info(f"Using Portfolio Management System for {name}")
        else:
            self.portfolio_adapter = None
            self.use_pms = False
            logger.warning(f"Portfolio Management System unavailable for {name}, using mock simulation")
        
        # Legacy Backtrader support (fallback)
        self.backtrader_available = BACKTRADER_AVAILABLE and not self.use_pms
        if self.backtrader_available:
            self.cerebro = bt.Cerebro()
            self.cerebro.broker.setcash(50000)
            self.cerebro.broker.setcommission(commission=0.001)
            self.cerebro.addsizer(bt.sizers.PercentSizer, percents=5)
        
        # Trading state
        self.active_positions = {}
        self.trade_history = []
        self.performance_metrics = {}
        self.strategy_results = {}
        
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.RISK_ASSESSMENT,
                AgentCapability.TREND_ANALYSIS,
                AgentCapability.CONTEXTUAL_REASONING
            ]
        
        # Load paper trading knowledge
        self._load_paper_trading_knowledge()
    
    def _load_paper_trading_knowledge(self):
        """Load paper trading knowledge into knowledge base"""
        try:
            paper_trading_knowledge = [
                "Portfolio Management System: Uses realistic fees and position tracking for trade simulation",
                "Performance Tracking: Monitor win rate, profit factor, and drawdown with real portfolio metrics",
                "Risk Management: Apply position sizing and stop-loss rules with actual portfolio constraints",
                "Strategy Testing: Validate trading strategies using realistic Portfolio Management System",
                "Performance Analysis: Use metrics like Sharpe ratio and max drawdown from actual portfolio",
                "Entry Timing: Execute trades with realistic fees (₹5 min brokerage + 0.05% bps)",
                "Exit Timing: Close positions with proper slippage modeling (0.02%)",
                "Commission Impact: Include actual trading costs in P&L calculations",
                "Position Tracking: Real-time position updates via Portfolio Management System",
                "Cash Management: Track available cash and margin requirements accurately",
                "PMS Integration: Direct connection to Portfolio Management System for realistic simulation",
                "Real-time Updates: Portfolio changes broadcast via WebSocket for immediate feedback",
                "Indian Market Fees: Realistic fee structure matching Indian brokerage costs",
                "Trade Validation: Pre-trade checks for feasibility and risk management"
            ]
            
            if self.use_knowledge_base:
                self.knowledge_base.add_knowledge(paper_trading_knowledge)
                
        except Exception as e:
            self.logger.error(f"Error loading paper trading knowledge: {e}")
    
    async def analyze(self, symbol: str, trade_plan: Dict[str, Any] = None) -> Dict[str, Any]:
        """Main analysis method for paper trading simulation"""
        try:
            self.logger.info(f"Starting CrewAI comprehensive paper trading analysis for {symbol}")
            
            # Use provided trade plan or create mock data
            if trade_plan is None:
                trade_plan = self._create_mock_trade_plan(symbol)
            
            # 1. Mathematical Analysis (Trade simulation and P&L calculation)
            math_results = await self.mathematical_analysis(symbol, {'trade_plan': trade_plan})
            if "error" in math_results:
                return math_results
            
            # 2. Get market context for CrewAI reasoning
            market_context = await self._get_market_context(symbol)
            
            # 3. CrewAI Reasoning (Trade analysis and strategy evaluation)
            if self.use_llm:
                crewai_reasoning = await self._get_crewai_paper_trading_reasoning(math_results, market_context)
            else:
                crewai_reasoning = {"reasoning": "CrewAI analysis not available"}
            
            # 4. Final Synthesis
            final_analysis = {
                "agent_name": self.name,
                "symbol": symbol,
                "analysis_timestamp": datetime.now().isoformat(),
                "mathematical_analysis": math_results,
                "crewai_reasoning": crewai_reasoning,
                "market_context": market_context,
                "confidence_score": math_results.get('execution_confidence', 0.5),
                "recommendation": math_results.get('trade_recommendation', 'HOLD'),
                "agent_weight": self.weight,
                "backtrader_available": self.backtrader_available
            }
            
            return final_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI comprehensive analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Perform mathematical/quantitative paper trading analysis using Portfolio Management System"""
        try:
            trade_plan = data.get('trade_plan', {})
            
            # Primary: Use Portfolio Management System if available
            if self.use_pms and self.portfolio_adapter and self.portfolio_adapter.is_available():
                trade_execution = self._simulate_trade_execution(symbol, trade_plan)
                portfolio_metrics = self._get_pms_portfolio_metrics()
            # Fallback: Use Backtrader if PMS unavailable
            elif self.backtrader_available:
                trade_execution = await self._run_backtrader_simulation(symbol, trade_plan)
                portfolio_metrics = self._calculate_performance_metrics()
            # Last resort: Simple simulation
            else:
                trade_execution = self._simulate_trade_execution(symbol, trade_plan)
                portfolio_metrics = self._calculate_performance_metrics()
            
            # Calculate P&L and performance metrics
            pnl_analysis = self._calculate_pnl_analysis(trade_execution)
            
            # Update portfolio state
            portfolio_update = self._update_portfolio(trade_execution)
            
            # Generate trade recommendation based on execution results
            trade_recommendation = self._generate_trade_recommendation(trade_execution, pnl_analysis)
            
            return {
                "symbol": symbol,
                "trade_execution": trade_execution,
                "pnl_analysis": pnl_analysis,
                "portfolio_update": portfolio_update,
                "performance_metrics": portfolio_metrics,
                "trade_recommendation": trade_recommendation,
                "pms_used": self.use_pms and self.portfolio_adapter and self.portfolio_adapter.is_available(),
                "backtrader_used": self.backtrader_available and not self.use_pms,
                "calculation_timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in mathematical analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def _run_backtrader_simulation(self, symbol: str, trade_plan: Dict[str, Any]) -> Dict[str, Any]:
        """Run Backtrader simulation for robust backtesting"""
        try:
            # Create historical data (in real implementation, fetch from data source)
            historical_data = self._create_historical_data(symbol, trade_plan)
            
            # Create Backtrader data feed
            data_feed = bt.feeds.PandasData(
                dataname=historical_data,
                datetime=None,  # Use index as datetime
                open=0, high=1, low=2, close=3, volume=4, openinterest=-1
            )
            
            # Reset cerebro
            self.cerebro = bt.Cerebro()
            self.cerebro.broker.setcash(self.initial_capital)
            self.cerebro.broker.setcommission(commission=self.commission_rate)
            self.cerebro.addsizer(bt.sizers.PercentSizer, percents=5)
            
            # Add data feed
            self.cerebro.adddata(data_feed)
            
            # Create strategy with trade plan parameters
            strategy_params = {
                'entry_price': trade_plan.get('entry_price', 100.0),
                'target_price': trade_plan.get('target_price', 105.0),
                'stop_loss': trade_plan.get('stop_loss', 95.0),
                'position_size': trade_plan.get('position_size', 0.05),
                'commission': self.commission_rate,
                'slippage': self.slippage_rate,
            }
            
            # Add strategy
            self.cerebro.addstrategy(BacktraderStrategy, **strategy_params)
            
            # Run simulation
            initial_value = self.cerebro.broker.getvalue()
            results = self.cerebro.run()
            final_value = self.cerebro.broker.getvalue()
            
            # Extract results
            strategy = results[0]
            portfolio_value = self.cerebro.broker.getvalue()
            cash = self.cerebro.broker.getcash()
            
            # Calculate metrics
            total_return = (final_value - initial_value) / initial_value
            trades = len(strategy.trades) if hasattr(strategy, 'trades') else 0
            
            return {
                "trade_id": f"{symbol}_backtrader_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "symbol": symbol,
                "strategy": trade_plan.get('strategy_type', 'BACKTRADER'),
                "direction": trade_plan.get('direction', 'BUY'),
                "entry_price": trade_plan.get('entry_price', 100.0),
                "target_price": trade_plan.get('target_price', 105.0),
                "stop_loss": trade_plan.get('stop_loss', 95.0),
                "quantity": 0,  # Will be calculated by Backtrader
                "entry_time": datetime.now(),
                "exit_time": None,
                "pnl": final_value - initial_value,
                "status": "COMPLETED",
                "fees": 0,  # Calculated by Backtrader
                "commission": 0,
                "position_value": portfolio_value - cash,
                "backtrader_results": {
                    "initial_value": initial_value,
                    "final_value": final_value,
                    "total_return": total_return,
                    "cash": cash,
                    "portfolio_value": portfolio_value,
                    "trades_executed": trades
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in Backtrader simulation: {e}")
            # Fallback to simple simulation
            return self._simulate_trade_execution(symbol, trade_plan)
    
    def _create_historical_data(self, symbol: str, trade_plan: Dict[str, Any]) -> pd.DataFrame:
        """Create historical data for Backtrader simulation"""
        try:
            # Generate realistic historical data (in real implementation, fetch from API)
            dates = pd.date_range(start=datetime.now() - timedelta(days=100), 
                                 end=datetime.now(), freq='D')
            
            # Create realistic price movements
            np.random.seed(hash(symbol) % 2**32)
            base_price = trade_plan.get('entry_price', 100.0)
            
            # Generate price series with some trend and volatility
            returns = np.random.normal(0.0005, 0.02, len(dates))
            prices = base_price * (1 + returns).cumprod()
            
            # Create OHLCV data
            data = pd.DataFrame({
                'Open': prices * (1 + np.random.normal(0, 0.005, len(dates))),
                'High': prices * (1 + abs(np.random.normal(0, 0.01, len(dates)))),
                'Low': prices * (1 - abs(np.random.normal(0, 0.01, len(dates)))),
                'Close': prices,
                'Volume': np.random.randint(100000, 1000000, len(dates))
            }, index=dates)
            
            return data
            
        except Exception as e:
            self.logger.error(f"Error creating historical data: {e}")
            # Return simple mock data
            return pd.DataFrame({
                'Open': [100, 101, 102, 103, 104],
                'High': [101, 102, 103, 104, 105],
                'Low': [99, 100, 101, 102, 103],
                'Close': [101, 102, 103, 104, 105],
                'Volume': [1000000, 1100000, 1200000, 1300000, 1400000]
            })
    
    def _simulate_trade_execution(self, symbol: str, trade_plan: Dict[str, Any]) -> Dict[str, Any]:
        """Execute trade using Portfolio Management System or fallback simulation"""
        try:
            direction = trade_plan.get('direction', 'HOLD')
            entry_price = trade_plan.get('entry_price', 100.0)
            target_price = trade_plan.get('target_price', 105.0)
            stop_loss = trade_plan.get('stop_loss', 95.0)
            position_size = trade_plan.get('position_size', 0.05)
            strategy = trade_plan.get('strategy_type', 'UNKNOWN')
            
            # Use Portfolio Management System if available
            if self.use_pms and self.portfolio_adapter and self.portfolio_adapter.is_available():
                return self._execute_pms_trade(symbol, direction, position_size, strategy, entry_price, target_price, stop_loss)
            
            # Fallback to simple simulation
            return self._execute_fallback_simulation(symbol, direction, position_size, strategy, entry_price, target_price, stop_loss)
            
        except Exception as e:
            logger.error(f"Trade execution failed: {e}")
            return {"error": str(e), "symbol": symbol, "direction": direction}
    
    def _execute_pms_trade(self, symbol: str, direction: str, position_size: float, strategy: str, entry_price: float, target_price: float, stop_loss: float) -> Dict[str, Any]:
        """Execute trade using Portfolio Management System"""
        try:
            # Skip HOLD actions
            if direction.upper() == 'HOLD':
                return {
                    "trade_id": f"{symbol}_HOLD_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                    "symbol": symbol,
                    "strategy": strategy,
                    "direction": direction,
                    "status": "HOLD",
                    "message": "No action taken",
                    "pms_used": True
                }
            
            # Convert direction to side
            side = "buy" if direction.upper() == "BUY" else "sell"
            
            # Calculate quantity based on position size and available portfolio value
            portfolio_value = self.portfolio_adapter.get_portfolio_value()
            position_value = portfolio_value * position_size
            quantity = max(1, int(position_value / entry_price))  # At least 1 share
            
            # Check if trade is feasible
            can_trade, reason = self.portfolio_adapter.portfolio_manager.can_trade(symbol, side, quantity)
            if not can_trade:
                return {
                    "error": reason,
                    "symbol": symbol,
                    "direction": direction,
                    "quantity": quantity,
                    "feasible": False,
                    "pms_used": True
                }
            
            # Execute the trade
            result = self.portfolio_adapter.place_order(symbol, direction.upper(), quantity)
            
            if result.get("status") == "executed":
                trade_record = {
                    "trade_id": result.get("order_id", f"{symbol}_{direction}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"),
                    "symbol": symbol,
                    "strategy": strategy,
                    "direction": direction,
                    "entry_price": entry_price,
                    "target_price": target_price,
                    "stop_loss": stop_loss,
                    "quantity": quantity,
                    "entry_time": datetime.now(),
                    "status": "EXECUTED",
                    "pms_result": result,
                    "pms_used": True,
                    "fees_realistic": True
                }
                
                # Store in trade history
                self.trade_history.append(trade_record)
                
                return trade_record
            else:
                return {
                    "error": result.get("message", "Trade execution failed"),
                    "symbol": symbol,
                    "direction": direction,
                    "quantity": quantity,
                    "pms_result": result,
                    "pms_used": True
                }
                
        except Exception as e:
            logger.error(f"PMS trade execution failed: {e}")
            return {"error": str(e), "symbol": symbol, "direction": direction, "pms_used": True}
    
    def _execute_fallback_simulation(self, symbol: str, direction: str, position_size: float, strategy: str, entry_price: float, target_price: float, stop_loss: float) -> Dict[str, Any]:
        """Fallback simulation when PMS is not available"""
        try:
            # Get current cash balance
            current_cash = 50000.0  # Default fallback
            if hasattr(self, 'portfolio') and 'cash_balance' in self.portfolio:
                current_cash = self.portfolio['cash_balance']
            
            # Calculate position size in dollars
            position_value = current_cash * position_size
            quantity = max(1, int(position_value / entry_price))
            
            # Calculate fees and slippage
            commission = position_value * 0.001  # 0.1% commission
            slippage = position_value * 0.0005   # 0.05% slippage
            total_fees = commission + slippage
            
            # Generate trade ID
            trade_id = f"{symbol}_{direction}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            # Create trade record
            trade = {
                "trade_id": trade_id,
                "symbol": symbol,
                "strategy": strategy,
                "direction": direction,
                "entry_price": entry_price,
                "target_price": target_price,
                "stop_loss": stop_loss,
                "quantity": quantity,
                "entry_time": datetime.now(),
                "exit_time": None,
                "pnl": 0.0,
                "status": "SIMULATED",
                "fees": total_fees,
                "commission": commission,
                "position_value": position_value,
                "pms_used": False,
                "fallback_simulation": True
            }
            
            # Add to portfolio trades
            self.portfolio['trades'].append(trade)
            
            return trade
            
        except Exception as e:
            self.logger.error(f"Error simulating trade execution: {e}")
            return {
                "trade_id": "ERROR",
                "symbol": symbol,
                "strategy": "ERROR",
                "direction": "HOLD",
                "entry_price": 0,
                "target_price": 0,
                "stop_loss": 0,
                "quantity": 0,
                "entry_time": datetime.now(),
                "exit_time": None,
                "pnl": 0.0,
                "status": "ERROR",
                "fees": 0.0,
                "commission": 0.0,
                "position_value": 0.0,
                "backtrader_used": False
            }
    
    def _calculate_pnl_analysis(self, trade: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate P&L analysis for trade"""
        try:
            # Check if Backtrader was used
            if trade.get('backtrader_used', False):
                backtrader_results = trade.get('backtrader_results', {})
                unrealized_pnl = backtrader_results.get('total_return', 0) * trade.get('position_value', 0)
                pnl_percentage = backtrader_results.get('total_return', 0) * 100
                current_price = trade.get('entry_price', 100.0) * (1 + backtrader_results.get('total_return', 0))
            else:
                # Mock current price (in real implementation, get from market data)
                current_price = trade.get('entry_price', 100.0) * 1.02  # 2% gain for demo
                
                # Calculate unrealized P&L
                if trade.get('direction') == 'BUY':
                    unrealized_pnl = (current_price - trade.get('entry_price', 0)) * trade.get('quantity', 0)
                else:
                    unrealized_pnl = (trade.get('entry_price', 0) - current_price) * trade.get('quantity', 0)
                
                # Calculate P&L percentage
                position_value = trade.get('position_value', 0)
                pnl_percentage = (unrealized_pnl / position_value * 100) if position_value > 0 else 0
            
            return {
                "unrealized_pnl": unrealized_pnl,
                "pnl_percentage": pnl_percentage,
                "current_price": current_price,
                "fees_paid": trade.get('fees', 0),
                "backtrader_used": trade.get('backtrader_used', False)
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating P&L analysis: {e}")
            return {
                "unrealized_pnl": 0.0,
                "pnl_percentage": 0.0,
                "current_price": 0.0,
                "fees_paid": 0.0,
                "backtrader_used": False
            }
    
    def _update_portfolio(self, trade: Dict[str, Any]) -> Dict[str, Any]:
        """Update portfolio with new trade"""
        try:
            # Update cash balance
            position_value = trade.get('position_value', 0)
            fees = trade.get('fees', 0)
            
            if trade.get('direction') == 'BUY':
                self.portfolio['cash_balance'] -= (position_value + fees)
            else:
                self.portfolio['cash_balance'] += (position_value - fees)
            
            return {
                "cash_balance": self.portfolio['cash_balance'],
                "total_trades": len(self.portfolio['trades']),
                "portfolio_value": self.portfolio['cash_balance'] + position_value,
                "backtrader_available": self.backtrader_available
            }
            
        except Exception as e:
            self.logger.error(f"Error updating portfolio: {e}")
            return {
                "cash_balance": self.portfolio['cash_balance'],
                "total_trades": 0,
                "portfolio_value": self.portfolio['cash_balance'],
                "backtrader_available": self.backtrader_available
            }
    
    def _get_pms_portfolio_metrics(self) -> Dict[str, Any]:
        """Get portfolio metrics from Portfolio Management System"""
        try:
            if not self.use_pms or not self.portfolio_adapter or not self.portfolio_adapter.is_available():
                return self._calculate_performance_metrics()
            
            # Get real portfolio metrics from PMS
            metrics = self.portfolio_adapter.get_performance_metrics()
            
            if "error" in metrics:
                logger.warning(f"PMS metrics error: {metrics['error']}")
                return self._calculate_performance_metrics()
            
            return {
                "total_value": metrics.get("total_value", 0),
                "cash": metrics.get("cash", 0),
                "invested_value": metrics.get("invested_value", 0),
                "unrealized_pnl": metrics.get("unrealized_pnl", 0),
                "positions_count": metrics.get("positions_count", 0),
                "trades_executed": metrics.get("trades_executed", 0),
                "portfolio_utilization": metrics.get("portfolio_utilization", 0),
                "available_margin": metrics.get("available_margin", 0),
                "pms_used": True
            }
            
        except Exception as e:
            logger.error(f"Error getting PMS portfolio metrics: {e}")
            return self._calculate_performance_metrics()
    
    def _calculate_performance_metrics(self) -> Dict[str, Any]:
        """Calculate performance metrics"""
        try:
            total_trades = len(self.portfolio['trades'])
            winning_trades = sum(1 for trade in self.portfolio['trades'] if trade.get('pnl', 0) > 0)
            
            win_rate = winning_trades / total_trades if total_trades > 0 else 0
            
            return {
                "total_trades": total_trades,
                "winning_trades": winning_trades,
                "win_rate": win_rate,
                "total_pnl": self.portfolio['total_pnl'],
                "backtrader_used": any(trade.get('backtrader_used', False) for trade in self.portfolio['trades'])
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating performance metrics: {e}")
            return {
                "total_trades": 0,
                "winning_trades": 0,
                "win_rate": 0.0,
                "total_pnl": 0.0,
                "backtrader_used": False
            }
    
    def _generate_trade_recommendation(self, trade: Dict[str, Any], pnl_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Generate trade recommendation based on execution and P&L"""
        try:
            pnl_percentage = pnl_analysis.get('pnl_percentage', 0)
            backtrader_used = pnl_analysis.get('backtrader_used', False)
            
            # Determine recommendation based on P&L
            if pnl_percentage > 2:
                recommendation = "STRONG_HOLD"
                reasoning = "Profitable trade with good performance"
            elif pnl_percentage > 0:
                recommendation = "HOLD"
                reasoning = "Profitable trade, continue monitoring"
            elif pnl_percentage < -2:
                recommendation = "CLOSE"
                reasoning = "Significant loss, consider closing position"
            else:
                recommendation = "MONITOR"
                reasoning = "Trade within acceptable parameters"
            
            # Add Backtrader context to reasoning
            if backtrader_used:
                reasoning += " (Backtrader simulation used)"
            
            return {
                "recommendation": recommendation,
                "reasoning": reasoning,
                "pnl_percentage": pnl_percentage,
                "execution_confidence": 0.9 if backtrader_used else 0.8 if trade.get('status') == 'OPEN' else 0.5,
                "backtrader_used": backtrader_used
            }
            
        except Exception as e:
            self.logger.error(f"Error generating trade recommendation: {e}")
            return {
                "recommendation": "MONITOR",
                "reasoning": "Unable to generate recommendation",
                "pnl_percentage": 0,
                "execution_confidence": 0.5,
                "backtrader_used": False
            }
    
    def _create_mock_trade_plan(self, symbol: str) -> Dict[str, Any]:
        """Create mock trade plan for testing"""
        return {
            "direction": "BUY",
            "entry_price": 100.0,
            "target_price": 105.0,
            "stop_loss": 95.0,
            "position_size": 0.05,
            "strategy_type": "MOMENTUM",
            "time_horizon": "SHORT_TERM",
            "confidence": 0.7
        }
    
    async def _get_market_context(self, symbol: str) -> str:
        """Get current market context for CrewAI reasoning"""
        try:
            backtrader_context = ""
            if self.backtrader_available:
                backtrader_context = """
            - Backtrader Integration: Using Backtrader for robust backtesting and simulation
            - Historical Data: Testing strategies against real historical market data
            - Strategy Validation: Validating strategies before live implementation
            - Risk Metrics: Calculating proper risk metrics using Backtrader analytics
            """
            
            return f"""
            Paper trading context for {symbol}:
            - Market volatility: Impact on trade execution and slippage
            - Liquidity conditions: Effect on trade execution quality
            - Market hours: Impact on trade timing and execution
            - News events: Potential impact on trade performance
            - Sector performance: How sector trends affect individual stocks
            - Market sentiment: Overall market mood and its effect on trades{backtrader_context}
            """
        except Exception as e:
            self.logger.error(f"Error getting market context: {e}")
            return "Market context not available"

    async def _get_crewai_paper_trading_reasoning(self, math_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Get CrewAI-based paper trading reasoning for trade analysis"""
        try:
            backtrader_info = ""
            if math_results.get('backtrader_used', False):
                backtrader_info = """
            Backtrader Analysis:
            - Historical backtesting performed with real market data
            - Strategy validation against historical performance
            - Risk metrics calculated using Backtrader analytics
            - Portfolio simulation with realistic execution costs
            """
            
            reasoning_prompt = f"""
            You are an expert paper trading specialist with deep knowledge of trade execution and performance analysis.
            
            Paper Trading Analysis Results:
            {math_results}
            
            Market Context:
            {market_context}
            
            {backtrader_info}
            
            Based on this comprehensive paper trading analysis, provide:
            1. Trade Execution Assessment - Quality of trade execution and timing
            2. Performance Analysis - P&L analysis and risk assessment
            3. Strategy Evaluation - Effectiveness of trading strategy used
            4. Risk Management - Position sizing and risk control measures
            5. Portfolio Impact - How trade affects overall portfolio
            6. Future Recommendations - Suggestions for trade management
            
            Provide comprehensive paper trading analysis that combines execution metrics with market wisdom.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive paper trading reasoning and performance analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            return {"reasoning": str(result)}
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI paper trading reasoning: {str(e)}")
            return {"error": str(e)}

    async def execute_trade(self, symbol: str, trade_plan: Dict[str, Any] = None) -> dict:
        """Main method for executing paper trades. Calls analyze method."""
        try:
            return await self.analyze(symbol, trade_plan)
        except Exception as e:
            self.logger.error(f"Error in execute_trade: {e}")
            return {"error": str(e)}
    
    # Convenience methods for Portfolio Management System integration
    def get_portfolio_status(self) -> Dict[str, Any]:
        """Get current portfolio status"""
        if self.use_pms and self.portfolio_adapter and self.portfolio_adapter.is_available():
            return {
                "status": "connected",
                "portfolio_value": self.portfolio_adapter.get_portfolio_value(),
                "cash": self.portfolio_adapter.get_cash(),
                "positions": self.portfolio_adapter.get_positions(),
                "pms_available": True
            }
        else:
            return {
                "status": "disconnected",
                "portfolio_value": 50000.0,
                "cash": 50000.0,
                "positions": [],
                "pms_available": False,
                "fallback_mode": True
            }
    
    def buy_stock(self, symbol: str, quantity: int) -> Dict[str, Any]:
        """Convenience method to buy stock"""
        if self.use_pms and self.portfolio_adapter:
            return self.portfolio_adapter.buy(symbol, quantity)
        else:
            return {"error": "Portfolio Management System not available"}
    
    def sell_stock(self, symbol: str, quantity: int) -> Dict[str, Any]:
        """Convenience method to sell stock"""
        if self.use_pms and self.portfolio_adapter:
            return self.portfolio_adapter.sell(symbol, quantity)
        else:
            return {"error": "Portfolio Management System not available"}
    
    def get_trade_history(self) -> List[Dict[str, Any]]:
        """Get trading history"""
        if self.use_pms and self.portfolio_adapter:
            return self.portfolio_adapter.get_trade_history()
        else:
            return self.trade_history
    
    def reset_simulation(self) -> Dict[str, Any]:
        """Reset paper trading simulation"""
        if self.use_pms and self.portfolio_adapter:
            return self.portfolio_adapter.reset_simulation()
        else:
            self.trade_history.clear()
            return {"status": "reset", "mode": "fallback"}