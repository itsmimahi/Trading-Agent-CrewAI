"""
Enhanced Research Agent using CrewAI Framework - Hybrid Plus Approach
Mathematical Core + LLM Reasoning + Tools + Memory + Knowledge Base
"""


import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from data.collectors.market_data import market_data_collector
from config.settings import config
from crewai import Task, Crew, Process

logger = logging.getLogger(__name__)

@dataclass
class FinancialRatios:
    """Financial ratios calculation results"""
    pe_ratio: float
    pb_ratio: float
    roe: float
    roa: float
    debt_to_equity: float
    current_ratio: float
    quick_ratio: float
    profit_margin: float
    revenue_growth: float
    eps_growth: float
    dividend_yield: float

@dataclass
class ValuationMetrics:
    """Valuation metrics calculation results"""
    intrinsic_value: float
    fair_value: float
    margin_of_safety: float
    dcf_value: float
    book_value: float
    tangible_book_value: float

class EnhancedResearchAgent(EnhancedBaseAgent):
    memory = None
    """
    Enhanced Research Agent using CrewAI Framework with Hybrid Plus Approach
    
    Mathematical Core: Financial ratio calculations, valuation models
    LLM Reasoning: Earnings call analysis, competitive positioning, strategic insights
    Tools: DCF calculator, ratio analyzer, peer comparison
    Memory: Company analysis history, market cycles, performance patterns
    Knowledge Base: Sector knowledge, historical precedents, regulatory insights
    """
    
    def __init__(self, name: str = "Research Agent", description: str = "Fundamental analysis and company health assessment", role: str = "Research Specialist", goal: str = "Provide deep market and company research using LLMs and quantitative methods", backstory: str = "Expert in financial research and analysis", capabilities: Optional[List[Any]] = None, weight: float = 0.25, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        if capabilities is None:
            capabilities = [
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.CONTEXTUAL_REASONING,
                AgentCapability.NATURAL_LANGUAGE_PROCESSING
            ]
        super().__init__(name=name, description=description, capabilities=capabilities, weight=weight, use_llm=use_llm, use_memory=use_memory, use_knowledge_base=use_knowledge_base, role=role, goal=goal, backstory=backstory, **kwargs)
        
        # Mathematical thresholds and models
        self.valuation_models = {
            'pe_model': {'excellent': 15, 'good': 25, 'fair': 35, 'poor': 50},
            'pb_model': {'excellent': 1.5, 'good': 3.0, 'fair': 5.0, 'poor': 8.0},
            'roe_model': {'excellent': 20, 'good': 15, 'fair': 10, 'poor': 5},
            'debt_model': {'excellent': 0.3, 'good': 0.6, 'fair': 1.0, 'poor': 2.0}
        }
        
        # Sector-specific knowledge
        self.sector_multiples = {
            'technology': {'pe': 25, 'pb': 4.0, 'roe': 18},
            'banking': {'pe': 12, 'pb': 1.2, 'roe': 12},
            'pharma': {'pe': 20, 'pb': 3.0, 'roe': 15},
            'fmcg': {'pe': 35, 'pb': 8.0, 'roe': 25},
            'auto': {'pe': 18, 'pb': 2.5, 'roe': 14},
            'metals': {'pe': 10, 'pb': 1.5, 'roe': 10}
        }
        
        # Load sector knowledge into knowledge base
        self._load_sector_knowledge()
        
    def _initialize_tools(self):
        """Initialize Research Agent specific tools"""
        super()._initialize_tools()
        
        # Add specialized research tools
        self.tools.extend([
            AgentTool(
                name="calculate_financial_ratios",
                description="Calculate comprehensive financial ratios",
                function=self._calculate_financial_ratios
            ),
            AgentTool(
                name="dcf_valuation",
                description="Perform Discounted Cash Flow valuation",
                function=self._dcf_valuation
            ),
            AgentTool(
                name="peer_comparison",
                description="Compare company metrics with industry peers",
                function=self._peer_comparison
            ),
            AgentTool(
                name="growth_analysis",
                description="Analyze growth trends and sustainability",
                function=self._growth_analysis
            ),
            AgentTool(
                name="quality_assessment",
                description="Assess company quality metrics",
                function=self._quality_assessment
            ),
            AgentTool(
                name="earnings_analysis",
                description="Analyze earnings quality and trends",
                function=self._earnings_analysis
            )
        ])
    
    def _load_sector_knowledge(self):
        """Load sector-specific knowledge into knowledge base"""
        try:
            sector_knowledge = []
            for sector, multiples in self.sector_multiples.items():
                knowledge = f"Sector: {sector.upper()}\n"
                knowledge += f"Typical PE Ratio: {multiples['pe']}\n"
                knowledge += f"Typical PB Ratio: {multiples['pb']}\n"
                knowledge += f"Typical ROE: {multiples['roe']}%\n"
                sector_knowledge.append(knowledge)
            
            # Add general valuation principles
            sector_knowledge.extend([
                "Value investing principles: Buy below intrinsic value with margin of safety",
                "Growth investing: Focus on companies with sustainable competitive advantages",
                "Quality metrics: Look for consistent profitability and strong balance sheets",
                "Cyclical vs defensive sectors: Adjust expectations based on economic cycles",
                "Interest rate sensitivity: Higher rates affect valuations differently across sectors"
            ])
            
            if self.use_knowledge_base:
                self.knowledge_base.add_knowledge(sector_knowledge)
                
        except Exception as e:
            self.logger.error(f"Error loading sector knowledge: {e}")
    
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform mathematical/quantitative fundamental analysis
        Pure mathematical calculations without LLM
        """
        try:
            # Get financial/company info data
            financial_data = await market_data_collector.get_company_info(symbol)
            if not financial_data:
                return {"error": "No financial/company info available"}
            
            # Calculate financial ratios
            ratios = self._calculate_financial_ratios(financial_data)
            
            # Perform valuation analysis
            valuation = self._dcf_valuation(financial_data)
            
            # Growth analysis
            growth_metrics = self._growth_analysis(financial_data)
            
            # Quality assessment
            quality_metrics = self._quality_assessment(financial_data)
            
            # Earnings analysis
            earnings_metrics = self._earnings_analysis(financial_data)
            
            # Peer comparison
            peer_analysis = self._peer_comparison(symbol, financial_data)
            
            # Calculate overall scores
            fundamental_score = self._calculate_fundamental_score(ratios, valuation, growth_metrics, quality_metrics)
            
            return {
                "symbol": symbol,
                "financial_ratios": ratios.__dict__ if ratios else {},
                "valuation_metrics": valuation.__dict__ if valuation else {},
                "growth_metrics": growth_metrics,
                "quality_metrics": quality_metrics,
                "earnings_metrics": earnings_metrics,
                "peer_analysis": peer_analysis,
                "fundamental_score": fundamental_score,
                "calculation_timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in mathematical analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    def _calculate_financial_ratios(self, financial_data: Dict[str, Any]) -> Optional[FinancialRatios]:
        """Calculate comprehensive financial ratios"""
        try:
            # Extract key financial metrics
            market_cap = financial_data.get('market_cap', 0)
            total_revenue = financial_data.get('total_revenue', 0)
            net_income = financial_data.get('net_income', 0)
            total_assets = financial_data.get('total_assets', 0)
            shareholders_equity = financial_data.get('shareholders_equity', 0)
            total_debt = financial_data.get('total_debt', 0)
            current_assets = financial_data.get('current_assets', 0)
            current_liabilities = financial_data.get('current_liabilities', 0)
            cash_and_equivalents = financial_data.get('cash_and_equivalents', 0)
            shares_outstanding = financial_data.get('shares_outstanding', 0)
            dividend_per_share = financial_data.get('dividend_per_share', 0)
            
            # Calculate ratios
            eps = net_income / shares_outstanding if shares_outstanding > 0 else 0
            book_value_per_share = shareholders_equity / shares_outstanding if shares_outstanding > 0 else 0
            price_per_share = market_cap / shares_outstanding if shares_outstanding > 0 else 0
            
            return FinancialRatios(
                pe_ratio=price_per_share / eps if eps > 0 else 0,
                pb_ratio=price_per_share / book_value_per_share if book_value_per_share > 0 else 0,
                roe=net_income / shareholders_equity * 100 if shareholders_equity > 0 else 0,
                roa=net_income / total_assets * 100 if total_assets > 0 else 0,
                debt_to_equity=total_debt / shareholders_equity if shareholders_equity > 0 else 0,
                current_ratio=current_assets / current_liabilities if current_liabilities > 0 else 0,
                quick_ratio=(current_assets - financial_data.get('inventory', 0)) / current_liabilities if current_liabilities > 0 else 0,
                profit_margin=net_income / total_revenue * 100 if total_revenue > 0 else 0,
                revenue_growth=financial_data.get('revenue_growth', 0),
                eps_growth=financial_data.get('eps_growth', 0),
                dividend_yield=dividend_per_share / price_per_share * 100 if price_per_share > 0 else 0
            )
            
        except Exception as e:
            self.logger.error(f"Error calculating financial ratios: {e}")
            return None
    
    def _dcf_valuation(self, financial_data: Dict[str, Any]) -> Optional[ValuationMetrics]:
        """Perform Discounted Cash Flow valuation"""
        try:
            # Extract DCF inputs
            free_cash_flow = financial_data.get('free_cash_flow', 0)
            revenue_growth = financial_data.get('revenue_growth', 0.05)  # Default 5%
            terminal_growth = 0.03  # 3% terminal growth
            discount_rate = 0.10  # 10% discount rate
            shares_outstanding = financial_data.get('shares_outstanding', 0)
            
            # Project cash flows for 5 years
            projected_fcf = []
            current_fcf = free_cash_flow
            
            for year in range(1, 6):
                # Declining growth rate
                growth_rate = max(revenue_growth * (0.9 ** year), terminal_growth)
                current_fcf *= (1 + growth_rate)
                projected_fcf.append(current_fcf)
            
            # Calculate terminal value
            terminal_value = projected_fcf[-1] * (1 + terminal_growth) / (discount_rate - terminal_growth)
            
            # Discount all cash flows to present value
            pv_fcf = sum([fcf / ((1 + discount_rate) ** (i + 1)) for i, fcf in enumerate(projected_fcf)])
            pv_terminal = terminal_value / ((1 + discount_rate) ** 5)
            
            # Calculate enterprise value and equity value
            enterprise_value = pv_fcf + pv_terminal
            equity_value = enterprise_value - financial_data.get('net_debt', 0)
            
            # Per share values
            intrinsic_value = equity_value / shares_outstanding if shares_outstanding > 0 else 0
            book_value = financial_data.get('book_value_per_share', 0)
            current_price = financial_data.get('current_price', 0)
            
            return ValuationMetrics(
                intrinsic_value=intrinsic_value,
                fair_value=intrinsic_value * 0.9,  # 10% discount for fair value
                margin_of_safety=(intrinsic_value - current_price) / intrinsic_value * 100 if intrinsic_value > 0 else 0,
                dcf_value=intrinsic_value,
                book_value=book_value,
                tangible_book_value=book_value - financial_data.get('intangible_assets_per_share', 0)
            )
            
        except Exception as e:
            self.logger.error(f"Error in DCF valuation: {e}")
            return None
    
    def _peer_comparison(self, symbol: str, financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Compare company metrics with industry peers"""
        try:
            # Get sector information
            sector = financial_data.get('sector', 'unknown').lower()
            industry_multiples = self.sector_multiples.get(sector, {})
            
            # Company ratios
            company_pe = financial_data.get('pe_ratio', 0)
            company_pb = financial_data.get('pb_ratio', 0)
            company_roe = financial_data.get('roe', 0)
            
            # Compare with sector averages
            comparison = {
                'sector': sector,
                'pe_vs_sector': company_pe / industry_multiples.get('pe', company_pe) if industry_multiples.get('pe', 0) > 0 else 1,
                'pb_vs_sector': company_pb / industry_multiples.get('pb', company_pb) if industry_multiples.get('pb', 0) > 0 else 1,
                'roe_vs_sector': company_roe / industry_multiples.get('roe', company_roe) if industry_multiples.get('roe', 0) > 0 else 1,
                'relative_valuation': 'undervalued' if company_pe < industry_multiples.get('pe', company_pe) else 'overvalued'
            }
            
            return comparison
            
        except Exception as e:
            self.logger.error(f"Error in peer comparison: {e}")
            return {"error": str(e)}
    
    def _growth_analysis(self, financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze growth trends and sustainability"""
        try:
            # Historical growth rates
            revenue_growth_5y = financial_data.get('revenue_growth_5y', 0)
            earnings_growth_5y = financial_data.get('earnings_growth_5y', 0)
            
            # Current growth metrics
            current_revenue_growth = financial_data.get('revenue_growth', 0)
            current_earnings_growth = financial_data.get('earnings_growth', 0)
            
            # Calculate growth sustainability score
            growth_consistency = 1 - abs(current_revenue_growth - revenue_growth_5y) / max(abs(revenue_growth_5y), 0.01)
            
            return {
                'revenue_growth_5y': revenue_growth_5y,
                'earnings_growth_5y': earnings_growth_5y,
                'current_revenue_growth': current_revenue_growth,
                'current_earnings_growth': current_earnings_growth,
                'growth_consistency': max(0, growth_consistency),
                'growth_sustainability_score': (growth_consistency + min(current_revenue_growth/20, 1)) / 2
            }
            
        except Exception as e:
            self.logger.error(f"Error in growth analysis: {e}")
            return {"error": str(e)}
    
    def _quality_assessment(self, financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assess company quality metrics"""
        try:
            # Quality metrics
            roe = financial_data.get('roe', 0)
            roa = financial_data.get('roa', 0)
            debt_to_equity = financial_data.get('debt_to_equity', 0)
            current_ratio = financial_data.get('current_ratio', 0)
            profit_margin = financial_data.get('profit_margin', 0)
            
            # Quality score calculation
            quality_factors = []
            
            # Profitability quality
            if roe > 15:
                quality_factors.append(1.0)
            elif roe > 10:
                quality_factors.append(0.7)
            else:
                quality_factors.append(0.3)
            
            # Financial stability
            if debt_to_equity < 0.5:
                quality_factors.append(1.0)
            elif debt_to_equity < 1.0:
                quality_factors.append(0.7)
            else:
                quality_factors.append(0.3)
            
            # Liquidity
            if current_ratio > 1.5:
                quality_factors.append(1.0)
            elif current_ratio > 1.0:
                quality_factors.append(0.7)
            else:
                quality_factors.append(0.3)
            
            overall_quality = sum(quality_factors) / len(quality_factors) if quality_factors else 0
            
            return {
                'profitability_score': quality_factors[0] if len(quality_factors) > 0 else 0,
                'financial_stability_score': quality_factors[1] if len(quality_factors) > 1 else 0,
                'liquidity_score': quality_factors[2] if len(quality_factors) > 2 else 0,
                'overall_quality_score': overall_quality,
                'quality_grade': 'A' if overall_quality > 0.8 else 'B' if overall_quality > 0.6 else 'C' if overall_quality > 0.4 else 'D'
            }
            
        except Exception as e:
            self.logger.error(f"Error in quality assessment: {e}")
            return {"error": str(e)}
    
    def _earnings_analysis(self, financial_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze earnings quality and trends"""
        try:
            # Earnings quality metrics
            net_income = financial_data.get('net_income', 0)
            operating_cash_flow = financial_data.get('operating_cash_flow', 0)
            free_cash_flow = financial_data.get('free_cash_flow', 0)
            
            # Earnings quality ratios
            earnings_quality = operating_cash_flow / net_income if net_income > 0 else 0
            cash_conversion = free_cash_flow / net_income if net_income > 0 else 0
            
            return {
                'earnings_quality_ratio': earnings_quality,
                'cash_conversion_ratio': cash_conversion,
                'earnings_sustainability': 'high' if earnings_quality > 1.2 else 'medium' if earnings_quality > 0.8 else 'low',
                'cash_generation_strength': 'strong' if cash_conversion > 0.8 else 'moderate' if cash_conversion > 0.5 else 'weak'
            }
            
        except Exception as e:
            self.logger.error(f"Error in earnings analysis: {e}")
            return {"error": str(e)}
    
    def _calculate_fundamental_score(self, ratios: FinancialRatios, valuation: ValuationMetrics, 
                                   growth: Dict[str, Any], quality: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall fundamental score"""
        try:
            scores = []
            
            # Valuation score (30%)
            if valuation and valuation.margin_of_safety > 20:
                valuation_score = 1.0
            elif valuation and valuation.margin_of_safety > 0:
                valuation_score = 0.7
            else:
                valuation_score = 0.3
            scores.append(('valuation', valuation_score, 0.3))
            
            # Quality score (25%)
            quality_score = quality.get('overall_quality_score', 0.5)
            scores.append(('quality', quality_score, 0.25))
            
            # Growth score (25%)
            growth_score = min(growth.get('growth_sustainability_score', 0.5), 1.0)
            scores.append(('growth', growth_score, 0.25))
            
            # Profitability score (20%)
            if ratios and ratios.roe > 15:
                profitability_score = 1.0
            elif ratios and ratios.roe > 10:
                profitability_score = 0.7
            else:
                profitability_score = 0.3
            scores.append(('profitability', profitability_score, 0.2))
            
            # Calculate weighted score
            weighted_score = sum(score * weight for _, score, weight in scores)
            
            return {
                'overall_score': weighted_score,
                'component_scores': {name: score for name, score, _ in scores},
                'recommendation': 'strong_buy' if weighted_score > 0.8 else 'buy' if weighted_score > 0.6 else 'hold' if weighted_score > 0.4 else 'sell',
                'confidence': weighted_score
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating fundamental score: {e}")
            return {"error": str(e)}
    
    async def analyze(self, symbol: str, timeframe: str = "1d") -> Dict[str, Any]:
        """
        Main analysis method combining mathematical analysis with CrewAI reasoning
        Hybrid Plus Approach: Math + CrewAI + Tools + Memory + Knowledge Base
        """
        try:
            self.logger.info(f"Starting CrewAI comprehensive research analysis for {symbol}")
            
            # 1. Mathematical Analysis (Fast, Reliable)
            math_results = await self.mathematical_analysis(symbol, {})
            if "error" in math_results:
                return math_results
            
            # 2. Get market context for CrewAI reasoning
            market_context = await self._get_market_context(symbol)
            
            # 3. CrewAI Reasoning (Intelligent Interpretation)
            if self.use_llm:
                crewai_reasoning = await self._get_crewai_reasoning(math_results, market_context)
                
                # 4. CrewAI Analysis for strategic insights
                strategic_analysis = await self._get_crewai_strategic_analysis(
                    data=math_results,
                    context=market_context,
                    symbol=symbol
                )
            else:
                crewai_reasoning = {"reasoning": "CrewAI analysis not available"}
                strategic_analysis = {"analysis": "Strategic analysis not available"}
            
            # 5. Memory Integration
            relevant_experiences = self.get_relevant_experiences(symbol) if self.use_memory else []
            
            # 6. Knowledge Base Insights
            kb_insights = []
            if self.use_knowledge_base:
                sector = math_results.get('peer_analysis', {}).get('sector', 'unknown')
                kb_insights = self.knowledge_base.query_knowledge(f"sector analysis {sector}")
            
            # 7. Final Synthesis
            final_analysis = {
                "agent_name": self.name,
                "symbol": symbol,
                "analysis_timestamp": datetime.now().isoformat(),
                "mathematical_analysis": math_results,
                "crewai_reasoning": crewai_reasoning,
                "strategic_insights": strategic_analysis,
                "market_context": market_context,
                "relevant_experiences": relevant_experiences,
                "knowledge_base_insights": kb_insights,
                "confidence_score": math_results.get('fundamental_score', {}).get('confidence', 0.5),
                "recommendation": math_results.get('fundamental_score', {}).get('recommendation', 'hold'),
                "agent_weight": self.weight
            }
            
            # 8. Learn from this analysis
            self.add_experience({
                "symbol": symbol,
                "analysis_type": "fundamental_research",
                "key_metrics": {
                    "pe_ratio": math_results.get('financial_ratios', {}).get('pe_ratio', 0),
                    "overall_score": math_results.get('fundamental_score', {}).get('overall_score', 0),
                    "recommendation": math_results.get('fundamental_score', {}).get('recommendation', 'hold')
                },
                "market_conditions": market_context
            })
            
            return final_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI comprehensive analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def _get_market_context(self, symbol: str) -> str:
        """Get current market context for LLM reasoning"""
        try:
            # This would typically fetch current market data
            # For now, return a structured context
            return f"""
            Current market analysis for {symbol}:
            - Market conditions: Current economic environment and sector trends
            - Interest rate environment: Current rates and expected changes
            - Regulatory environment: Recent changes affecting the sector
            - Competitive landscape: Key competitors and market position
            - Economic indicators: GDP growth, inflation, employment data
            """
        except Exception as e:
            self.logger.error(f"Error getting market context: {e}")
            return "Market context not available"

    async def _get_crewai_reasoning(self, math_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Get CrewAI-based reasoning for fundamental analysis"""
        try:
            reasoning_prompt = f"""
            You are an expert financial research analyst with deep knowledge of fundamental analysis and valuation.
            
            Mathematical Analysis Results:
            {math_results}
            
            Market Context:
            {market_context}
            
            Based on this quantitative analysis, provide:
            1. Financial Health Assessment - Overall company financial strength and stability
            2. Valuation Analysis - Whether the stock is undervalued, fairly valued, or overvalued
            3. Growth Prospects - Assessment of future growth potential and sustainability
            4. Risk Factors - Key risks and concerns for investors
            5. Competitive Position - How the company compares to industry peers
            6. Investment Thesis - Clear reasoning for investment decision
            
            Consider:
            - Financial ratios and their implications
            - Valuation metrics and margin of safety
            - Growth trends and sustainability
            - Quality metrics and business model strength
            - Market conditions and sector trends
            - Competitive advantages and moats
            
            Provide clear, actionable insights that combine quantitative rigor with qualitative judgment.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive financial reasoning and analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            reasoning = self._parse_crewai_reasoning_response(str(result))
            
            return reasoning
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI reasoning: {str(e)}")
            return {"error": str(e)}

    async def _get_crewai_strategic_analysis(self, data: Dict[str, Any], context: str, symbol: str) -> Dict[str, Any]:
        """Get CrewAI-based strategic analysis for investment insights"""
        try:
            strategic_prompt = f"""
            You are an expert investment strategist with deep knowledge of market dynamics and investment timing.
            
            Company Analysis Data:
            {data}
            
            Market Context:
            {context}
            
            Symbol: {symbol}
            
            Based on this comprehensive analysis, provide:
            1. Strategic Investment Insights - Key factors driving investment decision
            2. Timing Considerations - Best entry/exit points and holding period
            3. Portfolio Fit - How this stock fits in a diversified portfolio
            4. Risk Management - Specific risk mitigation strategies
            5. Alternative Scenarios - What could go right or wrong
            6. Monitoring Points - Key metrics to track going forward
            
            Consider:
            - Current market environment and economic conditions
            - Sector rotation and thematic investing
            - Interest rate sensitivity and inflation impact
            - Geopolitical and regulatory risks
            - Technological disruption and innovation
            - ESG factors and sustainability trends
            
            Provide strategic insights that help investors make informed decisions.
            """
            
            # Use CrewAI agent for strategic analysis
            task = Task(
                description=strategic_prompt,
                agent=self.crewai_agent,
                expected_output="Strategic investment analysis and recommendations"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            analysis = self._parse_crewai_strategic_response(str(result))
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI strategic analysis: {str(e)}")
            return {"error": str(e)}

    def _parse_crewai_reasoning_response(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI reasoning response into structured format"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Split response into sections
            sections = response.split('\n\n')
            parsed_reasoning = {
                "financial_health_assessment": "",
                "valuation_analysis": "",
                "growth_prospects": "",
                "risk_factors": "",
                "competitive_position": "",
                "investment_thesis": ""
            }
            
            current_section = None
            for section in sections:
                if "Financial Health Assessment" in section:
                    current_section = "financial_health_assessment"
                elif "Valuation Analysis" in section:
                    current_section = "valuation_analysis"
                elif "Growth Prospects" in section:
                    current_section = "growth_prospects"
                elif "Risk Factors" in section:
                    current_section = "risk_factors"
                elif "Competitive Position" in section:
                    current_section = "competitive_position"
                elif "Investment Thesis" in section:
                    current_section = "investment_thesis"
                elif current_section and section.strip():
                    parsed_reasoning[current_section] = section.strip()
            
            return parsed_reasoning
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI reasoning response: {str(e)}")
            return {"raw_response": response}

    def _parse_crewai_strategic_response(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI strategic response into structured format"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Split response into sections
            sections = response.split('\n\n')
            parsed_analysis = {
                "strategic_insights": "",
                "timing_considerations": "",
                "portfolio_fit": "",
                "risk_management": "",
                "alternative_scenarios": "",
                "monitoring_points": ""
            }
            
            current_section = None
            for section in sections:
                if "Strategic Investment Insights" in section:
                    current_section = "strategic_insights"
                elif "Timing Considerations" in section:
                    current_section = "timing_considerations"
                elif "Portfolio Fit" in section:
                    current_section = "portfolio_fit"
                elif "Risk Management" in section:
                    current_section = "risk_management"
                elif "Alternative Scenarios" in section:
                    current_section = "alternative_scenarios"
                elif "Monitoring Points" in section:
                    current_section = "monitoring_points"
                elif current_section and section.strip():
                    parsed_analysis[current_section] = section.strip()
            
            return parsed_analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI strategic response: {str(e)}")
            return {"raw_response": response}


    async def analyze_stock(self, symbol: str) -> dict:
        """Stub for compatibility with coordinator. Calls analyze method."""
        try:
            return await self.analyze(symbol)
        except Exception as e:
            self.logger.error(f"Error in analyze_stock: {e}")
            return {"error": str(e)}


