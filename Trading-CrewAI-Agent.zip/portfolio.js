// Portfolio Dashboard Module
(function(){
  const api = new APIClient();
  const currency = CONFIG.market?.currencySymbol || '₹';

  function fmt(n){
    try { return new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(n); } catch { return n; }
  }

  async function fetchHoldings(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/holdings');
    return res && res.success ? res.data : { cash: 0, holdings: [] };
  }

  async function fetchMargins(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/margins');
    return res && res.success ? res.data : { available: 0, used: 0, net: 0 };
  }

  async function lastPrice(sym){
    const res = await api.makeRequest(`/api/proxy/pta/market/last_price/${encodeURIComponent(sym)}`, { skipCache: true });
    return res && res.success ? res.data?.last_price : null;
  }

  function el(id){ return document.getElementById(id); }

  async function renderSummary(cash, holdings){
    const totalPosVal = await holdings.reduce(async (accP, h) => {
      const acc = await accP; const lp = await lastPrice(h.symbol); return acc + (lp || 0) * h.quantity; 
    }, Promise.resolve(0));
    const total = cash + totalPosVal;
    const container = el('portfolioSummary');
    if (!container) return;
    const stats = container.querySelectorAll('.portfolio-stat .stat-value');
    if (stats && stats.length >= 3){
      stats[0].textContent = `${currency} ${fmt(total)}`;
      stats[1].textContent = `${currency} ${fmt(0)}`; // day change placeholder
      stats[2].textContent = `${fmt(holdings.length)}`;
    }
  }

  // On landing page we only maintain the summary widget; full table lives on portfolio.html
  async function renderTable(holdings){ return; }

  async function init(){
    try {
      const [hold, marg] = await Promise.all([fetchHoldings(), fetchMargins()]);
      const holdings = hold.holdings || [];
      await renderSummary(hold.cash || marg.available || 0, holdings);
  await renderTable(holdings); // no-op on landing page
      // Attempt adapter subscribe for current symbols to improve LTP updates
      const symbols = holdings.map(h => h.symbol);
      if (symbols.length){
        await api.makeRequest('/api/proxy/pta/adapter/subscribe', { method: 'POST', body: JSON.stringify({ symbols }) });
      }
    } catch (e){ console.warn('Portfolio init failed', e); }
  }

  // Lazy start when DOM ready
  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else { init(); }
})();
