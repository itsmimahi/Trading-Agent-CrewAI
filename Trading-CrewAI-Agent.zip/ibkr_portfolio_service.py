"""IBKR paper trading portfolio service — IBKR-only, no fallback.

Wraps ib_insync with:
- Real-time account-update subscription (push events from TWS/Gateway)
- Thread-safe TTL cache (IB_PORTFOLIO_TTL env var, default 30 s)
- Auto-reconnect on disconnect
- Single process-wide singleton via ``get_ibkr_service()``

Environment variables
---------------------
IB_ENABLED          Set to "1" to activate (default "0" = disabled)
IB_HOST             TWS/Gateway host (default "127.0.0.1")
IB_PORT             TWS/Gateway port (default 7497 for live, 7496 for paper)
IB_CLIENT_ID        IB client ID (default 108)
IB_ACCOUNT          Account number, e.g. "DU123456" (default: first account)
IB_EXCHANGE         Default exchange for order routing (default "SMART")
IB_CURRENCY         Default currency (default "USD")
IB_ALLOW_TRADES     Set to "1" to enable order placement (default "0")
IB_PORTFOLIO_TTL    Seconds before cache is considered stale (default 30)
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any, Dict, List, Optional

try:
    from ib_insync import IB, Stock, MarketOrder  # type: ignore
    _IB_AVAILABLE = True
except Exception:
    IB = None  # type: ignore
    Stock = None  # type: ignore
    MarketOrder = None  # type: ignore
    _IB_AVAILABLE = False

logger = logging.getLogger(__name__)


class IBKRPortfolioService:
    """
    Live IBKR portfolio service for the advisory agent.

    Maintains a persistent IB connection, subscribes to account-update push
    events for real-time state, and exposes holdings / metrics / order
    operations.  No fallback to any other broker or local simulation.

    Usage::

        svc = IBKRPortfolioService()
        svc.connect()                     # call once at startup
        snapshot = svc.get_snapshot()     # call per advisory request
        svc.disconnect()                  # call at shutdown
    """

    def __init__(self) -> None:
        self._host = os.getenv("IB_HOST", "127.0.0.1")
        self._port = int(os.getenv("IB_PORT", "7497"))
        self._client_id = int(os.getenv("IB_CLIENT_ID", "108"))
        self._account = os.getenv("IB_ACCOUNT", "")
        self._exchange = os.getenv("IB_EXCHANGE", "SMART")
        self._currency = os.getenv("IB_CURRENCY", "USD")
        self._allow_trades = os.getenv("IB_ALLOW_TRADES", "0") == "1"
        self._cache_ttl = int(os.getenv("IB_PORTFOLIO_TTL", "30"))

        self._ib: Optional[Any] = None
        self._lock = threading.Lock()

        # Portfolio cache (populated by _refresh_cache)
        self._cache_holdings: Dict[str, Any] = {}
        self._cache_metrics: Dict[str, Any] = {}
        self._cache_ts: float = 0.0

        # Real-time shadow state — updated via IB push event callbacks
        self._rt_cash: float = 0.0
        self._rt_net_liq: float = 0.0
        self._rt_unrealized_pnl: float = 0.0
        self._rt_realized_pnl: float = 0.0
        self._rt_margin_used: float = 0.0
        self._rt_positions: List[Dict[str, Any]] = []
        self._rt_initialized: bool = False  # True once at least one full summary received

    # ─────────────────────────────────────────────────────────────────────────
    # Connection management
    # ─────────────────────────────────────────────────────────────────────────

    def connect(self) -> bool:
        """Connect to IB Gateway / TWS and subscribe to account updates.

        Returns True on success, False otherwise.
        """
        if not _IB_AVAILABLE:
            logger.error("IBKRPortfolioService: ib_insync not installed — run: pip install ib_insync")
            return False
        if os.getenv("IB_ENABLED", "0") != "1":
            logger.warning(
                "IBKRPortfolioService: IB_ENABLED != '1' — not connecting. "
                "Set IB_ENABLED=1 to activate."
            )
            return False

        with self._lock:
            if self._ib is not None and self._ib.isConnected():
                return True
            try:
                ib = IB()
                ib.connect(
                    host=self._host,
                    port=self._port,
                    clientId=self._client_id,
                    timeout=10,
                    account=self._account or None,
                )
                # Use delayed free data for paper trading (type 4).
                # Falls back silently — some paper accounts allow real-time.
                try:
                    ib.reqMarketDataType(4)
                except Exception:
                    pass

                # Subscribe to real-time push events
                ib.accountValueEvent += self._on_account_value
                ib.positionEvent += self._on_position
                ib.reqAccountUpdates(subscribe=True, acctCode=self._account or "")

                self._ib = ib
                logger.info(
                    "IBKRPortfolioService connected | host=%s port=%s client_id=%s account=%s",
                    self._host,
                    self._port,
                    self._client_id,
                    self._account or "<default>",
                )
                # Warm the cache immediately so first advisory request has data
                self._refresh_cache()
                return True
            except Exception as exc:
                logger.error("IBKRPortfolioService.connect failed: %s", exc)
                self._ib = None
                return False

    def disconnect(self) -> None:
        """Cleanly unsubscribe and disconnect."""
        with self._lock:
            if self._ib is not None:
                try:
                    self._ib.reqAccountUpdates(subscribe=False, acctCode=self._account or "")
                    self._ib.disconnect()
                except Exception:
                    pass
                self._ib = None
                logger.info("IBKRPortfolioService disconnected")

    def is_connected(self) -> bool:
        """Return True if the IB connection is alive."""
        return self._ib is not None and bool(self._ib.isConnected())

    def _ensure_connected(self) -> bool:
        """Reconnect if the link dropped.  Returns True if connected."""
        if self.is_connected():
            return True
        logger.warning("IBKRPortfolioService: connection lost — attempting reconnect…")
        return self.connect()

    # ─────────────────────────────────────────────────────────────────────────
    # Real-time push event handlers (called from ib_insync event loop)
    # ─────────────────────────────────────────────────────────────────────────

    def _on_account_value(self, account_value: Any) -> None:
        """IB push: account value tag changed."""
        tag = getattr(account_value, "tag", "")
        try:
            val = float(getattr(account_value, "value", 0.0) or 0.0)
        except Exception:
            return
        if tag == "AvailableFunds":
            self._rt_cash = val
        elif tag == "NetLiquidation":
            self._rt_net_liq = val
        elif tag == "UnrealizedPnL":
            self._rt_unrealized_pnl = val
        elif tag == "RealizedPnL":
            self._rt_realized_pnl = val
        elif tag == "MaintMarginReq":
            self._rt_margin_used = val
        self._rt_initialized = True
        # Invalidate cache so next get_holdings/get_metrics reads fresh data
        self._cache_ts = 0.0

    def _on_position(self, position: Any) -> None:
        """IB push: a position changed."""
        contract = getattr(position, "contract", None)
        symbol = (getattr(contract, "symbol", "") or "") if contract else ""
        qty = int(getattr(position, "position", 0) or 0)
        avg = float(getattr(position, "avgCost", 0.0) or 0.0)
        with self._lock:
            if qty == 0:
                self._rt_positions = [p for p in self._rt_positions if p.get("symbol") != symbol]
            else:
                existing = next(
                    (p for p in self._rt_positions if p.get("symbol") == symbol), None
                )
                if existing:
                    existing["quantity"] = qty
                    existing["avg_price"] = avg
                else:
                    self._rt_positions.append(
                        {"symbol": symbol, "quantity": qty, "avg_price": avg}
                    )
        self._cache_ts = 0.0

    # ─────────────────────────────────────────────────────────────────────────
    # Cache management
    # ─────────────────────────────────────────────────────────────────────────

    def _is_cache_valid(self) -> bool:
        return (time.time() - self._cache_ts) < self._cache_ttl

    def _refresh_cache(self) -> None:
        """Pull the latest holdings and account summary from IB and repopulate cache."""
        if not self._ensure_connected():
            return
        try:
            # Pump the ib_insync event loop briefly to drain pending push messages
            self._ib.sleep(0.3)

            # Positions
            positions = self._ib.positions()
            portfolio_list: List[Dict[str, Any]] = []
            for p in positions:
                c = getattr(p, "contract", None)
                sym = (getattr(c, "symbol", "") or "") if c else ""
                qty = int(getattr(p, "position", 0) or 0)
                avg = float(getattr(p, "avgCost", 0.0) or 0.0)
                if sym:
                    portfolio_list.append({"symbol": sym, "quantity": qty, "avg_price": avg})

            # Account summary
            cash = net = upnl = rpnl = margin_used = 0.0
            for row in self._ib.accountSummary():
                tag = getattr(row, "tag", "")
                try:
                    val = float(getattr(row, "value", 0.0) or 0.0)
                except Exception:
                    continue
                if tag == "AvailableFunds":
                    cash = val
                elif tag == "NetLiquidation":
                    net = val
                elif tag == "UnrealizedPnL":
                    upnl = val
                elif tag == "RealizedPnL":
                    rpnl = val
                elif tag == "MaintMarginReq":
                    margin_used = val

            now = time.time()
            with self._lock:
                self._cache_holdings = {
                    "broker": "ib",
                    "cash": cash,
                    "holdings": portfolio_list,
                    "positions_count": len(portfolio_list),
                    "as_of": now,
                }
                self._cache_metrics = {
                    "broker": "ib",
                    "cash": cash,
                    "total_value_est": net,
                    "unrealized_pnl": upnl,
                    "realized_pnl": rpnl,
                    "margin_used": margin_used,
                    "as_of": now,
                }
                self._cache_ts = now

            logger.debug(
                "IBKRPortfolioService cache refreshed | positions=%d cash=%.2f net=%.2f",
                len(portfolio_list),
                cash,
                net,
            )
        except Exception as exc:
            logger.warning("IBKRPortfolioService._refresh_cache failed: %s", exc)

    # ─────────────────────────────────────────────────────────────────────────
    # Portfolio queries (called by advisory flow)
    # ─────────────────────────────────────────────────────────────────────────

    def get_holdings(self) -> Dict[str, Any]:
        """Return current holdings and cash from the IBKR paper account.

        Returns a cached response if still within the TTL window; otherwise
        fetches fresh data from IB.
        """
        if not self._is_cache_valid():
            self._refresh_cache()
        if self._cache_holdings:
            return dict(self._cache_holdings)
        return {
            "error": (
                "IBKR not connected — set IB_ENABLED=1 and start TWS/IB Gateway "
                f"on {self._host}:{self._port}"
            ),
            "broker": "ib",
            "cash": 0.0,
            "holdings": [],
        }

    def get_metrics(self) -> Dict[str, Any]:
        """Return portfolio metrics (net liquidation, P&L) from IBKR."""
        if not self._is_cache_valid():
            self._refresh_cache()
        if self._cache_metrics:
            return dict(self._cache_metrics)
        return {
            "error": (
                "IBKR not connected — set IB_ENABLED=1 and start TWS/IB Gateway "
                f"on {self._host}:{self._port}"
            ),
            "broker": "ib",
            "cash": 0.0,
            "total_value_est": 0.0,
        }

    def get_margins(self) -> Dict[str, Any]:
        """Return margin/buying-power info from IBKR (always live, not cached)."""
        if not self._ensure_connected():
            return {"error": "IBKR not connected", "broker": "ib", "available": 0.0}
        try:
            self._ib.sleep(0.2)
            available = net = margin_used = 0.0
            for row in self._ib.accountSummary():
                tag = getattr(row, "tag", "")
                try:
                    val = float(getattr(row, "value", 0.0) or 0.0)
                except Exception:
                    continue
                if tag == "AvailableFunds":
                    available = val
                elif tag == "NetLiquidation":
                    net = val
                elif tag == "MaintMarginReq":
                    margin_used = val
            return {
                "broker": "ib",
                "available": available,
                "used": margin_used,
                "net": net,
                "as_of": time.time(),
            }
        except Exception as exc:
            return {"error": f"margins failed: {exc}", "broker": "ib"}

    def get_snapshot(self) -> Dict[str, Any]:
        """Return a combined live snapshot for the advisory flow.

        Merges holdings + metrics into a single dict.  Called at
        ``initialize_flow`` and again before ``execution_step``.
        """
        holdings = self.get_holdings()
        metrics = self.get_metrics()
        return {
            "broker": "ib",
            "cash": holdings.get("cash", 0.0),
            "holdings": holdings.get("holdings", []),
            "positions_count": holdings.get("positions_count", 0),
            "total_value_est": metrics.get("total_value_est", 0.0),
            "unrealized_pnl": metrics.get("unrealized_pnl", 0.0),
            "realized_pnl": metrics.get("realized_pnl", 0.0),
            "margin_used": metrics.get("margin_used", 0.0),
            "as_of": holdings.get("as_of", time.time()),
            "error": holdings.get("error") or metrics.get("error"),
        }

    def get_last_price(self, symbol: str) -> Dict[str, Any]:
        """Fetch the last market price for a symbol via IB market data."""
        if not self._ensure_connected():
            return {"error": "IBKR not connected", "broker": "ib"}
        if Stock is None:
            return {"error": "ib_insync Stock class unavailable", "broker": "ib"}
        try:
            contract = Stock(symbol.upper(), self._exchange, self._currency)
            self._ib.qualifyContracts(contract)
            ticker = self._ib.reqMktData(contract, "", False, False)
            self._ib.sleep(0.8)
            price = float(ticker.marketPrice() or 0.0)
            return {"broker": "ib", "symbol": symbol.upper(), "last_price": price}
        except Exception as exc:
            return {"error": f"last_price failed: {exc}", "broker": "ib"}

    # ─────────────────────────────────────────────────────────────────────────
    # Order operations
    # ─────────────────────────────────────────────────────────────────────────

    def preview_order(self, symbol: str, side: str, quantity: int) -> Dict[str, Any]:
        """Estimate the cost of a potential order without placing it."""
        if quantity <= 0:
            return {"error": "quantity must be > 0", "broker": "ib"}
        px_data = self.get_last_price(symbol)
        if "error" in px_data:
            return px_data
        last_px = float(px_data.get("last_price", 0.0))
        est = last_px * int(quantity)
        fee = max(1.0, est * 0.0005)
        return {
            "broker": "ib",
            "symbol": symbol.upper(),
            "side": side.lower(),
            "quantity": int(quantity),
            "last_price": last_px,
            "estimated_total": est + fee,
            "estimated_fees": fee,
            "preview": True,
        }

    def place_order(
        self,
        symbol: str,
        side: str,
        quantity: int,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Place a paper trade order via IBKR.

        Requires ``IB_ALLOW_TRADES=1``.  Invalidates the cache after placement
        so the next portfolio fetch reflects the updated position.
        """
        if not self._allow_trades:
            return {
                "error": "IBKR order placement blocked — set IB_ALLOW_TRADES=1",
                "broker": "ib",
            }
        if not self._ensure_connected():
            return {"error": "IBKR not connected", "broker": "ib"}
        if MarketOrder is None or Stock is None:
            return {"error": "ib_insync contract/order classes unavailable", "broker": "ib"}
        if quantity <= 0:
            return {"error": "quantity must be > 0", "broker": "ib"}
        try:
            contract = Stock(symbol.upper(), self._exchange, self._currency)
            self._ib.qualifyContracts(contract)
            action = "BUY" if str(side).lower() == "buy" else "SELL"
            order = MarketOrder(action, int(quantity))
            trade = self._ib.placeOrder(contract, order)
            self._ib.sleep(1.5)
            status = getattr(getattr(trade, "orderStatus", None), "status", "Submitted")
            # Invalidate cache — position will change after fill
            self._cache_ts = 0.0
            logger.info(
                "IBKRPortfolioService.place_order | symbol=%s side=%s qty=%d status=%s key=%s",
                symbol.upper(),
                action,
                quantity,
                status,
                idempotency_key,
            )
            return {
                "broker": "ib",
                "status": status,
                "idempotency_key": idempotency_key,
                "order": {
                    "symbol": symbol.upper(),
                    "side": side.lower(),
                    "quantity": int(quantity),
                },
            }
        except Exception as exc:
            return {"error": f"place_order failed: {exc}", "broker": "ib"}

    def list_orders(self) -> List[Dict[str, Any]]:
        """Return all open / recently filled orders from IBKR."""
        if not self._ensure_connected():
            return [{"error": "IBKR not connected", "broker": "ib"}]
        try:
            out: List[Dict[str, Any]] = []
            for tr in self._ib.trades():
                c = getattr(tr, "contract", None)
                o = getattr(tr, "order", None)
                s = getattr(tr, "orderStatus", None)
                out.append(
                    {
                        "broker": "ib",
                        "symbol": getattr(c, "symbol", ""),
                        "side": (
                            "buy"
                            if str(getattr(o, "action", "")).upper() == "BUY"
                            else "sell"
                        ),
                        "quantity": int(getattr(o, "totalQuantity", 0) or 0),
                        "status": getattr(s, "status", ""),
                    }
                )
            return out
        except Exception as exc:
            return [{"error": f"list_orders failed: {exc}", "broker": "ib"}]


# ─────────────────────────────────────────────────────────────────────────────
# Process-wide singleton
# ─────────────────────────────────────────────────────────────────────────────

_service: Optional[IBKRPortfolioService] = None
_service_lock = threading.Lock()


def get_ibkr_service() -> IBKRPortfolioService:
    """Return the process-wide singleton ``IBKRPortfolioService``.

    Auto-connects on first call; attempts reconnect if the link dropped.
    """
    global _service
    with _service_lock:
        if _service is None:
            _service = IBKRPortfolioService()
            _service.connect()
        elif not _service.is_connected():
            _service.connect()
        return _service
