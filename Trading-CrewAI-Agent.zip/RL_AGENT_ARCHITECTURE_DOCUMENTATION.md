# 🧠 RL Agent System - Comprehensive Architecture & Design Documentation (Updated)

## 📋 Executive Summary

This document provides an up-to-date architectural analysis of the **Reinforcement Learning (RL) Trading Agent System**, reflecting the current code in `RL_Agent/`. It details algorithms, environment mechanics, reward design, APIs, integration bridges, and operational guidance. The RL Agent is the adaptive learning engine that continuously optimizes trading strategies based on market feedback and performance outcomes, and integrates with the CrewAI advisory system over HTTP or an event bus.

What's new in this revision (2025-09 update):
- Verified mapping to current modules: `rl_agent.py`, `trading_environment.py`, `rl_api.py`, `integration_api.py`, `run_rl_api.py`, `bridge_api.py`, `rl_event_worker.py`, `crewai_integration.py`.
- Added missing RL API endpoint: `POST /api/rl/agents/<id>/training/stop` (best‑effort stop request).
- Documented training hyperparameter overrides via `algo_params` (DQN/PPO/A2C) and new device selection env vars `RL_DEVICE`, `RL_USE_CUDA`.
- Clarified difference between implemented features vs roadmap (removed previous overstatements about attention layers, residual connections, Monte Carlo, walk‑forward, dynamic algorithm switching—these are NOT implemented yet).
- Corrected observation space note: environment now derives shape from 22 feature columns; only the optional `CustomTradingNetwork` still assumes 25 features and would need adaptation.
- Explicitly distinguished "Implemented" vs "Planned/Roadmap" capabilities in Advanced Features section.
- Minor wording & accuracy improvements (e.g., feature count alignment, integration path clarification).

---

## 🏗️ System Architecture Overview

The RL Agent System employs a **learning-driven architecture** with the following key components:

1. **🧠 Core RL Agent (`rl_agent.py`)** – Multi-algorithm learning engine (DQN, PPO, A2C) using Stable-Baselines3
2. **🌍 Trading Environment (`trading_environment.py`)** – Gymnasium-compatible market simulator using Yahoo Finance + TA-Lib
3. **🔗 Integration Layer** – CrewAI HTTP integration (`crewai_integration.py`, `integration_api.py`) and optional Redis Streams worker (`rl_event_worker.py`)
4. **🛠️ API Services** – RL Agent HTTP API (`rl_api.py`) with runner (`run_rl_api.py`); legacy `main.py`
5. **🧩 Compatibility Bridge** – Lightweight shim (`bridge_api.py`) to avoid 404s when the full integration isn’t active
6. **📊 Performance Analytics** – Training callback with periodic evaluation, best model checkpoint, plotting utilities

---

## 🔍 Complete System Analysis

### 1. 🧠 Core RL Agent Engine

#### 1.1 🎯 **RLTradingAgent** - Main Learning Engine
Location: `RL_Agent/rl_agent.py`
Purpose: Main RL agent with multi-algorithm support, training pipeline, evaluation/backtesting, model save/load, and explainable predictions.

**🔧 Core Capabilities:**
- Multi-Algorithm Support: DQN, PPO, A2C (Stable-Baselines3)
- Model Architectures:
    - Default policy: MlpPolicy (feed-forward) for reliability and simplicity
    - CustomTradingNetwork: CNN + Dense hybrid defined and available but not wired by default
- Training Pipeline with periodic evaluation and best-model checkpointing
- Evaluation and Backtesting utilities
- Explainable Predictions: action + confidence + textual explanation
- Model Persistence: save/load with metadata

**🛠️ Key Features:**

##### 🧮 Model Architectures

1) Default (in use): Stable-Baselines3 MlpPolicy
- A robust feed-forward network provided by SB3; chosen for stability and quick training.

2) CustomTradingNetwork (available, optional)
- Class `CustomTradingNetwork(nn.Module)` defines a hybrid CNN + Dense architecture:
    - CNN 1D stack: [Conv1d(25→64), Conv1d(64→128), Conv1d(128→64)] with ReLU
    - Dense branch for portfolio features (6 → 32)
    - Combined MLP: 512 → 256 → 128 → output(action_space)
- Status: Defined but not plugged into the training loop by default. To use, you’d implement a custom SB3 policy that wraps this module and pass it as the policy to DQN/PPO/A2C.

##### **🎯 Supported RL Algorithms:**

1. **🎲 Deep Q-Network (DQN)**
   - **Use Case**: Discrete trading decisions
   - **Actions**: Hold, Buy, Sell, Close Position
   - **Strengths**: Stable learning, good for beginners
   - **Implementation**: Stable Baselines3 DQN

2. **🎭 Proximal Policy Optimization (PPO)**
   - **Use Case**: Continuous allocation optimization
   - **Actions**: Position sizing, allocation percentages
   - **Strengths**: Sample efficient, stable gradients
   - **Implementation**: Stable Baselines3 PPO

3. **⚡ Advantage Actor-Critic (A2C)**
   - **Use Case**: Multi-agent coordination learning
   - **Actions**: Combined discrete + continuous actions
   - **Strengths**: Fast learning, good exploration
   - **Implementation**: Stable Baselines3 A2C

**🔗 Integration Points:**
- Receives strategy requests from CrewAI via Integration API
- Accepts feedback (performance, market regime, strategy validation)
- Exposes evaluation, backtest, predict endpoints
- Optional non-HTTP message handling via Redis Streams worker

---

#### 1.2 📊 **TradingCallback** - Training Monitor
Location: `RL_Agent/rl_agent.py`
Purpose: Advanced training monitoring and evaluation during `.learn()`.

**🔧 Core Capabilities:**
- **Real-time Training Metrics** monitoring
- **Periodic Model Evaluation** during training
- **Best Model Checkpointing**
- **Episode Reward Tracking**
- **Performance Visualization**

Key Features:
- Configurable evaluation frequency
- Automatic best model saving
- Episode statistics collection
- Training progress logging (stdout/CSV/TensorBoard)

---

### 2. 🌍 Trading Environment Engine

#### 2.1 🏪 **TradingEnvironment** - Market Simulation
Location: `RL_Agent/trading_environment.py`
Purpose: Gymnasium-compatible trading environment with realistic costs and risk constraints.

**🔧 Core Capabilities:**
- Gymnasium-compatible Env (Discrete(4) actions)
- Realistic market simulation using Yahoo Finance data (`yfinance`), with robust dummy fallback
- Technical indicators via TA-Lib and rolling features
- Transaction cost modeling and position sizing
- Risk management: drawdown tracking and penalties

**🛠️ Key Features:**

##### 📈 Market Data Integration
- Yahoo Finance historical data with explicit `start_date`/`end_date`
- Forward/backward fill for missing values
- Graceful dummy data fallback when downloads fail (ensures tests don’t break)

##### 🔧 Technical Indicators Suite (as implemented)
- Moving Averages: SMA(5, 10, 20), EMA(12, 26)
- Momentum: RSI(14), MACD (macd, signal, histogram)
- Volatility: Bollinger Bands (upper, middle, lower, width), ATR
- Volume: Volume, Volume_SMA(20)
- Price: Price_Change (1d), Price_Change_5d

##### 🎯 Action Space
- Discrete(4):
    - 0: HOLD – Maintain
    - 1: BUY – Buy ~10% of portfolio value worth of shares (capped by max position)
    - 2: SELL – Sell ~50% of current position
    - 3: CLOSE – Close entire position

##### 📊 Observation Space
- Lookback window: default 20
- Feature columns currently used (22):
    `Open, High, Low, Close, Volume, SMA_5, SMA_10, SMA_20, EMA_12, EMA_26, RSI, MACD, MACD_signal, MACD_histogram, BB_upper, BB_middle, BB_lower, BB_width, ATR, Volume_SMA, Price_Change, Price_Change_5d`
- Portfolio features (6): `cash_ratio, portfolio_value_ratio, position_ratio, avg_price_ratio, unrealized_pnl_ratio, drawdown`
- Effective observation length ≈ `lookback_window * 22 + 6` (with zero-padding at episode start)
Note: The environment dynamically sets observation size using the current 22 feature columns * lookback + 6 portfolio features. The earlier constant (25 features/timestep) now only exists as the default argument in `CustomTradingNetwork(features_per_timestep=25)`; if you enable that custom network you must either (a) pass `features_per_timestep=22` or (b) extend the feature set to 25.

##### 💰 Trading, Costs, and Risk
- Transaction cost: percentage of trade value (default 0.1%)
- Position sizing: BUY takes ~10% of portfolio value; SELL reduces 50% of current position; CLOSE exits fully
- Risk: drawdown tracked vs max portfolio value; penalties applied beyond threshold (default 20%)
- Portfolio tracking: balance, position, avg buy price, unrealized P&L, portfolio value, trades count

**🔗 Integration Points:**
- Core environment for training/evaluation/backtests
- Supports CrewAI strategy simulation calls via RL API

---

### 3. 🔗 Integration & Communication Layer

#### 3.1 🌉 **CrewAIIntegrationService** - Bridge to Advisory System
```python
📍 Location: RL Agent/crewai_integration.py
📊 Lines of Code: 623
🎯 Purpose: Seamless integration with CrewAI multi-agent system
```

**🔧 Core Capabilities:**
- **Bidirectional Communication** with CrewAI agents
- **Strategy Simulation Requests** handling
- **Performance Feedback** processing
- **Health Monitoring** of both systems
- **Communication History** tracking

**🛠️ Key Features:**

##### **📨 Strategy Request Processing:**
```python
@dataclass
class StrategyRequest:
    strategy_description: str  # Natural language strategy
    symbol: str               # Target trading symbol
    start_date: str          # Simulation start date
    end_date: str            # Simulation end date
    initial_balance: float   # Starting capital
    agent_id: str           # RL agent identifier
    requester_agent: str    # CrewAI agent making request
```

##### **🔄 Feedback Loop Management:**
```python
@dataclass
class FeedbackData:
    feedback_type: str        # 'performance', 'market_regime', 'strategy_validation'
    feedback_data: Dict       # Detailed feedback information
    source_agent: str        # CrewAI agent providing feedback
    timestamp: str           # Feedback timestamp
    confidence: float        # Confidence level (0-1)
```

##### **🏥 Health Monitoring:**
- **RL Agent Health Checks**: Continuous availability monitoring
- **CrewAI System Health**: Advisory system connectivity
- **Communication Metrics**: Success rates, response times
- **Error Handling**: Robust fallback mechanisms

**🔗 Integration Points:**
- Main interface between RL and CrewAI systems
- Handles strategy validation requests
- Processes performance feedback from advisory agents
- Manages communication reliability and monitoring

---

#### 3.2 🔌 **RLIntegrationService** - Advisory-Side Integration
```python
📍 Location: RL Agent/rl_integration_service.py
📊 Lines of Code: 610
🎯 Purpose: CrewAI-side integration service
```

**🔧 Core Capabilities:**
- **Strategy Validation Requests** to RL agent
- **Performance Feedback Delivery** to RL system
- **Market Regime Signaling** 
- **Learned Rules Retrieval** from RL agent
- **Integration Status Monitoring**

**🛠️ Key Features:**

##### **🎯 Strategy Validation:**
```python
@dataclass
class StrategyValidationRequest:
    strategy_description: str    # Strategy to validate
    symbol: str                 # Trading symbol
    timeframe: str             # Time horizon
    confidence: float          # Strategy confidence
    requesting_agent: str      # Agent requesting validation
    additional_context: Dict   # Extra context data
```

##### **📊 Performance Feedback:**
```python
@dataclass
class PerformanceFeedback:
    metrics: Dict[str, float]           # Performance metrics
    benchmark_comparison: Dict          # Benchmark comparisons
    risk_assessment: Dict              # Risk analysis
    recommendations: List[str]         # Improvement suggestions
```

**🔗 Integration Points:**
- Called by CrewAI agents for strategy validation
- Delivers performance feedback to RL system
- Retrieves learned insights for advisory decisions
- Monitors integration health and status

---

#### 3.3 📨 Event Bus Worker (Optional)
Location: `RL_Agent/rl_event_worker.py`
Purpose: Listens to Redis Streams (if `REDIS_URL` is configured) to exchange messages between advisory and RL systems without HTTP.

Streams consumed (prefix `a2a:` internal to EventBus):
- `rl:performance_feedback` – Records performance feedback; replies with ack
- `rl:regime_change` – Records market regime updates; replies with ack
- `rl:get_weight_updates` – Returns last cached weight updates (or `has_updates=False`)
- `rl:get_learning_insights` – Returns last cached insights (placeholder by default)
- `rl:validate_strategy` – Placeholder; advises HTTP endpoint usage

Notes:
- Requires `integration.event_bus.RedisStreamsEventBus` to be importable (project root on PYTHONPATH) and a valid `REDIS_URL`.
- This worker focuses on lightweight message handling; heavy simulations/backtests remain on the HTTP RL API for now.

---

### 4. 🛠️ API Services Layer

#### 4.1 🌐 **RL API** - Core RL Agent API
Location: `RL_Agent/rl_api.py`
Purpose: Manage agents, training, evaluation, backtesting, predictions, and integrations.

**🔧 Core Capabilities:**
- **Agent Lifecycle Management** (Create, Delete, Monitor)
- **Training Pipeline Control** (Start, Stop, Monitor)
- **Model Management** (Save, Load, Export)
- **Evaluation & Backtesting** endpoints
- **Real-time Trading** simulation

Key Endpoints (as implemented):

Health & Listing
- GET `/api/rl/health` – Service health
- GET `/api/rl/agents` – List agents
- GET `/api/rl/agents/<agent_id>` – Agent info

Agent Lifecycle
- POST `/api/rl/agents` – Create agent (algorithm, symbol, dates, balance, lookback)
- DELETE `/api/rl/agents/<agent_id>` – Delete agent

Training
- POST `/api/rl/agents/<agent_id>/train` – Start async training (total_timesteps, eval_freq)
- GET  `/api/rl/agents/<agent_id>/training/status` – Status + history/results/errors
 - POST `/api/rl/agents/<agent_id>/training/stop` – Best-effort stop flag (cooperative; current training run finishes current SB3 loop chunk)

Evaluation & Testing
- POST `/api/rl/agents/<agent_id>/evaluate` – Evaluate (n_episodes)
- POST `/api/rl/agents/<agent_id>/backtest` – Backtest (start_date, end_date)
- POST `/api/rl/agents/<agent_id>/predict` – Predict next action for an observation

Integration Helpers
- POST `/api/rl/agents/<agent_id>/simulate_strategy` – Strategy simulation over period
- POST `/api/rl/agents/<agent_id>/feedback` – Store/process feedback
- GET  `/api/rl/agents/<agent_id>/learned_rules` – Simplified learned rules extraction

Model Persistence
- POST `/api/rl/agents/<agent_id>/save` – Save model + metadata
- POST `/api/rl/agents/<agent_id>/load` – Load model

Training Hyperparameter Overrides
- All algorithms accept an `algo_params` object on the train endpoint for selective overrides. Examples:
    - DQN: `{"learning_rate": 5e-5, "buffer_size": 100000}`
    - PPO: `{"n_steps": 1024, "ent_coef": 0.01}`
    - A2C: `{"n_steps": 10, "ent_coef": 0.02}`
Unspecified fields fall back to the defaults encoded in `rl_agent.py`.

**🔗 Integration Points:**
- Used by integration services for agent management
- Provides training control for automated learning
- Enables performance evaluation and backtesting
- Supports real-time trading simulation

---

#### 4.2 🔗 **Integration API** - CrewAI Communication
Location: `RL_Agent/integration_api.py`
Purpose: Fronts the CrewAI↔RL interactions with purpose-built endpoints.

**🔧 Core Capabilities:**
- **Strategy Simulation** for CrewAI agents
- **Feedback Reception** from advisory system
- **Performance Reporting** to CrewAI
- **Learning Insights** sharing
- **Market Regime Updates** handling

Key Endpoints (selection):

Health/Status
- GET `/api/integration/health`
- GET `/api/integration/status`

Setup
- POST `/api/integration/setup` – Create RL agent (and optionally start training)

CrewAI Interaction
- POST `/api/integration/crewai/simulate_strategy`
- POST `/api/integration/crewai/feedback`
- GET  `/api/integration/crewai/learned_rules`
- GET  `/api/integration/crewai/agent_status`
- POST `/api/integration/crewai/backtest`
- POST `/api/integration/crewai/predict`
- POST `/api/integration/crewai/market_regime_signal`
- POST `/api/integration/crewai/performance_feedback`

**🔗 Integration Points:**
- Main interface for CrewAI agent interactions
- Handles strategy simulation requests
- Processes performance feedback
- Shares learned insights with advisory system

---

#### 4.3 🚀 Runner & Bridge

- `run_rl_api.py`: Preferred runner creating a Flask app, registering the RL API (and optionally `bridge_api`), with root `/` and `/health` endpoints. Respects `RL_API_PORT`/`PORT` env for port selection.
- `bridge_api.py`: Provides lightweight compatibility endpoints:
    - GET `/api/learning_insights` (alias: `/api/insights`)
    - GET `/api/get_weight_updates`
    Use this when upstream components expect those routes but the full integration isn’t enabled yet.
- `main.py`: Legacy server wiring for an older stack (blueprints from `src/...`). Use `run_rl_api.py` for the current RL API.

---

## 🔄 Learning & Adaptation Architecture

### 🧠 **Multi-Algorithm Learning System**

#### **1. 🎲 DQN (Deep Q-Network) Learning**
```python
# Discrete Decision Learning
Action Space: [HOLD, BUY, SELL, CLOSE]
Network: CNN + Dense layers
Learning: Q-value optimization
Use Case: Basic trading decisions
```

**Learning Process:**
1. **Experience Collection**: Store (state, action, reward, next_state)
2. **Q-Value Updates**: Learn optimal action values
3. **Epsilon-Greedy Exploration**: Balance exploration vs exploitation
4. **Target Network Updates**: Stable learning with periodic updates

#### **2. 🎭 PPO (Proximal Policy Optimization) Learning**
```python
# Continuous Optimization Learning
Action Space: Position sizing (0.0 to 1.0)
Network: Actor-Critic architecture
Learning: Policy gradient optimization
Use Case: Portfolio allocation optimization
```

**Learning Process:**
1. **Policy Collection**: Gather trajectories under current policy
2. **Advantage Estimation**: Calculate action advantages
3. **Policy Updates**: Optimize policy with clipped objectives
4. **Value Function Updates**: Learn state value estimation

#### **3. ⚡ A2C (Advantage Actor-Critic) Learning**
```python
# Multi-Agent Coordination Learning
Action Space: Hybrid discrete + continuous
Network: Shared CNN + Separate heads
Learning: Actor-critic optimization
Use Case: Complex strategy coordination
```

**Learning Process:**
1. **Parallel Experience**: Multiple environment instances
2. **Advantage Calculation**: Actor-critic advantage estimation
3. **Simultaneous Updates**: Update actor and critic together
4. **Entropy Regularization**: Maintain exploration

### 📊 Performance Learning Framework

#### 🎯 Reward Function Design (as implemented)
The step reward includes the following components:
- Portfolio value change (scaled)
- Realized P&L when selling/closing positions
- Drawdown penalty when exceeding threshold
- Transaction cost penalty on trading actions
- Sharpe-like term using recent returns
- Periodic benchmark outperformance bonus (vs simplified 7% annual benchmark)

#### **📈 Learning Metrics Tracking**
```python
Training Metrics:
- Episode rewards and lengths
- Portfolio values over time
- Win/loss ratios
- Risk-adjusted returns
- Trading frequency and efficiency

Evaluation Metrics:
- Sharpe ratio
- Maximum drawdown
- Total return
- Volatility
- Alpha vs benchmark
```

### 🔄 **Integration Learning Loop**

#### **Phase 1: Strategy Request Processing**
```python
1. CrewAI Agent → Strategy Request → RL Agent
2. RL Agent → Environment Simulation → Performance Results
3. RL Agent → Results → CrewAI Agent
4. CrewAI Agent → Decision Implementation → Paper Trading
```

#### **Phase 2: Performance Feedback Learning**
```python
1. Paper Trading → Execution Results → Performance Agent
2. Performance Agent → Metrics Analysis → RL Integration Service
3. RL Integration Service → Feedback → RL Agent
4. RL Agent → Learning Update → Improved Strategies
```

#### **Phase 3: Continuous Adaptation**
```python
1. Market Data Updates → Environment State Updates
2. New State → RL Agent → Updated Predictions
3. Performance Feedback → Reward Updates → Learning
4. Improved Agent → Better Strategy Recommendations
```

---

## 🎯 **Advanced Features & Capabilities**

### 🧮 **Neural Architecture & Feature Processing**

Current Implementation (Implemented):
- Default Stable-Baselines3 `MlpPolicy` (feed-forward) for DQN/PPO/A2C
- Optional `CustomTradingNetwork`: 3 stacked Conv1d layers (no residual/attention), separate dense branch for 6 portfolio features, concatenated into MLP (512→256→128→actions)

Not Yet Implemented (Roadmap Ideas):
- Attention mechanisms over temporal features
- Explicit residual connections or multi-scale convolutional branches
- Hierarchical (short/medium/long horizon) feature fusion modules

Portfolio Feature Integration (Implemented):
- Cash ratio, portfolio value ratio, position ratio, average price ratio, unrealized PnL ratio, drawdown metric appended as last 6 features each timestep

If you adopt the custom network you must supply observations with the feature count it expects (adjust `features_per_timestep` accordingly).

### 📊 **Performance Analytics Engine**

Implemented:
- Episode reward & length tracking via custom callback
- Periodic evaluation (mean reward & std over 5 eval episodes)
- Best-model checkpointing
- Backtest statistics: total_return, annualized_return, volatility, Sharpe (simple), max_drawdown, win_rate, trades count
- Basic plotting helpers (training progress, backtest visualization)

Not Yet Implemented (Roadmap / Future Improvement):
- Walk-forward analysis automation
- Monte Carlo or bootstrap resampling of returns
- Scenario/stress testing modules
- Formal out-of-sample validation harness
- Sortino ratio & additional factor attribution reports

### 🔗 Integration Capabilities

#### **🌉 CrewAI Bridge Features**
```python
Integration Capabilities:
- Natural language strategy interpretation
- Multi-agent coordination learning
- Feedback loop optimization
- Performance attribution analysis
- Market regime adaptation
```

#### **🔄 Adaptive Learning System**
Current Mechanics (Implemented):
- Reward shaping combines portfolio change, realized PnL, drawdown penalty, transaction cost penalty, approximate Sharpe, benchmark outperformance bonus
- Manual hyperparameter override via `algo_params`

Planned / Not Implemented Yet:
- Automatic dynamic reward re-weighting
- On-the-fly algorithm switching based on regime detection
- Automated hyperparameter tuning loop
- Feature importance / explainability beyond heuristic action explanation
- Ensemble / model stacking of multiple policies

---

## 🏆 **Expected Learning Outcomes**

### 📈 **Performance Improvements**
1. **Strategy Optimization**: Continuously improve trading strategies
2. **Risk Management**: Learn optimal risk-reward trade-offs
3. **Market Adaptation**: Adapt to changing market conditions
4. **Timing Optimization**: Improve entry/exit timing decisions

### 🧠 **Intelligence Evolution**
1. **Pattern Recognition**: Identify profitable market patterns
2. **Regime Detection**: Recognize market regime changes
3. **Strategy Selection**: Learn when to use different strategies
4. **Risk Calibration**: Optimize risk parameters dynamically

### 🔄 **System Integration**
1. **Multi-Agent Learning**: Learn from advisory agent feedback
2. **Collective Intelligence**: Combine RL with expert knowledge
3. **Continuous Improvement**: Self-improving system performance
4. **Robust Decision Making**: Balanced human + AI intelligence

---

## 🚀 **Deployment & Scaling Architecture**

### 🏗️ **Infrastructure Requirements**

#### **💻 Computational Resources**
```python
Training Requirements:
- GPU: NVIDIA RTX 3080+ (8GB+ VRAM)
- CPU: Multi-core (8+ cores recommended)
- RAM: 16GB+ system memory
- Storage: SSD for fast data access

Production Requirements:
- CPU: 4+ cores for inference
- RAM: 8GB+ for model serving
- Network: Stable internet for market data
- Storage: Model persistence and logging
```

#### **🌐 Scalability Design**
```python
Horizontal Scaling:
- Multiple agent instances
- Distributed training capabilities
- Load balancing for API requests
- Database clustering for performance

Vertical Scaling:
- GPU acceleration for training
- Memory optimization for large models
- CPU optimization for inference
- Network optimization for real-time data
```

### 🔧 **Production Deployment**

#### **🐳 Container Architecture**
```python
Docker Deployment:
- RL Agent container with GPU support
- API gateway for load balancing
- Database container for persistence
- Monitoring container for observability
```

#### **☁️ Cloud Integration**
```python
Cloud Deployment Options:
- AWS: EC2 with GPU instances
- GCP: Compute Engine with TPUs
- Azure: Virtual Machines with ML services
- Kubernetes orchestration for scaling
```

---

## 🎯 **Integration with Main Advisory System**

### 🔄 **Three-Tier Intelligence Integration**

#### **Tier 1: Main Advisory Agent**
- **Receives**: User queries and market context
- **Sends**: Strategy requests to RL agent
- **Integration**: Via CrewAI integration service

#### **Tier 2: RL Agent (Learning Engine)**
- **Receives**: Strategy requests and performance feedback
- **Processes**: Simulation and learning
- **Sends**: Validated strategies and learned insights

#### **Tier 3: Specialized Subagents**
- **Provides**: Domain expertise and analysis
- **Receives**: RL-validated strategies
- **Feedback**: Performance data to RL learning loop

### 🎯 **Learning Integration Flow**

```python
1. User Query → Main Advisory Agent
2. Advisory Agent → Strategy Generation → Subagents
3. Subagents → Strategy Analysis → Trade Strategy Planner
4. Strategy Planner → Strategy Validation → RL Agent
5. RL Agent → Strategy Simulation → Performance Results
6. Performance Results → Strategy Refinement → Final Decision
7. Final Decision → Paper Trading → Execution Results
8. Execution Results → Performance Feedback → RL Learning
9. RL Learning → Improved Strategies → Better Future Decisions
```

---

## ⚙️ Configuration & Dependencies

Environment Variables (Implemented):
- `RL_API_PORT` or `PORT`: HTTP port for `run_rl_api.py` (default 5000)
- `REDIS_URL`: Enables Redis Streams worker (`rl_event_worker.py`)
- `RL_DEVICE`: Force device (`cpu` | `cuda` | `gpu`) for SB3 models (defaults to CPU unless CUDA explicitly enabled)
- `RL_USE_CUDA`: If set to `1`, attempts to use CUDA when available (overrides absence of RL_DEVICE)

Directories:
- Created per agent automatically: `models/<agent_id>`, `logs/<agent_id>`

Core Dependencies (non-exhaustive):
- Runtime: `flask`, `flask-cors`
- RL: `torch`, `stable-baselines3`, `gymnasium`
- Data/Indicators: `yfinance`, `ta-lib` (prebuilt wheel included), `pandas`, `numpy`
- Visualization: `matplotlib`, `seaborn`

Note: Use the provided TA-Lib wheel on Windows if a build from source fails.

## ▶️ Running & Using the APIs

- Preferred: launch `run_rl_api.py` (respects `RL_API_PORT`). The root `/` and `/health` endpoints report capability and installed dependencies.
- RL API (`/api/rl/*`): create an agent, start training (async), get status, evaluate/backtest, predict, save/load.
- Integration API (`/api/integration/*`): CrewAI-oriented workflows (simulate_strategy, feedback, learned_rules, backtest, predict, regime signals).
- Bridge API (`/api/learning_insights`, `/api/get_weight_updates`): lightweight compatibility endpoints when the full integration isn’t active.

Example payloads (shape only):
- Create agent: `{ "agent_id": "main_rl_agent", "algorithm": "PPO", "symbol": "AAPL" }`
- Train: `{ "total_timesteps": 50000, "eval_freq": 5000 }`
- Backtest: `{ "start_date": "2023-01-01", "end_date": "2023-12-31" }`
- Predict: `{ "observation": [ ... float array length lookback*22+6 ... ], "deterministic": true }`
- Simulate strategy: `{ "strategy_description": "breakout", "symbol": "AAPL", "start_date": "2023-01-01", "end_date": "2023-12-31" }`

## ⚠️ Known Limitations and Notes

- The `CustomTradingNetwork` is not wired into SB3 policies; enabling it requires creating a custom `ActorCriticPolicy` (PPO/A2C) or `DQNPolicy` subclass that instantiates this network with the correct `features_per_timestep`.
- Feature count mismatch: environment uses 22 per timestep; custom net default is 25 → adjust parameter or extend feature engineering.
- Advanced analytics & adaptive mechanisms listed as roadmap are not present yet (attention, walk-forward, Monte Carlo, auto alg switching, etc.).
- Some legacy wiring (`main.py`, historic `src/...` imports) remains; prefer `run_rl_api.py` as the entrypoint.
- Fallback dummy price series is generated if `yfinance` fetch fails—suitable for smoke tests, not production training.
- Action explanation is heuristic; for production-grade interpretability integrate SHAP/LIME or feature attribution libraries.
- Event-bus worker depends on `integration.event_bus.RedisStreamsEventBus`; ensure PYTHONPATH includes project root & `REDIS_URL` is configured.

## 📊 Conclusion

The **RL Agent System** represents a robust, learning-driven trading intelligence that forms the adaptive backbone of the advisory system. With multi-algorithm capabilities, clear HTTP APIs, optional event-bus integration, and a realistic market environment, it’s production-lean yet extensible. The defined CustomTradingNetwork enables CNN+Dense experimentation; the default MlpPolicy balances performance and simplicity. Together, these components provide a strong foundation for a continuously improving trading advisor.
