"""
Agent Registry Model
Manages the registration and discovery of specialized agents.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from enum import Enum


class AgentStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"


@dataclass
class AgentCapability:
    """Represents a capability of an agent."""
    name: str
    description: str
    input_format: Dict[str, Any]
    output_format: Dict[str, Any]


@dataclass
class SpecializedAgent:
    """Represents a specialized agent in the registry."""
    agent_id: str
    name: str
    role: str
    description: str
    capabilities: List[AgentCapability]
    status: AgentStatus
    endpoint: str
    version: str
    last_updated: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert agent to dictionary format."""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "role": self.role,
            "description": self.description,
            "capabilities": [
                {
                    "name": cap.name,
                    "description": cap.description,
                    "input_format": cap.input_format,
                    "output_format": cap.output_format
                }
                for cap in self.capabilities
            ],
            "status": self.status.value,
            "endpoint": self.endpoint,
            "version": self.version,
            "last_updated": self.last_updated
        }


class AgentRegistry:
    """Registry for managing specialized agents."""
    
    def __init__(self):
        self._agents: Dict[str, SpecializedAgent] = {}
        self._initialize_default_agents()
    
    def _initialize_default_agents(self):
        """Initialize the registry with default specialized agents."""
        
        # Fundamental Research Agent
        fundamental_capabilities = [
            AgentCapability(
                name="company_analysis",
                description="Analyze company financials, ratios, and performance metrics",
                input_format={"symbol": "str", "period": "str", "metrics": "List[str]"},
                output_format={"analysis": "str", "key_metrics": "Dict", "recommendation": "str"}
            ),
            AgentCapability(
                name="industry_analysis",
                description="Analyze industry trends and competitive landscape",
                input_format={"industry": "str", "companies": "List[str]"},
                output_format={"trends": "List[str]", "competitive_analysis": "str", "outlook": "str"}
            )
        ]
        
        self.register_agent(SpecializedAgent(
            agent_id="fundamental_research",
            name="Fundamental Research Agent",
            role="Financial Analyst",
            description="Specializes in fundamental analysis of companies and industries",
            capabilities=fundamental_capabilities,
            status=AgentStatus.ACTIVE,
            endpoint="/api/agents/fundamental",
            version="1.0.0",
            last_updated="2025-01-01"
        ))
        
        # Technical Analysis Agent
        technical_capabilities = [
            AgentCapability(
                name="chart_analysis",
                description="Analyze stock price charts and technical indicators",
                input_format={"symbol": "str", "timeframe": "str", "indicators": "List[str]"},
                output_format={"signals": "List[str]", "support_resistance": "Dict", "trend": "str"}
            ),
            AgentCapability(
                name="pattern_recognition",
                description="Identify chart patterns and trading signals",
                input_format={"symbol": "str", "pattern_types": "List[str]"},
                output_format={"patterns": "List[Dict]", "signals": "List[str]"}
            )
        ]
        
        self.register_agent(SpecializedAgent(
            agent_id="technical_analysis",
            name="Technical Analysis Agent",
            role="Technical Analyst",
            description="Specializes in technical analysis and chart pattern recognition",
            capabilities=technical_capabilities,
            status=AgentStatus.ACTIVE,
            endpoint="/api/agents/technical",
            version="1.0.0",
            last_updated="2025-01-01"
        ))
        
        # Sentiment Analysis Agent
        sentiment_capabilities = [
            AgentCapability(
                name="news_sentiment",
                description="Analyze sentiment from news articles and reports",
                input_format={"symbol": "str", "sources": "List[str]", "timeframe": "str"},
                output_format={"sentiment_score": "float", "key_themes": "List[str]", "summary": "str"}
            ),
            AgentCapability(
                name="social_sentiment",
                description="Analyze sentiment from social media and forums",
                input_format={"symbol": "str", "platforms": "List[str]"},
                output_format={"sentiment_trend": "Dict", "volume": "int", "key_mentions": "List[str]"}
            )
        ]
        
        self.register_agent(SpecializedAgent(
            agent_id="sentiment_analysis",
            name="Sentiment Analysis Agent",
            role="Sentiment Analyst",
            description="Specializes in analyzing market sentiment from various sources",
            capabilities=sentiment_capabilities,
            status=AgentStatus.ACTIVE,
            endpoint="/api/agents/sentiment",
            version="1.0.0",
            last_updated="2025-01-01"
        ))
        
        # Macroeconomy Specialist Agent
        macro_capabilities = [
            AgentCapability(
                name="economic_indicators",
                description="Analyze economic indicators and their market impact",
                input_format={"indicators": "List[str]", "region": "str", "timeframe": "str"},
                output_format={"analysis": "str", "market_impact": "Dict", "outlook": "str"}
            ),
            AgentCapability(
                name="policy_analysis",
                description="Analyze monetary and fiscal policy impacts",
                input_format={"policy_type": "str", "region": "str", "details": "str"},
                output_format={"impact_analysis": "str", "sector_effects": "Dict", "timeline": "str"}
            )
        ]
        
        self.register_agent(SpecializedAgent(
            agent_id="macroeconomy_specialist",
            name="Macroeconomy Specialist Agent",
            role="Macroeconomic Analyst",
            description="Specializes in macroeconomic analysis and policy impact assessment",
            capabilities=macro_capabilities,
            status=AgentStatus.ACTIVE,
            endpoint="/api/agents/macro",
            version="1.0.0",
            last_updated="2025-01-01"
        ))
        
        # Risk Assessment Agent
        risk_capabilities = [
            AgentCapability(
                name="portfolio_risk",
                description="Assess portfolio risk and diversification",
                input_format={"holdings": "List[Dict]", "risk_metrics": "List[str]"},
                output_format={"risk_score": "float", "diversification_analysis": "Dict", "recommendations": "List[str]"}
            ),
            AgentCapability(
                name="scenario_analysis",
                description="Perform scenario and stress testing",
                input_format={"portfolio": "Dict", "scenarios": "List[str]"},
                output_format={"scenario_results": "Dict", "worst_case": "Dict", "mitigation_strategies": "List[str]"}
            )
        ]
        
        self.register_agent(SpecializedAgent(
            agent_id="risk_assessment",
            name="Risk Assessment Agent",
            role="Risk Analyst",
            description="Specializes in risk assessment and portfolio analysis",
            capabilities=risk_capabilities,
            status=AgentStatus.ACTIVE,
            endpoint="/api/agents/risk",
            version="1.0.0",
            last_updated="2025-01-01"
        ))
        
        # Timing Agent
        timing_capabilities = [
            AgentCapability(
                name="entry_timing",
                description="Determine optimal entry points for trades",
                input_format={"symbol": "str", "strategy": "str", "timeframe": "str"},
                output_format={"entry_signals": "List[Dict]", "confidence": "float", "rationale": "str"}
            ),
            AgentCapability(
                name="exit_timing",
                description="Determine optimal exit points and stop losses",
                input_format={"position": "Dict", "strategy": "str", "market_conditions": "Dict"},
                output_format={"exit_signals": "List[Dict]", "stop_loss": "float", "take_profit": "float"}
            )
        ]
        
        self.register_agent(SpecializedAgent(
            agent_id="timing_agent",
            name="Timing Agent",
            role="Timing Specialist",
            description="Specializes in market timing and entry/exit point optimization",
            capabilities=timing_capabilities,
            status=AgentStatus.ACTIVE,
            endpoint="/api/agents/timing",
            version="1.0.0",
            last_updated="2025-01-01"
        ))
        
        # Trade & Strategy Planner Agent
        strategy_capabilities = [
            AgentCapability(
                name="strategy_development",
                description="Develop comprehensive trading strategies",
                input_format={"goals": "Dict", "risk_tolerance": "str", "timeframe": "str", "capital": "float"},
                output_format={"strategy": "Dict", "allocation": "Dict", "execution_plan": "List[str]"}
            ),
            AgentCapability(
                name="trade_execution",
                description="Plan and optimize trade execution",
                input_format={"trades": "List[Dict]", "market_conditions": "Dict", "constraints": "Dict"},
                output_format={"execution_plan": "Dict", "order_sequence": "List[Dict]", "timing": "str"}
            )
        ]
        
        self.register_agent(SpecializedAgent(
            agent_id="trade_strategy_planner",
            name="Trade & Strategy Planner Agent",
            role="Strategy Planner",
            description="Specializes in trading strategy development and execution planning",
            capabilities=strategy_capabilities,
            status=AgentStatus.ACTIVE,
            endpoint="/api/agents/strategy",
            version="1.0.0",
            last_updated="2025-01-01"
        ))
    
    def register_agent(self, agent: SpecializedAgent) -> bool:
        """Register a new agent in the registry."""
        if agent.agent_id in self._agents:
            return False  # Agent already exists
        
        self._agents[agent.agent_id] = agent
        return True
    
    def get_agent(self, agent_id: str) -> Optional[SpecializedAgent]:
        """Get an agent by ID."""
        return self._agents.get(agent_id)
    
    def get_all_agents(self) -> List[SpecializedAgent]:
        """Get all registered agents."""
        return list(self._agents.values())
    
    def get_active_agents(self) -> List[SpecializedAgent]:
        """Get all active agents."""
        return [agent for agent in self._agents.values() if agent.status == AgentStatus.ACTIVE]
    
    def find_agents_by_capability(self, capability_name: str) -> List[SpecializedAgent]:
        """Find agents that have a specific capability."""
        matching_agents = []
        for agent in self._agents.values():
            if agent.status == AgentStatus.ACTIVE:
                for capability in agent.capabilities:
                    if capability.name == capability_name:
                        matching_agents.append(agent)
                        break
        return matching_agents
    
    def find_agents_by_role(self, role: str) -> List[SpecializedAgent]:
        """Find agents by their role."""
        return [agent for agent in self._agents.values() 
                if agent.status == AgentStatus.ACTIVE and agent.role.lower() == role.lower()]
    
    def update_agent_status(self, agent_id: str, status: AgentStatus) -> bool:
        """Update an agent's status."""
        if agent_id in self._agents:
            self._agents[agent_id].status = status
            return True
        return False
    
    def remove_agent(self, agent_id: str) -> bool:
        """Remove an agent from the registry."""
        if agent_id in self._agents:
            del self._agents[agent_id]
            return True
        return False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the entire registry to dictionary format."""
        return {
            "agents": {agent_id: agent.to_dict() for agent_id, agent in self._agents.items()},
            "total_agents": len(self._agents),
            "active_agents": len(self.get_active_agents())
        }


# Global registry instance
agent_registry = AgentRegistry()

