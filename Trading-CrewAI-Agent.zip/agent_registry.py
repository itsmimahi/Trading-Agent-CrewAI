"""
Agent Registry for the AI Trading Advisory System.

This module provides centralized agent registration and discovery services.
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Set, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import sqlite3
from pathlib import Path

# from .base_server import AgentInfo, BaseMCPServer

@dataclass
class AgentInfo:
    """Information about an agent in the system."""
    id: str
    name: str
    type: str
    capabilities: List[str]
    status: str
    last_heartbeat: datetime
    endpoint: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert agent info to dictionary format."""
        return {
            **asdict(self),
            'last_heartbeat': self.last_heartbeat.isoformat()
        }


class AgentRegistry:
    """
    Centralized registry for all agents in the trading system.
    
    This class manages agent registration, discovery, health monitoring,
    and service location for the multi-agent system.
    """
    
    def __init__(self, db_path: str = "data/storage/agent_registry.db"):
        """
        Initialize the agent registry.
        
        Args:
            db_path: Path to the SQLite database for persistence
        """
        self.db_path = db_path
        self.agents: Dict[str, AgentInfo] = {}
        self.agent_capabilities: Dict[str, Set[str]] = {}
        self.logger = logging.getLogger("agent_registry")
        
        # Initialize database
        self._init_database()
        
        # Load existing agents from database
        self._load_agents()
    
    def _init_database(self):
        """Initialize the SQLite database for agent persistence."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agents (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    type TEXT NOT NULL,
                    capabilities TEXT NOT NULL,
                    status TEXT NOT NULL,
                    last_heartbeat TEXT NOT NULL,
                    endpoint TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_metrics (
                    agent_id TEXT,
                    metric_name TEXT,
                    metric_value REAL,
                    timestamp TEXT,
                    FOREIGN KEY (agent_id) REFERENCES agents (id)
                )
            """)
            
            conn.commit()
    
    def _load_agents(self):
        """Load agents from database on startup."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("""
                    SELECT id, name, type, capabilities, status, last_heartbeat, endpoint
                    FROM agents
                """)
                
                for row in cursor.fetchall():
                    agent_id, name, agent_type, capabilities_str, status, last_heartbeat, endpoint = row
                    
                    capabilities = json.loads(capabilities_str)
                    
                    agent_info = AgentInfo(
                        id=agent_id,
                        name=name,
                        type=agent_type,
                        capabilities=capabilities,
                        status=status,
                        last_heartbeat=datetime.fromisoformat(last_heartbeat),
                        endpoint=endpoint
                    )
                    
                    self.agents[agent_id] = agent_info
                    self.agent_capabilities[agent_id] = set(capabilities)
                    
        except Exception as e:
            self.logger.error(f"Error loading agents from database: {e}")
    
    def _save_agent(self, agent_info: AgentInfo):
        """Save agent information to database."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                now = datetime.now().isoformat()
                
                conn.execute("""
                    INSERT OR REPLACE INTO agents 
                    (id, name, type, capabilities, status, last_heartbeat, endpoint, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    agent_info.id,
                    agent_info.name,
                    agent_info.type,
                    json.dumps(agent_info.capabilities),
                    agent_info.status,
                    agent_info.last_heartbeat.isoformat(),
                    agent_info.endpoint,
                    now,
                    now
                ))
                
                conn.commit()
                
        except Exception as e:
            self.logger.error(f"Error saving agent {agent_info.id}: {e}")
    
    def register_agent(self, agent_info: AgentInfo) -> bool:
        """
        Register a new agent in the system.
        
        Args:
            agent_info: Information about the agent to register
            
        Returns:
            True if registration successful, False otherwise
        """
        try:
            # Check if agent already exists
            if agent_info.id in self.agents:
                self.logger.warning(f"Agent {agent_info.id} already registered, updating...")
            
            # Store agent information
            self.agents[agent_info.id] = agent_info
            self.agent_capabilities[agent_info.id] = set(agent_info.capabilities)
            
            # Persist to database
            self._save_agent(agent_info)
            
            self.logger.info(f"Registered agent {agent_info.id} ({agent_info.name})")
            return True
            
        except Exception as e:
            self.logger.error(f"Error registering agent {agent_info.id}: {e}")
            return False
    
    def unregister_agent(self, agent_id: str) -> bool:
        """
        Unregister an agent from the system.
        
        Args:
            agent_id: ID of the agent to unregister
            
        Returns:
            True if unregistration successful, False otherwise
        """
        try:
            if agent_id in self.agents:
                del self.agents[agent_id]
                
            if agent_id in self.agent_capabilities:
                del self.agent_capabilities[agent_id]
            
            # Remove from database
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("DELETE FROM agents WHERE id = ?", (agent_id,))
                conn.execute("DELETE FROM agent_metrics WHERE agent_id = ?", (agent_id,))
                conn.commit()
            
            self.logger.info(f"Unregistered agent {agent_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error unregistering agent {agent_id}: {e}")
            return False
    
    def get_agent(self, agent_id: str) -> Optional[AgentInfo]:
        """
        Get information about a specific agent.
        
        Args:
            agent_id: ID of the agent
            
        Returns:
            Agent information or None if not found
        """
        return self.agents.get(agent_id)
    
    def list_agents(self, agent_type: Optional[str] = None, status: Optional[str] = None) -> List[AgentInfo]:
        """
        List all registered agents, optionally filtered by type and status.
        
        Args:
            agent_type: Filter by agent type (optional)
            status: Filter by agent status (optional)
            
        Returns:
            List of agent information
        """
        agents = list(self.agents.values())
        
        if agent_type:
            agents = [a for a in agents if a.type == agent_type]
        
        if status:
            agents = [a for a in agents if a.status == status]
        
        return agents
    
    def find_agents_by_capability(self, capability: str) -> List[AgentInfo]:
        """
        Find all agents that have a specific capability.
        
        Args:
            capability: The capability to search for
            
        Returns:
            List of agents with the specified capability
        """
        matching_agents = []
        
        for agent_id, capabilities in self.agent_capabilities.items():
            if capability in capabilities:
                agent_info = self.agents.get(agent_id)
                if agent_info:
                    matching_agents.append(agent_info)
        
        return matching_agents
    
    def update_agent_heartbeat(self, agent_id: str) -> bool:
        """
        Update the last heartbeat timestamp for an agent.
        
        Args:
            agent_id: ID of the agent
            
        Returns:
            True if update successful, False otherwise
        """
        try:
            if agent_id in self.agents:
                self.agents[agent_id].last_heartbeat = datetime.now()
                self.agents[agent_id].status = "active"
                self._save_agent(self.agents[agent_id])
                return True
            return False
        except Exception as e:
            self.logger.error(f"Error updating heartbeat for agent {agent_id}: {e}")
            return False
    
    def update_agent_status(self, agent_id: str, status: str) -> bool:
        """
        Update the status of an agent.
        
        Args:
            agent_id: ID of the agent
            status: New status (active, inactive, error, etc.)
            
        Returns:
            True if update successful, False otherwise
        """
        try:
            if agent_id in self.agents:
                self.agents[agent_id].status = status
                self._save_agent(self.agents[agent_id])
                return True
            return False
        except Exception as e:
            self.logger.error(f"Error updating status for agent {agent_id}: {e}")
            return False
    
    def check_agent_health(self, timeout_minutes: int = 5) -> Dict[str, str]:
        """
        Check the health of all registered agents.
        
        Args:
            timeout_minutes: Minutes after which an agent is considered unhealthy
            
        Returns:
            Dictionary mapping agent IDs to health status
        """
        health_status = {}
        timeout_threshold = datetime.now() - timedelta(minutes=timeout_minutes)
        
        for agent_id, agent_info in self.agents.items():
            if agent_info.last_heartbeat < timeout_threshold:
                health_status[agent_id] = "unhealthy"
                # Update status to inactive
                self.update_agent_status(agent_id, "inactive")
            else:
                health_status[agent_id] = "healthy"
        
        return health_status
    
    def get_agent_metrics(self, agent_id: str, hours: int = 24) -> List[Dict]:
        """
        Get performance metrics for an agent.
        
        Args:
            agent_id: ID of the agent
            hours: Number of hours of metrics to retrieve
            
        Returns:
            List of metrics
        """
        try:
            since_time = datetime.now() - timedelta(hours=hours)
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("""
                    SELECT metric_name, metric_value, timestamp
                    FROM agent_metrics
                    WHERE agent_id = ? AND timestamp > ?
                    ORDER BY timestamp DESC
                """, (agent_id, since_time.isoformat()))
                
                metrics = []
                for row in cursor.fetchall():
                    metrics.append({
                        'metric_name': row[0],
                        'metric_value': row[1],
                        'timestamp': row[2]
                    })
                
                return metrics
                
        except Exception as e:
            self.logger.error(f"Error getting metrics for agent {agent_id}: {e}")
            return []
    
    def record_agent_metric(self, agent_id: str, metric_name: str, metric_value: float):
        """
        Record a performance metric for an agent.
        
        Args:
            agent_id: ID of the agent
            metric_name: Name of the metric
            metric_value: Value of the metric
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT INTO agent_metrics (agent_id, metric_name, metric_value, timestamp)
                    VALUES (?, ?, ?, ?)
                """, (agent_id, metric_name, metric_value, datetime.now().isoformat()))
                
                conn.commit()
                
        except Exception as e:
            self.logger.error(f"Error recording metric for agent {agent_id}: {e}")
    
    def get_system_overview(self) -> Dict:
        """
        Get an overview of the entire agent system.
        Returns:
            Dictionary with system statistics
        """
        total_agents = len(self.agents)
        active_agents = len([a for a in self.agents.values() if a.status == "active"])
        inactive_agents = total_agents - active_agents
        # Count agents by type
        agent_types = {}
        for agent_info in self.agents.values():
            agent_types[agent_info.type] = agent_types.get(agent_info.type, 0) + 1
        # Count capabilities
        all_capabilities = set()
        for capabilities in self.agent_capabilities.values():
            all_capabilities.update(capabilities)
        return {
            "total_agents": total_agents,
            "active_agents": active_agents,
            "inactive_agents": inactive_agents,
            "agent_types": agent_types,
            "total_capabilities": len(all_capabilities),
            "capabilities": sorted(list(all_capabilities)),
            "last_updated": datetime.now().isoformat()
        }

    # --- UI & Group Messaging Helper Methods ---
    def get_agents_by_type(self, agent_type: str) -> List[AgentInfo]:
        """Return all agents of a given type."""
        return [a for a in self.agents.values() if a.type == agent_type]

    def get_agents_by_capability(self, capability: str) -> List[AgentInfo]:
        """Return all agents with a given capability."""
        return self.find_agents_by_capability(capability)

    def get_all_agent_statuses(self) -> Dict[str, str]:
        """Return a dict of agent_id: status for all agents."""
        return {agent_id: agent.status for agent_id, agent in self.agents.items()}

    def get_agent_details(self) -> List[Dict]:
        """Return a list of agent details for UI display."""
        return [
            {
                "id": agent.id,
                "name": agent.name,
                "type": agent.type,
                "capabilities": list(agent.capabilities),
                "status": agent.status,
                "endpoint": agent.endpoint
            }
            for agent in self.agents.values()
        ]
    
    async def start_health_monitor(self, check_interval: int = 300):
        """
        Start background health monitoring task.
        
        Args:
            check_interval: Interval between health checks in seconds
        """
        while True:
            try:
                health_status = self.check_agent_health()
                unhealthy_agents = [agent_id for agent_id, status in health_status.items() if status == "unhealthy"]
                
                if unhealthy_agents:
                    self.logger.warning(f"Unhealthy agents detected: {unhealthy_agents}")
                
                await asyncio.sleep(check_interval)
                
            except Exception as e:
                self.logger.error(f"Error in health monitor: {e}")
                await asyncio.sleep(30)  # Shorter retry interval on error

    async def send_message(self, message: dict) -> dict:
        """
        Async method to deliver A2A message to the correct agent instance.
        Assumes agents are registered with their instance in self.agents dict.
        """
        agent_id = message.get("to")
        agent_info = self.get_agent(agent_id)
        if not agent_info or not hasattr(agent_info, "instance"):
            return {"response": f"Agent {agent_id} not found or not initialized."}
        agent_instance = agent_info.instance
        action = message.get("action", "analyze")
        data = message.get("data", {})
        # Default to 'analyze' method
        if hasattr(agent_instance, action):
            method = getattr(agent_instance, action)
            if asyncio.iscoroutinefunction(method):
                return await method(**data)
            else:
                return method(**data)
        elif hasattr(agent_instance, "analyze") and asyncio.iscoroutinefunction(agent_instance.analyze):
            return await agent_instance.analyze(**data)
        else:
            return {"response": f"Agent {agent_id} does not support requested action."}

    async def broadcast_message(self, from_agent: str, action: str, data: dict, agent_types: List[str] = None, capabilities: List[str] = None) -> Dict[str, Any]:
        """
        Async broadcast to agents by type or capability.
        Returns dict of agent_id: response.
        """
        results = {}
        targets = []
        if capabilities:
            for cap in capabilities:
                targets.extend(self.get_agents_by_capability(cap))
        elif agent_types:
            for typ in agent_types:
                targets.extend(self.get_agents_by_type(typ))
        else:
            targets = list(self.agents.values())
        for agent_info in targets:
            if hasattr(agent_info, "instance"):
                msg = {
                    "from": from_agent,
                    "to": agent_info.id,
                    "type": "request",
                    "action": action,
                    "data": data
                }
                results[agent_info.id] = await self.send_message(msg)
        return results

    def get_agent_by_capability(self, capability: str) -> List[str]:
        """
        Return agent IDs with a given capability.
        """
        return [agent_id for agent_id, caps in self.agent_capabilities.items() if capability in caps]

    def get_agent_status(self, agent_id: str) -> str:
        """
        Return status of a specific agent.
        """
        agent = self.get_agent(agent_id)
        return agent.status if agent else "unknown"

    def get_agents_dynamic(self, query: str) -> List[str]:
        """
        Dynamic routing: return agent IDs relevant to a query based on capabilities/keywords.
        """
        query_lower = query.lower()
        relevant_agents = []
        keyword_map = {
            "mathematical_analysis": ["math", "quant", "calculate", "number", "stat"],
            "pattern_recognition": ["pattern", "trend", "sequence"],
            "natural_language_processing": ["language", "text", "nlp", "chat"],
            "data_interpretation": ["data", "interpret", "insight"],
            "contextual_reasoning": ["context", "reason", "logic"],
            "risk_assessment": ["risk", "volatility", "drawdown"],
            "trend_analysis": ["trend", "momentum", "direction"]
        }
        for cap, keywords in keyword_map.items():
            if any(word in query_lower for word in keywords):
                relevant_agents.extend(self.get_agent_by_capability(cap))
        return relevant_agents if relevant_agents else list(self.agents.keys())


