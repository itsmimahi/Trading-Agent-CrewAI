# Flow Persistence & Checkpoint / Resume

> **Sources**: `main_advisory_agent/advisory_flow.py` (`_persist_step`, `_restore_from_checkpoint`),  
> `crewai.flow.persistence.sqlite.SQLiteFlowPersistence`  
> **Phase**: 6

---

## Overview

`AdvisoryFlow` writes a SQLite checkpoint after each major step. If the process
crashes mid-flow, the next request for the same conversation can **resume from the
last checkpoint** rather than re-running all upstream steps.

```mermaid
sequenceDiagram
    participant U as User
    participant AF as AdvisoryFlow
    participant DB as SQLite (advisory_checkpoints.db)

    U->>AF: request (conversation_id=conv_abc)
    AF->>DB: load_state("conv_abc") → None (first run)

    AF->>AF: initialize_flow
    AF->>DB: save_state("conv_abc", "initialize_flow", state)   ← checkpoint 1

    AF->>AF: market_analysis_step
    AF->>DB: save_state("conv_abc", "market_analysis_step", state)  ← checkpoint 2

    Note over AF: CRASH

    U->>AF: retry same request
    AF->>DB: load_state("conv_abc") → {method: "market_analysis_step", state: {...}}
    AF->>AF: _restore_from_checkpoint: skip to synthesis_step
    AF->>AF: synthesis_step  (market_results already in state)
    AF->>DB: save_state("conv_abc", "synthesis_step", state)    ← checkpoint 3

    AF->>AF: execution_step
    AF->>DB: save_state("conv_abc", "execution_step", state)    ← checkpoint 4
```

---

## `SQLiteFlowPersistence`

Provided by CrewAI 1.14.5.

```python
from crewai.flow.persistence.sqlite import SQLiteFlowPersistence

persist = SQLiteFlowPersistence(db_path="data/advisory_checkpoints.db")
```

### Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `save_state` | `(flow_uuid: str, method_name: str, state_data: dict) → None` | Serialise + upsert checkpoint row |
| `load_state` | `(flow_uuid: str) → dict \| None` | Return last saved row, or `None` if none exists |

### Database schema

Table: `flow_checkpoints`

| Column | Type | Description |
|--------|------|-------------|
| `flow_uuid` | TEXT PK | Equals `state.id` = `state.conversation_id` |
| `method_name` | TEXT | Step that wrote the checkpoint |
| `state_json` | TEXT | JSON-serialised `AdvisoryFlowState` |
| `updated_at` | REAL | Unix timestamp of last write |

WAL mode is enabled for concurrent read safety.

---

## Checkpoint sites in `AdvisoryFlow`

| Step | Checkpoint # | Fields critical to preserve |
|------|-------------|------------------------------|
| `initialize_flow` | 1 | `intent`, `entities`, `active_markets`, `portfolio_snapshot`, `parsed_order`, `approval_decision` |
| `market_analysis_step` | 2 | `market_results`, `memory_recall` |
| `synthesis_step` | 3 | `synthesis_result` |
| `execution_step` | 4 | `execution_result` |

---

## `_persist_step`

```python
def _persist_step(self, method_name: str) -> None:
    """Write current state to SQLite. Silent on failure."""
    if self._persist is None:
        return
    try:
        self._persist.save_state(self.state.id, method_name, self.state.model_dump())
    except Exception as exc:
        logger.warning("Flow:persist_step failed | method=%s | err=%s", method_name, exc)
```

- `self._persist` is `None` when `ADVISORY_CHECKPOINT_DB` is not set or `persist_db_path=None`
- Failure is **silent** — the flow continues normally

---

## `_restore_from_checkpoint`

```python
def _restore_from_checkpoint(self, state: AdvisoryFlowState) -> bool:
    """
    Load prior state from SQLite. Returns True if restored.
    Only restores fields that are expensive to recompute.
    """
    if self._persist is None:
        return False
    row = self._persist.load_state(state.id)
    if row is None:
        return False

    saved = row.get("state_data", {})
    method = row.get("method_name", "")

    if method == "market_analysis_step":
        state.market_results  = saved.get("market_results", {})
        state.memory_recall   = saved.get("memory_recall", {})
        state.active_markets  = saved.get("active_markets", state.active_markets)
        state.portfolio_snapshot = saved.get("portfolio_snapshot", {})
        # signal to initialize_flow to skip to synthesis
        state.response_metadata["_resume_from"] = "synthesis_step"

    elif method == "synthesis_step":
        state.synthesis_result = saved.get("synthesis_result", "")
        # ... also restore market_results for context
        state.response_metadata["_resume_from"] = "execution_step"

    logger.info("Flow:restore | conv=%s | resuming_after=%s", state.id, method)
    return True
```

### Fields never restored from checkpoint

| Field | Reason |
|-------|--------|
| `portfolio_snapshot` (if IBKR connected) | Always refresh live data |
| `approval_decision` | User must re-supply decisions |
| `advisory_approval_pending` | Recomputed from approval DB |

---

## Resume trigger

Checkpoint restoration is triggered inside `initialize_flow`:

```python
# If a resume was requested externally:
if state.response_metadata.get("resume_from_checkpoint"):
    restored = self._restore_from_checkpoint(state)
```

Externally, callers set `resume_from_checkpoint=True` by including it in the
`response_metadata` of the initial `AdvisoryFlow.kickoff()` call:

```python
flow.kickoff(inputs={
    "user_input": "...",
    "conversation_id": "conv_abc",
    "response_metadata": {"resume_from_checkpoint": True},
})
```

Alternatively, `MainAdvisoryAgent.process_request()` automatically attempts a
checkpoint resume when it detects an existing checkpoint row for the conversation.

---

## Configuration

| Env var | Default | Description |
|---------|---------|-------------|
| `ADVISORY_CHECKPOINT_DB` | `data/advisory_checkpoints.db` | Path to the SQLite file |

Set to empty string to disable persistence entirely.

---

## Testing (Phase 6)

`scripts/test_flow_persistence.py` — **41 tests**

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_persist_and_load_full_cycle` | Write + read round-trip produces identical state |
| `test_resume_skips_market_analysis` | After checkpoint at `market_analysis_step`, flow skips to synthesis |
| `test_resume_skips_synthesis` | After checkpoint at `synthesis_step`, flow skips to execution |
| `test_persist_silent_on_failure` | DB write failure does not crash the flow |
| `test_wal_mode_enabled` | Verifies `PRAGMA journal_mode=WAL` after DB open |
| `test_concurrent_writes` | Two threads writing different `flow_uuid`s don't conflict |
| `test_expired_checkpoint_ignored` | Checkpoints older than 24h are not restored |
