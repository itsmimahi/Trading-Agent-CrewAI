"""
SQLite-backed idempotency store for API boundary de-duplication.

Key features:
- Persist results keyed by an idempotency key.
- Track status: in_progress | completed | failed.
- Basic polling support to wait for completion from concurrent callers.
"""

from __future__ import annotations

import sqlite3
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import threading
import os


@dataclass
class IdempotencyRecord:
    key: str
    status: str
    created_at: str
    updated_at: str
    conversation_id: Optional[str] = None
    request_hash: Optional[str] = None
    response_json: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        if self.response_json:
            try:
                data["response"] = json.loads(self.response_json)
            except Exception:
                data["response"] = None
        return data


class IdempotencyStore:
    def __init__(self, db_path: str = "idempotency_cache.db"):
        self.db_path = db_path
        # ensure directory exists
        try:
            d = os.path.dirname(self.db_path)
            if d and not os.path.exists(d):
                os.makedirs(d, exist_ok=True)
        except Exception:
            pass
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        # timeout prevents immediate lock errors under concurrency
        return sqlite3.connect(self.db_path, timeout=5.0, isolation_level=None)

    def _init_db(self):
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS idempotency_cache (
                    key TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    conversation_id TEXT,
                    request_hash TEXT,
                    response_json TEXT
                )
                """
            )
            conn.commit()

    def get(self, key: str) -> Optional[IdempotencyRecord]:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT key, status, created_at, updated_at, conversation_id, request_hash, response_json FROM idempotency_cache WHERE key = ?",
                (key,),
            )
            row = cur.fetchone()
            if not row:
                return None
            return IdempotencyRecord(
                key=row[0],
                status=row[1],
                created_at=row[2],
                updated_at=row[3],
                conversation_id=row[4],
                request_hash=row[5],
                response_json=row[6],
            )

    def start(self, key: str, conversation_id: Optional[str] = None, request_hash: Optional[str] = None) -> tuple[IdempotencyRecord, bool]:
        """Mark a request as started if not present.

        Returns a tuple of (record, inserted) where inserted=True means this caller
        created the in_progress record and therefore "owns" the processing.
        If inserted=False and the record exists with status=in_progress, another
        worker is already processing it.
        """
        now = datetime.utcnow().isoformat()
        with self._lock:
            existing = self.get(key)
            if existing:
                return existing, False
            with self._connect() as conn:
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT OR IGNORE INTO idempotency_cache (key, status, created_at, updated_at, conversation_id, request_hash)
                    VALUES (?, 'in_progress', ?, ?, ?, ?)
                    """,
                    (key, now, now, conversation_id, request_hash),
                )
                inserted = cur.rowcount == 1
                conn.commit()
        # Return fresh read (handles race with another process)
        rec = self.get(key)
        # rec cannot be None here; but guard anyway
        return (rec or IdempotencyRecord(key=key, status='in_progress', created_at=now, updated_at=now, conversation_id=conversation_id, request_hash=request_hash), inserted)

    def set_result(self, key: str, response: Dict[str, Any], conversation_id: Optional[str] = None, status: str = 'completed') -> None:
        now = datetime.utcnow().isoformat()
        payload = json.dumps(response, ensure_ascii=False)
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                UPDATE idempotency_cache
                SET status = ?, updated_at = ?, conversation_id = COALESCE(?, conversation_id), response_json = ?
                WHERE key = ?
                """,
                (status, now, conversation_id, payload, key),
            )
            # If no row existed, insert completed row (edge case)
            if cur.rowcount == 0:
                cur.execute(
                    """
                    INSERT INTO idempotency_cache (key, status, created_at, updated_at, conversation_id, response_json)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (key, status, now, now, conversation_id, payload),
                )
            conn.commit()

    def set_failed(self, key: str, error_payload: Dict[str, Any], conversation_id: Optional[str] = None) -> None:
        self.set_result(key, error_payload, conversation_id, status='failed')

    def purge_expired(self, ttl_seconds: int = 86400, max_rows: int = 500) -> int:
        """Purge entries older than ttl_seconds based on updated_at. Returns number of rows deleted.

        Uses a two-step select-then-delete to remain compatible with older SQLite versions.
        """
        try:
            cutoff = (datetime.utcnow() - timedelta(seconds=ttl_seconds)).isoformat()
            with self._connect() as conn:
                cur = conn.cursor()
                cur.execute(
                    "SELECT key FROM idempotency_cache WHERE updated_at < ? LIMIT ?",
                    (cutoff, max_rows),
                )
                keys = [row[0] for row in cur.fetchall()]
                if not keys:
                    return 0
                cur.executemany("DELETE FROM idempotency_cache WHERE key = ?", [(k,) for k in keys])
                conn.commit()
                return len(keys)
        except Exception:
            return 0
