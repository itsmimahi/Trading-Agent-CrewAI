# Integration Layer

> **Sources**: `integration/event_bus.py`, `integration/crewai_rl_bridge.py`,  
> `integration/agent_worker.py`, `integration/rl_enhanced_orchestrator.py`

---

## Overview

The integration layer connects three subsystems asynchronously:

1. **EventBus** — Redis Streams–based publish/subscribe for agent coordination
2. **CrewAI-RL Bridge** — typed message passing between advisory flow and RL agent
3. **Agent Worker** — background consumer that processes events from Redis Streams

```mermaid
flowchart LR
    subgraph Advisory
        AF[AdvisoryFlow]
        MAA[MainAdvisoryAgent]
    end

    subgraph RL
        RL2[RLAgentV2]
        RC[RegimeClassifier]
    end

    subgraph Integration
        EB[(EventBus\nRedis Streams)]
        BRG[CrewAIRLBridge]
        AW[AgentWorker]
    end

    AF -->|publish regime_change_v2| BRG
    BRG --> EB
    EB --> AW
    AW -->|consume + dispatch| RL2
    RL2 -->|publish weight_update| EB
    EB --> MAA
```

---

## `EventBus`

> **Source**: `integration/event_bus.py`

Thin wrapper around Redis Streams. Requires `REDIS_URL` env var.

### Methods

```python
class EventBus:
    def publish(self, stream: str, message: Dict[str, Any]) -> str:
        """Publish a message dict to a Redis stream. Returns message ID."""

    def consume(
        self,
        stream: str,
        group: str,
        consumer: str,
        count: int = 10,
        block_ms: int = 1000,
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """Read unprocessed messages from a consumer group."""

    def ack(self, stream: str, group: str, message_id: str) -> None:
        """Acknowledge a consumed message."""

    def create_group(self, stream: str, group: str, start_id: str = "0") -> None:
        """Create a consumer group (idempotent)."""
```

### Stream names

| Stream | Purpose |
|--------|---------|
| `advisory.regime_change` | Regime change signals from AdvisoryFlow |
| `advisory.performance` | Performance feedback from RL agent |
| `advisory.weight_updates` | Portfolio weight recommendations from RL |

---

## `MessageType` enum

```python
class MessageType(str, Enum):
    REGIME_CHANGE        = "regime_change"
    REGIME_CHANGE_V2     = "regime_change_v2"
    PORTFOLIO_WEIGHT_UPDATE = "portfolio_weight_update"
    PERFORMANCE_FEEDBACK = "performance_feedback"
    PERFORMANCE_FEEDBACK_V2 = "performance_feedback_v2"
```

---

## `CrewAIRLBridge`

> **Source**: `integration/crewai_rl_bridge.py`

Handles typed serialisation/deserialisation for `EventBus` messages.

### Dataclasses (v2)

```python
@dataclass
class RegimeData:
    regime: str              # "BULL" / "BEAR" / "SIDEWAYS" / "HIGH_VOL"
    confidence: float
    prices: Dict[str, float] # {symbol: last_price}
    timestamp: float

@dataclass
class AssetMetrics:
    symbol: str
    weight: float
    return_1d: float
    volatility: float

@dataclass
class PerformanceMetricsV2:
    portfolio_return: float
    sharpe: float
    max_drawdown: float
    assets: List[AssetMetrics]
    timestamp: float

@dataclass
class PortfolioWeightUpdate:
    weights: Dict[str, float]   # {symbol: recommended_weight}
    regime: str
    confidence: float
    no_trade_override: bool
    timestamp: float
```

### Methods

```python
bridge = CrewAIRLBridge(event_bus=EventBus())

# Publish regime change (v2) from advisory flow
bridge.notify_regime_change_v2(regime_data: RegimeData) -> str

# Publish performance feedback from RL evaluation
bridge.send_performance_feedback_v2(metrics: PerformanceMetricsV2) -> str

# Request portfolio weights from RL agent (synchronous, polls stream)
result = bridge.get_portfolio_weights(
    symbols: List[str],
    regime: str,
    timeout_seconds: float = 3.0,
) -> Optional[PortfolioWeightUpdate]
```

---

## `AgentWorker`

> **Source**: `integration/agent_worker.py`

A long-running background process that:

1. Subscribes to all advisory event streams
2. Dispatches `regime_change_v2` to `RLAgentV2.online_finetune`
3. Publishes resulting `PortfolioWeightUpdate` back to the weight stream
4. Acknowledges processed messages

### Startup

```python
# Launched by launcher.py or docker-compose
worker = AgentWorker(
    event_bus=EventBus(),
    rl_agent=RLAgentV2(...),
    consumer_name="worker_01",
)
worker.run()   # blocking; uses asyncio internally
```

### Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `REDIS_URL` | `redis://localhost:6379/0` | Redis connection URL |
| `AGENT_WORKER_CONSUMER` | `worker_01` | Consumer name for Redis groups |

---

## `RLEnhancedOrchestrator`

> **Source**: `integration/rl_enhanced_orchestrator.py`

Optional component that enriches advisory flow outputs with RL recommendations
when the flow does not have direct access to `RLAgentV2` (e.g. remote deployment).

It polls `advisory.weight_updates` for new `PortfolioWeightUpdate` messages and
merges them into `state.synthesis_result` as an annotation block.

This is an alternative to the inline `rl_a2a_validate_v2` path:

| Path | When to use |
|------|------------|
| `rl_a2a_validate_v2` (inline) | Single-process deployment; `RLAgentV2` loaded in-process |
| `RLEnhancedOrchestrator` | Distributed deployment; RL runs in a separate worker |

---

## Enabling the integration layer

```dotenv
# Redis EventBus
REDIS_URL=redis://localhost:6379/0

# Worker (start separately)
# python integration/agent_worker.py

# Use distributed RL path (instead of inline)
ENABLE_RL_ORCHESTRATOR=1
```

Without Redis, `EventBus` raises `ConnectionError` on first use. The advisory
flow does not use `EventBus` directly (only the worker does), so the main
advisory API remains available.
