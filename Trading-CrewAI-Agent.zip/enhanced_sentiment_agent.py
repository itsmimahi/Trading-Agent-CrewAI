"""
Enhanced Sentiment Agent using CrewAI Framework - Hybrid Plus Approach  
Mathematical Core + LLM Reasoning + Transformer Models + Tools + Memory + Knowledge Base
"""
import warnings
warnings.filterwarnings("ignore")


import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass
import requests
import feedparser
from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import re
import json
from bs4 import BeautifulSoup

# Transformer models for financial sentiment
try:
    from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from data.collectors.market_data import market_data_collector
from config.settings import config
from crewai import Task, Crew, Process

logger = logging.getLogger(__name__)

@dataclass
class SentimentScores:
    """Sentiment analysis scores from different models"""
    textblob_polarity: float
    textblob_subjectivity: float
    vader_compound: float
    vader_positive: float
    vader_negative: float
    vader_neutral: float
    finbert_score: float
    finbert_label: str
    overall_sentiment: float
    confidence: float

@dataclass
class NewsAnalysis:
    """News sentiment analysis results"""
    total_articles: int
    positive_articles: int
    negative_articles: int
    neutral_articles: int
    average_sentiment: float
    sentiment_trend: str
    key_themes: List[str]
    impact_score: float
    credibility_score: float

@dataclass
class SocialSentiment:
    """Social media sentiment analysis"""
    platform: str
    mentions_count: int
    sentiment_score: float
    engagement_rate: float
    influencer_sentiment: float
    trending_topics: List[str]
    sentiment_volume: int

class EnhancedSentimentAgent(EnhancedBaseAgent):
    # Utility: Convert dataclass objects to dict for JSON serialization
    @staticmethod
    def _to_dict(obj):
        from dataclasses import asdict, is_dataclass
        if is_dataclass(obj):
            return asdict(obj)
        elif isinstance(obj, list):
            return [EnhancedSentimentAgent._to_dict(item) for item in obj]
        elif isinstance(obj, dict):
            return {k: EnhancedSentimentAgent._to_dict(v) for k, v in obj.items()}
        else:
            return obj
    memory = None
    """
    Enhanced Sentiment Agent using CrewAI Framework with Hybrid Plus Approach
    
    Mathematical Core: Sentiment scoring algorithms, statistical analysis
    LLM Reasoning: Context interpretation, sentiment nuance analysis
    Transformer Models: FinBERT, RoBERTa for financial sentiment
    Tools: News scraper, social media analyzer, sentiment aggregator
    Memory: Sentiment patterns, news impact correlation, market reaction history
    Knowledge Base: Sentiment-price correlations, news source reliability
    """
    
    def __init__(self, name: str = "EnhancedSentimentAgent", description: str = "Sentiment Analysis Agent for market and stock sentiment", role: str = "Market Sentiment Analyst", goal: str = "Analyze market and stock sentiment to provide a view on market mood", backstory: str = "An expert in NLP and sentiment analysis, capable of understanding the nuances of financial news and social media.", capabilities: Optional[List[Any]] = None, weight: float = 0.15, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        if capabilities is None:
            capabilities = [
                AgentCapability.NATURAL_LANGUAGE_PROCESSING,
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.CONTEXTUAL_REASONING
            ]
        super().__init__(
            name=name,
            description=description,
            capabilities=capabilities,
            weight=weight,
            use_llm=use_llm,
            use_memory=use_memory,
            use_knowledge_base=use_knowledge_base,
            role=role,
            goal=goal,
            backstory=backstory,
            **kwargs
        )
        
        # Initialize sentiment analyzers
        self.vader_analyzer = SentimentIntensityAnalyzer()
        
        # Initialize transformer models
        self.finbert_model = None
        self.roberta_model = None
        # Commenting out FinBERT and RoBERTa to force TF-IDF fallback and avoid download issues
        # if TRANSFORMERS_AVAILABLE:
        #     try:
        #         self.finbert_model = pipeline(
        #             "sentiment-analysis",
        #             model="ProsusAI/finbert",
        #             tokenizer="ProsusAI/finbert"
        #         )
        #         self.roberta_model = pipeline(
        #             "sentiment-analysis",
        #             model="cardiffnlp/twitter-roberta-base-sentiment-latest",
        #             tokenizer="cardiffnlp/twitter-roberta-base-sentiment-latest"
        #         )
        #     except Exception as e:
        #         self.logger.warning(f"FinBERT or RoBERTa model could not be loaded. Bypassing transformer-based sentiment. Reason: {e}")
        #         self.finbert_model = None
        #         self.roberta_model = None
        # else:
        #     self.finbert_model = None
        #     self.roberta_model = None
        
        # News sources configuration
        self.news_sources = {
            'economic_times': {
                'url': 'https://economictimes.indiatimes.com/markets/stocks/rssfeeds/2146842.cms',
                'credibility': 0.85,
                'weight': 0.25
            },
            'moneycontrol': {
                'url': 'https://www.moneycontrol.com/rss/MCtopstories.xml',
                'credibility': 0.80,
                'weight': 0.20
            },
            'business_standard': {
                'url': 'https://www.business-standard.com/rss/markets-106.rss',
                'credibility': 0.75,
                'weight': 0.15
            },
            'financial_express': {
                'url': 'https://www.financialexpress.com/market/rss',
                'credibility': 0.70,
                'weight': 0.15
            },
            'mint': {
                'url': 'https://www.livemint.com/rss/markets',
                'credibility': 0.75,
                'weight': 0.15
            },
            'reuters': {
                'url': 'https://feeds.reuters.com/reuters/INbusinessNews',
                'credibility': 0.90,
                'weight': 0.10
            }
        }
        
        # Sentiment scoring parameters
        self.sentiment_weights = {
            'news_sentiment': 0.40,
            'social_sentiment': 0.25,
            'analyst_sentiment': 0.20,
            'earnings_sentiment': 0.15
        }
        
        # Load sentiment knowledge
        self._load_sentiment_knowledge()
    
    def _initialize_tools(self):
        """Initialize Sentiment Agent specific tools"""
        super()._initialize_tools()
        
        # Add specialized sentiment tools
        self.tools.extend([
            AgentTool(
                name="analyze_news_sentiment",
                description="Analyze sentiment from news articles",
                function=self._analyze_news_sentiment
            ),
            AgentTool(
                name="analyze_social_sentiment",
                description="Analyze sentiment from social media",
                function=self._analyze_social_sentiment
            ),
            AgentTool(
                name="analyze_earnings_sentiment",
                description="Analyze sentiment from earnings calls",
                function=self._analyze_earnings_sentiment
            ),
            AgentTool(
                name="aggregate_sentiment",
                description="Aggregate sentiment from multiple sources",
                function=self._aggregate_sentiment_scores
            ),
            AgentTool(
                name="sentiment_impact_analysis",
                description="Analyze sentiment impact on price",
                function=self._sentiment_impact_analysis
            ),
            AgentTool(
                name="detect_sentiment_anomalies",
                description="Detect unusual sentiment patterns",
                function=self._detect_sentiment_anomalies
            )
        ])
    
    def _load_sentiment_knowledge(self):
        """Load sentiment analysis knowledge into knowledge base"""
        try:
            sentiment_knowledge = [
                # Sentiment-Price Correlations
                "Strong positive news sentiment (>0.6) correlates with 3-5% price increases within 1-2 days",
                "Earnings surprise sentiment drives 5-10% price moves in same session",
                "Analyst upgrade sentiment typically results in 2-4% price appreciation",
                "CEO/Management positive sentiment shows 1-3% price impact over 1 week",
                "Regulatory positive news creates 2-8% price moves depending on sector",
                
                # Sentiment Patterns
                "Sentiment momentum: 3+ consecutive positive days increases probability of continued uptrend",
                "Sentiment reversal: Extreme negative sentiment (-0.8) often marks market bottoms",
                "Sentiment divergence: Price up but sentiment down indicates potential reversal",
                "Volume confirmation: High sentiment with high volume amplifies price impact",
                
                # News Source Reliability
                "Economic Times: High credibility for Indian market news, 85% accuracy",
                "Moneycontrol: Reliable for technical analysis news, 80% accuracy",
                "Reuters: Excellent for global market impact, 90% accuracy",
                "Business Standard: Good for sector-specific news, 75% accuracy",
                
                # Sentiment Timing
                "Pre-market sentiment analysis most predictive for day trading",
                "Earnings call sentiment drives 2-3 day price action",
                "Weekend sentiment analysis predicts Monday opening sentiment",
                "Holiday sentiment typically muted, requires higher threshold",
                
                # Social Media Patterns
                "Twitter sentiment leads price by 2-4 hours in volatile periods",
                "Reddit sentiment useful for retail stock identification",
                "LinkedIn sentiment indicates institutional investor mood",
                "YouTube sentiment shows retail investor education trends",
                
                # Sentiment Thresholds
                "Sentiment > 0.6: Strong positive, high probability of price appreciation",
                "Sentiment 0.2-0.6: Moderate positive, cautious optimism",
                "Sentiment -0.2-0.2: Neutral, no clear directional bias",
                "Sentiment -0.6--0.2: Moderate negative, potential selling pressure",
                "Sentiment < -0.6: Strong negative, high probability of price decline"
            ]
            
            if self.use_knowledge_base:
                self.knowledge_base.add_knowledge(sentiment_knowledge)
                
        except Exception as e:
            self.logger.error(f"Error loading sentiment knowledge: {e}")
    
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform mathematical/quantitative sentiment analysis
        Pure mathematical calculations and statistical analysis
        """
        try:
            # Get company name for better news filtering
            company_name = await self._get_company_name(symbol)
            
            # Analyze news sentiment
            news_analysis = await self._analyze_news_sentiment(symbol, company_name)
            
            # Analyze social sentiment
            social_analysis = await self._analyze_social_sentiment(symbol, company_name)
            
            # Analyze earnings sentiment
            earnings_analysis = await self._analyze_earnings_sentiment(symbol, company_name)
            
            # Aggregate sentiment scores
            aggregated_sentiment = self._aggregate_sentiment_scores(news_analysis, social_analysis, earnings_analysis)
            
            # Sentiment impact analysis
            impact_analysis = self._sentiment_impact_analysis(symbol, aggregated_sentiment)
            
            # Detect sentiment anomalies
            anomaly_analysis = self._detect_sentiment_anomalies(symbol, aggregated_sentiment)
            
            # Calculate overall sentiment score
            overall_sentiment_score = self._calculate_sentiment_score(aggregated_sentiment, impact_analysis)
            
            return {
                "symbol": symbol,
                "company_name": company_name,
                "news_sentiment": news_analysis,
                "social_sentiment": social_analysis,
                "earnings_sentiment": earnings_analysis,
                "aggregated_sentiment": aggregated_sentiment,
                "impact_analysis": impact_analysis,
                "anomaly_analysis": anomaly_analysis,
                "overall_sentiment_score": overall_sentiment_score,
                "calculation_timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in mathematical analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def _get_company_name(self, symbol: str) -> str:
        """Get company name from symbol"""
        try:
            # This would typically fetch from a financial data API
            # For now, return a cleaned version of the symbol
            return symbol.replace('.NS', '').replace('.BO', '').replace('.', ' ')
        except Exception as e:
            self.logger.error(f"Error getting company name: {e}")
            return symbol
    
    async def _analyze_news_sentiment(self, symbol: str, company_name: str) -> dict:
        """Analyze sentiment from news articles"""
        try:
            all_articles = []
            
            # Collect news from multiple sources
            for source_name, source_config in self.news_sources.items():
                try:
                    articles = await self._fetch_news_from_source(source_config['url'], company_name)
                    for article in articles:
                        article['source'] = source_name
                        article['credibility'] = source_config['credibility']
                        article['weight'] = source_config['weight']
                    all_articles.extend(articles)
                except Exception as e:
                    self.logger.error(f"Error fetching news from {source_name}: {e}")
                    continue
            
            if not all_articles:
                return self._to_dict(NewsAnalysis(
                    total_articles=0,
                    positive_articles=0,
                    negative_articles=0,
                    neutral_articles=0,
                    average_sentiment=0.0,
                    sentiment_trend="neutral",
                    key_themes=[],
                    impact_score=0.0,
                    credibility_score=0.0
                ))
            
            # Analyze sentiment for each article
            sentiment_scores = []
            positive_count = 0
            negative_count = 0
            neutral_count = 0
            key_themes = []
            
            for article in all_articles:
                # Multi-model sentiment analysis
                sentiment_score = self._analyze_text_sentiment(article['title'] + ' ' + article.get('description', ''))
                weighted_score = sentiment_score.overall_sentiment * article['weight']
                sentiment_scores.append(weighted_score)
                
                # Categorize sentiment
                if sentiment_score.overall_sentiment > 0.2:
                    positive_count += 1
                elif sentiment_score.overall_sentiment < -0.2:
                    negative_count += 1
                else:
                    neutral_count += 1
                
                # Extract key themes
                themes = self._extract_themes(article['title'])
                key_themes.extend(themes)
            
            # Calculate aggregate metrics
            average_sentiment = sum(sentiment_scores) / len(sentiment_scores) if sentiment_scores else 0
            credibility_score = sum(article['credibility'] for article in all_articles) / len(all_articles)
            
            # Determine sentiment trend
            if positive_count > negative_count * 1.5:
                sentiment_trend = "positive"
            elif negative_count > positive_count * 1.5:
                sentiment_trend = "negative"
            else:
                sentiment_trend = "neutral"
            
            # Calculate impact score
            impact_score = abs(average_sentiment) * credibility_score * min(len(all_articles) / 10, 1.0)
            
            return self._to_dict(NewsAnalysis(
                total_articles=len(all_articles),
                positive_articles=positive_count,
                negative_articles=negative_count,
                neutral_articles=neutral_count,
                average_sentiment=average_sentiment,
                sentiment_trend=sentiment_trend,
                key_themes=list(set(key_themes))[:10],  # Top 10 unique themes
                impact_score=impact_score,
                credibility_score=credibility_score
            ))
            
        except Exception as e:
            self.logger.error(f"Error analyzing news sentiment: {e}")
            return self._to_dict(NewsAnalysis(
                total_articles=0,
                positive_articles=0,
                negative_articles=0,
                neutral_articles=0,
                average_sentiment=0.0,
                sentiment_trend="neutral",
                key_themes=[],
                impact_score=0.0,
                credibility_score=0.0
            ))
    
    async def _fetch_news_from_source(self, url: str, company_name: str) -> List[Dict[str, Any]]:
        """Fetch news articles from RSS feed"""
        try:
            # Fetch RSS feed
            feed = feedparser.parse(url)
            articles = []
            
            # Filter articles related to company
            for entry in feed.entries[:20]:  # Limit to recent 20 articles
                title = entry.get('title', '')
                description = entry.get('description', '')
                
                # Check if article is relevant to company
                if (company_name.lower() in title.lower() or 
                    company_name.lower() in description.lower() or
                    any(keyword in title.lower() for keyword in ['stock', 'market', 'share', 'trading'])):
                    
                    articles.append({
                        'title': title,
                        'description': description,
                        'link': entry.get('link', ''),
                        'published': entry.get('published', ''),
                        'source_url': url
                    })
            
            return articles
            
        except Exception as e:
            self.logger.error(f"Error fetching news from {url}: {e}")
            return []
    
    def _analyze_text_sentiment(self, text: str) -> SentimentScores:
        """Analyze sentiment using multiple models"""
        try:
            # TextBlob analysis
            blob = TextBlob(text)
            textblob_polarity = blob.sentiment.polarity
            textblob_subjectivity = blob.sentiment.subjectivity
            
            # VADER analysis
            vader_scores = self.vader_analyzer.polarity_scores(text)
            
            # FinBERT analysis (if available)
            finbert_score = 0.0
            finbert_label = "neutral"
            if self.finbert_model:
                try:
                    finbert_result = self.finbert_model(text[:512])  # Limit text length
                    finbert_label = finbert_result[0]['label'].lower()
                    finbert_score = finbert_result[0]['score']
                    
                    # Convert to consistent scale
                    if finbert_label == 'positive':
                        finbert_score = finbert_score
                    elif finbert_label == 'negative':
                        finbert_score = -finbert_score
                    else:  # neutral
                        finbert_score = 0.0
                except Exception as e:
                    self.logger.error(f"Error in FinBERT analysis: {e}")
            
            # Calculate overall sentiment (weighted average)
            overall_sentiment = (
                textblob_polarity * 0.3 +
                vader_scores['compound'] * 0.4 +
                finbert_score * 0.3
            )
            
            # Calculate confidence
            confidence = 1.0 - textblob_subjectivity  # Higher subjectivity = lower confidence
            
            return SentimentScores(
                textblob_polarity=textblob_polarity,
                textblob_subjectivity=textblob_subjectivity,
                vader_compound=vader_scores['compound'],
                vader_positive=vader_scores['pos'],
                vader_negative=vader_scores['neg'],
                vader_neutral=vader_scores['neu'],
                finbert_score=finbert_score,
                finbert_label=finbert_label,
                overall_sentiment=overall_sentiment,
                confidence=confidence
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing text sentiment: {e}")
            return SentimentScores(
                textblob_polarity=0.0,
                textblob_subjectivity=0.5,
                vader_compound=0.0,
                vader_positive=0.0,
                vader_negative=0.0,
                vader_neutral=1.0,
                finbert_score=0.0,
                finbert_label="neutral",
                overall_sentiment=0.0,
                confidence=0.5
            )
    
    def _extract_themes(self, text: str) -> List[str]:
        """Extract key themes from text"""
        try:
            # Simple keyword extraction
            financial_keywords = [
                'earnings', 'revenue', 'profit', 'growth', 'expansion',
                'merger', 'acquisition', 'ipo', 'dividend', 'buyback',
                'partnership', 'contract', 'deal', 'launch', 'innovation',
                'regulation', 'compliance', 'lawsuit', 'competition',
                'market', 'sector', 'industry', 'economy', 'inflation'
            ]
            
            text_lower = text.lower()
            themes = [keyword for keyword in financial_keywords if keyword in text_lower]
            
            return themes
            
        except Exception as e:
            self.logger.error(f"Error extracting themes: {e}")
            return []
    
    async def _analyze_social_sentiment(self, symbol: str, company_name: str) -> List[dict]:
        """Analyze sentiment from social media platforms"""
        try:
            # Placeholder for social media analysis
            # In a real implementation, this would connect to Twitter API, Reddit API, etc.
            
            social_sentiments = []
            # Twitter sentiment (placeholder)
            twitter_sentiment = SocialSentiment(
                platform="twitter",
                mentions_count=50,
                sentiment_score=0.1,
                engagement_rate=0.05,
                influencer_sentiment=0.2,
                trending_topics=["stock", "market"],
                sentiment_volume=100
            )
            social_sentiments.append(self._to_dict(twitter_sentiment))
            # Reddit sentiment (placeholder)
            reddit_sentiment = SocialSentiment(
                platform="reddit",
                mentions_count=25,
                sentiment_score=0.0,
                engagement_rate=0.08,
                influencer_sentiment=0.1,
                trending_topics=["investing", "stocks"],
                sentiment_volume=50
            )
            social_sentiments.append(self._to_dict(reddit_sentiment))
            return social_sentiments
            
        except Exception as e:
            self.logger.error(f"Error analyzing social sentiment: {e}")
            return []
    
    async def _analyze_earnings_sentiment(self, symbol: str, company_name: str) -> Dict[str, Any]:
        """Analyze sentiment from earnings calls and reports"""
        try:
            # Placeholder for earnings sentiment analysis
            # In a real implementation, this would analyze earnings call transcripts
            
            return {
                "management_tone": 0.2,
                "guidance_sentiment": 0.1,
                "analyst_questions_sentiment": 0.0,
                "earnings_surprise_sentiment": 0.3,
                "forward_looking_sentiment": 0.2,
                "overall_earnings_sentiment": 0.16
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing earnings sentiment: {e}")
            return {"overall_earnings_sentiment": 0.0}
    
    def _aggregate_sentiment_scores(self, news_analysis: NewsAnalysis, 
                                  social_analysis: List[SocialSentiment], 
                                  earnings_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Aggregate sentiment scores from multiple sources"""
        try:
            # News sentiment (support both dataclass and dict)
            if hasattr(news_analysis, 'average_sentiment'):
                news_sentiment = news_analysis.average_sentiment
            elif isinstance(news_analysis, dict):
                news_sentiment = news_analysis.get('average_sentiment', 0.0)
            else:
                news_sentiment = 0.0
            news_weight = self.sentiment_weights['news_sentiment']
            
            # Social sentiment
            social_sentiment = 0.0
            if social_analysis:
                # Support both dataclass and dict for social_analysis items
                def get_sentiment_score(s):
                    if hasattr(s, 'sentiment_score'):
                        return s.sentiment_score
                    elif isinstance(s, dict):
                        return s.get('sentiment_score', 0.0)
                    return 0.0
                social_sentiment = sum(get_sentiment_score(s) for s in social_analysis) / len(social_analysis)
            social_weight = self.sentiment_weights['social_sentiment']
            
            # Earnings sentiment
            earnings_sentiment = earnings_analysis.get('overall_earnings_sentiment', 0.0)
            earnings_weight = self.sentiment_weights['earnings_sentiment']
            
            # Analyst sentiment (placeholder)
            analyst_sentiment = 0.0
            analyst_weight = self.sentiment_weights['analyst_sentiment']
            
            # Calculate weighted aggregate
            total_weight = news_weight + social_weight + earnings_weight + analyst_weight
            
            aggregate_sentiment = (
                news_sentiment * news_weight +
                social_sentiment * social_weight +
                earnings_sentiment * earnings_weight +
                analyst_sentiment * analyst_weight
            ) / total_weight
            
            # Calculate confidence based on data availability and consistency
            confidence_factors = []
            
            # Handle news analysis safely
            if hasattr(news_analysis, 'total_articles'):
                if news_analysis.total_articles > 0:
                    confidence_factors.append(min(news_analysis.total_articles / 10, 1.0))
            elif isinstance(news_analysis, dict) and news_analysis.get('total_articles', 0) > 0:
                confidence_factors.append(min(news_analysis.get('total_articles', 0) / 10, 1.0))
            
            if social_analysis:
                confidence_factors.append(0.6)  # Social sentiment confidence
            if earnings_analysis.get('overall_earnings_sentiment', 0) != 0:
                confidence_factors.append(0.8)  # Earnings sentiment confidence
            
            confidence = sum(confidence_factors) / len(confidence_factors) if confidence_factors else 0.5
            
            return {
                "aggregate_sentiment": aggregate_sentiment,
                "confidence": confidence,
                "news_sentiment": news_sentiment,
                "social_sentiment": social_sentiment,
                "earnings_sentiment": earnings_sentiment,
                "analyst_sentiment": analyst_sentiment,
                "sentiment_breakdown": {
                    "news": {"score": news_sentiment, "weight": news_weight},
                    "social": {"score": social_sentiment, "weight": social_weight},
                    "earnings": {"score": earnings_sentiment, "weight": earnings_weight},
                    "analyst": {"score": analyst_sentiment, "weight": analyst_weight}
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error aggregating sentiment scores: {e}")
            return {"aggregate_sentiment": 0.0, "confidence": 0.5}
    
    def _sentiment_impact_analysis(self, symbol: str, sentiment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze potential impact of sentiment on stock price"""
        try:
            sentiment_score = sentiment_data.get('aggregate_sentiment', 0.0)
            confidence = sentiment_data.get('confidence', 0.5)
            
            # Estimate price impact based on sentiment
            if sentiment_score > 0.6:
                expected_impact = "strong_positive"
                price_impact_range = (2.0, 5.0)  # 2-5% positive
            elif sentiment_score > 0.2:
                expected_impact = "moderate_positive"
                price_impact_range = (0.5, 2.0)  # 0.5-2% positive
            elif sentiment_score > -0.2:
                expected_impact = "neutral"
                price_impact_range = (-0.5, 0.5)  # -0.5 to 0.5%
            elif sentiment_score > -0.6:
                expected_impact = "moderate_negative"
                price_impact_range = (-2.0, -0.5)  # -2 to -0.5%
            else:
                expected_impact = "strong_negative"
                price_impact_range = (-5.0, -2.0)  # -5 to -2%
            
            # Adjust for confidence
            impact_probability = confidence * 0.8 + 0.2  # Minimum 20% probability
            
            return {
                "expected_impact": expected_impact,
                "price_impact_range": price_impact_range,
                "impact_probability": impact_probability,
                "time_horizon": "1-3 days",
                "sentiment_strength": abs(sentiment_score),
                "impact_confidence": confidence
            }
            
        except Exception as e:
            self.logger.error(f"Error in sentiment impact analysis: {e}")
            return {"expected_impact": "neutral", "impact_probability": 0.5}
    
    def _detect_sentiment_anomalies(self, symbol: str, sentiment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Detect unusual sentiment patterns"""
        try:
            sentiment_score = sentiment_data.get('aggregate_sentiment', 0.0)
            confidence = sentiment_data.get('confidence', 0.5)
            
            anomalies = []
            
            # Extreme sentiment detection
            if abs(sentiment_score) > 0.8:
                anomalies.append({
                    "type": "extreme_sentiment",
                    "description": f"Extreme sentiment detected: {sentiment_score:.2f}",
                    "significance": "high"
                })
            
            # Low confidence with strong sentiment
            if abs(sentiment_score) > 0.5 and confidence < 0.3:
                anomalies.append({
                    "type": "low_confidence_strong_sentiment",
                    "description": "Strong sentiment with low confidence",
                    "significance": "medium"
                })
            
            # Sentiment divergence (would need historical data)
            # This is a placeholder for more sophisticated anomaly detection
            
            return {
                "anomalies_detected": len(anomalies),
                "anomalies": anomalies,
                "anomaly_score": len(anomalies) / 3.0,  # Normalize to 0-1
                "requires_attention": len(anomalies) > 0
            }
            
        except Exception as e:
            self.logger.error(f"Error detecting sentiment anomalies: {e}")
            return {"anomalies_detected": 0, "anomalies": []}
    
    def _calculate_sentiment_score(self, sentiment_data: Dict[str, Any], 
                                 impact_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall sentiment score"""
        try:
            aggregate_sentiment = sentiment_data.get('aggregate_sentiment', 0.0)
            confidence = sentiment_data.get('confidence', 0.5)
            impact_probability = impact_analysis.get('impact_probability', 0.5)
            
            # Calculate overall score (normalize to 0-1)
            overall_score = (aggregate_sentiment + 1) / 2  # Convert from -1,1 to 0,1
            
            # Adjust for confidence
            adjusted_score = overall_score * confidence + 0.5 * (1 - confidence)
            
            # Determine recommendation
            if adjusted_score > 0.7:
                recommendation = "positive"
            elif adjusted_score > 0.3:
                recommendation = "neutral"
            else:
                recommendation = "negative"
            
            return {
                "overall_score": adjusted_score,
                "raw_sentiment": aggregate_sentiment,
                "confidence": confidence,
                "recommendation": recommendation,
                "impact_probability": impact_probability,
                "sentiment_strength": abs(aggregate_sentiment)
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating sentiment score: {e}")
            return {"overall_score": 0.5, "recommendation": "neutral"}
    
    async def analyze(self, symbol: str, timeframe: str = "1d") -> Dict[str, Any]:
        """
        Main analysis method combining mathematical analysis with CrewAI reasoning
        Returns required fields ('sentiment_score', 'signal', 'confidence') from actual analysis results.
        """
        try:
            self.logger.info(f"Starting CrewAI comprehensive sentiment analysis for {symbol}")
            # 1. Mathematical Analysis (Statistical + Transformer Models)
            math_results = await self.mathematical_analysis(symbol, {})
            if "error" in math_results:
                return math_results

            # Extract required fields from mathematical analysis
            sentiment_score = None
            confidence = None
            signal = None
            # Try to extract from overall_sentiment_score
            oss = math_results.get('overall_sentiment_score', {})
            if isinstance(oss, dict):
                sentiment_score = oss.get('raw_sentiment')
                confidence = oss.get('confidence')
                # Map recommendation to signal
                recommendation = oss.get('recommendation')
                if recommendation == "positive":
                    signal = "BUY"
                elif recommendation == "negative":
                    signal = "SELL"
                else:
                    signal = "NEUTRAL"
            # If not found, try to extract from aggregate_sentiment
            if sentiment_score is None:
                sentiment_score = math_results.get('aggregated_sentiment', {}).get('aggregate_sentiment', None)
            if confidence is None:
                confidence = math_results.get('aggregated_sentiment', {}).get('confidence', None)
            if signal is None:
                signal = "NEUTRAL"

            # Compose result
            result = {
                "sentiment_score": sentiment_score,
                "signal": signal,
                "confidence": confidence,
                "news_sentiment": math_results.get("news_sentiment"),
                "social_sentiment": math_results.get("social_sentiment"),
                "earnings_sentiment": math_results.get("earnings_sentiment"),
                "overall_sentiment": oss,
                "agent_name": self.name,
                "symbol": symbol,
                "timeframe": timeframe,
                "analysis_timestamp": datetime.now().isoformat(),
                "mathematical_analysis": math_results
            }
            return result
        except Exception as e:
            self.logger.error(f"Error in CrewAI comprehensive analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def _get_market_context(self, symbol: str, timeframe: str) -> str:
        """Get current market context for LLM reasoning"""
        try:
            return f"""
            Sentiment analysis market context for {symbol} ({timeframe}):
            - Market sentiment regime: Risk-on vs Risk-off environment
            - News cycle: Earnings season, policy announcements, economic data
            - Social media trends: Retail investor sentiment and activity
            - Analyst coverage: Recent upgrades/downgrades and target changes
            - Sector sentiment: How sector-specific news affects individual stocks
            - Economic backdrop: GDP growth, inflation, employment affecting sentiment
            - Geopolitical events: Regional/global events impacting market psychology
            - Technical sentiment: How price action influences news interpretation
            """
        except Exception as e:
            self.logger.error(f"Error getting market context: {e}")
            return "Market context not available"

    async def _get_crewai_sentiment_reasoning(self, math_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Get CrewAI-based sentiment reasoning for market psychology analysis"""
        try:
            reasoning_prompt = f"""
            You are an expert sentiment analyst with deep knowledge of market psychology and behavioral finance.
            
            Mathematical Sentiment Analysis Results:
            {math_results}
            
            Market Context:
            {market_context}
            
            Based on this quantitative sentiment analysis, provide:
            1. Market Psychology Assessment - Overall market sentiment and mood
            2. Sentiment Drivers - Key factors driving current sentiment
            3. Behavioral Patterns - Investor behavior and crowd psychology
            4. Sentiment Momentum - Whether sentiment is strengthening or weakening
            5. Contrarian Signals - Potential sentiment extremes and reversals
            6. Market Psychology Insights - What sentiment tells us about market psychology
            
            Consider:
            - News sentiment patterns and their impact
            - Social media sentiment and retail investor behavior
            - Earnings sentiment and corporate communication
            - Market sentiment cycles and psychology
            - Sentiment-price relationships and divergences
            - Behavioral finance principles and crowd psychology
            
            Provide insights that combine quantitative sentiment data with market psychology understanding.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive sentiment reasoning and market psychology analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            reasoning = self._parse_crewai_sentiment_reasoning(str(result))
            
            return reasoning
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI sentiment reasoning: {str(e)}")
            return {"error": str(e)}

    async def _get_crewai_sentiment_insights(self, data: Dict[str, Any], context: str, symbol: str) -> Dict[str, Any]:
        """Get CrewAI-based sentiment insights for nuanced interpretation"""
        try:
            insights_prompt = f"""
            You are an expert market psychologist specializing in sentiment analysis and behavioral finance.
            
            Sentiment Analysis Data:
            {data}
            
            Market Context:
            {context}
            
            Symbol: {symbol}
            
            Based on this comprehensive sentiment analysis, provide:
            1. Nuanced Sentiment Interpretation - Beyond the numbers, what does sentiment really mean?
            2. Market Psychology Insights - How sentiment reflects investor psychology
            3. Sentiment-Price Dynamics - How sentiment might influence price action
            4. Sentiment Timing - When sentiment signals are most reliable
            5. Sentiment Risk Factors - Potential sentiment-related risks
            6. Behavioral Finance Insights - What sentiment tells us about investor behavior
            
            Consider:
            - Sentiment extremes and mean reversion
            - Sentiment momentum and trend continuation
            - Sentiment divergences and potential reversals
            - Market psychology cycles and patterns
            - Behavioral biases reflected in sentiment
            - Sentiment as a contrarian indicator
            
            Provide nuanced insights that go beyond simple positive/negative sentiment to understand market psychology.
            """
            
            # Use CrewAI agent for insights
            task = Task(
                description=insights_prompt,
                agent=self.crewai_agent,
                expected_output="Nuanced sentiment insights and market psychology analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            insights = self._parse_crewai_sentiment_insights(str(result))
            
            return insights
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI sentiment insights: {str(e)}")
            return {"error": str(e)}

    def _parse_crewai_sentiment_reasoning(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI sentiment reasoning response into structured format"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Split response into sections
            sections = response.split('\n\n')
            parsed_reasoning = {
                "market_psychology_assessment": "",
                "sentiment_drivers": "",
                "behavioral_patterns": "",
                "sentiment_momentum": "",
                "contrarian_signals": "",
                "market_psychology_insights": ""
            }
            
            current_section = None
            for section in sections:
                if "Market Psychology Assessment" in section:
                    current_section = "market_psychology_assessment"
                elif "Sentiment Drivers" in section:
                    current_section = "sentiment_drivers"
                elif "Behavioral Patterns" in section:
                    current_section = "behavioral_patterns"
                elif "Sentiment Momentum" in section:
                    current_section = "sentiment_momentum"
                elif "Contrarian Signals" in section:
                    current_section = "contrarian_signals"
                elif "Market Psychology Insights" in section:
                    current_section = "market_psychology_insights"
                elif current_section and section.strip():
                    parsed_reasoning[current_section] = section.strip()
            
            return parsed_reasoning
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI sentiment reasoning response: {str(e)}")
            return {"raw_response": response}

    def _parse_crewai_sentiment_insights(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI sentiment insights response into structured format"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Split response into sections
            sections = response.split('\n\n')
            parsed_insights = {
                "nuanced_sentiment_interpretation": "",
                "market_psychology_insights": "",
                "sentiment_price_dynamics": "",
                "sentiment_timing": "",
                "sentiment_risk_factors": "",
                "behavioral_finance_insights": ""
            }
            
            current_section = None
            for section in sections:
                if "Nuanced Sentiment Interpretation" in section:
                    current_section = "nuanced_sentiment_interpretation"
                elif "Market Psychology Insights" in section:
                    current_section = "market_psychology_insights"
                elif "Sentiment-Price Dynamics" in section:
                    current_section = "sentiment_price_dynamics"
                elif "Sentiment Timing" in section:
                    current_section = "sentiment_timing"
                elif "Sentiment Risk Factors" in section:
                    current_section = "sentiment_risk_factors"
                elif "Behavioral Finance Insights" in section:
                    current_section = "behavioral_finance_insights"
                elif current_section and section.strip():
                    parsed_insights[current_section] = section.strip()
            
            return parsed_insights
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI sentiment insights response: {str(e)}")
            return {"raw_response": response}


    async def analyze_sentiment(self, symbol: str) -> dict:
        """Stub for compatibility with coordinator. Calls analyze method."""
        try:
            return await self.analyze(symbol)
        except Exception as e:
            self.logger.error(f"Error in analyze_sentiment: {e}")
            return {"error": str(e)}

# Global instance creation moved to coordinator
# enhanced_sentiment_agent = EnhancedSentimentAgent()
