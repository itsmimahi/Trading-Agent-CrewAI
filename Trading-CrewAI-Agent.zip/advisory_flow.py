"""
CrewAI Flow-based orchestration for the Main Advisory Agent.
Architecture (Phase 0 — CrewAI 1.14.5):

    initialize_flow (@start)
        │  @router
    market_router ──────────────────────► "portfolio_gate"
        │                                       │
        │ "market_analysis"           portfolio_gate_step
        ▼
    market_analysis_step   (parallel market crews via asyncio.gather)
        │  @listen
    synthesis_step         (combine results; Phase 3: AnalysisCrew + RL via A2A)
        │  @router
    approval_gate ──────────────────────► "approved" ──► execution_step
        │                                ► "needs_revision" ──► revision_step
        │                                ► "rejected" ──► rejected_step

Phase 1 adds MarketCrewBuilder (5 markets: IN/US/EU/APAC/CRYPTO).
Phase 3 adds AnalysisCrew + RL via A2A inside synthesis_step.
Phase 4 upgrades approval_gate to @human_feedback with async HTTP webhook.
Phase 5 adds LanceDB hierarchical memory.
Phase 6 adds SQLiteFlowPersistence checkpoint/resume (ADVISORY_CHECKPOINT_DB env var).

All dependencies are injected at construction time so the Flow is
stateless between requests and never imports from main_advisory_agent.py
(which would create a circular import).
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import sys
import uuid
from datetime import datetime, timedelta, time as dt_time
from typing import Any, Callable, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field

# Ensure package and project root are resolvable for sibling imports
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_HERE, _ROOT):
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from crewai.flow.flow import Flow, listen, router, start, and_
except ImportError as _e:
    raise ImportError(
        f"CrewAI Flow not available — need crewai>=1.8.0, got: {_e}"
    ) from _e

from crewai import Agent, Task, Crew, Process
from crewai.llm import LLM

# Phase 6: SQLite-backed flow state checkpoint/resume
try:
    from crewai.flow.persistence.sqlite import SQLiteFlowPersistence  # noqa: F401
    _SQLITE_PERSISTENCE_AVAILABLE = True
except ImportError:
    SQLiteFlowPersistence = None  # type: ignore[assignment,misc]
    _SQLITE_PERSISTENCE_AVAILABLE = False

from routing import GlobalMarketRouter, PortfolioActionGuard
from conversation import (
    ConversationState,
    MessageType,
    conversation_manager,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Flow State
# ─────────────────────────────────────────────────────────────────────────────


class AdvisoryFlowState(BaseModel):
    """Typed, serializable state shared across all AdvisoryFlow steps."""

    # ── Input ─────────────────────────────────────────────────────────────────
    user_input: str = ""
    conversation_id: str = ""
    request_id: str = ""

    # ── NLU outputs ──────────────────────────────────────────────────────────
    intent: str = "general_advice"
    confidence: float = 0.5
    entities: List[Dict[str, Any]] = Field(default_factory=list)
    active_markets: List[str] = Field(default_factory=lambda: ["IN"])
    invocation_mode: str = "orchestrated"   # "single_agent" | "orchestrated"
    preferred_agents: List[str] = Field(default_factory=list)
    bypass_reason: str = ""

    # ── Market analysis (Phase 1+) ────────────────────────────────────────────
    # Per-market crew results keyed by market code (IN, US, EU, APAC, CRYPTO)
    market_results: Dict[str, Any] = Field(default_factory=dict)
    # Synthesized advisory output (Phase 3: AnalysisCrew + RL validation)
    synthesis_result: str = ""
    # Pre-fetched portfolio state for risk/sizing checks
    portfolio_snapshot: Dict[str, Any] = Field(default_factory=dict)
    # Legacy market snapshot (kept for tool-based prefetch)
    market_snapshot: Dict[str, Any] = Field(default_factory=dict)

    # ── Portfolio gate ────────────────────────────────────────────────────────
    parsed_order: Optional[Dict[str, Any]] = None
    approval_decision: str = ""   # "approve" | "reject" | ""
    approval_id: str = ""

    # ── Execution results ─────────────────────────────────────────────────────
    agent_results: Dict[str, Any] = Field(default_factory=dict)
    # Phase 4: output from ExecutionCrew (validated trade list markdown + JSON)
    execution_result: str = ""
    # Phase 4: True when advisory approval is pending human confirmation
    advisory_approval_pending: bool = False

    # ── Response ──────────────────────────────────────────────────────────────
    final_response: str = ""
    response_metadata: Dict[str, Any] = Field(default_factory=dict)

    # ── Observability ─────────────────────────────────────────────────────────
    step_trace: List[str] = Field(default_factory=list)
    execution_path: str = ""
    error: Optional[str] = None
    duration_ms: float = 0.0
    # Phase 5: per-market memory recall context (for observability + injection)
    memory_recall: Dict[str, Any] = Field(default_factory=dict)

    # Phase 6: flow UUID used as key for SQLite persistence (= conversation_id)
    id: str = ""


# ─────────────────────────────────────────────────────────────────────────────
# Flow
# ─────────────────────────────────────────────────────────────────────────────


class AdvisoryFlow(Flow[AdvisoryFlowState]):
    """
    Event-driven CrewAI Flow for one advisory request (Phase 0).

    Topology:
        initialize_flow → market_router → market_analysis → synthesis → approval_gate
                                        ↘ portfolio_gate (direct trade path)

    Constructed by MainAdvisoryAgent.process_user_input() once per request.
    All external dependencies are injected at construction time.
    """

    def __init__(
        self,
        *,
        llm: LLM,
        tools: list,
        embedder_config: Optional[dict],
        entity_extractor: Any,
        intent_classifier: Any,
        default_market: str = "IN",
        advisory_disclaimer: str = "",
        verbose: bool = False,
        append_disclaimer: bool = True,
        enforce_market_hours: bool = True,
        approval_timeout_minutes: int = 30,
        idempotency_window_minutes: int = 30,
        max_position_size: float = 0.20,
        max_order_risk_fraction: float = 0.05,
        # Portfolio operation callables (injected from MainAdvisoryAgent)
        portfolio_holdings_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        portfolio_metrics_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        portfolio_preview_fn: Optional[Callable[[str, str, int], Dict[str, Any]]] = None,
        portfolio_submit_fn: Optional[Callable[[str, str, int, str], Dict[str, Any]]] = None,
        portfolio_available_fn: Optional[Callable[[], bool]] = None,
        # Phase 5: LanceDB hierarchical memory (optional — graceful no-op when None)
        memory_store: Optional[Any] = None,
        # Phase 6: SQLite checkpoint/resume — path to .db file (or env ADVISORY_CHECKPOINT_DB)
        persist_db_path: Optional[str] = None,
    ) -> None:
        super().__init__()
        self._llm = llm
        self._tools = tools
        self._embedder_config = embedder_config
        self._entity_extractor = entity_extractor
        self._intent_classifier = intent_classifier
        self._default_market = default_market
        self._disclaimer = advisory_disclaimer
        self._verbose = verbose
        self._append_disclaimer = append_disclaimer
        self._enforce_market_hours = enforce_market_hours
        self._approval_timeout_minutes = approval_timeout_minutes
        self._idempotency_window_minutes = idempotency_window_minutes
        self._max_position_size = max_position_size
        self._max_order_risk_fraction = max_order_risk_fraction
        self._portfolio_holdings_fn = portfolio_holdings_fn
        self._portfolio_metrics_fn = portfolio_metrics_fn
        self._portfolio_preview_fn = portfolio_preview_fn
        self._portfolio_submit_fn = portfolio_submit_fn
        self._portfolio_available_fn = portfolio_available_fn
        self._memory_store = memory_store  # Phase 5
        # Phase 6: SQLite flow state persistence
        _persist_path = persist_db_path or os.getenv("ADVISORY_CHECKPOINT_DB")
        self._persistence: Optional[Any] = None
        if _persist_path and _SQLITE_PERSISTENCE_AVAILABLE:
            try:
                self._persistence = SQLiteFlowPersistence(_persist_path)
                logger.debug("Flow:persistence_ready | db=%s", _persist_path)
            except Exception as _pe:
                logger.warning("Flow:persistence_init_failed | db=%s | err=%s", _persist_path, _pe)
        # Lazy-created agent (reused across steps in the same request)
        self._crew_agent: Optional[Agent] = None

    # ─────────────────────────────────────────────────────────────────────────
    # Step 1 – Initialization & NLU
    # ─────────────────────────────────────────────────────────────────────────

    @start()
    def initialize_flow(self) -> None:
        """
        NLU step: classify intent, extract entities, detect markets, determine
        invocation mode, prefetch portfolio snapshot, and parse any trade order
        or approval decision in the user's message.
        """
        s = self.state
        s.step_trace.append("initialize_flow")
        step_start = datetime.now()

        # Phase 6: pin state.id = conversation_id (SQLite persistence key)
        s.id = s.conversation_id

        # Phase 6: restore prior partial results when caller requests resume
        _resume_requested = s.response_metadata.get("resume_from_checkpoint", False)
        if _resume_requested:
            self._restore_from_checkpoint(s)

        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)

        message_id = context.add_message(MessageType.USER_INPUT, s.user_input)
        context.set_context_data("request_id", s.request_id)

        # Entity extraction
        entities = self._entity_extractor.extract_entities(s.user_input)
        for e in entities:
            context.add_extracted_entity(
                e["type"], e["value"], e["confidence"], message_id
            )
        s.entities = entities

        # Intent classification
        intent, confidence = self._intent_classifier.classify_intent(s.user_input)
        s.intent = intent
        s.confidence = confidence
        context.set_inferred_intent(f"{intent} (confidence: {confidence:.2f})")
        context.set_current_query(s.user_input)

        # Market detection + invocation mode
        s.active_markets = GlobalMarketRouter.detect_markets(
            s.user_input, entities, self._default_market
        )
        s.preferred_agents = GlobalMarketRouter.preferred_agents_for_intent(intent)
        invocation_mode = GlobalMarketRouter.invocation_mode(
            intent, s.user_input, confidence
        )
        bypass, reason = GlobalMarketRouter.should_bypass_fastpath(intent, s.user_input)
        if bypass:
            invocation_mode = "orchestrated"
        s.invocation_mode = invocation_mode
        s.bypass_reason = reason

        context.set_context_data("active_markets", s.active_markets)
        context.set_context_data("active_market", s.active_markets[0])
        context.set_context_data("preferred_agents", s.preferred_agents)
        context.set_context_data("invocation_mode", s.invocation_mode)
        context.set_context_data("fastpath_bypass_reason", reason)

        # Parse portfolio action (order or approval decision)
        s.parsed_order = PortfolioActionGuard.parse_order_request(
            text=s.user_input,
            entities=entities,
            default_market=s.active_markets[0],
        )
        decision_action, decision_id = PortfolioActionGuard.extract_decision(s.user_input)
        s.approval_decision = decision_action or ""
        s.approval_id = decision_id or ""

        # Phase 4: Advisory approval resume detection (ENABLE_ADVISORY_APPROVAL=1)
        if os.getenv("ENABLE_ADVISORY_APPROVAL", "0") == "1":
            try:
                from advisory_approval_provider import AdvisoryApprovalProvider
                _adv_provider = AdvisoryApprovalProvider()
                _adv_pending = _adv_provider.get_pending(s.conversation_id)
                if _adv_pending:
                    _adv_decision = _adv_provider.extract_decision(s.user_input)
                    if _adv_decision:
                        s.response_metadata["external_approval_outcome"] = _adv_decision
                        s.synthesis_result = _adv_pending["synthesis_text"]
                        s.advisory_approval_pending = True
                        logger.info(
                            "Flow:initialize_flow:advisory_resume | conv=%s | decision=%s",
                            s.conversation_id, _adv_decision,
                        )
            except ImportError:
                pass

        # Portfolio snapshot prefetch (Phase 4: IBKR via IBKR adapter)
        if self._portfolio_holdings_fn:
            try:
                s.portfolio_snapshot = self._portfolio_holdings_fn() or {}
            except Exception as exc:
                logger.warning("Flow:portfolio_snapshot_prefetch failed: %s", exc)

        # Best-effort market data prefetch
        self._try_prefetch_market_snapshot(context, s)

        s.duration_ms += (datetime.now() - step_start).total_seconds() * 1000.0
        logger.info(
            "Flow:initialize_flow | conv=%s | req=%s | intent=%s | mode=%s | markets=%s "
            "| order=%s | decision=%s",
            s.conversation_id, s.request_id, s.intent, s.invocation_mode,
            s.active_markets, bool(s.parsed_order), s.approval_decision or "none",
        )
        # Phase 6: checkpoint NLU results
        self._persist_step("initialize_flow")

    # ─────────────────────────────────────────────────────────────────────────
    # Router – decide execution path
    # ─────────────────────────────────────────────────────────────────────────

    @router(initialize_flow)
    def market_router(self) -> str:
        """
        Routes to:
          "portfolio_gate"   – trade order or approval decision detected
          "market_analysis"  – all other advisory queries (→ parallel market crews)
        """
        s = self.state
        s.step_trace.append("market_router")

        context = conversation_manager.get_conversation(s.conversation_id)
        pending = context.get_context_data("pending_portfolio_action") if context else None

        # Phase 4: Advisory approval resume path
        if s.advisory_approval_pending and s.response_metadata.get("external_approval_outcome"):
            s.execution_path = "advisory_execution_resume"
            return "advisory_execution_resume"

        # Handle approval decision for existing pending portfolio action
        if pending and s.approval_decision in ("approve", "reject"):
            s.execution_path = "portfolio_gate"
            return "portfolio_gate"

        # New trade order
        if s.parsed_order:
            s.execution_path = "portfolio_gate"
            return "portfolio_gate"

        # Greeting / chitchat — skip all crews and reply directly
        if s.intent == "greeting":
            s.execution_path = "greeting"
            return "greeting"

        s.execution_path = "market_analysis"
        return "market_analysis"

    # ─────────────────────────────────────────────────────────────────────────
    # Path A1 – Greeting / chitchat fast path (no crews)
    # ─────────────────────────────────────────────────────────────────────────

    @listen("greeting")
    def greeting_step(self) -> None:
        """Handle greetings and capability questions directly via LLM — no crews."""
        s = self.state
        s.step_trace.append("greeting_step")

        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)

        try:
            prompt = (
                f"The user sent a greeting or introductory message: \"{s.user_input}\"\n\n"
                "Reply warmly and briefly. Introduce yourself as an AI Trading Advisory Agent "
                "that can help with: stock market analysis (IN/US/EU/APAC/Crypto), "
                "fundamental & technical analysis, sentiment, risk assessment, trading strategy, "
                "market timing, and executing paper trades. "
                "Keep the reply under 5 sentences. Do NOT perform any market analysis."
            )
            response = self._llm.call([{"role": "user", "content": prompt}])
            s.final_response = str(response).strip()
        except Exception as exc:
            logger.warning("Flow:greeting_step:llm_error | %s", exc)
            s.final_response = (
                f"Hello! I'm your AI Trading Advisory Agent. I can help you with "
                f"stock market analysis, fundamental and technical research, sentiment, "
                f"risk assessment, trading strategies, and paper trading across Indian, "
                f"US, European, APAC, and crypto markets. What would you like to explore today?"
            )

        self._finalize(context)
        logger.info(
            "Flow:greeting_step | conv=%s | resp_chars=%d",
            s.conversation_id, len(s.final_response),
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Path A – Portfolio Gate
    # ─────────────────────────────────────────────────────────────────────────

    @listen("portfolio_gate")
    def portfolio_gate_step(self) -> None:
        """
        Handle full trade approval lifecycle:
          - Expire stale pending approvals
          - Process approve/reject decisions
          - Validate and create new approval requests
        """
        s = self.state
        s.step_trace.append("portfolio_gate_step")
        step_start = datetime.now()

        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)

        # 1. Expiry check
        expired_msg = self._check_and_expire_approval(context, s)
        if expired_msg:
            s.final_response = expired_msg
            self._finalize(context)
            s.duration_ms += (datetime.now() - step_start).total_seconds() * 1000.0
            return

        pending = context.get_context_data("pending_portfolio_action")

        # 2. Decision for existing pending action
        if pending and s.approval_decision in ("approve", "reject"):
            s.final_response = self._execute_approval_decision(context, s, pending)
            self._finalize(context)
            s.duration_ms += (datetime.now() - step_start).total_seconds() * 1000.0
            return

        # 3. New order: validate + create approval
        if s.parsed_order:
            s.final_response = self._create_approval_request(context, s)
            self._finalize(context)
            s.duration_ms += (datetime.now() - step_start).total_seconds() * 1000.0
            return

        s.final_response = "No pending trade action to process."
        self._finalize(context)
        s.duration_ms += (datetime.now() - step_start).total_seconds() * 1000.0

    # ─────────────────────────────────────────────────────────────────────────
    # Path B – Market Analysis (parallel per-market crews)
    # ─────────────────────────────────────────────────────────────────────────

    @listen("market_analysis")
    async def market_analysis_step(self) -> None:
        """
        Phase 0: Run the existing orchestrated Crew for all market analysis.
        Phase 1: Replace with MarketCrewBuilder to run one Crew per active market
                 in parallel via asyncio.gather (IN/US/EU/APAC/CRYPTO).

        Results stored in self.state.market_results[market_code].
        """
        s = self.state
        s.step_trace.append("market_analysis_step")
        step_start = datetime.now()

        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)

        # ── Phase 5: Recall prior market context before running crews ────────
        if self._memory_store:
            try:
                from advisory_memory_hooks import recall_market_history
                for _market in s.active_markets:
                    _prior = recall_market_history(
                        self._memory_store, _market, s.user_input
                    )
                    if _prior:
                        s.memory_recall[_market] = _prior
                        logger.info(
                            "Flow:memory_recall | conv=%s | market=%s | chars=%d",
                            s.conversation_id, _market, len(_prior),
                        )
            except ImportError:
                pass
        # ── End Phase 5 recall ───────────────────────────────────────────────

        # ── Phase 1 + Phase 2 hook ────────────────────────────────────────────
        # Try to use MarketCrewBuilder (Phase 1+) with MCP data tools (Phase 2+)
        market_crew_builder = None
        try:
            from market_crew_builder import MarketCrewBuilder  # noqa: F401

            # Phase 2: build market-data tools and merge with any pre-existing tools
            _combined_tools = list(self._tools)
            try:
                from mcp_data_layer import build_data_tools  # noqa: F401
                _data_tools = build_data_tools(
                    av_key=os.getenv("ALPHA_VANTAGE_API_KEY")
                )
                _combined_tools = _combined_tools + _data_tools
                logger.info(
                    "Flow:phase2_data_tools_loaded | count=%d", len(_data_tools)
                )
            except ImportError:
                pass  # Phase 2 not yet available — continue without data tools

            market_crew_builder = MarketCrewBuilder(
                llm=self._llm,
                tools=_combined_tools,
                verbose=self._verbose,
            )
        except ImportError:
            pass  # Phase 0: fall through to legacy Crew

        if market_crew_builder is not None:
            tasks = [
                self._run_market_crew_async(market_crew_builder, market, context, s)
                for market in s.active_markets
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for market, result in zip(s.active_markets, results):
                if isinstance(result, Exception):
                    logger.warning(
                        "Flow:market_crew_error | market=%s | err=%s", market, result
                    )
                    s.market_results[market] = {"error": str(result), "market": market}
                else:
                    s.market_results[market] = result or {}
        else:
            # Phase 0 fallback: run the existing orchestrated Crew once
            self._run_crew(context, s)
            for market in s.active_markets:
                s.market_results[market] = {
                    "raw": s.final_response,
                    "market": market,
                    "intent": s.intent,
                }

        # ── Phase 5: Store market analysis results to memory ─────────────────
        if self._memory_store:
            try:
                from advisory_memory_hooks import remember_market_analysis
                for _market, _result in s.market_results.items():
                    _raw = _result.get("raw", "") if isinstance(_result, dict) else str(_result)
                    if _raw and not _result.get("error"):
                        remember_market_analysis(self._memory_store, _market, _raw)
            except ImportError:
                pass
        # ── End Phase 5 store ─────────────────────────────────────────────────────

        s.duration_ms += (datetime.now() - step_start).total_seconds() * 1000.0
        logger.info(
            "Flow:market_analysis_step | conv=%s | markets=%s | dur_ms=%.1f",
            s.conversation_id, s.active_markets,
            (datetime.now() - step_start).total_seconds() * 1000.0,
        )
        # Phase 6: checkpoint market analysis results (most expensive step)
        self._persist_step("market_analysis_step")

    async def _run_market_crew_async(
        self,
        builder: Any,
        market: str,
        context: Any,
        s: AdvisoryFlowState,
    ) -> Dict[str, Any]:
        """Run a single market's Crew asynchronously (Phase 1+)."""
        try:
            crew = builder.build_market_crew(
                market=market,
                user_input=s.user_input,
                intent=s.intent,
                entities=s.entities,
                portfolio_snapshot=s.portfolio_snapshot,
            )
            result = await asyncio.to_thread(crew.kickoff)
            return {"raw": str(result), "market": market, "intent": s.intent}
        except Exception as exc:
            logger.error(
                "Flow:market_crew_async_error | market=%s | err=%s", market, exc
            )
            raise

    # ─────────────────────────────────────────────────────────────────────────
    # Step C – Synthesis
    # ─────────────────────────────────────────────────────────────────────────

    @listen(market_analysis_step)
    def synthesis_step(self) -> None:
        """
        Phase 0: Combine market_results into a single synthesis string.
        Phase 3: Replace with AnalysisCrew + RL validation via A2A SDK.

        Populates self.state.synthesis_result for approval_gate.
        """
        s = self.state
        s.step_trace.append("synthesis_step")

        # ── Phase 3 hook ──────────────────────────────────────────────────────
        try:
            from analysis_crew_builder import (  # noqa: F401
                AnalysisCrewBuilder,
                rl_a2a_validate,
            )
            builder = AnalysisCrewBuilder(llm=self._llm, verbose=self._verbose)
            crew = builder.build(
                market_results=s.market_results,
                portfolio_snapshot=s.portfolio_snapshot,
            )
            result = crew.kickoff()
            # RL A2A: optional confidence calibration (graceful no-op if unavailable)
            synthesis_text = rl_a2a_validate(str(result), s.market_results)
            s.synthesis_result = synthesis_text
            logger.info(
                "Flow:synthesis_step:phase3 | conv=%s | synthesis_len=%d | rl=%s",
                s.conversation_id, len(synthesis_text),
                os.getenv("ENABLE_RL_VALIDATION", "0"),
            )
            if not s.final_response:
                s.final_response = s.synthesis_result
            return
        except ImportError:
            pass  # Phase 0: inline synthesis

        # Phase 0: combine raw market crew results
        if not s.market_results:
            s.synthesis_result = s.final_response or "No market analysis available."
            return

        if len(s.market_results) == 1:
            only = next(iter(s.market_results.values()))
            s.synthesis_result = (
                only.get("raw", str(only)) if isinstance(only, dict) else str(only)
            )
        else:
            parts = []
            for market, result in s.market_results.items():
                raw = (
                    result.get("raw", str(result)) if isinstance(result, dict) else str(result)
                )
                parts.append(f"**{market}**:\n{raw}")
            s.synthesis_result = "\n\n".join(parts)

        if not s.final_response:
            s.final_response = s.synthesis_result

        # ── Phase 5: Store synthesis to memory ───────────────────────────────
        if self._memory_store and s.synthesis_result:
            try:
                from advisory_memory_hooks import remember_synthesis
                remember_synthesis(
                    self._memory_store, s.conversation_id, s.synthesis_result
                )
                logger.info(
                    "Flow:synthesis_step:phase5_store | conv=%s | len=%d",
                    s.conversation_id, len(s.synthesis_result),
                )
            except ImportError:
                pass
        # ── End Phase 5 synthesis store ──────────────────────────────────────

        logger.info(
            "Flow:synthesis_step | conv=%s | synthesis_len=%d",
            s.conversation_id, len(s.synthesis_result),
        )
        # Phase 6: checkpoint synthesis (critical — before human approval gate)
        self._persist_step("synthesis_step")

    # ─────────────────────────────────────────────────────────────────────────
    # Step D – Approval Gate
    # Phase 0: @router auto-approves (no blocking input() call).
    # Phase 4: Replace with @human_feedback + async HTTP webhook provider.
    # ─────────────────────────────────────────────────────────────────────────

    @router(synthesis_step)
    def approval_gate(self) -> str:
        """
        Phase 0: Auto-approves all advisory synthesis.
        Phase 4: Replace with @human_feedback + async HTTP webhook provider:

            from crewai.flow.human_feedback import human_feedback
            @listen(synthesis_step)
            @human_feedback(
                message="Advisory synthesis ready. Review and approve/revise/reject:",
                emit=["approved", "needs_revision", "rejected"],
                llm="azure/gpt-4.1",
                default_outcome="approved",
                provider=HttpWebhookFeedbackProvider(),
            )
            async def approval_gate(self) -> str:
                return self.state.synthesis_result

        Returns one of: "approved" | "needs_revision" | "rejected"
        """
        s = self.state
        s.step_trace.append("approval_gate")

        # Phase 4+: honour externally injected outcome (e.g. from HTTP webhook)
        external = s.response_metadata.get("external_approval_outcome")
        if external in ("approved", "needs_revision", "rejected"):
            return external

        # Phase 0: Auto-approve all synthesis
        return "approved"

    # ─────────────────────────────────────────────────────────────────────────
    # Step E – Execution (post-approval)
    # ─────────────────────────────────────────────────────────────────────────

    @listen("approved")
    def execution_step(self) -> None:
        """
        Phase 0: Finalise the advisory response after approval.
        Phase 4: ExecutionCrew — translate approved recommendations into
                 IBKR paper-trade orders via IBKRPortfolioService.

        Portfolio snapshot is refreshed from IBKR immediately before execution
        to ensure positions and cash balances are current.
        """
        s = self.state
        s.step_trace.append("execution_step")

        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)

        if not s.final_response and s.synthesis_result:
            s.final_response = s.synthesis_result

        # ── IBKR portfolio refresh before execution ───────────────────────────
        # Re-fetch live portfolio state from IBKR so ExecutionCrew uses the most
        # recent positions and cash, not the snapshot from initialize_flow.
        if self._portfolio_holdings_fn:
            try:
                fresh_snapshot = self._portfolio_holdings_fn() or {}
                if fresh_snapshot and "error" not in fresh_snapshot:
                    s.portfolio_snapshot = fresh_snapshot
                    logger.info(
                        "Flow:execution_step:ibkr_refresh | conv=%s | positions=%d cash=%.2f",
                        s.conversation_id,
                        len(fresh_snapshot.get("holdings", [])),
                        float(fresh_snapshot.get("cash", 0.0) or 0.0),
                    )
            except Exception as _ref_exc:
                logger.warning(
                    "Flow:execution_step:ibkr_refresh failed | conv=%s | err=%s",
                    s.conversation_id,
                    _ref_exc,
                )
        # ── End IBKR portfolio refresh ────────────────────────────────────────

        # ── Phase 4 hook ──────────────────────────────────────────────────────
        try:
            from execution_crew_builder import ExecutionCrewBuilder  # noqa: F401

            # Advisory-level approval gate (opt-in via ENABLE_ADVISORY_APPROVAL=1)
            if os.getenv("ENABLE_ADVISORY_APPROVAL", "0") == "1":
                from advisory_approval_provider import AdvisoryApprovalProvider
                provider = AdvisoryApprovalProvider()
                external = s.response_metadata.get("external_approval_outcome")
                if not external:
                    # First time here — create a pending approval and pause
                    pending = provider.create_pending(
                        s.conversation_id, s.synthesis_result
                    )
                    s.final_response = pending["draft_message"]
                    s.advisory_approval_pending = True
                    self._finalize(context)
                    logger.info(
                        "Flow:execution_step:approval_pending | conv=%s | id=%s",
                        s.conversation_id, pending["approval_id"],
                    )
                    return
                # User responded — clean up pending entry
                provider.resolve(s.conversation_id)
                if external != "approved":
                    # Revise / reject — let the downstream listener handle it
                    self._finalize(context)
                    return

            # Run ExecutionCrew (synthesis already approved at this point)
            exec_crew = ExecutionCrewBuilder(
                llm=self._llm,
                verbose=self._verbose,
                max_position_size=self._max_position_size,
                max_order_risk_fraction=self._max_order_risk_fraction,
            ).build(
                synthesis=s.synthesis_result,
                portfolio_snapshot=s.portfolio_snapshot,
            )
            exec_result = exec_crew.kickoff()
            s.execution_result = str(exec_result)
            if not s.final_response:
                s.final_response = s.execution_result
            elif s.execution_result:
                s.final_response = s.final_response + "\n\n---\n\n" + s.execution_result
            # ── Phase 5: Store execution result to memory ─────────────────────
            if self._memory_store and s.execution_result:
                try:
                    from advisory_memory_hooks import remember_trade_execution
                    remember_trade_execution(
                        self._memory_store, s.execution_result, s.conversation_id
                    )
                except ImportError:
                    pass
            # ── End Phase 5 execution store ────────────────────────────────────
            logger.info(
                "Flow:execution_step:phase4 | conv=%s | exec_len=%d",
                s.conversation_id, len(s.execution_result),
            )
        except ImportError:
            pass  # Phase 0 fallback — execution_crew_builder not yet active
        # ── End Phase 4 hook ──────────────────────────────────────────────────

        self._finalize(context)
        # Phase 6: final checkpoint after full execution
        self._persist_step("execution_step")
        logger.info(
            "Flow:execution_step | conv=%s | response_len=%d",
            s.conversation_id, len(s.final_response),
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Step E2 – Revision stub
    # ─────────────────────────────────────────────────────────────────────────

    @listen("needs_revision")
    def revision_step(self) -> None:
        """Phase 0: Record revision request. Phase 4: re-run AnalysisCrew with feedback."""
        s = self.state
        s.step_trace.append("revision_step")
        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)
        feedback = s.response_metadata.get("human_feedback_text", "")
        s.final_response = (
            "The advisory analysis has been flagged for revision. "
            "Your feedback has been recorded"
            + (f": {feedback}" if feedback else ".")
            + "\n\nPlease provide updated query details for a revised analysis."
        )
        self._finalize(context)

    # ─────────────────────────────────────────────────────────────────────────
    # Step E3 – Rejected stub
    # ─────────────────────────────────────────────────────────────────────────

    @listen("rejected")
    def rejected_step(self) -> None:
        """Handle rejection of advisory synthesis."""
        s = self.state
        s.step_trace.append("rejected_step")
        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)
        s.final_response = (
            "The advisory analysis was rejected. Please rephrase your query "
            "or provide additional context for a new analysis."
        )
        self._finalize(context)

    # ─────────────────────────────────────────────────────────────────────────
    # Step E4 – Advisory Execution Resume (Phase 4)
    # Entered when user approves/revises/rejects a pending advisory synthesis.
    # Skips re-analysis — restores synthesis from AdvisoryApprovalProvider.
    # ─────────────────────────────────────────────────────────────────────────

    @listen("advisory_execution_resume")
    def advisory_execution_resume_step(self) -> None:
        """
        Phase 4: Resume the advisory flow after the user responds to an
        advisory synthesis approval request.

        The synthesis has already been restored from AdvisoryApprovalProvider
        in initialize_flow.  This step applies the user's decision:
          - "rejected"      → dismissal message
          - "needs_revision" → revision message
          - "approved"       → run ExecutionCrew with stored synthesis
        """
        s = self.state
        s.step_trace.append("advisory_execution_resume_step")
        context = conversation_manager.get_conversation(s.conversation_id)
        if not context:
            context = conversation_manager.create_conversation(s.conversation_id)

        # Clean up pending entry
        try:
            from advisory_approval_provider import AdvisoryApprovalProvider
            AdvisoryApprovalProvider.resolve(s.conversation_id)
        except ImportError:
            pass

        external = s.response_metadata.get("external_approval_outcome", "approved")

        if external == "rejected":
            s.final_response = (
                "The advisory analysis was rejected. Please rephrase your query "
                "or provide additional context for a new analysis."
            )
            self._finalize(context)
            return

        if external == "needs_revision":
            feedback = s.response_metadata.get("human_feedback_text", "")
            s.final_response = (
                "The advisory analysis has been flagged for revision. "
                "Your feedback has been recorded"
                + (f": {feedback}" if feedback else ".")
                + "\n\nPlease provide updated query details for a revised analysis."
            )
            self._finalize(context)
            return

        # "approved" — run ExecutionCrew
        try:
            from execution_crew_builder import ExecutionCrewBuilder
            exec_crew = ExecutionCrewBuilder(
                llm=self._llm,
                verbose=self._verbose,
                max_position_size=self._max_position_size,
                max_order_risk_fraction=self._max_order_risk_fraction,
            ).build(
                synthesis=s.synthesis_result,
                portfolio_snapshot=s.portfolio_snapshot,
            )
            exec_result = exec_crew.kickoff()
            s.execution_result = str(exec_result)
            s.final_response = s.execution_result
            logger.info(
                "Flow:advisory_execution_resume | conv=%s | exec_len=%d",
                s.conversation_id, len(s.execution_result),
            )
        except ImportError:
            s.final_response = s.synthesis_result or "Advisory approved — no execution crew available."

        self._finalize(context)

    # ─────────────────────────────────────────────────────────────────────────
    # Phase 6 – Checkpoint helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _persist_step(self, method_name: str) -> None:
        """
        Phase 6: Save the current AdvisoryFlowState to SQLite after a step
        completes.  Uses conversation_id as the flow UUID so any request with
        the same conv-id can restore partial results on retry/crash-recovery.

        Completely silent — errors are logged at WARNING but never raised.
        """
        if self._persistence is None:
            return
        s = self.state
        flow_uuid = s.conversation_id or s.id
        if not flow_uuid:
            return
        try:
            self._persistence.save_state(
                flow_uuid=flow_uuid,
                method_name=method_name,
                state_data=s,
            )
            logger.debug(
                "Flow:checkpoint_saved | conv=%s | step=%s", flow_uuid, method_name
            )
        except Exception as exc:
            logger.warning(
                "Flow:checkpoint_failed | conv=%s | step=%s | err=%s",
                flow_uuid, method_name, exc,
            )

    def _restore_from_checkpoint(self, s: Any) -> bool:
        """
        Phase 6: Try to restore partial state from the latest SQLite checkpoint
        for this conversation.  Returns True if a checkpoint was found and applied.

        Only restores fields that represent expensive computation results;
        never overwrites user-supplied request fields (user_input, request_id, etc.).
        """
        if self._persistence is None or not s.conversation_id:
            return False
        try:
            stored = self._persistence.load_state(s.conversation_id)
            if not stored:
                return False
            _restorable = {
                "market_results", "synthesis_result", "execution_result",
                "step_trace", "execution_path", "market_snapshot",
                "portfolio_snapshot", "entities", "active_markets",
                "intent", "confidence", "invocation_mode",
                "preferred_agents", "bypass_reason",
                "advisory_approval_pending", "memory_recall",
            }
            restored_any = False
            for field in _restorable:
                val = stored.get(field)
                empty = val in (None, "", [], {}, False)
                if not empty:
                    setattr(s, field, val)
                    restored_any = True
            if restored_any:
                logger.info(
                    "Flow:checkpoint_restored | conv=%s | steps=%s",
                    s.conversation_id, stored.get("step_trace", []),
                )
            return restored_any
        except Exception as exc:
            logger.warning(
                "Flow:checkpoint_restore_failed | conv=%s | err=%s",
                s.conversation_id, exc,
            )
            return False

    # ─────────────────────────────────────────────────────────────────────────
    # Crew builder + runner
    # ─────────────────────────────────────────────────────────────────────────

    def _get_crew_agent(self) -> Agent:
        """Return lazily created Agent instance (reused within a single request)."""
        if self._crew_agent is None:
            self._crew_agent = Agent(
                role="AI Trading Advisory Agent",
                goal=(
                    "Provide expert-level stock market analysis and investment "
                    "recommendations by orchestrating specialized agents and maintaining "
                    "contextual conversations with users"
                ),
                backstory=(
                    "You are a sophisticated AI Trading Advisory Agent with deep expertise "
                    "in financial markets. You serve as the primary interface between users "
                    "and a suite of specialized financial analysis agents. Your role is to "
                    "understand user queries, intelligently delegate tasks to appropriate "
                    "specialized agents, synthesize their insights, and provide comprehensive, "
                    "actionable investment advice. You are known for your ability to break down "
                    "complex financial concepts into understandable insights while maintaining "
                    "the depth and accuracy expected from a professional financial advisor."
                ),
                verbose=self._verbose,
                allow_delegation=True,
                max_iter=25,
                memory=True,
                reasoning=True,
                max_reasoning_attempts=2,
                tools=self._tools,
                llm=self._llm,
            )
        return self._crew_agent

    def _build_task_description(self, context: Any, s: AdvisoryFlowState) -> str:
        """Build the detailed task description for the Crew from current state."""
        context_summary = context.get_conversation_summary()
        market_info = ""
        if s.market_snapshot:
            market_info = (
                f"\n\nMarket Snapshot:\n{json.dumps(s.market_snapshot, indent=2)[:1500]}"
            )

        desc = (
            f"User Query: {s.user_input}\n\n"
            f"Intent: {s.intent} (confidence: {s.confidence:.2f})\n"
            f"Active Markets: {', '.join(s.active_markets)}\n"
            f"Extracted Entities: {json.dumps(s.entities)}\n"
            f"Preferred Agents (if scoped): {s.preferred_agents}\n"
            f"Invocation Mode: {s.invocation_mode}\n"
            f"Fast-Path Bypass Reason: {s.bypass_reason}\n"
            f"Conversation Summary: {json.dumps(context_summary)}"
            f"{market_info}\n\n"
            "Instructions:\n"
            "1. Analyze the user query and determine if specialized agents are needed.\n"
            "2. For single-agent needs, use specialized_agent_tool; for multi-agent, use parallel_specialized_agent_tool.\n"
            "3. Use agent_registry_tool only with: list_all, find_by_capability, find_by_role, get_agent, get_capabilities, find_by_tag.\n"
            "4. Synthesize information from multiple sources and provide a comprehensive, actionable response.\n"
            "5. Ask at most ONE clarifying question. If the market is unspecified, assume the default market and proceed.\n"
            "6. If Invocation Mode is single_agent, prioritize only the first Preferred Agent.\n"
            "7. Do NOT submit any portfolio order without explicit APPROVE <approval_id> confirmation.\n"
            f"8. Default market: {self._default_market}."
        )

        # Inject pre-fetched market data
        try:
            mo = context.get_context_data("market_overview")
            tm = context.get_context_data("top_movers")
            if mo or tm:
                desc += "\n\nPre-fetched Market Data:\n"
                if mo:
                    desc += f"- Market Overview: {json.dumps(mo)[:1200]}\n"
                if tm:
                    desc += f"- Top Movers: {json.dumps(tm)[:1200]}\n"
        except Exception:
            pass

        return desc

    def _run_crew(self, context: Any, s: AdvisoryFlowState) -> None:
        """Build and kick off a Crew with planning for the current request."""
        if context.state == ConversationState.INITIAL_QUERY:
            context.update_state(ConversationState.CONTEXT_GATHERING)

        task = Task(
            description=self._build_task_description(context, s),
            expected_output=(
                "A comprehensive response to the user's query with analysis, "
                "insights, and actionable recommendations"
            ),
            agent=self._get_crew_agent(),
        )

        crew = Crew(
            agents=[self._get_crew_agent()],
            tasks=[task],
            process=Process.sequential,
            verbose=self._verbose,
            memory=False,  # Disabled: CrewAI 1.14.5 memory bugs cause noise; no cross-session recall loss
            embedder=self._embedder_config,
            planning=True,
            planning_llm=self._llm,
            step_callback=self._step_callback,
            task_callback=self._task_done_callback,
        )

        # Suppress LTM save errors (known upstream issue)
        try:
            setattr(crew, "_long_term_memory", None)
        except Exception:
            pass

        crew_start = datetime.now()
        result = crew.kickoff()
        crew_dur = (datetime.now() - crew_start).total_seconds() * 1000.0
        s.final_response = str(result)

        logger.info(
            "Flow:crew_kickoff | conv=%s | req=%s | dur_ms=%.1f | resp_chars=%d",
            s.conversation_id, s.request_id, crew_dur, len(s.final_response),
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Callbacks
    # ─────────────────────────────────────────────────────────────────────────

    def _step_callback(self, step_output: Any) -> None:
        """Invoked after each agent step; used for observability."""
        try:
            logger.debug(
                "Flow:step_cb | conv=%s | output=%s",
                self.state.conversation_id,
                str(step_output)[:300],
            )
        except Exception:
            pass

    def _task_done_callback(self, task_output: Any) -> None:
        """Invoked after each task completes; used for observability."""
        try:
            logger.info(
                "Flow:task_done | conv=%s | output_len=%d",
                self.state.conversation_id,
                len(str(task_output)),
            )
        except Exception:
            pass

    # ─────────────────────────────────────────────────────────────────────────
    # Response finalisation
    # ─────────────────────────────────────────────────────────────────────────

    def _finalize(self, context: Any) -> None:
        """Append disclaimer, store response in conversation context, record metadata."""
        s = self.state
        if self._append_disclaimer and self._disclaimer and s.final_response:
            if self._disclaimer not in s.final_response:
                s.final_response = f"{s.final_response}\n\n{self._disclaimer}"

        context.add_message(MessageType.AGENT_RESPONSE, s.final_response)
        context.update_state(ConversationState.RECOMMENDATION_GENERATION)

        s.response_metadata.update({
            "execution_path": s.execution_path,
            "step_trace": s.step_trace,
            "intent": s.intent,
            "confidence": s.confidence,
            "active_markets": s.active_markets,
            "duration_ms": s.duration_ms,
        })

    # ─────────────────────────────────────────────────────────────────────────
    # Market snapshot prefetch
    # ─────────────────────────────────────────────────────────────────────────

    def _try_prefetch_market_snapshot(self, context: Any, s: AdvisoryFlowState) -> None:
        """Best-effort market overview + top movers prefetch."""
        text_lower = s.user_input.lower()
        needs = s.intent in ("risk_assessment",) or any(
            k in text_lower
            for k in ["today", "market view", "top stock", "top performer", "gainer", "loser"]
        )
        if not needs:
            return
        try:
            md_tool = next(
                (t for t in self._tools if type(t).__name__ == "MarketDataTool"), None
            )
            if md_tool is None:
                return
            snapshot: Dict[str, Any] = {}
            for market in s.active_markets[:2]:
                overview = json.loads(md_tool._run("market_overview", market=market))
                movers = json.loads(md_tool._run("top_movers", market=market, top=10))
                snapshot[market] = {"overview": overview, "movers": movers}
            s.market_snapshot = snapshot
            context.set_context_data(
                "market_overview", {m: v["overview"] for m, v in snapshot.items()}
            )
            context.set_context_data(
                "top_movers", {m: v["movers"] for m, v in snapshot.items()}
            )
        except Exception as exc:
            logger.warning("Flow:prefetch_market_snapshot failed: %s", exc)

    # ─────────────────────────────────────────────────────────────────────────
    # Approval lifecycle helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _check_and_expire_approval(
        self, context: Any, s: AdvisoryFlowState
    ) -> Optional[str]:
        """Return an expiry message if the pending approval has timed out."""
        pending = context.get_context_data("pending_portfolio_action")
        if not pending:
            return None
        expires_raw = pending.get("expires_at")
        if not expires_raw:
            return None
        try:
            expires_at = datetime.fromisoformat(str(expires_raw))
            if datetime.utcnow() <= expires_at:
                return None
        except Exception:
            return None

        approval_id = str(pending.get("approval_id", ""))
        self._record_approval_state(context, pending, "expired", "approval_timeout")
        context.set_context_data("pending_portfolio_action", None)
        logger.info(
            "Flow:approval_expired | approval_id=%s | conv=%s", approval_id, s.conversation_id
        )

        if s.approval_decision in ("approve", "reject"):
            return (
                f"Approval request `{approval_id}` has expired and was not executed. "
                f"Please submit a new order request if you still want to proceed."
            )
        return None

    def _execute_approval_decision(
        self, context: Any, s: AdvisoryFlowState, pending: Dict[str, Any]
    ) -> str:
        """Process an approve or reject decision against a pending order."""
        pending_id = str(pending.get("approval_id", ""))

        # ID mismatch guard
        if s.approval_id and s.approval_id != pending_id:
            return (
                f"Approval ID mismatch. Pending approval is `{pending_id}`. "
                f"Reply with `APPROVE {pending_id}` or `REJECT {pending_id}`."
            )

        order = pending.get("order") or {}

        if s.approval_decision == "reject":
            self._record_approval_state(context, pending, "rejected", "user_rejected")
            context.set_context_data("pending_portfolio_action", None)
            return (
                f"Order request `{pending_id}` rejected. No trade was submitted.\n"
                f"Order: {str(order.get('side','')).upper()} "
                f"{order.get('quantity','')} {order.get('symbol','')}."
            )

        # Approve: submit via injected callable
        idem_key = str(pending.get("idempotency_key", pending_id))
        if self._portfolio_submit_fn is None:
            context.set_context_data("pending_portfolio_action", None)
            self._record_approval_state(context, pending, "approved_no_broker", "no_broker")
            return (
                f"Order approved (`{pending_id}`), but no broker connection is active. "
                "Set IB_ENABLED=1 to enable live order execution."
            )

        try:
            result = self._portfolio_submit_fn(
                str(order.get("symbol", "")),
                str(order.get("side", "")),
                int(order.get("quantity", 0) or 0),
                idem_key,
            )
            if isinstance(result, dict) and result.get("error"):
                return (
                    f"Approval `{pending_id}` accepted, but order submission failed: "
                    f"{result.get('error')}"
                )
            self._record_approval_state(context, pending, "approved_executed", "submitted")
            context.set_context_data("pending_portfolio_action", None)
            # Record to idempotency history
            history = context.get_context_data("trade_idempotency_history", []) or []
            history.append(
                {"key": idem_key, "ts": datetime.utcnow().timestamp(), "status": "submitted"}
            )
            context.set_context_data("trade_idempotency_history", history)
            return (
                f"Order executed. Approval `{pending_id}`.\n"
                f"Result: {json.dumps(result)}"
            )
        except Exception as exc:
            self._record_approval_state(context, pending, "approved_execution_failed", str(exc))
            logger.error(
                "Flow:order_exec_failed | approval=%s | err=%s", pending_id, exc
            )
            return f"Approval `{pending_id}` accepted but execution failed: {exc}"

    def _create_approval_request(
        self, context: Any, s: AdvisoryFlowState
    ) -> str:
        """Validate a new order and create a pending approval request."""
        order = s.parsed_order
        approval_id = str(uuid.uuid4())
        idem_key = self._generate_idempotency_key(s.conversation_id, order)

        # Duplicate order guard
        pending = context.get_context_data("pending_portfolio_action")
        if pending and pending.get("idempotency_key") == idem_key:
            pid = pending.get("approval_id", "")
            return (
                f"A duplicate order is already pending approval (ID: `{pid}`).\n"
                f"Reply `APPROVE {pid}` to confirm or `REJECT {pid}` to cancel."
            )

        # Idempotency history check
        history = context.get_context_data("trade_idempotency_history", []) or []
        now_ts = datetime.utcnow().timestamp()
        window_s = self._idempotency_window_minutes * 60
        fresh_history = [h for h in history if now_ts - float(h.get("ts", 0)) <= window_s]
        context.set_context_data("trade_idempotency_history", fresh_history)
        if any(h.get("key") == idem_key for h in fresh_history):
            return "Duplicate order blocked by idempotency window. Please wait before resubmitting."

        # Preview
        preview_obj: Dict[str, Any] = {}
        if self._portfolio_preview_fn:
            try:
                preview_obj = self._portfolio_preview_fn(
                    order["symbol"], order["side"], order["quantity"]
                )
            except Exception as exc:
                preview_obj = {"error": str(exc)}

        # Pre-trade hard validation
        validation = self._validate_pre_trade(order, preview_obj, context, idem_key)
        if not validation["allowed"]:
            reasons_text = "\n".join(f"- {r}" for r in validation["reasons"])
            return (
                "Trade request blocked by pre-trade validation gates.\n\n"
                f"Order: {str(order['side']).upper()} {order['quantity']} {order['symbol']} "
                f"(market: {order.get('market', 'IN')})\n"
                f"Reasons:\n{reasons_text}"
            )

        # Create pending approval
        pending_obj: Dict[str, Any] = {
            "approval_id": approval_id,
            "idempotency_key": idem_key,
            "order": order,
            "preview": preview_obj,
            "validation": validation,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": (
                datetime.utcnow() + timedelta(minutes=self._approval_timeout_minutes)
            ).isoformat(),
            "state": "pending_approval",
            "request_id": s.request_id,
        }
        context.set_context_data("pending_portfolio_action", pending_obj)
        self._record_approval_state(context, pending_obj, "pending_approval", "created")

        estimated_total = (
            preview_obj.get("estimated_total") if isinstance(preview_obj, dict) else None
        )
        fee = (
            preview_obj.get("fee") or preview_obj.get("estimated_fees")
            if isinstance(preview_obj, dict)
            else None
        )
        preview_line = ""
        if estimated_total is not None:
            preview_line = f"Estimated total: {estimated_total}."
            if fee is not None:
                preview_line += f" Estimated fee: {fee}."

        return (
            "Approval required before order submission.\n\n"
            f"Order: {str(order['side']).upper()} {order['quantity']} {order['symbol']} "
            f"(market: {order.get('market', 'IN')})\n"
            f"{preview_line}\n"
            f"Idempotency key: {idem_key}\n"
            f"Approval timeout: {self._approval_timeout_minutes} minutes\n\n"
            f"To confirm: `APPROVE {approval_id}`\n"
            f"To cancel: `REJECT {approval_id}`"
        ).strip()

    # ─────────────────────────────────────────────────────────────────────────
    # Pre-trade validation
    # ─────────────────────────────────────────────────────────────────────────

    def _validate_pre_trade(
        self,
        order: Dict[str, Any],
        preview_obj: Dict[str, Any],
        context: Any,
        idempotency_key: str,
    ) -> Dict[str, Any]:
        """Hard pre-trade gates: shape, market hours, cash, position, risk limits."""
        reasons: List[str] = []
        side = str(order.get("side", "")).lower()
        symbol = str(order.get("symbol", "")).upper()
        quantity = int(order.get("quantity", 0) or 0)
        market = str(order.get("market", "IN")).upper()

        # Basic shape
        if quantity <= 0:
            reasons.append("Quantity must be greater than 0")
        if side not in ("buy", "sell"):
            reasons.append("Order side must be buy or sell")
        if quantity > 100_000:
            reasons.append(f"Quantity {quantity} exceeds single-order limit of 100,000")

        # Market hours
        if self._enforce_market_hours:
            is_open, hour_reason = self._check_market_hours(market)
            if not is_open:
                reasons.append(hour_reason)

        # Portfolio-based checks (best-effort; skip if portfolio unavailable)
        holdings: Dict[str, Any] = {}
        metrics: Dict[str, Any] = {}
        if self._portfolio_holdings_fn:
            try:
                holdings = self._portfolio_holdings_fn() or {}
            except Exception:
                pass
        if self._portfolio_metrics_fn:
            try:
                metrics = self._portfolio_metrics_fn() or {}
            except Exception:
                pass

        cash = float((holdings or {}).get("cash", 0.0) or 0.0)
        holdings_list = (
            (holdings or {}).get("holdings", [])
            if isinstance(holdings, dict)
            else []
        )
        existing_pos = next(
            (h for h in holdings_list if str(h.get("symbol", "")).upper() == symbol), None
        )
        existing_qty = int((existing_pos or {}).get("quantity", 0) or 0)
        existing_avg = float((existing_pos or {}).get("avg_price", 0.0) or 0.0)
        existing_value = existing_qty * existing_avg

        estimated_total = float((preview_obj or {}).get("estimated_total", 0.0) or 0.0)
        last_price = float((preview_obj or {}).get("last_price", 0.0) or 0.0)
        notional = last_price * quantity if last_price > 0 else estimated_total

        if side == "buy" and estimated_total > 0 and estimated_total > cash:
            reasons.append(
                f"Insufficient cash: required {estimated_total:.2f}, available {cash:.2f}"
            )
        if side == "sell" and quantity > existing_qty:
            reasons.append(
                f"Insufficient position: required {quantity}, available {existing_qty}"
            )

        total_value = float((metrics or {}).get("total_value_est", 0.0) or 0.0) or cash
        if total_value > 0 and notional > 0:
            if side == "buy":
                projected = existing_value + notional
                if projected > total_value * self._max_position_size:
                    reasons.append(
                        f"Position size limit: projected {projected:.2f} > "
                        f"limit {total_value * self._max_position_size:.2f}"
                    )
            if notional > total_value * self._max_order_risk_fraction:
                reasons.append(
                    f"Order risk limit: notional {notional:.2f} > "
                    f"limit {total_value * self._max_order_risk_fraction:.2f}"
                )

        return {
            "allowed": len(reasons) == 0,
            "reasons": reasons,
            "idempotency_key": idempotency_key,
            "risk_summary": {
                "notional": notional,
                "total_value": total_value,
                "max_position_size": self._max_position_size,
                "max_order_risk_fraction": self._max_order_risk_fraction,
            },
        }

    def _check_market_hours(self, market: str) -> Tuple[bool, str]:
        """Return (is_open, reason) for the given market."""
        m = (market or "IN").upper()
        if m == "CRYPTO":
            return True, "24x7"
        try:
            from zoneinfo import ZoneInfo
        except ImportError:
            return True, "zoneinfo unavailable — market hours not enforced"

        windows: Dict[str, Tuple[str, dt_time, dt_time]] = {
            "IN":   ("Asia/Kolkata",      dt_time(9, 15),  dt_time(15, 30)),
            "US":   ("America/New_York",  dt_time(9, 30),  dt_time(16, 0)),
            "EU":   ("Europe/London",     dt_time(8, 0),   dt_time(16, 30)),
            "APAC": ("Asia/Tokyo",        dt_time(9, 0),   dt_time(15, 0)),
        }
        zone_name, open_t, close_t = windows.get(m, windows["IN"])
        now = datetime.now(ZoneInfo(zone_name))
        if now.weekday() >= 5:
            return False, f"{m} market closed (weekend)"
        now_t = now.time().replace(tzinfo=None)
        if open_t <= now_t <= close_t:
            return True, f"{m} market open"
        return False, f"{m} market closed (outside hours {open_t}-{close_t} {zone_name})"

    # ─────────────────────────────────────────────────────────────────────────
    # Static utilities
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _generate_idempotency_key(conversation_id: str, order: Dict[str, Any]) -> str:
        seed = (
            f"{conversation_id}"
            f"|{str(order.get('symbol', '')).upper()}"
            f"|{str(order.get('side', '')).lower()}"
            f"|{int(order.get('quantity', 0))}"
        )
        return hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]

    @staticmethod
    def _record_approval_state(
        context: Any,
        pending: Dict[str, Any],
        state: str,
        reason: Optional[str] = None,
    ) -> None:
        """Append to approval_state_history and update last_approval_state."""
        history = context.get_context_data("approval_state_history", []) or []
        entry: Dict[str, Any] = {
            "approval_id": pending.get("approval_id"),
            "idempotency_key": pending.get("idempotency_key"),
            "state": state,
            "reason": reason,
            "updated_at": datetime.utcnow().isoformat(),
        }
        history.append(entry)
        context.set_context_data("approval_state_history", history)
        context.set_context_data("last_approval_state", entry)
