from flask import Blueprint, jsonify, current_app
from datetime import datetime, timezone
try:
    from ..storage.paper_state import load_state  # type: ignore
except Exception:  # pragma: no cover
    load_state = None  # type: ignore
try:
    # Load persisted paper state if available
    from ..storage.paper_state import load_state  # type: ignore
except Exception:  # pragma: no cover
    load_state = None  # type: ignore

portfolio_bp = Blueprint('portfolio', __name__)

# Simple paper portfolio state; load from disk if possible
if callable(load_state):
    _loaded_portfolio, _meta = load_state()  # type: ignore
    _PORTFOLIO = {
        'cash': float(_loaded_portfolio.get('cash', 1_000_000.0)),
        'positions': dict(_loaded_portfolio.get('positions', {})),
    }
else:
    _PORTFOLIO = {
        'cash': 1000000.0,
        'positions': {},  # symbol -> {'qty': int, 'avg_price': float}
    }

@portfolio_bp.route('/holdings', methods=['GET'])
def holdings():
    svc = current_app.config.get('PORTFOLIO_SERVICE')
    if svc is not None:
        try:
            return jsonify(svc.holdings())
        except Exception:
            pass
    holdings_list = []
    for sym, pos in _PORTFOLIO['positions'].items():
        holdings_list.append({'symbol': sym, 'quantity': pos['qty'], 'avg_price': pos['avg_price']})
    return jsonify({'cash': _PORTFOLIO['cash'], 'holdings': holdings_list})

@portfolio_bp.route('/margins', methods=['GET'])
def margins():
    svc = current_app.config.get('PORTFOLIO_SERVICE')
    if svc is not None:
        try:
            return jsonify(svc.margins())
        except Exception:
            pass
    return jsonify({'available': _PORTFOLIO['cash'], 'used': 0.0, 'net': _PORTFOLIO['cash']})


@portfolio_bp.route('/live', methods=['GET'])
def live_portfolio():
    exec_mode = str(current_app.config.get('EXECUTION_MODE', 'PAPER')).upper()
    trading_adapter = current_app.config.get('TRADING_ADAPTER')
    if exec_mode != 'SHOONYA' or trading_adapter is None:
        return jsonify({'error': 'live trading not enabled'}), 400
    try:
        positions = trading_adapter.get_positions()
        balance = trading_adapter.get_balance()
        return jsonify({'positions': positions, 'balance': balance})
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@portfolio_bp.route('/metrics', methods=['GET'])
def portfolio_metrics():
    svc = current_app.config.get('PORTFOLIO_SERVICE')
    if svc is not None:
        try:
            return jsonify(svc.metrics())
        except Exception:
            pass
    # Fallback legacy computation
    portfolio = _PORTFOLIO
    total_cost_basis = 0.0
    positions = portfolio.get('positions', {})
    pos_count = len(positions)
    for sym, pos in positions.items():
        total_cost_basis += float(pos.get('avg_price', 0.0)) * int(pos.get('qty', 0))
    # Load orders to estimate turnover
    orders = []
    if callable(load_state):
        _, meta = load_state()  # type: ignore
        orders = meta.get('orders', []) if isinstance(meta, dict) else []
    now = datetime.now(timezone.utc)
    def _parse_ts(o):
        ts = o.get('timestamp') if isinstance(o, dict) else None
        if not ts:
            return None
        try:
            dt = datetime.fromisoformat(ts.replace('Z','+00:00'))
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except Exception:
            return None
    one_day = 0.0
    seven_day = 0.0
    for o in orders:
        ts = _parse_ts(o) or now
        qty = int(o.get('quantity', 0)) if isinstance(o, dict) else 0
        px = float(o.get('price', 0.0)) if isinstance(o, dict) else 0.0
        notional = qty * px
        age_days = (now - ts).total_seconds() / 86400.0
        if age_days <= 1.0: one_day += notional
        if age_days <= 7.0: seven_day += notional
    metrics = {
        'cash': float(portfolio.get('cash', 0.0)),
        'positions_count': pos_count,
        'cost_basis': round(total_cost_basis, 2),
        'unrealized_pnl': 0.0,
        'total_value_est': round(float(portfolio.get('cash', 0.0)) + total_cost_basis, 2),
        'turnover_1d': round(one_day, 2),
        'turnover_7d': round(seven_day, 2),
        'as_of': now.isoformat(),
    }
    return jsonify(metrics)
