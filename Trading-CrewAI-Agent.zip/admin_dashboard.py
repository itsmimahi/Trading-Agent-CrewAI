#!/usr/bin/env python3
"""
Enhanced Streamlit Admin Dashboard for AI Trading Advisory System
Advanced monitoring, configuration, and administration interface
"""

import streamlit as st
import asyncio
import logging
import sys
import os
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
import time

# Add project path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Configure page
st.set_page_config(
    page_title="AI Trading Advisory - Admin Dashboard",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for enhanced styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
        margin-bottom: 1rem;
    }
    .status-online {
        color: #28a745;
        font-weight: bold;
    }
    .status-offline {
        color: #dc3545;
        font-weight: bold;
    }
    .status-warning {
        color: #ffc107;
        font-weight: bold;
    }
    .sidebar .sidebar-content {
        background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    }
</style>
""", unsafe_allow_html=True)

# Configuration (derive Web UI URL from environment to match launcher/UI server)
_ui_port = os.environ.get('UI_PORT') or os.environ.get('PORT')
_env_ui_url = os.environ.get('WEB_UI_URL')
if _env_ui_url:
    _WEB_UI_URL = _env_ui_url
elif _ui_port:
    _WEB_UI_URL = f"http://localhost:{_ui_port}"
else:
    _WEB_UI_URL = 'http://localhost:5000'

CONFIG = {
    'MAIN_AGENT_URL': 'http://localhost:8000',
    'RL_AGENT_URL': 'http://localhost:5500',
    'WEB_UI_URL': _WEB_UI_URL,
    'REFRESH_INTERVAL': 30  # seconds
}

# UI proxy session and CSRF token management
if 'ui_session' not in st.session_state:
    sess = requests.Session()
    sess.headers.update({'User-Agent': 'AdminDashboard/1.0'})
    st.session_state.ui_session = sess
if 'csrf_token' not in st.session_state:
    st.session_state.csrf_token = None


def _ui_headers() -> dict:
    # Provide Origin/Referer to satisfy CSRF origin checks on the UI server
    base = CONFIG['WEB_UI_URL']
    headers = {
        'Origin': base,
        'Referer': base + '/',
    }
    if st.session_state.csrf_token:
        headers['X-CSRF-Token'] = st.session_state.csrf_token
    return headers


def ensure_csrf_token():
    """Fetch and cache CSRF token from the Web UI server."""
    try:
        resp = st.session_state.ui_session.get(f"{CONFIG['WEB_UI_URL']}/api/csrf-token", timeout=5)
        if resp.ok and resp.headers.get('Content-Type', '').startswith('application/json'):
            data = resp.json()
            token = data.get('token')
            if token:
                st.session_state.csrf_token = token
                return True
    except Exception as e:
        logging.warning(f"CSRF token fetch failed: {e}")
    return False


# Initialize session state
if 'last_refresh' not in st.session_state:
    st.session_state.last_refresh = datetime.now()
if 'auto_refresh' not in st.session_state:
    st.session_state.auto_refresh = True
if 'system_metrics' not in st.session_state:
    st.session_state.system_metrics = []
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []


def check_service_health(url, service_name):
    """Check health of a service (via UI proxy when possible)."""
    try:
        # Prefer Web UI health for the UI itself
        if service_name == 'Web UI Server':
            response = st.session_state.ui_session.get(f"{CONFIG['WEB_UI_URL']}/api/health", timeout=5)
            if response.ok:
                data = response.json() if response.headers.get('content-type', '').startswith('application/json') else {}
                return {
                    'status': 'online',
                    'service': service_name,
                    'url': CONFIG['WEB_UI_URL'],
                    'response_time': round(response.elapsed.total_seconds() * 1000, 2),
                    'timestamp': datetime.now(),
                    'data': data
                }
        # For others, use aggregated system status
        response = st.session_state.ui_session.get(f"{CONFIG['WEB_UI_URL']}/api/system/status", timeout=8)
        if response.ok:
            payload = response.json().get('data', {})
            # Map services
            if service_name == 'Main Advisory Agent':
                s = payload.get('mainAgent', {})
            elif service_name == 'RL Agent':
                s = payload.get('rlAgent', {})
            else:
                s = {}
            status = s.get('status', 'unknown')
            return {
                'status': status,
                'service': service_name,
                'url': s.get('url', ''),
                'response_time': s.get('response_time', 'N/A'),
                'timestamp': datetime.now(),
                'data': s
            }
        else:
            return {
                'status': 'error',
                'service': service_name,
                'url': CONFIG['WEB_UI_URL'],
                'error': f'HTTP {response.status_code}',
                'timestamp': datetime.now()
            }
    except requests.exceptions.ConnectionError:
        return {
            'status': 'offline',
            'service': service_name,
            'url': CONFIG['WEB_UI_URL'],
            'error': 'Connection refused - UI may be down',
            'timestamp': datetime.now()
        }
    except requests.exceptions.Timeout:
        return {
            'status': 'timeout',
            'service': service_name,
            'url': CONFIG['WEB_UI_URL'],
            'error': 'Request timeout (>8s)',
            'timestamp': datetime.now()
        }
    except Exception as e:
        return {
            'status': 'error',
            'service': service_name,
            'url': CONFIG['WEB_UI_URL'],
            'error': str(e),
            'timestamp': datetime.now()
        }


def get_system_status():
    """Get comprehensive system status from the Web UI proxy."""
    try:
        response = st.session_state.ui_session.get(f"{CONFIG['WEB_UI_URL']}/api/system/status", timeout=8)
        if response.ok:
            return response.json().get('data', {})
        return {}
    except Exception:
        return {}


def render_status_indicator(status):
    """Render status indicator with appropriate styling"""
    if status == 'online':
        return '<span class="status-online">🟢 ONLINE</span>'
    elif status == 'offline':
        return '<span class="status-offline">🔴 OFFLINE</span>'
    elif status in ['error', 'timeout']:
        return '<span class="status-warning">🟡 ERROR</span>'
    else:
        return '<span class="status-warning">🟡 UNKNOWN</span>'


def main_dashboard():
    """Main dashboard page"""
    st.markdown('<div class="main-header"><h1>🔧 AI Trading Advisory - Admin Dashboard</h1><p>System Monitoring & Administration</p></div>', unsafe_allow_html=True)

    # Ensure CSRF for any POST actions later
    if st.session_state.csrf_token is None:
        ensure_csrf_token()

    # Auto-refresh controls
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        st.session_state.auto_refresh = st.checkbox("Auto-refresh (30s)", value=st.session_state.auto_refresh)
    with col2:
        if st.button("🔄 Refresh Now"):
            st.session_state.last_refresh = datetime.now()
            st.rerun()
    with col3:
        st.write(f"Last updated: {st.session_state.last_refresh.strftime('%H:%M:%S')}")

    # System Status Overview via UI proxy
    st.subheader("🌐 System Status Overview")

    sys_status = get_system_status()

    cards = {
        'Main Advisory Agent': sys_status.get('mainAgent', {'status': 'unknown'}),
        'RL Agent': sys_status.get('rlAgent', {'status': 'unknown'}),
        'Web UI Server': sys_status.get('webUI', {'status': 'unknown', 'url': CONFIG['WEB_UI_URL']})
    }

    cols = st.columns(len(cards))
    for i, (service, sdata) in enumerate(cards.items()):
        with cols[i]:
            status_html = render_status_indicator(sdata.get('status', 'unknown'))
            st.markdown(f"""
            <div class="metric-card">
                <h4>{service}</h4>
                {status_html}
                <br><small>Response: {sdata.get('response_time', 'N/A')} ms</small>
                <br><small>{sdata.get('url', '')}</small>
            </div>
            """, unsafe_allow_html=True)
            if sdata.get('status') not in ['online']:
                err = sdata.get('error') or 'Unavailable'
                st.error(f"⚠️ {err}")

    # Detailed System Metrics
    st.subheader("📊 System Metrics")
    col1, col2 = st.columns(2)
    with col1:
        st.write("**From UI /api/system/status**")
        st.json(sys_status)
    with col2:
        try:
            resp = st.session_state.ui_session.get(f"{CONFIG['WEB_UI_URL']}/api/metrics", timeout=5)
            st.write("**Web UI Metrics**")
            st.json(resp.json() if resp.ok else {'error': f'HTTP {resp.status_code}'})
        except Exception as e:
            st.json({'error': str(e)})

    # Integration Status - via UI proxy info
    st.subheader("🔗 Integration Status")
    if 'integration' in sys_status:
        st.json(sys_status['integration'])
    else:
        st.info("Integration status not available from UI")


def api_testing_page():
    """API testing and debugging page (via UI proxy)."""
    st.header("🧪 API Testing & Debugging")

    # Ensure CSRF token for POST
    if st.session_state.csrf_token is None:
        ensured = ensure_csrf_token()
        if not ensured:
            st.warning("Could not obtain CSRF token from Web UI. POST actions may fail.")

    st.subheader("Chat API Test (proxied)")
    test_message = st.text_area("Test Message", value="What's the current market sentiment?")
    col1, col2 = st.columns(2)

    with col1:
        if st.button("Send via Web UI Proxy"):
            try:
                payload = {
                    "message": test_message,
                    "timestamp": datetime.now().isoformat()
                }
                headers = _ui_headers()
                with st.spinner("Sending request via UI proxy..."):
                    response = st.session_state.ui_session.post(
                        f"{CONFIG['WEB_UI_URL']}/api/proxy/chat",
                        json=payload,
                        headers=headers,
                        timeout=30
                    )
                if response.ok:
                    st.success("✅ Chat request successful!")
                    st.json(response.json())
                else:
                    st.error(f"❌ Chat request failed: HTTP {response.status_code}")
                    st.text(response.text)
            except Exception as e:
                st.error(f"❌ Chat request error: {e}")

    with col2:
        if st.button("Get RL Insights via Proxy"):
            try:
                headers = _ui_headers()
                with st.spinner("Fetching RL insights via UI proxy..."):
                    response = st.session_state.ui_session.get(
                        f"{CONFIG['WEB_UI_URL']}/api/proxy/rl/insights",
                        headers=headers,
                        timeout=10
                    )
                if response.ok:
                    st.success("✅ RL insights request successful!")
                    st.json(response.json())
                else:
                    st.error(f"❌ RL insights request failed: HTTP {response.status_code}")
                    st.text(response.text)
            except Exception as e:
                st.error(f"❌ RL insights error: {e}")

    # Health check section
    st.subheader("🏥 Health Check Results (via UI)")
    if st.button("Run All Health Checks"):
        status = get_system_status()
        for service, sdata in {
            'Main Advisory Agent': status.get('mainAgent', {}),
            'RL Agent': status.get('rlAgent', {}),
            'Web UI Server': status.get('webUI', {})
        }.items():
            state = sdata.get('status', 'unknown')
            if state == 'online':
                st.success(f"✅ {service}: {state.upper()} ({sdata.get('response_time', 'N/A')}ms)")
            else:
                st.error(f"❌ {service}: {state.upper()} - {sdata.get('error', 'Unknown error')}")


def configuration_page():
    """Configuration and settings page"""
    st.header("⚙️ Configuration & Settings")
    st.subheader("Service URLs")

    col1, col2 = st.columns(2)
    with col1:
        st.write("**Current Configuration:**")
        st.json(CONFIG)
    with col2:
        st.write("**Update Configuration:**")
        new_web_url = st.text_input("Web UI URL", value=CONFIG['WEB_UI_URL'])
        new_main_url = st.text_input("Main Agent URL (informational)", value=CONFIG['MAIN_AGENT_URL'])
        new_rl_url = st.text_input("RL Agent URL (informational)", value=CONFIG['RL_AGENT_URL'])
        if st.button("Update Configuration"):
            CONFIG['WEB_UI_URL'] = new_web_url
            CONFIG['MAIN_AGENT_URL'] = new_main_url
            CONFIG['RL_AGENT_URL'] = new_rl_url
            # Reset CSRF so it can be re-fetched for the new UI URL
            st.session_state.csrf_token = None
            st.success("✅ Configuration updated!")
            st.rerun()

    st.subheader("System Controls")
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("🔄 Restart Monitoring"):
            st.session_state.last_refresh = datetime.now()
            st.success("✅ Monitoring restarted")
    with col2:
        if st.button("🧹 Clear UI Session/CSRF"):
            st.session_state.ui_session = requests.Session()
            st.session_state.csrf_token = None
            st.success("✅ Cleared UI session and CSRF token")
    with col3:
        if st.button("📊 Export Metrics"):
            metrics_export = {
                'timestamp': datetime.now().isoformat(),
                'system_status': get_system_status(),
                'configuration': CONFIG
            }
            st.download_button(
                "📥 Download Metrics",
                data=json.dumps(metrics_export, indent=2, default=str),
                file_name=f"system_metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )


def logs_page():
    """Logs and monitoring page"""
    st.header("📋 Logs & Monitoring (via Web UI)")

    # Ensure CSRF for any POST actions
    if st.session_state.csrf_token is None:
        ensure_csrf_token()

    # List logs via UI
    try:
        resp = st.session_state.ui_session.get(f"{CONFIG['WEB_UI_URL']}/api/admin/logs/list", timeout=6)
        files = resp.json().get('files', []) if resp.ok else []
    except Exception as e:
        st.error(f"Failed to list logs: {e}")
        files = []

    if files:
        names = [f["name"] for f in files]
        selected = st.selectbox("Select Log File", names)
        lines = st.slider("Lines to show", 10, 1000, 200)
        if st.button("🔄 Refresh Tail"):
            try:
                r = st.session_state.ui_session.get(
                    f"{CONFIG['WEB_UI_URL']}/api/admin/logs/tail",
                    params={'file': selected, 'lines': lines},
                    timeout=8
                )
                if r.ok:
                    content = r.json().get('content', [])
                    st.text_area(
                        f"Last {len(content)} lines from {selected}",
                        value='\n'.join(content),
                        height=400
                    )
                else:
                    st.error(f"Tail failed: HTTP {r.status_code}")
            except Exception as e:
                st.error(f"Tail error: {e}")
    else:
        st.info("No log files available from UI.")

    st.subheader("Cache Control")
    if st.button("🧹 Clear Web UI Cache"):
        try:
            headers = _ui_headers()
            r = st.session_state.ui_session.post(
                f"{CONFIG['WEB_UI_URL']}/api/admin/cache/clear",
                headers=headers,
                timeout=8
            )
            if r.ok:
                st.success("Cache cleared via UI")
            else:
                st.error(f"Clear cache failed: HTTP {r.status_code}")
        except Exception as e:
            st.error(f"Clear cache error: {e}")


def main():
    """Main application entry point"""
    # Sidebar navigation
    st.sidebar.title("🔧 Admin Dashboard")
    st.sidebar.markdown("---")
    
    pages = {
        "🏠 Dashboard": main_dashboard,
        "🧪 API Testing": api_testing_page,
        "⚙️ Configuration": configuration_page,
        "📋 Logs & Monitoring": logs_page
    }
    
    selected_page = st.sidebar.radio("Navigate to:", list(pages.keys()))
    
    # System info in sidebar
    st.sidebar.markdown("---")
    st.sidebar.subheader("📊 Quick Status")
    
    system_status = get_system_status()
    for service, status in system_status.items():
        status_emoji = "🟢" if status['status'] == 'online' else "🔴"
        st.sidebar.write(f"{status_emoji} {service}")
    
    st.sidebar.markdown("---")
    st.sidebar.subheader("🔗 Quick Links")
    st.sidebar.markdown(f"[Web UI]({CONFIG['WEB_UI_URL']})")
    st.sidebar.markdown(f"[Main Agent API]({CONFIG['MAIN_AGENT_URL']}/docs)")
    st.sidebar.markdown(f"[RL Agent API]({CONFIG['RL_AGENT_URL']}/docs)")
    
    # Auto-refresh logic
    if st.session_state.auto_refresh:
        time_since_refresh = (datetime.now() - st.session_state.last_refresh).total_seconds()
        if time_since_refresh >= CONFIG['REFRESH_INTERVAL']:
            st.session_state.last_refresh = datetime.now()
            st.rerun()
    
    # Render selected page
    pages[selected_page]()

if __name__ == "__main__":
    main()
