"""
Performance Feedback System
Collects and processes performance metrics for RL learning feedback
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import json
import sqlite3
import numpy as np
import os
import threading

from integration.crewai_rl_bridge import PerformanceMetrics, CrewAIRLBridge
from integration.event_bus import make_default_event_bus


@dataclass
class StrategyExecutionResult:
    """Results from strategy execution"""
    strategy_id: str
    symbol: str
    entry_price: float
    exit_price: float
    quantity: int
    entry_time: datetime
    exit_time: datetime
    profit_loss: float
    return_percentage: float
    trade_duration_hours: float
    execution_agent: str
    


@dataclass
class AgentPerformanceScore:
    """Performance score for individual agents"""
    agent_id: str
    total_strategies: int
    successful_strategies: int
    average_return: float
    average_confidence: float
    contribution_score: float
    last_updated: datetime


class PerformanceCollector:
    """
    Collects and analyzes performance metrics for RL feedback
    
    This system:
    1. Tracks strategy execution results
    2. Calculates agent contribution scores
    3. Generates performance metrics for RL learning
    4. Manages performance history and analytics
    """
    
    def __init__(self, db_path: str = "performance_data.db"):
        self.db_path = db_path
        self.logger = logging.getLogger("PerformanceCollector")
        self.rl_bridge = None
        self._bus = make_default_event_bus()
        
        # Performance tracking
        self.strategy_results = {}
        self.agent_scores = {}
        self.performance_cache = {
            # Latest benchmark comparison metrics to enrich daily events
            # {
            #   'tracking_error': float | None,
            #   'information_ratio': float | None,
            #   'benchmark_correlation': float | None,
            #   'source': str | None,
            #   'timestamp': iso8601 str,
            # }
            'benchmark_metrics': None,
        }
        
        # Background consumer thread ref
        self._bench_consumer_thread: Optional[threading.Thread] = None

        # Initialize database
        self._init_database()

        # Optionally start subscriber to ingest TE/IR benchmark metrics from bus
        try:
            if self._bus and os.environ.get("PERF_START_BENCHMARK_CONSUMER", "1") in ("1", "true", "True"):
                self.start_benchmark_metrics_consumer()
        except Exception:
            pass
        
    def _init_database(self):
        """Initialize SQLite database for performance tracking"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Strategy executions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS strategy_executions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    entry_price REAL NOT NULL,
                    exit_price REAL,
                    quantity INTEGER NOT NULL,
                    entry_time TEXT NOT NULL,
                    exit_time TEXT,
                    profit_loss REAL,
                    return_percentage REAL,
                    trade_duration_hours REAL,
                    execution_agent TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Agent contributions table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS agent_contributions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_id TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    contribution_weight REAL NOT NULL,
                    confidence_score REAL,
                    signal_strength REAL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Performance metrics table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS performance_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_id TEXT NOT NULL,
                    total_return REAL,
                    sharpe_ratio REAL,
                    max_drawdown REAL,
                    win_rate REAL,
                    avg_trade_duration REAL,
                    total_trades INTEGER,
                    calculated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
            conn.close()
            self.logger.info("Performance database initialized")
            
        except Exception as e:
            self.logger.error(f"Error initializing database: {e}")
            raise
    
    def set_rl_bridge(self, rl_bridge: CrewAIRLBridge):
        """Set RL bridge for feedback communication"""
        self.rl_bridge = rl_bridge
    
    async def record_strategy_execution(self, execution_result: StrategyExecutionResult):
        """Record a strategy execution result"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO strategy_executions 
                (strategy_id, symbol, entry_price, exit_price, quantity, 
                 entry_time, exit_time, profit_loss, return_percentage, 
                 trade_duration_hours, execution_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                execution_result.strategy_id,
                execution_result.symbol,
                execution_result.entry_price,
                execution_result.exit_price,
                execution_result.quantity,
                execution_result.entry_time.isoformat(),
                execution_result.exit_time.isoformat() if execution_result.exit_time else None,
                execution_result.profit_loss,
                execution_result.return_percentage,
                execution_result.trade_duration_hours,
                execution_result.execution_agent
            ))
            
            conn.commit()
            conn.close()
            
            # Update cached results
            if execution_result.strategy_id not in self.strategy_results:
                self.strategy_results[execution_result.strategy_id] = []
            self.strategy_results[execution_result.strategy_id].append(execution_result)
            
            self.logger.info(f"Recorded execution for strategy {execution_result.strategy_id}")
            
            # Trigger performance analysis if strategy is complete
            if execution_result.exit_time:
                await self._analyze_completed_strategy(execution_result.strategy_id)
            
        except Exception as e:
            self.logger.error(f"Error recording strategy execution: {e}")
    
    async def record_agent_contribution(self, strategy_id: str, agent_id: str, 
                                        contribution_weight: float, confidence_score: float = None,
                                        signal_strength: float = None):
        """Record an agent's contribution to a strategy"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO agent_contributions 
                (strategy_id, agent_id, contribution_weight, confidence_score, signal_strength)
                VALUES (?, ?, ?, ?, ?)
            ''', (strategy_id, agent_id, contribution_weight, confidence_score, signal_strength))
            
            conn.commit()
            conn.close()
            
            self.logger.info(f"Recorded contribution for agent {agent_id} in strategy {strategy_id}")
            
        except Exception as e:
            self.logger.error(f"Error recording agent contribution: {e}")
    
    async def _analyze_completed_strategy(self, strategy_id: str):
        """Analyze a completed strategy and send feedback to RL"""
        try:
            # Calculate strategy performance
            performance_metrics = await self._calculate_strategy_performance(strategy_id)
            
            if performance_metrics:
                # Store metrics in database
                await self._store_performance_metrics(strategy_id, performance_metrics)
                
                # Send feedback to RL agent
                if self.rl_bridge:
                    await self.rl_bridge.send_performance_feedback(performance_metrics)
                # Also publish a reward signal on the bus for other listeners
                await self._publish_rl_reward_signal(performance_metrics)
                
                # Update agent scores
                await self._update_agent_scores(strategy_id, performance_metrics)
                
                self.logger.info(f"Completed analysis for strategy {strategy_id}")
            
        except Exception as e:
            self.logger.error(f"Error analyzing completed strategy {strategy_id}: {e}")
    
    async def _calculate_strategy_performance(self, strategy_id: str) -> Optional[PerformanceMetrics]:
        """Calculate performance metrics for a strategy"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get strategy executions
            cursor.execute('''
                SELECT * FROM strategy_executions 
                WHERE strategy_id = ? AND exit_time IS NOT NULL
            ''', (strategy_id,))
            
            executions = cursor.fetchall()
            
            if not executions:
                return None
            
            # Calculate basic metrics
            total_trades = len(executions)
            returns = [row[9] for row in executions if row[9] is not None]  # return_percentage
            
            if not returns:
                return None
            
            total_return = sum(returns)
            avg_return = np.mean(returns)
            std_return = np.std(returns) if len(returns) > 1 else 0
            
            # Calculate Sharpe ratio (assuming risk-free rate = 0)
            sharpe_ratio = avg_return / std_return if std_return > 0 else 0
            
            # Calculate max drawdown
            cumulative_returns = np.cumsum(returns)
            running_max = np.maximum.accumulate(cumulative_returns)
            drawdowns = cumulative_returns - running_max
            max_drawdown = abs(min(drawdowns)) if len(drawdowns) > 0 else 0
            
            # Calculate win rate
            winning_trades = len([r for r in returns if r > 0])
            win_rate = winning_trades / total_trades if total_trades > 0 else 0
            
            # Calculate average trade duration
            durations = [row[10] for row in executions if row[10] is not None]  # trade_duration_hours
            avg_trade_duration = np.mean(durations) if durations else 0
            
            # Get agent contributions
            cursor.execute('''
                SELECT agent_id, AVG(contribution_weight) as avg_contribution
                FROM agent_contributions 
                WHERE strategy_id = ?
                GROUP BY agent_id
            ''', (strategy_id,))
            
            agent_contributions = dict(cursor.fetchall())
            
            conn.close()
            
            # Create performance metrics object
            performance_metrics = PerformanceMetrics(
                strategy_id=strategy_id,
                total_return=total_return,
                sharpe_ratio=sharpe_ratio,
                max_drawdown=max_drawdown,
                win_rate=win_rate,
                avg_trade_duration=avg_trade_duration,
                total_trades=total_trades,
                agent_contributions=agent_contributions
            )
            
            self.logger.info(f"Calculated performance for {strategy_id}: Return={total_return:.2%}, Sharpe={sharpe_ratio:.2f}")
            
            return performance_metrics
            
        except Exception as e:
            self.logger.error(f"Error calculating strategy performance: {e}")
            return None
    
    async def _store_performance_metrics(self, strategy_id: str, metrics: PerformanceMetrics):
        """Store performance metrics in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO performance_metrics 
                (strategy_id, total_return, sharpe_ratio, max_drawdown, 
                 win_rate, avg_trade_duration, total_trades)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                strategy_id,
                metrics.total_return,
                metrics.sharpe_ratio,
                metrics.max_drawdown,
                metrics.win_rate,
                metrics.avg_trade_duration,
                metrics.total_trades
            ))
            
            conn.commit()
            conn.close()
            # Publish a performance exec snapshot for dashboards or subscribers
            await self._publish_performance_exec(metrics)
            
        except Exception as e:
            self.logger.error(f"Error storing performance metrics: {e}")
    
    async def _update_agent_scores(self, strategy_id: str, metrics: PerformanceMetrics):
        """Update agent performance scores based on strategy results"""
        try:
            for agent_id, contribution in metrics.agent_contributions.items():
                if agent_id not in self.agent_scores:
                    self.agent_scores[agent_id] = AgentPerformanceScore(
                        agent_id=agent_id,
                        total_strategies=0,
                        successful_strategies=0,
                        average_return=0.0,
                        average_confidence=0.0,
                        contribution_score=0.0,
                        last_updated=datetime.now()
                    )
                
                score = self.agent_scores[agent_id]
                
                # Update statistics
                old_total = score.total_strategies
                score.total_strategies += 1
                
                # Update average return (weighted by contribution)
                weighted_return = metrics.total_return * contribution
                score.average_return = (
                    (score.average_return * old_total + weighted_return) / score.total_strategies
                )
                
                # Update successful strategies
                if metrics.total_return > 0:
                    score.successful_strategies += 1
                
                # Update contribution score
                score.contribution_score = score.successful_strategies / score.total_strategies
                
                score.last_updated = datetime.now()
                
                self.logger.info(f"Updated score for agent {agent_id}: {score.contribution_score:.2f}")
            
        except Exception as e:
            self.logger.error(f"Error updating agent scores: {e}")
    
    async def get_agent_performance_summary(self, agent_id: str = None) -> Dict[str, Any]:
        """Get performance summary for agents"""
        try:
            if agent_id:
                # Return specific agent performance
                if agent_id in self.agent_scores:
                    return asdict(self.agent_scores[agent_id])
                else:
                    return {"error": f"No performance data for agent {agent_id}"}
            else:
                # Return all agent performances
                return {
                    agent_id: asdict(score) 
                    for agent_id, score in self.agent_scores.items()
                }
                
        except Exception as e:
            self.logger.error(f"Error getting agent performance summary: {e}")
            return {"error": str(e)}
    
    async def get_strategy_performance_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent strategy performance history"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM performance_metrics 
                ORDER BY calculated_at DESC 
                LIMIT ?
            ''', (limit,))
            
            rows = cursor.fetchall()
            conn.close()
            
            # Convert to list of dictionaries
            columns = ['id', 'strategy_id', 'total_return', 'sharpe_ratio', 
                      'max_drawdown', 'win_rate', 'avg_trade_duration', 
                      'total_trades', 'calculated_at']
            
            history = []
            for row in rows:
                history.append(dict(zip(columns, row)))
            
            return history
            
        except Exception as e:
            self.logger.error(f"Error getting strategy performance history: {e}")
            return []
    
    async def calculate_system_performance_metrics(self) -> Dict[str, Any]:
        """Calculate overall system performance metrics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Overall statistics
            cursor.execute('''
                SELECT 
                    COUNT(*) as total_strategies,
                    AVG(total_return) as avg_return,
                    AVG(sharpe_ratio) as avg_sharpe,
                    AVG(win_rate) as avg_win_rate,
                    SUM(total_trades) as total_trades
                FROM performance_metrics
            ''')
            
            overall_stats = cursor.fetchone()
            
            # Recent performance (last 30 days)
            cursor.execute('''
                SELECT 
                    COUNT(*) as recent_strategies,
                    AVG(total_return) as recent_avg_return
                FROM performance_metrics 
                WHERE calculated_at >= datetime('now', '-30 days')
            ''')
            
            recent_stats = cursor.fetchone()
            
            # Top performing agents
            cursor.execute('''
                SELECT 
                    agent_id,
                    COUNT(*) as strategy_count,
                    AVG(contribution_weight) as avg_contribution
                FROM agent_contributions 
                GROUP BY agent_id
                ORDER BY avg_contribution DESC
                LIMIT 5
            ''')
            
            top_agents = cursor.fetchall()
            
            conn.close()
            
            # Enrich with latest benchmark metrics if available
            bench = self.performance_cache.get('benchmark_metrics') if isinstance(self.performance_cache, dict) else None
            payload = {
                "overall": {
                    "total_strategies": overall_stats[0],
                    "average_return": overall_stats[1] or 0,
                    "average_sharpe_ratio": overall_stats[2] or 0,
                    "average_win_rate": overall_stats[3] or 0,
                    "total_trades": overall_stats[4] or 0
                },
                "recent_performance": {
                    "strategies_last_30_days": recent_stats[0],
                    "avg_return_last_30_days": recent_stats[1] or 0
                },
                "benchmark": {
                    "tracking_error": (bench or {}).get('tracking_error'),
                    "information_ratio": (bench or {}).get('information_ratio'),
                    "benchmark_correlation": (bench or {}).get('benchmark_correlation'),
                    "source": (bench or {}).get('source'),
                    "as_of": (bench or {}).get('timestamp'),
                },
                "top_agents": [
                    {
                        "agent_id": agent[0],
                        "strategy_count": agent[1],
                        "avg_contribution": agent[2]
                    }
                    for agent in top_agents
                ],
                "agent_scores": self.agent_scores
            }
            # Publish daily/system metrics snapshot
            await self._publish_performance_daily(payload)
            return payload
            
        except Exception as e:
            self.logger.error(f"Error calculating system performance metrics: {e}")
            return {"error": str(e)}
    
    async def export_performance_data(self, output_file: str = None) -> str:
        """Export performance data to JSON file"""
        try:
            # Get all performance data
            system_metrics = await self.calculate_system_performance_metrics()
            strategy_history = await self.get_strategy_performance_history(limit=1000)
            agent_summary = await self.get_agent_performance_summary()
            
            export_data = {
                "export_timestamp": datetime.now().isoformat(),
                "system_metrics": system_metrics,
                "strategy_history": strategy_history,
                "agent_summary": agent_summary
            }
            
            # Default filename
            if not output_file:
                output_file = f"performance_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            # Write to file
            with open(output_file, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            self.logger.info(f"Performance data exported to {output_file}")
            return output_file
            
        except Exception as e:
            self.logger.error(f"Error exporting performance data: {e}")
            raise

    # --- Bus consumer for benchmark metrics (TE/IR/corr) ---
    def start_benchmark_metrics_consumer(
        self,
        *,
        stream: str = "performance:benchmark_metrics",
        group: str = "perf",
    ) -> bool:
        """
        Start a background Redis Streams consumer to ingest TE/IR/correlation events.
        Expected payloads examples:
          {"type": "performance.benchmark_metrics.v1", "data": {"tracking_error": 0.12, "information_ratio": 0.45, "benchmark_correlation": 0.78, "source": "PM"}}
          or flat keys at top level.
        """
        if not self._bus:
            self.logger.info("Event bus not configured; benchmark metrics consumer not started")
            return False
        if self._bench_consumer_thread and self._bench_consumer_thread.is_alive():
            return True

        def _run():
            try:
                async def _handler(payload: Dict[str, Any]):
                    try:
                        self._handle_benchmark_metrics_event(payload)
                    except Exception as e:  # noqa: BLE001
                        self.logger.debug(f"benchmark metrics handler failed: {e}")

                async def _main():
                    self._bus.start_consumer(
                        stream=stream,
                        group=group,
                        consumer_name=None,
                        handler=_handler,
                        auto_ack=True,
                        max_retries=3,
                        concurrency=1,
                        block_ms=5000,
                    )
                    self.logger.info("Benchmark metrics consumer started")
                    await asyncio.Event().wait()

                asyncio.run(_main())
            except Exception as e:  # noqa: BLE001
                self.logger.exception(f"benchmark consumer thread crashed: {e}")

        t = threading.Thread(target=_run, name="perf-benchmark-consumer", daemon=True)
        t.start()
        self._bench_consumer_thread = t
        return True

    def _handle_benchmark_metrics_event(self, payload: Dict[str, Any]) -> None:
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, dict):
            data = payload if isinstance(payload, dict) else {}
        te = data.get("tracking_error") or data.get("te")
        ir = data.get("information_ratio") or data.get("ir")
        corr = (
            data.get("benchmark_correlation")
            or data.get("bench_corr")
            or data.get("correlation")
        )
        source = data.get("source") or payload.get("source") or payload.get("agent")
        # Only update if at least one metric present
        if te is None and ir is None and corr is None:
            return
        self.update_benchmark_metrics(
            tracking_error=te,
            information_ratio=ir,
            benchmark_correlation=corr,
            metadata={"source": source or "unknown"},
        )

    # --- Benchmark metrics ingestion ---
    def update_benchmark_metrics(
        self,
        *,
        tracking_error: Optional[float] = None,
        information_ratio: Optional[float] = None,
        benchmark_correlation: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Update cached benchmark comparison metrics (TE/IR/correlation) for inclusion in daily events.
        Intended to be called by Portfolio Manager or Risk Agent when they compute benchmark comparisons.
        """
        try:
            now = datetime.now().isoformat()
            self.performance_cache['benchmark_metrics'] = {
                'tracking_error': float(tracking_error) if tracking_error is not None else None,
                'information_ratio': float(information_ratio) if information_ratio is not None else None,
                'benchmark_correlation': float(benchmark_correlation) if benchmark_correlation is not None else None,
                'source': (metadata or {}).get('source'),
                'timestamp': now,
            }
            self.logger.info("Updated benchmark metrics for daily performance events")
        except Exception as e:
            self.logger.debug(f"Failed to update benchmark metrics: {e}")

    # --- Event publishing helpers ---
    async def _publish_performance_daily(self, data: Dict[str, Any]) -> None:
        try:
            if not self._bus:
                return
            message = {
                "correlation_id": f"perf-{datetime.now().strftime('%Y%m%d')}",
                "version": 1,
                "timestamp": datetime.now().isoformat(),
                "type": "performance.daily.v1",
                "data": data,
            }
            self._bus.publish("performance:daily", message)
        except Exception as e:
            self.logger.debug(f"performance.daily publish failed: {e}")

    async def publish_daily_with_benchmark(
        self,
        *,
        tracking_error: Optional[float],
        information_ratio: Optional[float],
        benchmark_correlation: Optional[float],
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Convenience: update TE/IR/corr and publish daily metrics in one call.
        Does not recalc system stats; uses current calculate_system_performance_metrics output.
        """
        try:
            self.update_benchmark_metrics(
                tracking_error=tracking_error,
                information_ratio=information_ratio,
                benchmark_correlation=benchmark_correlation,
                metadata={"source": (extra or {}).get("source")},
            )
            snapshot = await self.calculate_system_performance_metrics()
            # The calculate method already calls _publish_performance_daily
            # This function can optionally publish again with explicit correlation id
        except Exception as e:
            self.logger.debug(f"publish_daily_with_benchmark failed: {e}")

    async def _publish_performance_exec(self, metrics: PerformanceMetrics) -> None:
        try:
            if not self._bus:
                return
            message = {
                "correlation_id": f"exec-{metrics.strategy_id}",
                "version": 1,
                "timestamp": datetime.now().isoformat(),
                "type": "performance.exec.v1",
                "data": {
                    "strategy_id": metrics.strategy_id,
                    "total_return": metrics.total_return,
                    "sharpe_ratio": metrics.sharpe_ratio,
                    "max_drawdown": metrics.max_drawdown,
                    "win_rate": metrics.win_rate,
                    "avg_trade_duration": metrics.avg_trade_duration,
                    "total_trades": metrics.total_trades,
                },
            }
            self._bus.publish("performance:exec", message)
        except Exception as e:
            self.logger.debug(f"performance.exec publish failed: {e}")

    async def _publish_rl_reward_signal(self, metrics: PerformanceMetrics) -> None:
        try:
            if not self._bus:
                return
            # Simple shaped reward: Sharpe minus turnover penalty proxy (1/total_trades)
            turnover_penalty = 0.0
            try:
                turnover_penalty = 0.01 / max(1, metrics.total_trades)
            except Exception:
                turnover_penalty = 0.0
            shaped_reward = float(metrics.sharpe_ratio) - turnover_penalty
            message = {
                "correlation_id": f"reward-{metrics.strategy_id}",
                "version": 1,
                "timestamp": datetime.now().isoformat(),
                "type": "rl.reward_signal.v1",
                "data": {
                    "strategy_id": metrics.strategy_id,
                    "reward": shaped_reward,
                    "components": {
                        "sharpe": metrics.sharpe_ratio,
                        "turnover_penalty": turnover_penalty,
                    },
                },
            }
            self._bus.publish("rl:reward_signal", message)
        except Exception as e:
            self.logger.debug(f"rl.reward_signal publish failed: {e}")


# Example usage and testing
async def main():
    """Example usage of PerformanceCollector"""
    collector = PerformanceCollector()
    
    # Create test data
    test_execution = StrategyExecutionResult(
        strategy_id="test_strategy_001",
        symbol="AAPL",
        entry_price=150.0,
        exit_price=155.0,
        quantity=100,
        entry_time=datetime.now() - timedelta(hours=24),
        exit_time=datetime.now(),
        profit_loss=500.0,
        return_percentage=0.033,
        trade_duration_hours=24.0,
        execution_agent="PaperTradingAgent"
    )
    
    # Record execution
    await collector.record_strategy_execution(test_execution)
    
    # Record agent contributions
    await collector.record_agent_contribution("test_strategy_001", "TechnicalAgent", 0.6, 0.8)
    await collector.record_agent_contribution("test_strategy_001", "SentimentAgent", 0.4, 0.7)
    
    # Get performance summary
    summary = await collector.calculate_system_performance_metrics()
    print(f"System performance: {summary}")
    
    # Export data
    export_file = await collector.export_performance_data()
    print(f"Data exported to: {export_file}")


if __name__ == "__main__":
    asyncio.run(main())
