"""
Market Data Collector for AI Trading Advisory System
"""

import asyncio
import yfinance as yf
import pandas as pd
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
import requests
from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.fundamentaldata import FundamentalData

from config.settings import config

logger = logging.getLogger(__name__)

@dataclass
class MarketData:
    """Standard market data format"""
    symbol: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: int
    adj_close: float
    
    # Technical indicators (to be calculated)
    sma_20: Optional[float] = None
    sma_50: Optional[float] = None
    rsi: Optional[float] = None
    macd: Optional[float] = None
    bollinger_upper: Optional[float] = None
    bollinger_lower: Optional[float] = None

@dataclass
class NewsData:
    """News data format"""
    symbol: str
    headline: str
    summary: str
    url: str
    published_date: datetime
    source: str
    sentiment_score: Optional[float] = None

class MarketDataCollector:
    """
    Collects market data from various free sources
    """
    
    def __init__(self):
        self.logger = logging.getLogger(f"{__name__}.MarketDataCollector")
        
        # Initialize API clients
        self.alpha_vantage = None
        if config.data.alpha_vantage_api_key:
            self.alpha_vantage = TimeSeries(key=config.data.alpha_vantage_api_key)
            self.fundamental_data = FundamentalData(key=config.data.alpha_vantage_api_key)
        
        # Cache for avoiding repeated API calls
        self.cache = {}
        self.cache_timeout = 300  # 5 minutes
    
    async def get_stock_data(self, symbol: str, period: str = "1d") -> List[MarketData]:
        """
        Get stock price data from Yahoo Finance
        
        Args:
            symbol: Stock symbol (e.g., "RELIANCE.NS")
            period: Time period ("1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "ytd", "max")
            
        Returns:
            List of MarketData objects
        """
        try:
            # Check cache first
            cache_key = f"{symbol}_{period}"
            if cache_key in self.cache:
                cached_data, timestamp = self.cache[cache_key]
                if datetime.now() - timestamp < timedelta(seconds=self.cache_timeout):
                    return cached_data
            
            # Fetch from Yahoo Finance
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period=period)
            
            if hist.empty:
                self.logger.warning(f"No data found for symbol {symbol}")
                return []
            
            # Convert to MarketData objects
            market_data = []
            for date, row in hist.iterrows():
                market_data.append(MarketData(
                    symbol=symbol,
                    timestamp=date,
                    open=float(row['Open']),
                    high=float(row['High']),
                    low=float(row['Low']),
                    close=float(row['Close']),
                    volume=int(row['Volume']),
                    adj_close=float(row['Close'])  # Yahoo Finance already provides adjusted close
                ))
            
            # Cache the data
            self.cache[cache_key] = (market_data, datetime.now())
            
            self.logger.info(f"Retrieved {len(market_data)} data points for {symbol}")
            return market_data
            
        except Exception as e:
            self.logger.error(f"Error fetching stock data for {symbol}: {e}")
            return []
    
    async def get_current_price(self, symbol: str) -> Optional[float]:
        """
        Get current stock price
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Current price or None if error
        """
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            
            # Try different price fields
            current_price = info.get('currentPrice') or info.get('regularMarketPrice') or info.get('previousClose')
            
            if current_price:
                return float(current_price)
            
            # Fallback to latest close price
            hist = ticker.history(period="1d")
            if not hist.empty:
                return float(hist['Close'].iloc[-1])
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error fetching current price for {symbol}: {e}")
            return None
    
    async def get_company_info(self, symbol: str) -> Dict[str, Any]:
        """
        Get company information and fundamentals
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Dictionary with company information
        """
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            
            # Extract key information
            company_info = {
                'symbol': symbol,
                'name': info.get('longName', 'Unknown'),
                'sector': info.get('sector', 'Unknown'),
                'industry': info.get('industry', 'Unknown'),
                'market_cap': info.get('marketCap', 0),
                'pe_ratio': info.get('trailingPE', 0),
                'pb_ratio': info.get('priceToBook', 0),
                'dividend_yield': info.get('dividendYield', 0),
                'beta': info.get('beta', 1.0),
                'fifty_two_week_high': info.get('fiftyTwoWeekHigh', 0),
                'fifty_two_week_low': info.get('fiftyTwoWeekLow', 0),
                'avg_volume': info.get('averageVolume', 0),
                'revenue_growth': info.get('revenueGrowth', 0),
                'earnings_growth': info.get('earningsGrowth', 0),
                'debt_to_equity': info.get('debtToEquity', 0),
                'return_on_equity': info.get('returnOnEquity', 0),
                'return_on_assets': info.get('returnOnAssets', 0),
                'current_ratio': info.get('currentRatio', 0),
                'quick_ratio': info.get('quickRatio', 0),
                'timestamp': datetime.now()
            }
            
            return company_info
            
        except Exception as e:
            self.logger.error(f"Error fetching company info for {symbol}: {e}")
            return {'symbol': symbol, 'error': str(e)}
    
    async def get_news(self, symbol: str, limit: int = 10) -> List[NewsData]:
        """
        Get recent news for a stock
        
        Args:
            symbol: Stock symbol
            limit: Number of news items to retrieve
            
        Returns:
            List of NewsData objects
        """
        try:
            # Extract company name from symbol for better news search
            company_name = symbol.replace('.NS', '').replace('.BO', '')
            
            # Use NewsAPI if available
            if config.data.news_api_key:
                return await self._get_news_from_api(company_name, limit)
            else:
                # Fallback to Yahoo Finance news
                return await self._get_yahoo_news(symbol, limit)
                
        except Exception as e:
            self.logger.error(f"Error fetching news for {symbol}: {e}")
            return []
    
    async def _get_news_from_api(self, company_name: str, limit: int) -> List[NewsData]:
        """
        Get news from NewsAPI
        
        Args:
            company_name: Company name for search
            limit: Number of news items
            
        Returns:
            List of NewsData objects
        """
        try:
            url = "https://newsapi.org/v2/everything"
            params = {
                'q': company_name,
                'sortBy': 'publishedAt',
                'pageSize': limit,
                'apiKey': config.data.news_api_key,
                'language': 'en'
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            data = response.json()
            news_items = []
            
            for article in data.get('articles', []):
                news_items.append(NewsData(
                    symbol=company_name,
                    headline=article.get('title', ''),
                    summary=article.get('description', ''),
                    url=article.get('url', ''),
                    published_date=datetime.fromisoformat(article.get('publishedAt', '').replace('Z', '+00:00')),
                    source=article.get('source', {}).get('name', 'Unknown')
                ))
            
            return news_items
            
        except Exception as e:
            self.logger.error(f"Error fetching news from API: {e}")
            return []
    
    async def _get_yahoo_news(self, symbol: str, limit: int) -> List[NewsData]:
        """
        Get news from Yahoo Finance (fallback)
        
        Args:
            symbol: Stock symbol
            limit: Number of news items
            
        Returns:
            List of NewsData objects
        """
        try:
            ticker = yf.Ticker(symbol)
            news = ticker.news[:limit]
            
            news_items = []
            for item in news:
                news_items.append(NewsData(
                    symbol=symbol,
                    headline=item.get('title', ''),
                    summary=item.get('summary', ''),
                    url=item.get('link', ''),
                    published_date=datetime.fromtimestamp(item.get('providerPublishTime', 0)),
                    source=item.get('publisher', 'Yahoo Finance')
                ))
            
            return news_items
            
        except Exception as e:
            self.logger.error(f"Error fetching Yahoo Finance news: {e}")
            return []
    
    async def get_market_indices(self) -> Dict[str, float]:
        """
        Get current values of major market indices
        
        Returns:
            Dictionary with index values
        """
        try:
            indices = {
                '^NSEI': 'NIFTY 50',
                '^BSESN': 'SENSEX',
                '^NSEBANK': 'NIFTY BANK',
                '^NSEIT': 'NIFTY IT'
            }
            
            index_values = {}
            
            for symbol, name in indices.items():
                try:
                    ticker = yf.Ticker(symbol)
                    hist = ticker.history(period="1d")
                    
                    if not hist.empty:
                        current_price = float(hist['Close'].iloc[-1])
                        index_values[name] = current_price
                        
                except Exception as e:
                    self.logger.warning(f"Error fetching {name}: {e}")
                    continue
            
            return index_values
            
        except Exception as e:
            self.logger.error(f"Error fetching market indices: {e}")
            return {}
    
    async def get_economic_indicators(self) -> Dict[str, Any]:
        """
        Get economic indicators (simplified version)
        
        Returns:
            Dictionary with economic data
        """
        try:
            # This is a simplified version
            # In production, you would fetch from RBI, World Bank, etc.
            indicators = {
                'repo_rate': 6.5,  # Current RBI repo rate
                'inflation_rate': 5.2,  # Current inflation estimate
                'gdp_growth': 7.0,  # GDP growth estimate
                'usd_inr': 83.0,  # USD/INR exchange rate estimate
                'crude_oil': 85.0,  # Crude oil price estimate
                'gold_price': 60000.0,  # Gold price estimate
                'timestamp': datetime.now()
            }
            
            # Try to get real USD/INR rate
            try:
                usd_inr_ticker = yf.Ticker("USDINR=X")
                usd_inr_hist = usd_inr_ticker.history(period="1d")
                if not usd_inr_hist.empty:
                    indicators['usd_inr'] = float(usd_inr_hist['Close'].iloc[-1])
            except:
                pass
            
            return indicators
            
        except Exception as e:
            self.logger.error(f"Error fetching economic indicators: {e}")
            return {}
    
    async def get_bulk_data(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Get bulk data for multiple symbols
        
        Args:
            symbols: List of stock symbols
            
        Returns:
            Dictionary with symbol as key and data as value
        """
        bulk_data = {}
        
        # Use asyncio to fetch data concurrently
        tasks = []
        for symbol in symbols:
            tasks.append(self._get_single_stock_data(symbol))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                self.logger.error(f"Error fetching data for {symbols[i]}: {result}")
                bulk_data[symbols[i]] = {'error': str(result)}
            else:
                bulk_data[symbols[i]] = result
        
        return bulk_data
    
    async def _get_single_stock_data(self, symbol: str) -> Dict[str, Any]:
        """
        Get comprehensive data for a single stock
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Dictionary with all available data
        """
        try:
            # Get price data
            price_data = await self.get_stock_data(symbol, "1mo")
            
            # Get current price
            current_price = await self.get_current_price(symbol)
            
            # Get company info
            company_info = await self.get_company_info(symbol)
            
            # Get recent news
            news = await self.get_news(symbol, 5)
            
            return {
                'symbol': symbol,
                'current_price': current_price,
                'price_data': price_data,
                'company_info': company_info,
                'news': news,
                'timestamp': datetime.now()
            }
            
        except Exception as e:
            self.logger.error(f"Error fetching comprehensive data for {symbol}: {e}")
            return {'symbol': symbol, 'error': str(e)}

# Global instance
market_data_collector = MarketDataCollector()
