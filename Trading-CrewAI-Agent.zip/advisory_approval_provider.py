"""
Phase 4 — AdvisoryApprovalProvider
====================================
Lightweight, in-process store for advisory synthesis approval requests.

When ``ENABLE_ADVISORY_APPROVAL=1`` is set, the advisory flow pauses
before running the ExecutionCrew and asks the user to approve/revise/reject
the synthesis.  This module handles:

    1. Creating a pending approval (stores the synthesis digest + conv_id)
    2. Generating the draft message that is returned to the user
    3. Detecting the user's approval decision from their reply
    4. Resolving / cleaning up the pending entry

Storage
-------
In-process Python dict (``_PENDING``).  Suitable for single-process
deployments.  For multi-process / multi-instance, replace with Redis or
a shared DB.

Approval keywords (case-insensitive, anywhere in the user message)
-------------------------------------------------------------------
    APPROVE   → "approved"
    REVISE    → "needs_revision"
    REJECT    → "rejected"

Example usage in advisory_flow.py
-----------------------------------
    provider = AdvisoryApprovalProvider()

    # --- In execution_step (or a pre-execution gate) ---
    if os.getenv("ENABLE_ADVISORY_APPROVAL", "0") == "1":
        external = s.response_metadata.get("external_approval_outcome")
        if not external:
            pending = provider.create_pending(s.conversation_id, s.synthesis_result)
            s.final_response = pending["draft_message"]
            s.advisory_approval_pending = True
            return

    # --- In initialize_flow (next user turn) ---
    if s.advisory_approval_pending:
        decision = provider.extract_decision(s.user_input)
        if decision:
            s.response_metadata["external_approval_outcome"] = decision
            provider.resolve(s.conversation_id)
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import time
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Module-level pending-approval store
# ─────────────────────────────────────────────────────────────────────────────

_PENDING: Dict[str, Dict] = {}
_TTL_SECONDS: int = 1800  # 30-minute window for the user to respond


# ─────────────────────────────────────────────────────────────────────────────

class AdvisoryApprovalProvider:
    """
    In-process store and helper for advisory synthesis approval requests.

    Thread-safety note: ``_PENDING`` is a plain dict.  Concurrent writes from
    multiple threads may cause lost updates.  For production multi-threaded
    usage, wrap mutation operations with a threading.Lock.
    """

    # ── Public API ─────────────────────────────────────────────────────────

    @staticmethod
    def create_pending(
        conv_id: str,
        synthesis_text: str,
        ttl_seconds: int = _TTL_SECONDS,
    ) -> Dict:
        """
        Register a new pending advisory approval and return the draft message.

        Args:
            conv_id: Conversation / session identifier.
            synthesis_text: Full synthesis text from AnalysisCrewBuilder.
            ttl_seconds: How long (in seconds) the pending entry stays valid.

        Returns:
            Dict with keys:
                approval_id  – short hash for this approval request
                draft_message – the text to return to the user
                expires_at   – Unix timestamp when entry expires
        """
        approval_id = AdvisoryApprovalProvider._make_id(conv_id, synthesis_text)
        digest = AdvisoryApprovalProvider._digest(synthesis_text)
        expires_at = time.time() + ttl_seconds

        _PENDING[conv_id] = {
            "approval_id": approval_id,
            "synthesis_digest": digest,
            "synthesis_text": synthesis_text,
            "expires_at": expires_at,
        }

        draft_message = AdvisoryApprovalProvider._build_draft(digest, approval_id)
        logger.info(
            "AdvisoryApprovalProvider.create_pending | conv=%s | id=%s | ttl=%ds",
            conv_id, approval_id, ttl_seconds,
        )

        return {
            "approval_id": approval_id,
            "draft_message": draft_message,
            "expires_at": expires_at,
        }

    @staticmethod
    def get_pending(conv_id: str) -> Optional[Dict]:
        """
        Return the pending approval entry for *conv_id* if it exists and is
        not expired.  Returns ``None`` otherwise.
        """
        entry = _PENDING.get(conv_id)
        if entry is None:
            return None
        if time.time() > entry["expires_at"]:
            logger.debug("AdvisoryApprovalProvider.get_pending | expired | conv=%s", conv_id)
            _PENDING.pop(conv_id, None)
            return None
        return entry

    @staticmethod
    def extract_decision(text: str) -> Optional[str]:
        """
        Parse the user's text for an approval decision keyword.

        Detection rules (case-insensitive):
            - "APPROVE"  / "APPROVED"  → "approved"
            - "REVISE"   / "REVISION"  → "needs_revision"
            - "REJECT"   / "REJECTED"  → "rejected"

        Returns the outcome string, or ``None`` if no keyword is found.

        Args:
            text: The raw user input string.

        Returns:
            ``"approved"``, ``"needs_revision"``, ``"rejected"``, or ``None``.
        """
        if not text:
            return None
        cleaned = text.strip().upper()

        if re.search(r"\bAPPROV(E|ED)?\b", cleaned):
            return "approved"
        if re.search(r"\bREVIS(E|ED|ION)?\b", cleaned):
            return "needs_revision"
        if re.search(r"\bREJECT(ED)?\b", cleaned):
            return "rejected"
        return None

    @staticmethod
    def resolve(conv_id: str) -> None:
        """
        Remove the pending approval entry for *conv_id* (after user responded).

        Args:
            conv_id: Conversation / session identifier.
        """
        removed = _PENDING.pop(conv_id, None)
        if removed:
            logger.info(
                "AdvisoryApprovalProvider.resolve | conv=%s | id=%s",
                conv_id, removed.get("approval_id"),
            )

    @staticmethod
    def clear_all() -> None:
        """Remove all pending entries.  Useful for test teardowns."""
        _PENDING.clear()

    # ── Internals ────────────────────────────────────────────────────────────

    @staticmethod
    def _make_id(conv_id: str, synthesis_text: str) -> str:
        """Create a short approval ID from conv_id + synthesis hash."""
        raw = f"{conv_id}:{synthesis_text[:200]}"
        return "adv_" + hashlib.sha1(raw.encode()).hexdigest()[:8]

    @staticmethod
    def _digest(synthesis_text: str, max_bullets: int = 6) -> str:
        """
        Extract up to *max_bullets* key points from the synthesis text.

        Looks for lines starting with common advisory markers (BUY, SELL,
        RECOMMENDATION, •, -, *, numbered lists).  Falls back to first
        *max_bullets* non-empty lines.
        """
        lines = synthesis_text.splitlines()
        markers = re.compile(
            r"^(\s*[-•*]|\s*\d+[.)]\s+|"
            r"\s*(BUY|SELL|HOLD|RECOMMEND|ACTION|KEY|RISK|WATCH)\b)",
            re.IGNORECASE,
        )
        bullets = [l.strip() for l in lines if markers.match(l) and l.strip()][:max_bullets]
        if not bullets:
            bullets = [l.strip() for l in lines if l.strip()][:max_bullets]

        numbered = "\n".join(f"  {i + 1}. {b}" for i, b in enumerate(bullets))
        return numbered or "(synthesis too short to summarise)"

    @staticmethod
    def _build_draft(digest: str, approval_id: str) -> str:
        """Build the approval-request message returned to the user."""
        return (
            "## Advisory Synthesis — Pending Your Approval\n\n"
            "The analysis is complete. Here are the key recommendations:\n\n"
            f"{digest}\n\n"
            "---\n"
            "Please respond with one of the following to proceed:\n\n"
            "| Command   | Effect                                      |\n"
            "|-----------+---------------------------------------------|\n"
            "| **APPROVE** | Execute the recommended trades immediately  |\n"
            "| **REVISE**  | Ask the advisory to refine its analysis     |\n"
            "| **REJECT**  | Dismiss this advisory, take no action       |\n\n"
            f"*Approval reference: `{approval_id}`*"
        )
