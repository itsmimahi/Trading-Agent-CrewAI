"""
Generic AgentWorker that consumes A2A requests from Redis Streams and dispatches to bound agent instances.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable, Dict, Optional

from .event_bus import RedisStreamsEventBus


class AgentWorker:
    def __init__(
        self,
        *,
        agent_id: str,
        agent_instance: Any,
        bus: RedisStreamsEventBus,
        stream: Optional[str] = None,
        group: Optional[str] = None,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        self.agent_id = agent_id
        self.agent_instance = agent_instance
        self.bus = bus
        self.stream = stream or f"agents:{agent_id}:requests"
        self.group = group or f"{agent_id}-group"
        self.log = logger or logging.getLogger(f"AgentWorker.{agent_id}")

    def start(self, *, concurrency: int = 1) -> None:
        def handler(msg: Dict[str, Any]):
            action = msg.get("action", "analyze")
            data = msg.get("data", {})
            corr_id = msg.get("correlation_id")
            reply_to = msg.get("reply_to")
            # Dispatch to agent instance
            if hasattr(self.agent_instance, action):
                method = getattr(self.agent_instance, action)
            elif hasattr(self.agent_instance, "analyze"):
                method = getattr(self.agent_instance, "analyze")
            else:
                result = {"success": False, "error": f"Unsupported action: {action}", "correlation_id": corr_id}
                if reply_to:
                    self.bus.publish(reply_to, result)
                return

            async def run_and_reply():
                try:
                    res = method(**data) if not asyncio.iscoroutinefunction(method) else await method(**data)
                    payload = {"success": True, "data": res, "correlation_id": corr_id}
                except Exception as e:  # noqa: BLE001
                    payload = {"success": False, "error": str(e), "correlation_id": corr_id}
                if reply_to:
                    self.bus.publish(reply_to, payload)

            # Fire-and-forget; processing is async
            return asyncio.create_task(run_and_reply())

        self.bus.start_consumer(stream=self.stream, group=self.group, consumer_name=None, handler=handler, concurrency=concurrency)
