"""
Base MCP Server implementation for the AI Trading Advisory System.

This module provides the foundation for all MCP servers used in agent-to-agent communication.
"""

import asyncio
import json
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
import uuid

from mcp import Client, Server
from mcp.server import NotificationOptions, InitializationOptions


@dataclass
class Message:
    """Standard message format for agent communication."""
    id: str
    sender: str
    recipient: str
    message_type: str
    content: Dict[str, Any]
    timestamp: datetime
    priority: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary format."""
        return {
            **asdict(self),
            'timestamp': self.timestamp.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        """Create message from dictionary."""
        return cls(
            id=data['id'],
            sender=data['sender'],
            recipient=data['recipient'],
            message_type=data['message_type'],
            content=data['content'],
            timestamp=datetime.fromisoformat(data['timestamp']),
            priority=data.get('priority', 0)
        )


@dataclass
class AgentInfo:
    """Information about an agent in the system."""
    id: str
    name: str
    type: str
    capabilities: List[str]
    status: str
    last_heartbeat: datetime
    endpoint: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert agent info to dictionary format."""
        return {
            **asdict(self),
            'last_heartbeat': self.last_heartbeat.isoformat()
        }


class BaseMCPServer(ABC):
    """
    Base class for MCP servers handling agent-to-agent communication.
    
    This class provides the foundation for implementing MCP servers that enable
    communication between different AI agents in the trading system.
    """
    
    def __init__(self, agent_id: str, agent_name: str, host: str = "localhost", port: int = 8000):
        """
        Initialize the MCP server.
        
        Args:
            agent_id: Unique identifier for the agent
            agent_name: Human-readable name for the agent
            host: Host address for the server
            port: Port number for the server
        """
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.host = host
        self.port = port
        self.server = None
        self.client = None
        self.is_running = False
        self.message_handlers: Dict[str, Callable] = {}
        self.logger = logging.getLogger(f"mcp.{agent_id}")
        
        # Message queue for incoming messages
        self.message_queue = asyncio.Queue()
        
        # Connected agents registry
        self.connected_agents: Dict[str, AgentInfo] = {}
        
        # Initialize message handlers
        self._setup_default_handlers()
    
    def _setup_default_handlers(self):
        """Set up default message handlers."""
        self.message_handlers.update({
            "ping": self._handle_ping,
            "heartbeat": self._handle_heartbeat,
            "register": self._handle_register,
            "unregister": self._handle_unregister,
            "request": self._handle_request,
            "response": self._handle_response,
            "notification": self._handle_notification,
            "error": self._handle_error
        })
    
    async def start(self):
        """Start the MCP server."""
        try:
            self.server = Server(self.agent_name)
            await self.server.start(self.host, self.port)
            self.is_running = True
            self.logger.info(f"MCP server started for agent {self.agent_id} on {self.host}:{self.port}")
            
            # Start background tasks
            asyncio.create_task(self._message_processor())
            asyncio.create_task(self._heartbeat_task())
            
        except Exception as e:
            self.logger.error(f"Failed to start MCP server: {e}")
            raise
    
    async def stop(self):
        """Stop the MCP server."""
        try:
            if self.server:
                await self.server.stop()
            self.is_running = False
            self.logger.info(f"MCP server stopped for agent {self.agent_id}")
        except Exception as e:
            self.logger.error(f"Error stopping MCP server: {e}")
    
    async def connect_to_agent(self, agent_endpoint: str) -> bool:
        """
        Connect to another agent's MCP server.
        
        Args:
            agent_endpoint: Endpoint of the target agent
            
        Returns:
            True if connection successful, False otherwise
        """
        try:
            self.client = Client()
            await self.client.connect(agent_endpoint)
            self.logger.info(f"Connected to agent at {agent_endpoint}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to connect to agent at {agent_endpoint}: {e}")
            return False
    
    async def send_message(self, recipient_id: str, message_type: str, content: Dict[str, Any], priority: int = 0) -> bool:
        """
        Send a message to another agent.
        
        Args:
            recipient_id: ID of the recipient agent
            message_type: Type of message (request, response, notification, etc.)
            content: Message content
            priority: Message priority (0 = normal, higher = more urgent)
            
        Returns:
            True if message sent successfully, False otherwise
        """
        try:
            message = Message(
                id=str(uuid.uuid4()),
                sender=self.agent_id,
                recipient=recipient_id,
                message_type=message_type,
                content=content,
                timestamp=datetime.now(),
                priority=priority
            )
            
            if self.client:
                await self.client.send_message(message.to_dict())
                self.logger.debug(f"Sent message {message.id} to {recipient_id}")
                return True
            else:
                self.logger.error("No client connection available")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to send message to {recipient_id}: {e}")
            return False
    
    async def _message_processor(self):
        """Background task to process incoming messages."""
        while self.is_running:
            try:
                # Wait for message with timeout
                message_data = await asyncio.wait_for(
                    self.message_queue.get(), 
                    timeout=1.0
                )
                
                message = Message.from_dict(message_data)
                await self._route_message(message)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"Error processing message: {e}")
    
    async def _route_message(self, message: Message):
        """Route incoming message to appropriate handler."""
        handler = self.message_handlers.get(message.message_type)
        if handler:
            try:
                await handler(message)
            except Exception as e:
                self.logger.error(f"Error handling message {message.id}: {e}")
                await self._send_error_response(message, str(e))
        else:
            self.logger.warning(f"No handler for message type: {message.message_type}")
    
    async def _heartbeat_task(self):
        """Background task to send heartbeat messages."""
        while self.is_running:
            try:
                # Send heartbeat to all connected agents
                for agent_id in self.connected_agents:
                    await self.send_message(
                        agent_id,
                        "heartbeat",
                        {"status": "alive", "timestamp": datetime.now().isoformat()}
                    )
                
                # Wait for next heartbeat interval
                await asyncio.sleep(30)  # 30 seconds
                
            except Exception as e:
                self.logger.error(f"Error in heartbeat task: {e}")
                await asyncio.sleep(5)
    
    async def _send_error_response(self, original_message: Message, error_msg: str):
        """Send error response for failed message processing."""
        await self.send_message(
            original_message.sender,
            "error",
            {
                "original_message_id": original_message.id,
                "error": error_msg,
                "timestamp": datetime.now().isoformat()
            }
        )
    
    # Default message handlers
    async def _handle_ping(self, message: Message):
        """Handle ping messages."""
        await self.send_message(
            message.sender,
            "response",
            {"type": "pong", "timestamp": datetime.now().isoformat()}
        )
    
    async def _handle_heartbeat(self, message: Message):
        """Handle heartbeat messages."""
        if message.sender in self.connected_agents:
            self.connected_agents[message.sender].last_heartbeat = datetime.now()
    
    async def _handle_register(self, message: Message):
        """Handle agent registration."""
        agent_info = AgentInfo(
            id=message.sender,
            name=message.content.get("name", "Unknown"),
            type=message.content.get("type", "Unknown"),
            capabilities=message.content.get("capabilities", []),
            status="active",
            last_heartbeat=datetime.now(),
            endpoint=message.content.get("endpoint", "")
        )
        
        self.connected_agents[message.sender] = agent_info
        self.logger.info(f"Registered agent {message.sender}")
        
        await self.send_message(
            message.sender,
            "response",
            {"status": "registered", "agent_id": message.sender}
        )
    
    async def _handle_unregister(self, message: Message):
        """Handle agent unregistration."""
        if message.sender in self.connected_agents:
            del self.connected_agents[message.sender]
            self.logger.info(f"Unregistered agent {message.sender}")
    
    async def _handle_request(self, message: Message):
        """Handle request messages - to be implemented by subclasses."""
        await self._send_error_response(message, "Request handler not implemented")
    
    async def _handle_response(self, message: Message):
        """Handle response messages - to be implemented by subclasses."""
        pass
    
    async def _handle_notification(self, message: Message):
        """Handle notification messages - to be implemented by subclasses."""
        pass
    
    async def _handle_error(self, message: Message):
        """Handle error messages."""
        self.logger.error(f"Received error from {message.sender}: {message.content}")
    
    @abstractmethod
    async def process_agent_request(self, request_type: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process agent-specific requests.
        
        Args:
            request_type: Type of request
            data: Request data
            
        Returns:
            Response data
        """
        pass
    
    def register_message_handler(self, message_type: str, handler: Callable):
        """Register a custom message handler."""
        self.message_handlers[message_type] = handler
    
    def get_agent_info(self) -> AgentInfo:
        """Get information about this agent."""
        return AgentInfo(
            id=self.agent_id,
            name=self.agent_name,
            type=self.__class__.__name__,
            capabilities=self.get_capabilities(),
            status="active" if self.is_running else "inactive",
            last_heartbeat=datetime.now(),
            endpoint=f"{self.host}:{self.port}"
        )
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Return list of capabilities this agent provides."""
        pass
