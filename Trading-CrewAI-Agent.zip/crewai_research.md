# CrewAI Framework Research

## What is CrewAI?
CrewAI is a lean, lightning-fast Python framework built entirely from scratch, independent of LangChain or other agent frameworks. It empowers developers with high-level simplicity and precise low-level control for creating autonomous AI agents.

## Key Components:
- **CrewAI Crews**: Optimize for autonomy and collaborative intelligence, enabling the creation of AI teams where each agent has specific roles, tools, and goals.
- **CrewAI Flows**: Enable granular, event-driven control, single LLM calls for precise task orchestration, and native support for Crews.

## How Crews Work:
Crews organize overall operations, with AI Agents working on specialized tasks. A defined Process ensures smooth collaboration, and Tasks are completed to achieve the overall goal.

### Crew Components:
- **Crew**: Top-level organization, manages AI agent teams, oversees workflows, ensures collaboration, and delivers outcomes.
- **AI Agents**: Specialized team members with specific roles (researcher, writer), designated tools, ability to delegate tasks, and autonomous decision-making.
- **Process**: Workflow management system, defines collaboration patterns, controls task assignments, manages interactions, and ensures efficient execution.
- **Tasks**: Individual assignments with clear objectives, specific tools, feeding into larger processes, and producing actionable results.

## Key Features:
- **Role-Based Agents**: Create specialized agents with defined roles, expertise, and goals.
- **Flexible Tools**: Equip agents with custom tools and APIs to interact with external services and data sources.
- **Intelligent Collaboration**: Agents work together, sharing insights and coordinating tasks.
- **Task Management**: Define sequential or parallel workflows, with agents automatically handling task dependencies.

## How Flows Work:
Flows provide structured automations with granular control over workflow execution, ensuring reliable, secure, and efficient task execution. They handle conditional logic, loops, and dynamic state management. Flows integrate seamlessly with Crews.

### Flow Components:
- **Flow**: Structured workflow orchestration, manages execution paths, handles state transitions, controls task sequencing, and ensures reliable execution.
- **Events**: Triggers for workflow actions, initiate specific processes, enable dynamic responses, support conditional branching, and allow for real-time adaptation.
- **States**: Workflow execution contexts, maintain execution data, enable persistence, support resumability, and ensure execution integrity.
- **Crew Support**: Enhances workflow automation, injects pockets of agency when needed, complements structured workflows, balances automation with intelligence, and enables adaptive decision-making.

## When to Use Crews vs. Flows:
- **Crews**: For autonomous problem-solving, creative collaboration, or exploratory tasks (e.g., open-ended research, content generation).
- **Flows**: For deterministic outcomes, auditability, or precise control over execution (e.g., decision workflows, API orchestration).
- **Combined Approach**: For applications needing both structured processes and autonomous intelligence.

## Why Choose CrewAI?
- **Autonomous Operation**: Agents make intelligent decisions.
- **Natural Interaction**: Agents communicate and collaborate like human team members.
- **Extensible Design**: Easy to add new tools, roles, and capabilities.
- **Production Ready**: Built for reliability and scalability.
- **Security-Focused**: Designed with enterprise security requirements.
- **Cost-Efficient**: Optimized to minimize token usage and API calls.




## CrewAI Agents

In the CrewAI framework, an `Agent` is an autonomous unit that can:
- Perform specific tasks
- Make decisions based on its role and goal
- Use tools to accomplish objectives
- Communicate and collaborate with other agents
- Maintain memory of interactions
- Delegate tasks when allowed

### Agent Attributes:
- **Role (`role`):** Defines the agent’s function and expertise within the crew.
- **Goal (`goal`):** The individual objective that guides the agent’s decision-making.
- **Backstory (`backstory`):** Provides context and personality to the agent.
- **LLM (`llm`):** Language model that powers the agent (optional).
- **Tools (`tools`):** Capabilities or functions available to the agent (optional).
- **Function Calling LLM (`function_calling_llm`):** Language model for tool calling (optional).
- **Max Iterations (`max_iter`):** Maximum iterations before the agent must provide its best answer (default is 20).
- **Max RPM (`max_rpm`):** Maximum requests per minute to avoid rate limits (optional).
- **Max Execution Time (`max_execution_time`):** Maximum time (in seconds) for task execution (optional).
- **Verbose (`verbose`):** Enable detailed execution logs for debugging (default is False).
- **Allow Delegation (`allow_delegation`):** Allow the agent to delegate tasks to other agents (default is False).
- **Step Callback (`step_callback`):** Function called after each agent step (optional).
- **Cache (`cache`):** Enable caching for tool usage (default is True).
- **System Template (`system_template`):** Custom system prompt template for the agent (optional).
- **Prompt Template (`prompt_template`):** Custom prompt template for the agent (optional).
- **Response Template (`response_template`):** Custom response template for the agent (optional).
- **Allow Code Execution (`allow_code_execution`):** Enable code execution for the agent (default is False).
- **Max Retry Limit (`max_retry_limit`):** Maximum number of retries when an error occurs (default is 2).
- **Respect Context Window (`respect_context_window`):** Keep messages under context window size by summarizing (default is True).
- **Code Execution Mode (`code_execution_mode`):** Mode for code execution: ‘safe’ (using Docker) or ‘unsafe’ (direct) (default is ‘safe’).
- **Multimodal (`multimodal`):** Whether the agent supports multimodal capabilities (default is False).
- **Inject Date (`inject_date`):** Whether to automatically inject the current date into tasks (default is False).
- **Date Format (`date_format`):** Format string for date when inject_date is enabled (default is “%Y-%m-%d”).
- **Reasoning (`reasoning`):** Whether the agent should reflect and create a plan before executing a task (default is False).
- **Max Reasoning Attempts (`max_reasoning_attempts`):** Maximum number of reasoning attempts before executing the task (optional).
- **Embedder (`embedder`):** Configuration for the embedder used by the agent (optional).
- **Knowledge Sources (`knowledge_sources`):** Knowledge sources available to the agent (optional).
- **Use System Prompt (`use_system_prompt`):** Whether to use system prompt (for o1 model support) (default is True).

### Creating Agents:
Agents can be created using **YAML configuration (recommended)** or by defining them **directly in code**.




## CrewAI Tasks

In the CrewAI framework, a `Task` is a specific assignment completed by an `Agent`. Tasks provide all necessary details for execution, such as a description, the agent responsible, required tools, and more. Tasks can be collaborative, requiring multiple agents to work together.

### Task Execution Flow:
Tasks can be executed in two ways:
- **Sequential**: Tasks are executed in the order they are defined.
- **Hierarchical**: Tasks are assigned to agents based on their roles and expertise.

### Task Attributes:
- **Description (`description`):** A clear, concise statement of what the task entails.
- **Expected Output (`expected_output`):** A detailed description of what the task’s completion looks like.
- **Name (`name`):** A name identifier for the task (optional).
- **Agent (`agent`):** The agent responsible for executing the task (optional).
- **Tools (`tools`):** The tools/resources the agent is limited to use for this task (optional).
- **Context (`context`):** Other tasks whose outputs will be used as context for this task (optional).
- **Async Execution (`async_execution`):** Whether the task should be executed asynchronously (default is False).
- **Human Input (`human_input`):** Whether the task should have a human review the final answer of the agent (default is False).
- **Markdown (`markdown`):** Whether the task should instruct the agent to return the final answer formatted in Markdown (default is False).
- **Config (`config`):** Task-specific configuration parameters (optional).
- **Output File (`output_file`):** File path for storing the task output (optional).
- **Create Directory (`create_directory`):** Whether to create the directory for output_file if it doesn’t exist (default is True).
- **Output JSON (`output_json`):** A Pydantic model to structure the JSON output (optional).
- **Output Pydantic (`output_pydantic`):** A Pydantic model for task output (optional).
- **Callback (`callback`):** Function/object to be executed after task completion (optional).
- **Guardrail (`guardrail`):** Function to validate task output before proceeding to next task (optional).

### Creating Tasks:
Tasks can be created using **YAML configuration (recommended)** or by defining them **directly in code**.




## CrewAI Crews

A crew in CrewAI represents a collaborative group of agents working together to achieve a set of tasks. Each crew defines the strategy for task execution, agent collaboration, and the overall workflow.

### Crew Attributes:
- **Tasks (`tasks`):** A list of tasks assigned to the crew.
- **Agents (`agents`):** A list of agents that are part of the crew.
- **Process (`process`):** The process flow (e.g., sequential, hierarchical) the crew follows. Default is `sequential`.
- **Verbose (`verbose`):** The verbosity level for logging during execution (defaults to `False`).
- **Manager LLM (`manager_llm`):** The language model used by the manager agent in a hierarchical process. Required when using a hierarchical process.
- **Function Calling LLM (`function_calling_llm`):** If passed, the crew will use this LLM to do function calling for tools for all agents in the crew. Each agent can have its own LLM, which overrides the crew’s LLM for function calling.
- **Config (`config`):** Optional configuration settings for the crew, in `Json` or `Dict[str, Any]` format.
- **Max RPM (`max_rpm`):** Maximum requests per minute the crew adheres to during execution (defaults to `None`).
- **Memory (`memory`):** Utilized for storing execution memories (short-term, long-term, entity memory).
- **Memory Config (`memory_config`):** Configuration for the memory provider to be used by the crew.
- **Cache (`cache`):** Specifies whether to use a cache for storing the results of tools’ execution (defaults to `True`).
- **Embedder (`embedder`):** Configuration for the embedder to be used by the crew. Mostly used by memory for now (default is `{"provider": "openai"}`).
- **Step Callback (`step_callback`):** A function that is called after each step of every agent.
- **Task Callback (`task_callback`):** A function that is called after the completion of each task.
- **Share Crew (`share_crew`):** Whether to share the complete crew information and execution with the crewAI team.
- **Output Log File (`output_log_file`):** Set to True to save logs as logs.txt or provide a file path (defaults to `None`).
- **Manager Agent (`manager_agent`):** Sets a custom agent that will be used as a manager.
- **Prompt File (`prompt_file`):** Path to the prompt JSON file to be used for the crew.
- **Planning (`planning`):** Adds planning ability to the Crew. When activated before each Crew iteration, all Crew data is sent to an AgentPlanner that will plan the tasks and this plan will be added to each task description.
- **Planning LLM (`planning_llm`):** The language model used by the AgentPlanner in a planning process.
- **Knowledge Sources (`knowledge_sources`):** Knowledge sources available at the crew level, accessible to all the agents.

### Creating Crews:
Crews can be created using **YAML configuration (recommended)** or by defining them **directly in code**.

