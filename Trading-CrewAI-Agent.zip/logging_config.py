"""
Centralized logging configuration for the Trading-CrewAI-Agent system.

Usage (call once at the entry point of each process):
    from config.logging_config import setup_logging
    setup_logging()

All modules should then get loggers the normal way:
    import logging
    logger = logging.getLogger(__name__)

Log files are written to the logs/ directory (one per major component),
overwritten fresh on each run (mode='w') — only the current run is kept.

Component → log file mapping (by logger name prefix):
  main_advisory_agent.*  → logs/main_advisory_agent.log
  advisory_flow          → logs/main_advisory_agent.log   (same package)
  agents.*               → logs/agents.log
  integration.*          → logs/integration.log
  paper_trading_agent.*  → logs/paper_trading_agent.log
  mcp_servers.*          → logs/mcp_servers.log
  analytics.*            → logs/analytics.log
  ui.*                   → logs/ui.log
  PTABusWorker           → logs/paper_trading_agent.log
  PortfolioWS            → logs/paper_trading_agent.log
  PerformanceCollector   → logs/analytics.log
  root (everything else) → logs/system.log
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import sys
from pathlib import Path

# ── Constants ──────────────────────────────────────────────────────────────────
_REPO_ROOT = Path(__file__).parent.parent
LOGS_DIR = _REPO_ROOT / "logs"

LOG_FORMAT = "%(asctime)s [%(levelname)-8s] %(name)s — %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Log files are overwritten on each run (mode='w') — only current run is kept.

# Logger name prefix → dedicated log file (relative to LOGS_DIR)
_COMPONENT_LOG_FILES: dict[str, str] = {
    "main_advisory_agent": "main_advisory_agent.log",
    "advisory_flow": "main_advisory_agent.log",
    "market_crew_builder": "main_advisory_agent.log",
    "analysis_crew_builder": "main_advisory_agent.log",
    "execution_crew_builder": "main_advisory_agent.log",
    "mcp_data_layer": "main_advisory_agent.log",
    "agents": "agents.log",
    "AgentWorker": "agents.log",
    "OrchestratorAgent": "agents.log",
    "PTAPortfolio": "agents.log",
    "AdvisoryPortfolio": "agents.log",
    "integration": "integration.log",
    "paper_trading_agent": "paper_trading_agent.log",
    "PTABusWorker": "paper_trading_agent.log",
    "PortfolioWS": "paper_trading_agent.log",
    "mcp_servers": "mcp_servers.log",
    "agent_registry": "mcp_servers.log",
    "communication_protocol": "mcp_servers.log",
    "analytics": "analytics.log",
    "PerformanceCollector": "analytics.log",
    "ui": "ui.log",
}

# Third-party loggers that should be silenced to WARNING unless DEBUG mode
_NOISY_LOGGERS: tuple[str, ...] = (
    "crewai",
    "LiteLLM",
    "httpx",
    "urllib3",
    "chromadb",
    "sentence_transformers",
    "openai",
    "azure",
    "werkzeug",
    "httpcore",
    "asyncio",
)

# Track whether setup has already run (safe to call multiple times)
_initialized: bool = False


# ── Public API ─────────────────────────────────────────────────────────────────

def setup_logging(
    level: str | None = None,
    console: bool = True,
) -> None:
    """Configure the global logging system.

    Should be called **once** at process startup before any loggers are used.
    Subsequent calls are no-ops (idempotent).

    Args:
        level:   Override log level (e.g. "DEBUG", "INFO", "WARNING").
                 Falls back to LOG_LEVEL env var, then defaults to INFO.
        console: Whether to also emit logs to stdout. Default True.
    """
    global _initialized
    if _initialized:
        return
    _initialized = True

    # Resolve effective log level
    effective_level_str = (
        level
        or os.getenv("LOG_LEVEL", "")
        or "INFO"
    ).upper()
    effective_level = getattr(logging, effective_level_str, logging.INFO)

    # Ensure logs/ directory exists
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    # ── Root logger: catches everything not matched by a named logger ──────────
    root = logging.getLogger()
    root.setLevel(effective_level)
    # Remove any handlers already attached (e.g. from basicConfig)
    for h in root.handlers[:]:
        root.removeHandler(h)

    formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

    # system.log — catches root + anything without a dedicated file
    root.addHandler(_file_handler("system.log", formatter))
    if console:
        root.addHandler(_console_handler(formatter))

    # ── Per-component file handlers on parent loggers ──────────────────────────
    # Group by target file to avoid opening the same file multiple times
    file_to_prefixes: dict[str, list[str]] = {}
    for prefix, fname in _COMPONENT_LOG_FILES.items():
        file_to_prefixes.setdefault(fname, []).append(prefix)

    # Cache open file handlers so siblings writing to the same file share one fd
    open_handlers: dict[str, logging.FileHandler] = {}

    for fname, prefixes in file_to_prefixes.items():
        fh = _file_handler(fname, formatter)
        open_handlers[fname] = fh
        for prefix in prefixes:
            comp_logger = logging.getLogger(prefix)
            comp_logger.setLevel(effective_level)
            # propagate=True so root still sees everything (for system.log)
            comp_logger.propagate = True
            # Only add if not already there
            if not any(isinstance(h, logging.FileHandler)
                       and getattr(h, 'baseFilename', None) == fh.baseFilename
                       for h in comp_logger.handlers):
                comp_logger.addHandler(fh)

    # ── Silence noisy third-party loggers ──────────────────────────────────────
    noisy_level = logging.DEBUG if effective_level <= logging.DEBUG else logging.WARNING
    for name in _NOISY_LOGGERS:
        logging.getLogger(name).setLevel(noisy_level)

    logging.getLogger(__name__).info(
        "Logging initialised | level=%s | logs_dir=%s",
        effective_level_str,
        LOGS_DIR,
    )


def get_logger(name: str) -> logging.Logger:
    """Return a logger, ensuring setup_logging() has been called.

    This is a convenience wrapper — modules that need a guaranteed-configured
    logger can call this instead of logging.getLogger(). Standard
    ``logging.getLogger(__name__)`` still works fine after setup_logging().
    """
    if not _initialized:
        setup_logging()
    return logging.getLogger(name)


# ── Internal helpers ───────────────────────────────────────────────────────────

def _file_handler(
    filename: str,
    formatter: logging.Formatter,
) -> logging.FileHandler:
    """Create a FileHandler writing to LOGS_DIR/filename, overwriting on each run."""
    path = LOGS_DIR / filename
    handler = logging.FileHandler(str(path), mode="w", encoding="utf-8")
    handler.setFormatter(formatter)
    return handler


def _console_handler(formatter: logging.Formatter) -> logging.StreamHandler:
    """Create a StreamHandler writing to stdout with UTF-8 safe output."""
    # On Windows, stdout may be cp1252 — wrap with a recoding stream
    stream = sys.stdout
    try:
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    handler = logging.StreamHandler(stream)
    handler.setFormatter(formatter)
    return handler


# kept for backward compat if anything imported this
def _handler_path(handler: logging.FileHandler) -> str:
    """Return the absolute file path of a FileHandler."""
    return str(Path(handler.baseFilename).resolve())
