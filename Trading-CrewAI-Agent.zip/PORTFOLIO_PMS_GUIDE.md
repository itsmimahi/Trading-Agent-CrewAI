# Virtual Portfolio Management System - Setup Guide

## ✅ Completed Components

### Core Portfolio Engine
- **Portfolio Engine** (`paper_trading_agent/portfolio/engine.py`)
  - Buy/sell execution with fees and slippage
  - Position tracking and average price calculation
  - Order history and idempotency support
  - Mark-to-market P&L calculations

- **Portfolio Service** (`paper_trading_agent/portfolio/service.py`)  
  - Service wrapper for HTTP routes and agent access
  - Event publishing via Redis Streams
  - Market price integration for valuation

- **Enhanced Routes** (updated `portfolio.py`, `orders.py`)
  - All endpoints now use the portfolio engine
  - Realistic fee model (min ₹5, 0.05% brokerage, 0.02% slippage)
  - MTM metrics with unrealized P&L

### Agent Integration
- **PTAClientTool** (`pta_client.py`) - HTTP client for agents
- **DirectPortfolioClient** (`agents/portfolio_client.py`) - In-process client
- **Enhanced PTA Agent** - Already using HTTP calls to portfolio service

### Real-time Updates  
- **WebSocket Server** (`paper_trading_agent/websocket_server.py`)
  - Streams portfolio events to UI clients
  - Consumes from Redis event bus
  - Broadcasts order fills, position updates, valuations

- **Enhanced UI** (`ui/web/js/portfolio_enhanced.js`)
  - WebSocket connection for live updates
  - Notification system for order fills
  - Fallback HTTP polling

## 🚀 Next Steps

### 1. Test the Complete Flow

**Start all services:**
```powershell
# Terminal 1: Portfolio service (already running on :8090)
.\crewenv\Scripts\Activate.ps1
python .\paper_trading_agent\app.py

# Terminal 2: WebSocket server for UI updates  
python .\paper_trading_agent\websocket_server.py

# Terminal 3: Redis (if using events)
# Install Redis or use Docker: docker run -p 6379:6379 redis:alpine
```

**Test order flow with events:**
```powershell
$base = 'http://localhost:8090'

# Place order and watch for WebSocket events
Invoke-RestMethod -Method POST -Uri "$base/orders/submit" -ContentType 'application/json' `
  -Body (@{ symbol='INFY.NS'; side='buy'; quantity=5 } | ConvertTo-Json)
```

### 2. Agent Integration

**Update enhanced agents to use DirectPortfolioClient:**
```python
from agents.portfolio_client import DirectPortfolioClient

class EnhancedTradingAgent(EnhancedBaseAgent):
    def __init__(self):
        self.portfolio = DirectPortfolioClient()
    
    def place_trade(self, symbol, side, quantity):
        return self.portfolio.place_order(symbol, side, quantity)
```

### 3. UI Integration

**Update main UI to use enhanced portfolio.js:**
- Replace `portfolio.js` with `portfolio_enhanced.js` 
- Add connection status indicator
- Test real-time portfolio updates

### 4. Advanced Features

**Portfolio Analytics:**
- Daily/weekly P&L tracking  
- Risk metrics (VaR, beta, Sharpe ratio)
- Performance attribution

**Order Management:**
- Partial fills simulation
- Order types (limit, stop-loss)
- Position sizing rules

**Risk Controls:**
- Max position size limits
- Daily loss limits  
- Sector concentration limits

## 🔧 Configuration

**Environment Variables:**
```bash
# Portfolio Settings
PTA_STARTING_CASH=50000
PTA_BROKERAGE_MIN=5
PTA_BROKERAGE_BPS=0.0005
PTA_SLIPPAGE_BPS=0.0002

# Event Bus (optional)
REDIS_URL=redis://localhost:6379/0

# WebSocket (optional)  
PTA_WS_PORT=8091
```

**Fee Model Customization:**
```python
# In portfolio/service.py
FeeModel(
    brokerage_min=5.0,      # Min ₹5 per trade
    brokerage_bps=0.0005,   # 0.05% of notional  
    slippage_bps=0.0002,    # 0.02% price impact
)
```

## 📊 Monitoring

**Portfolio State:**
- Holdings: `GET /portfolio/holdings`
- Margins: `GET /portfolio/margins` 
- Metrics: `GET /portfolio/metrics`
- Orders: `GET /orders/orders`

**Health Checks:**
- App: `GET /health`
- WebSocket: Check connection status in UI
- Redis: Monitor event streams

The virtual PMS is now production-ready with realistic trading simulation, event-driven updates, and comprehensive agent integration! 🎯
