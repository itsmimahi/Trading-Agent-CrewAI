(function(){
  const api = new APIClient();
  const currency = CONFIG.market?.currencySymbol || '₹';

  function fmt(n){ try { return new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(n); } catch { return n; } }

  async function fetchHoldings(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/holdings');
    return (res && res.success) ? res.data : { cash: 0, holdings: [] };
  }
  async function fetchMetrics(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/metrics');
    return (res && res.success) ? res.data : null;
  }
  async function fetchMargins(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/margins');
    return (res && res.success) ? res.data : { available: 0, used: 0, net: 0 };
  }
  async function lastPrice(sym){
    const res = await api.makeRequest(`/api/proxy/pta/market/last_price/${encodeURIComponent(sym)}`, { skipCache: true });
    return (res && res.success) ? res.data?.last_price : null;
  }

  async function refreshAll(){
  const [hold, marg, mets] = await Promise.all([fetchHoldings(), fetchMargins(), fetchMetrics()]);
    const holdings = hold.holdings || [];
  document.getElementById('mCash').textContent = `${currency} ${fmt(hold.cash || 0)}`;
  document.getElementById('mPositions').textContent = fmt(holdings.length);
    // compute total value
    const totalPosVal = await holdings.reduce(async (accP, h) => {
      const acc = await accP; const lp = await lastPrice(h.symbol); return acc + (lp || 0) * h.quantity;
    }, Promise.resolve(0));
  const total = (hold.cash || 0) + totalPosVal;
  document.getElementById('mTotal').textContent = `${currency} ${fmt(total)}`;
  const dayPnL = mets?.unrealized_pnl ?? 0;
  document.getElementById('mDayPnL').textContent = `${currency} ${fmt(dayPnL)}`;

    // table
    const tbody = document.querySelector('#portfolioTable tbody');
    tbody.innerHTML = '';
    for (const h of holdings){
      const lp = await lastPrice(h.symbol); const pnl = lp != null ? (lp - h.avg_price) * h.quantity : 0;
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${h.symbol}</td>
        <td>${h.quantity}</td>
        <td>${currency} ${fmt(h.avg_price)}</td>
        <td>${lp != null ? `${currency} ${fmt(lp)}` : '-'}</td>
        <td class="${pnl >= 0 ? 'pos' : 'neg'}">${currency} ${fmt(pnl)}</td>`;
      tbody.appendChild(tr);
    }

    // orders
    try {
      const ordersRes = await api.makeRequest('/api/proxy/pta/orders/orders');
      const orders = (ordersRes && ordersRes.success) ? ordersRes.data : [];
      const ob = document.querySelector('#ordersTable tbody'); ob.innerHTML = '';
      for (const o of orders){
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${o.order_id}</td><td>${o.symbol}</td><td>${o.side}</td><td>${o.quantity}</td><td>${currency} ${fmt(o.price)}</td><td>${o.status}</td>`;
        ob.appendChild(tr);
      }
    } catch(e) { console.warn('Orders fetch failed', e); }

    // subscribe to symbols for better LTPs
    const symbols = holdings.map(h => h.symbol);
    if (symbols.length){
      try { await api.makeRequest('/api/proxy/pta/adapter/subscribe', { method:'POST', body: JSON.stringify({ symbols }) }); } catch {}
    }
  }

  async function submitOrder(e){
    e.preventDefault();
    const symbol = document.getElementById('sym').value.trim().toUpperCase();
    const side = document.getElementById('side').value;
    const qty = parseInt(document.getElementById('qty').value || '1', 10);
    if (!symbol || !['buy','sell'].includes(side) || !qty || qty < 1){
      window.showToast?.('Enter valid order inputs', 'warning'); return;
    }
    try {
      const res = await api.makeRequest('/api/proxy/pta/orders/submit', { method:'POST', body: JSON.stringify({ symbol, side, quantity: qty }) });
      if (res && res.success){ window.showToast?.('Order submitted', 'success'); await refreshAll(); }
      else { throw new Error(res?.error || 'Submit failed'); }
    } catch (err){ window.showToast?.(err.message || 'Order failed', 'error'); }
  }

  function init(){
    const form = document.getElementById('orderForm');
    if (form) form.addEventListener('submit', submitOrder);
    refreshAll();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
