// Enhanced API Communication Module with Performance Optimizations
class APIClient {
    constructor() {
        this.baseUrls = {
            mainAgent: CONFIG.MAIN_AGENT_URL,
            rlAgent: CONFIG.RL_AGENT_URL,
            webUI: (typeof CONFIG.WEB_UI_URL !== 'undefined' && CONFIG.WEB_UI_URL) ? CONFIG.WEB_UI_URL : (window.location.origin || 'http://localhost:5000')
        };
        this.requestId = 0;
        this.activeRequests = new Map();
        this.requestQueue = [];
        this.isProcessingQueue = false;
        this.maxConcurrentRequests = 5;
        this.rateLimitDelay = 100; // ms between requests
        this.lastRequestTime = 0;
        this.lastRequestHeaderId = null;
        
        // Performance monitoring
        this.performanceMetrics = {
            totalRequests: 0,
            successfulRequests: 0,
            failedRequests: 0,
            averageResponseTime: 0,
            cacheHits: 0
        };
    }

    // Generate unique request ID
    generateRequestId() {
        return ++this.requestId;
    }

    // Rate limiting check
    async enforceRateLimit() {
        const now = Date.now();
        const timeSinceLastRequest = now - this.lastRequestTime;
        
        if (timeSinceLastRequest < this.rateLimitDelay) {
            await new Promise(resolve => 
                setTimeout(resolve, this.rateLimitDelay - timeSinceLastRequest)
            );
        }
        
        this.lastRequestTime = Date.now();
    }

    // Helper to read CSRF token from meta tag set by security.js
    getCsrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta && meta.content ? meta.content : null;
    }

    // Web UI health (same-origin)
    async getUIHealth() {
        return await this.makeRequest('/api/health');
    }

    // Web UI aggregated system status (same-origin)
    async getSystemStatusData() {
        return await this.makeRequest('/api/system/status');
    }

    // Get last price for a symbol
    async getLastPrice(symbol) {
        const encodedSymbol = encodeURIComponent(symbol);
        return await this.makeRequest(`/api/proxy/pta/market/last_price/${encodedSymbol}`, { skipCache: true });
    }

    // Enhanced API request method with caching, compression, and connection pooling
    async makeRequest(url, options = {}) {
        const requestId = this.generateRequestId();
        const requestStartTime = Date.now();
    // Generate a stable idempotency key for chat endpoints if not provided
    const isChatEndpoint = typeof url === 'string' && url.includes('/api/proxy/chat');
    const idemKey = (options && options.idemKey) || (isChatEndpoint ? (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`) : null);
        
        // Check cache first for GET requests
        if ((!options.method || options.method === 'GET') && !options.skipCache) {
            const cacheKey = `${url}_${JSON.stringify(options.params || {})}`;
            const cachedResponse = performanceOptimizer.getCachedResponse(cacheKey);
            
            if (cachedResponse) {
                this.performanceMetrics.cacheHits++;
                console.log(`Cache hit for request ${requestId}: ${url}`);
                return cachedResponse;
            }
        }

    const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Accept-Encoding': 'gzip, deflate, br',
        'X-Request-ID': requestId.toString(),
        ...(idemKey ? { 'Idempotency-Key': idemKey } : {})
            },
            timeout: CONFIG.settings?.requestTimeout || 30000,
            credentials: 'include'
        };

        const finalOptions = { ...defaultOptions, ...options };
        // Attach CSRF token automatically for state-changing requests
        try {
            const m = (finalOptions.method || 'GET').toUpperCase();
            if (m !== 'GET') {
                const csrf = this.getCsrfToken();
                if (csrf) {
                    finalOptions.headers = finalOptions.headers || {};
                    finalOptions.headers['X-CSRF-Token'] = csrf;
                }
            }
        } catch {}
        let lastError;

        // Add request to active requests
        this.activeRequests.set(requestId, { 
            url, 
            options: finalOptions, 
            startTime: requestStartTime 
        });

        // Enforce rate limiting
        await this.enforceRateLimit();

        for (let attempt = 1; attempt <= (CONFIG.settings?.retryAttempts || 3); attempt++) {
            try {
                console.log(`API Request ${requestId} (Attempt ${attempt}): ${finalOptions.method} ${url}`);
                
                // Check if too many concurrent requests
                if (this.activeRequests.size > this.maxConcurrentRequests) {
                    await this.waitForAvailableSlot();
                }

                const controller = new AbortController();
                const timeoutMs = (() => {
                    try {
                        const isChat = typeof url === 'string' && url.includes('/api/proxy/chat');
                        if (isChat && CONFIG.settings?.chatRequestTimeout) return CONFIG.settings.chatRequestTimeout;
                    } catch {}
                    return finalOptions.timeout;
                })();
                const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
                
                // If chat endpoint, for POST body we also mirror idempotency key as field for compatibility
                if (isChatEndpoint && finalOptions && typeof finalOptions.body === 'string' && idemKey) {
                    try {
                        const parsed = JSON.parse(finalOptions.body);
                        if (!parsed.idempotency_key) {
                            parsed.idempotency_key = idemKey;
                            finalOptions.body = JSON.stringify(parsed);
                        }
                    } catch {}
                }

                const response = await fetch(url, {
                    ...finalOptions,
                    signal: controller.signal
                });

                clearTimeout(timeoutId);
                
                // Handle 202 in-progress for idempotent chat: do a short backoff and retry
                if (response.status === 202 && isChatEndpoint && idemKey) {
                    await this.delay(1000);
                    attempt--; // don't count as an attempt
                    continue;
                }
                if (!response.ok) {
                    const err = new Error(`HTTP ${response.status}: ${response.statusText}`);
                    err.httpStatus = response.status;
                    throw err;
                }
                // Capture server-provided request id if present
                const serverReqId = response.headers.get('X-Request-ID');
                if (serverReqId) {
                    this.lastRequestHeaderId = serverReqId;
                    window.dispatchEvent(new CustomEvent('ui:lastRequestId', { detail: { requestId: serverReqId } }));
                }
                const data = await response.json();
                const responseTime = Date.now() - requestStartTime;
                
                // Update performance metrics
                this.performanceMetrics.totalRequests++;
                this.performanceMetrics.successfulRequests++;
                this.performanceMetrics.averageResponseTime = 
                    (this.performanceMetrics.averageResponseTime + responseTime) / 2;
                
                console.log(`API Response ${requestId} (${responseTime}ms):`, data);
                
                // Cache successful GET responses
                if ((!options.method || options.method === 'GET') && !options.skipCache) {
                    const cacheKey = `${url}_${JSON.stringify(options.params || {})}`;
                    performanceOptimizer.cacheResponse(cacheKey, {
                        success: true,
                        data,
                        status: response.status,
                        requestId,
                        cached: true,
                        timestamp: new Date().toISOString()
                    });
                }
                
                // Remove from active requests
                this.activeRequests.delete(requestId);
                
                const result = {
                    success: true,
                    data,
                    status: response.status,
                    requestId,
                    responseTime
                };
                try {
                    const reqIdEl = document.getElementById('telemetryReqId');
                    if (reqIdEl && (this.lastRequestHeaderId || requestId)) {
                        reqIdEl.textContent = this.lastRequestHeaderId || String(requestId);
                    }
                } catch {}
                return result;

            } catch (error) {
                lastError = error;
                this.performanceMetrics.totalRequests++;
                this.performanceMetrics.failedRequests++;
                
                // Normalize AbortError message
                if (error?.name === 'AbortError') {
                    lastError = new Error('Request aborted (timeout)');
                }
                console.warn(`API Request ${requestId} failed (Attempt ${attempt}):`, lastError.message || error.message);
                
                if (attempt < (CONFIG.settings?.retryAttempts || 3)) {
                    await this.delay((CONFIG.settings?.retryDelay || 1000) * attempt);
                }
            }
        }

        // Remove from active requests
        this.activeRequests.delete(requestId);
        
        console.error(`API Request ${requestId} failed after ${CONFIG.settings?.retryAttempts || 3} attempts:`, lastError);
        
        return {
            success: false,
            error: lastError?.message || 'Request failed',
            code: lastError?.httpStatus || (lastError?.name === 'AbortError' ? 'timeout' : undefined),
            requestId
        };
    }

    // Wait for available request slot
    async waitForAvailableSlot() {
        while (this.activeRequests.size >= this.maxConcurrentRequests) {
            await this.delay(100);
        }
    }

    // Utility method for delays
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Get performance metrics
    getPerformanceMetrics() {
        return { ...this.performanceMetrics };
    }

    // Check health of main agent
    async checkMainAgentHealth() {
        const url = `${this.baseUrls.mainAgent}${CONFIG.endpoints.mainAgent.health}`;
        return await this.makeRequest(url);
    }

    // Check health of RL agent
    async checkRLAgentHealth() {
        const url = `${this.baseUrls.rlAgent}${CONFIG.endpoints.rlAgent.health}`;
        return await this.makeRequest(url);
    }

    // Send chat message to main agent
    async sendChatMessage(message, conversationId = null) {
        // Route through Web UI proxy to handle retries, CORS and CSRF
        const url = `/api/proxy/chat`;
        const payload = {
            message: message.trim(),
            timestamp: new Date().toISOString()
        };
        if (conversationId) {
            payload.conversation_id = conversationId;
        }
        return await this.makeRequest(url, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    }

    // Get RL agent insights
    async getRLInsights(query = null) {
        // Route via Web UI proxy with endpoint alignment/fallback
        let url = `/api/proxy/rl/insights`;
        if (query) {
            url += `?query=${encodeURIComponent(query)}`;
        }
        return await this.makeRequest(url);
    }

    // Get RL agent prediction
    async getRLPrediction(data) {
        const url = `${this.baseUrls.rlAgent}${CONFIG.endpoints.rlAgent.predict}`;
        
        return await this.makeRequest(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    // Get main agent status
    async getMainAgentStatus() {
        const url = `${this.baseUrls.mainAgent}${CONFIG.endpoints.mainAgent.status}`;
        return await this.makeRequest(url);
    }

    // Get RL agent status  
    async getRLAgentStatus() {
        const url = `${this.baseUrls.rlAgent}${CONFIG.endpoints.rlAgent.status}`;
        return await this.makeRequest(url);
    }

    // Get integration status
    async getIntegrationStatus() {
        const url = `${this.baseUrls.mainAgent}${CONFIG.endpoints.mainAgent.integration}`;
        return await this.makeRequest(url);
    }

    // Cancel all active requests
    cancelAllRequests() {
        console.log(`Cancelling ${this.activeRequests.size} active requests`);
        this.activeRequests.clear();
    }

    // Get active request count
    getActiveRequestCount() {
        return this.activeRequests.size;
    }
}

// Performance metrics tracking
class PerformanceTracker {
    constructor() {
        this.metrics = {
            requestCount: 0,
            successCount: 0,
            errorCount: 0,
            totalResponseTime: 0,
            averageResponseTime: 0,
            lastResponseTime: 0
        };
        this.startTime = Date.now();
    }

    // Track API request
    trackRequest(responseTime, success = true) {
        this.metrics.requestCount++;
        this.metrics.totalResponseTime += responseTime;
        this.metrics.averageResponseTime = Math.round(this.metrics.totalResponseTime / this.metrics.requestCount);
        this.metrics.lastResponseTime = responseTime;

        if (success) {
            this.metrics.successCount++;
        } else {
            this.metrics.errorCount++;
        }
    }

    // Get success rate percentage
    getSuccessRate() {
        if (this.metrics.requestCount === 0) return 0;
        return Math.round((this.metrics.successCount / this.metrics.requestCount) * 100);
    }

    // Get uptime in seconds
    getUptime() {
        return Math.round((Date.now() - this.startTime) / 1000);
    }

    // Reset metrics
    reset() {
        this.metrics = {
            requestCount: 0,
            successCount: 0,
            errorCount: 0,
            totalResponseTime: 0,
            averageResponseTime: 0,
            lastResponseTime: 0
        };
        this.startTime = Date.now();
    }

    // Export metrics
    exportMetrics() {
        return {
            ...this.metrics,
            successRate: this.getSuccessRate(),
            uptime: this.getUptime()
        };
    }
}

// Service status manager
class ServiceStatusManager {
    constructor() {
        this.statuses = {
            mainAgent: CONFIG.statusTypes.CHECKING,
            rlAgent: CONFIG.statusTypes.CHECKING,
            integration: CONFIG.statusTypes.CHECKING,
            azure: CONFIG.statusTypes.CHECKING
        };
        this.callbacks = [];
    }

    // Register status change callback
    onStatusChange(callback) {
        this.callbacks.push(callback);
    }

    // Update service status
    updateStatus(service, status) {
        if (this.statuses[service] !== status) {
            this.statuses[service] = status;
            console.log(`Status update: ${service} -> ${status}`);
            
            // Notify callbacks
            this.callbacks.forEach(callback => {
                try {
                    callback(service, status);
                } catch (error) {
                    console.error('Status callback error:', error);
                }
            });
        }
    }

    // Get all statuses
    getAllStatuses() {
        return { ...this.statuses };
    }

    // Get overall system health
    getSystemHealth() {
        const statuses = Object.values(this.statuses);
        
        if (statuses.includes(CONFIG.statusTypes.OFFLINE)) {
            return CONFIG.statusTypes.OFFLINE;
        }
        
        if (statuses.includes(CONFIG.statusTypes.WARNING)) {
            return CONFIG.statusTypes.WARNING;
        }
        
        if (statuses.every(status => status === CONFIG.statusTypes.ONLINE)) {
            return CONFIG.statusTypes.ONLINE;
        }
        
        return CONFIG.statusTypes.CHECKING;
    }
}

// Initialize global instances
const apiClient = new APIClient();
const performanceTracker = new PerformanceTracker();
const serviceStatusManager = new ServiceStatusManager();

// Enhanced API wrapper with performance tracking
class EnhancedAPI {
    constructor() {
        this.client = apiClient;
        this.tracker = performanceTracker;
        this.statusManager = serviceStatusManager;
        this._lastSystemRaw = null;
    }

    // Wrapper for API requests with performance tracking
    async request(url, options = {}) {
        const startTime = Date.now();
        
        try {
            const result = await this.client.makeRequest(url, options);
            const responseTime = Date.now() - startTime;
            
            this.tracker.trackRequest(responseTime, result.success);
            
            return result;
        } catch (error) {
            const responseTime = Date.now() - startTime;
            this.tracker.trackRequest(responseTime, false);
            throw error;
        }
    }

    // Health check with status updates
    async healthCheck() {
        try {
            const res = await this.client.getSystemStatusData();
            if (res.success && res.data && res.data.data) {
                const s = res.data.data;
                this._lastSystemRaw = s;
                const mapStatus = (v) => {
                    const st = v && v.status ? v.status : 'offline';
                    if (st === 'online') return CONFIG.statusTypes.ONLINE;
                    if (st === 'error' || st === 'offline' || st === 'timeout') return CONFIG.statusTypes.OFFLINE;
                    return CONFIG.statusTypes.WARNING;
                };
                this.statusManager.updateStatus('mainAgent', mapStatus(s.mainAgent));
                this.statusManager.updateStatus('rlAgent', mapStatus(s.rlAgent));
                this.statusManager.updateStatus('integration', mapStatus(s.integration));
                if (s.azure) {
                    this.statusManager.updateStatus('azure', mapStatus(s.azure));
                }
            } else {
                this.statusManager.updateStatus('mainAgent', CONFIG.statusTypes.OFFLINE);
                this.statusManager.updateStatus('rlAgent', CONFIG.statusTypes.OFFLINE);
                this.statusManager.updateStatus('integration', CONFIG.statusTypes.OFFLINE);
                if (CONFIG.azure && CONFIG.azure.enabled) {
                    this.statusManager.updateStatus('azure', CONFIG.statusTypes.OFFLINE);
                }
            }
        } catch (e) {
            this.statusManager.updateStatus('mainAgent', CONFIG.statusTypes.OFFLINE);
            this.statusManager.updateStatus('rlAgent', CONFIG.statusTypes.OFFLINE);
            this.statusManager.updateStatus('integration', CONFIG.statusTypes.OFFLINE);
            if (CONFIG.azure && CONFIG.azure.enabled) {
                this.statusManager.updateStatus('azure', CONFIG.statusTypes.OFFLINE);
            }
        }
        // Azure card handling based on config
        try {
            if (CONFIG.azure && CONFIG.azure.enabled === false) {
                this.statusManager.updateStatus('azure', CONFIG.statusTypes.OFFLINE);
            }
        } catch {}
        return this.statusManager.getAllStatuses();
    }

    // Enhanced chat with RL insights
    async sendMessage(message, conversationId = null) {
        try {
            // Send to main agent (via proxy), passing conversationId if present
            const chatResult = await this.client.sendChatMessage(message, conversationId);
            
            if (chatResult.success) {
                // Try to get RL insights in parallel
                this.client.getRLInsights(message).then(rlResult => {
                    if (rlResult.success && window.rlInsightsManager) {
                        window.rlInsightsManager.addInsight(rlResult.data);
                    }
                }).catch(error => {
                    console.warn('Failed to get RL insights:', error);
                });
            }
            
            return chatResult;
        } catch (error) {
            console.error('Enhanced chat error:', error);
            throw error;
        }
    }

    // Expose last raw system status
    getLastSystemStatusRaw() {
        return this._lastSystemRaw;
    }

    // Get performance metrics
    getMetrics() {
        return this.tracker.exportMetrics();
    }

    // Get system status
    getSystemStatus() {
        return {
            services: this.statusManager.getAllStatuses(),
            overall: this.statusManager.getSystemHealth(),
            metrics: this.getMetrics(),
            activeRequests: this.client.getActiveRequestCount()
        };
    }
}

// Export enhanced API instance
const enhancedAPI = new EnhancedAPI();

// Global error handler for API errors
window.addEventListener('unhandledrejection', event => {
    console.error('Unhandled API error:', event.reason);
    
    if (window.showToast) {
        window.showToast('System Error: ' + event.reason.message, CONFIG.toastTypes.ERROR);
    }
});

// Export for global use
window.enhancedAPI = enhancedAPI;
window.apiClient = apiClient;
window.performanceTracker = performanceTracker;
window.serviceStatusManager = serviceStatusManager;
