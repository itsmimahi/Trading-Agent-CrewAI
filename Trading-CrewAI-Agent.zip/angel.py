from .base import MarketDataAdapter

class AngelAdapter(MarketDataAdapter):
    name = "ANGEL"

    def ws_connect(self) -> bool:
        return False
