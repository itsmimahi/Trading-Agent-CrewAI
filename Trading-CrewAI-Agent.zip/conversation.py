"""
Conversation Model
Manages conversation context, history, and state for the main advisory agent.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from datetime import datetime
import json
import uuid


class ConversationState(Enum):
    INITIAL_QUERY = "initial_query"
    CONTEXT_GATHERING = "context_gathering"
    TASK_DELEGATION = "task_delegation"
    INFORMATION_SYNTHESIS = "information_synthesis"
    RECOMMENDATION_GENERATION = "recommendation_generation"
    CLARIFICATION_REFINEMENT = "clarification_refinement"
    CONVERSATION_CLOSURE = "conversation_closure"


class MessageType(Enum):
    USER_INPUT = "user_input"
    AGENT_RESPONSE = "agent_response"
    SYSTEM_MESSAGE = "system_message"
    CLARIFICATION_REQUEST = "clarification_request"
    RECOMMENDATION = "recommendation"


@dataclass
class ConversationMessage:
    """Represents a single message in the conversation."""
    message_id: str
    timestamp: datetime
    message_type: MessageType
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary format."""
        return {
            "message_id": self.message_id,
            "timestamp": self.timestamp.isoformat(),
            "message_type": self.message_type.value,
            "content": self.content,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConversationMessage':
        """Create message from dictionary."""
        return cls(
            message_id=data["message_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            message_type=MessageType(data["message_type"]),
            content=data["content"],
            metadata=data.get("metadata", {})
        )


@dataclass
class ExtractedEntity:
    """Represents an entity extracted from user input."""
    entity_type: str  # e.g., "stock_symbol", "company_name", "time_period"
    value: str
    confidence: float
    source_message_id: str


@dataclass
class UserProfile:
    """Represents user profile information."""
    user_id: Optional[str] = None
    risk_tolerance: Optional[str] = None  # "conservative", "moderate", "aggressive"
    investment_goals: List[str] = field(default_factory=list)
    time_horizon: Optional[str] = None  # "short_term", "medium_term", "long_term"
    experience_level: Optional[str] = None  # "beginner", "intermediate", "advanced"
    preferred_sectors: List[str] = field(default_factory=list)
    portfolio_size: Optional[str] = None  # "small", "medium", "large"
    preferences: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskDelegationRecord:
    """Records information about tasks delegated to specialized agents."""
    task_id: str
    agent_id: str
    task_description: str
    input_parameters: Dict[str, Any]
    status: str  # "pending", "in_progress", "completed", "failed"
    result: Optional[Dict[str, Any]] = None
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert task record to dictionary format."""
        return {
            "task_id": self.task_id,
            "agent_id": self.agent_id,
            "task_description": self.task_description,
            "input_parameters": self.input_parameters,
            "status": self.status,
            "result": self.result,
            "timestamp": self.timestamp.isoformat()
        }


class ConversationContext:
    """Manages conversation context and state."""
    
    def __init__(self, conversation_id: Optional[str] = None):
        self.conversation_id = conversation_id or str(uuid.uuid4())
        self.state = ConversationState.INITIAL_QUERY
        self.messages: List[ConversationMessage] = []
        self.extracted_entities: List[ExtractedEntity] = []
        self.user_profile = UserProfile()
        self.current_query: Optional[str] = None
        self.inferred_intent: Optional[str] = None
        self.delegated_tasks: List[TaskDelegationRecord] = []
        self.context_data: Dict[str, Any] = {}
        self.created_at = datetime.now()
        self.last_updated = datetime.now()
    
    def add_message(self, message_type: MessageType, content: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Add a new message to the conversation."""
        message_id = str(uuid.uuid4())
        message = ConversationMessage(
            message_id=message_id,
            timestamp=datetime.now(),
            message_type=message_type,
            content=content,
            metadata=metadata or {}
        )
        self.messages.append(message)
        self.last_updated = datetime.now()
        return message_id
    
    def get_messages_by_type(self, message_type: MessageType) -> List[ConversationMessage]:
        """Get all messages of a specific type."""
        return [msg for msg in self.messages if msg.message_type == message_type]
    
    def get_recent_messages(self, count: int = 5) -> List[ConversationMessage]:
        """Get the most recent messages."""
        return self.messages[-count:] if len(self.messages) >= count else self.messages
    
    def update_state(self, new_state: ConversationState):
        """Update the conversation state."""
        self.state = new_state
        self.last_updated = datetime.now()
    
    def set_current_query(self, query: str):
        """Set the current query being processed."""
        self.current_query = query
        self.last_updated = datetime.now()
    
    def set_inferred_intent(self, intent: str):
        """Set the inferred intent from the current query."""
        self.inferred_intent = intent
        self.last_updated = datetime.now()
    
    def add_extracted_entity(self, entity_type: str, value: str, confidence: float, source_message_id: str):
        """Add an extracted entity to the context."""
        entity = ExtractedEntity(
            entity_type=entity_type,
            value=value,
            confidence=confidence,
            source_message_id=source_message_id
        )
        self.extracted_entities.append(entity)
        self.last_updated = datetime.now()
    
    def get_entities_by_type(self, entity_type: str) -> List[ExtractedEntity]:
        """Get all extracted entities of a specific type."""
        return [entity for entity in self.extracted_entities if entity.entity_type == entity_type]
    
    def add_delegated_task(self, agent_id: str, task_description: str, input_parameters: Dict[str, Any]) -> str:
        """Add a record of a task delegated to a specialized agent."""
        task_id = str(uuid.uuid4())
        task_record = TaskDelegationRecord(
            task_id=task_id,
            agent_id=agent_id,
            task_description=task_description,
            input_parameters=input_parameters,
            status="pending"
        )
        self.delegated_tasks.append(task_record)
        self.last_updated = datetime.now()
        return task_id
    
    def update_task_status(self, task_id: str, status: str, result: Optional[Dict[str, Any]] = None):
        """Update the status of a delegated task."""
        for task in self.delegated_tasks:
            if task.task_id == task_id:
                task.status = status
                if result:
                    task.result = result
                self.last_updated = datetime.now()
                break
    
    def get_completed_tasks(self) -> List[TaskDelegationRecord]:
        """Get all completed tasks."""
        return [task for task in self.delegated_tasks if task.status == "completed"]
    
    def get_pending_tasks(self) -> List[TaskDelegationRecord]:
        """Get all pending tasks."""
        return [task for task in self.delegated_tasks if task.status in ["pending", "in_progress"]]
    
    def update_user_profile(self, **kwargs):
        """Update user profile information."""
        for key, value in kwargs.items():
            if hasattr(self.user_profile, key):
                setattr(self.user_profile, key, value)
        self.last_updated = datetime.now()
    
    def set_context_data(self, key: str, value: Any):
        """Set context data."""
        self.context_data[key] = value
        self.last_updated = datetime.now()
    
    def get_context_data(self, key: str, default: Any = None) -> Any:
        """Get context data."""
        return self.context_data.get(key, default)
    
    def get_conversation_summary(self) -> Dict[str, Any]:
        """Get a summary of the conversation."""
        return {
            "conversation_id": self.conversation_id,
            "state": self.state.value,
            "message_count": len(self.messages),
            "current_query": self.current_query,
            "inferred_intent": self.inferred_intent,
            "entities_count": len(self.extracted_entities),
            "delegated_tasks_count": len(self.delegated_tasks),
            "completed_tasks_count": len(self.get_completed_tasks()),
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the entire conversation context to dictionary format."""
        return {
            "conversation_id": self.conversation_id,
            "state": self.state.value,
            "messages": [msg.to_dict() for msg in self.messages],
            "extracted_entities": [
                {
                    "entity_type": entity.entity_type,
                    "value": entity.value,
                    "confidence": entity.confidence,
                    "source_message_id": entity.source_message_id
                }
                for entity in self.extracted_entities
            ],
            "user_profile": {
                "user_id": self.user_profile.user_id,
                "risk_tolerance": self.user_profile.risk_tolerance,
                "investment_goals": self.user_profile.investment_goals,
                "time_horizon": self.user_profile.time_horizon,
                "experience_level": self.user_profile.experience_level,
                "preferred_sectors": self.user_profile.preferred_sectors,
                "portfolio_size": self.user_profile.portfolio_size,
                "preferences": self.user_profile.preferences
            },
            "current_query": self.current_query,
            "inferred_intent": self.inferred_intent,
            "delegated_tasks": [task.to_dict() for task in self.delegated_tasks],
            "context_data": self.context_data,
            "created_at": self.created_at.isoformat(),
            "last_updated": self.last_updated.isoformat()
        }
    
    def from_dict(self, data: Dict[str, Any]):
        """Load conversation context from dictionary."""
        self.conversation_id = data["conversation_id"]
        self.state = ConversationState(data["state"])
        self.messages = [ConversationMessage.from_dict(msg_data) for msg_data in data["messages"]]
        
        # Load extracted entities
        self.extracted_entities = []
        for entity_data in data["extracted_entities"]:
            entity = ExtractedEntity(
                entity_type=entity_data["entity_type"],
                value=entity_data["value"],
                confidence=entity_data["confidence"],
                source_message_id=entity_data["source_message_id"]
            )
            self.extracted_entities.append(entity)
        
        # Load user profile
        profile_data = data["user_profile"]
        self.user_profile = UserProfile(
            user_id=profile_data.get("user_id"),
            risk_tolerance=profile_data.get("risk_tolerance"),
            investment_goals=profile_data.get("investment_goals", []),
            time_horizon=profile_data.get("time_horizon"),
            experience_level=profile_data.get("experience_level"),
            preferred_sectors=profile_data.get("preferred_sectors", []),
            portfolio_size=profile_data.get("portfolio_size"),
            preferences=profile_data.get("preferences", {})
        )
        
        self.current_query = data.get("current_query")
        self.inferred_intent = data.get("inferred_intent")
        
        # Load delegated tasks
        self.delegated_tasks = []
        for task_data in data["delegated_tasks"]:
            task = TaskDelegationRecord(
                task_id=task_data["task_id"],
                agent_id=task_data["agent_id"],
                task_description=task_data["task_description"],
                input_parameters=task_data["input_parameters"],
                status=task_data["status"],
                result=task_data.get("result"),
                timestamp=datetime.fromisoformat(task_data["timestamp"])
            )
            self.delegated_tasks.append(task)
        
        self.context_data = data.get("context_data", {})
        self.created_at = datetime.fromisoformat(data["created_at"])
        self.last_updated = datetime.fromisoformat(data["last_updated"])


class ConversationManager:
    """Manages multiple conversation contexts."""
    
    def __init__(self):
        self._conversations: Dict[str, ConversationContext] = {}
    
    def create_conversation(self, conversation_id: Optional[str] = None) -> ConversationContext:
        """Create a new conversation context."""
        context = ConversationContext(conversation_id)
        self._conversations[context.conversation_id] = context
        return context
    
    def get_conversation(self, conversation_id: str) -> Optional[ConversationContext]:
        """Get a conversation context by ID."""
        return self._conversations.get(conversation_id)
    
    def delete_conversation(self, conversation_id: str) -> bool:
        """Delete a conversation context."""
        if conversation_id in self._conversations:
            del self._conversations[conversation_id]
            return True
        return False
    
    def get_all_conversations(self) -> List[ConversationContext]:
        """Get all conversation contexts."""
        return list(self._conversations.values())
    
    def get_active_conversations(self) -> List[ConversationContext]:
        """Get conversations that are not in closure state."""
        return [
            conv for conv in self._conversations.values() 
            if conv.state != ConversationState.CONVERSATION_CLOSURE
        ]


# Global conversation manager instance
conversation_manager = ConversationManager()

