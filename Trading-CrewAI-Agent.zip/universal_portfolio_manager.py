"""
Universal Portfolio Management Integration for All Agents
Provides standardized IBKR-only access to the portfolio for all trading agents.

Paper-trading fallbacks (DirectPortfolioClient, PTAClientTool) have been removed.
IBKR is the sole data source; configure via IB_ENABLED/IB_HOST/IB_PORT env vars.
"""
from typing import Dict, Any, Optional, List, Tuple
import os
import logging

# IBKRPortfolioService is the single broker backend
try:
    from .ibkr_portfolio_service import IBKRPortfolioService, get_ibkr_service
except ImportError:
    try:
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from ibkr_portfolio_service import IBKRPortfolioService, get_ibkr_service  # type: ignore
    except ImportError:
        IBKRPortfolioService = None  # type: ignore
        get_ibkr_service = None  # type: ignore

logger = logging.getLogger(__name__)


class UniversalPortfolioManager:
    """
    IBKR-only portfolio manager for all agents.

    Delegates every operation to IBKRPortfolioService (process singleton).
    Requires IB_ENABLED=1 and a running TWS / IB Gateway instance.
    """

    def __init__(self, agent_name: str = "UnknownAgent"):
        self.agent_name = agent_name
        self.ib_client: Optional[Any] = None

        if get_ibkr_service is not None:
            try:
                self.ib_client = get_ibkr_service()
                if self.ib_client.is_connected():
                    logger.info("%s: IBKRPortfolioService connected", agent_name)
                else:
                    logger.info(
                        "%s: IBKRPortfolioService initialised but not yet connected "
                        "(set IB_ENABLED=1 and start TWS/Gateway)",
                        agent_name,
                    )
            except Exception as exc:
                logger.warning("%s: IBKRPortfolioService init failed: %s", agent_name, exc)
        else:
            logger.warning(
                "%s: IBKRPortfolioService not importable — install ib_insync", agent_name
            )

    def is_available(self) -> bool:
        """Return True if IBKR is connected."""
        if self.ib_client is None:
            return False
        try:
            return bool(self.ib_client.is_connected())
        except Exception:
            return False

    # ========== Portfolio Queries ==========

    def get_holdings(self) -> Dict[str, Any]:
        """Return current holdings and cash from IBKR."""
        if self.ib_client is None:
            return {"error": "IBKRPortfolioService unavailable", "cash": 0, "holdings": []}
        try:
            return self.ib_client.get_holdings()
        except Exception as exc:
            logger.warning("%s: get_holdings failed: %s", self.agent_name, exc)
            return {"error": str(exc), "cash": 0, "holdings": []}

    def get_margins(self) -> Dict[str, Any]:
        """Return margin/buying-power info from IBKR."""
        if self.ib_client is None:
            return {"error": "IBKRPortfolioService unavailable", "available": 0, "used": 0, "net": 0}
        try:
            return self.ib_client.get_margins()
        except Exception as exc:
            logger.warning("%s: get_margins failed: %s", self.agent_name, exc)
            return {"error": str(exc), "available": 0, "used": 0, "net": 0}

    def get_metrics(self) -> Dict[str, Any]:
        """Return portfolio metrics (P&L, net liquidation) from IBKR."""
        if self.ib_client is None:
            return {"error": "IBKRPortfolioService unavailable", "cash": 0, "total_value_est": 0}
        try:
            return self.ib_client.get_metrics()
        except Exception as exc:
            logger.warning("%s: get_metrics failed: %s", self.agent_name, exc)
            return {"error": str(exc), "cash": 0, "total_value_est": 0}

    # ========== Market Data ==========

    def get_last_price(self, symbol: str) -> Optional[float]:
        """Return last market price for a symbol via IB market data."""
        if self.ib_client is None:
            return None
        try:
            data = self.ib_client.get_last_price(symbol)
            price = (data or {}).get("last_price", 0)
            return float(price) if price else None
        except Exception as exc:
            logger.warning("%s: get_last_price(%s) failed: %s", self.agent_name, symbol, exc)
            return None

    # ========== Trading Operations ==========

    def preview_order(self, symbol: str, side: str, quantity: int) -> Dict[str, Any]:
        """Estimate costs for a potential order without placing it."""
        if self.ib_client is None:
            return {"error": "IBKRPortfolioService unavailable"}
        try:
            return self.ib_client.preview_order(symbol, side, quantity)
        except Exception as exc:
            logger.warning("%s: preview_order failed: %s", self.agent_name, exc)
            return {"error": str(exc)}

    def place_order(
        self,
        symbol: str,
        side: str,
        quantity: int,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Place a paper trade order via IBKR (requires IB_ALLOW_TRADES=1)."""
        if self.ib_client is None:
            return {"error": "IBKRPortfolioService unavailable"}
        try:
            return self.ib_client.place_order(symbol, side, quantity, idempotency_key)
        except Exception as exc:
            logger.warning("%s: place_order failed: %s", self.agent_name, exc)
            return {"error": str(exc)}

    def get_orders(self) -> List[Dict[str, Any]]:
        """Return all open / recent orders from IBKR."""
        if self.ib_client is None:
            return [{"error": "IBKRPortfolioService unavailable"}]
        try:
            return self.ib_client.list_orders()
        except Exception as exc:
            logger.warning("%s: get_orders failed: %s", self.agent_name, exc)
            return [{"error": str(exc)}]

    # ========== High-Level Helper Methods ==========

    def get_portfolio_summary(self) -> Dict[str, Any]:
        """Return a comprehensive portfolio summary from IBKR."""
        holdings = self.get_holdings()
        margins = self.get_margins()
        metrics = self.get_metrics()
        return {
            "agent": self.agent_name,
            "broker": "ib",
            "cash": holdings.get("cash", 0),
            "positions_count": len(holdings.get("holdings", [])),
            "holdings": holdings.get("holdings", []),
            "available_margin": margins.get("available", 0),
            "total_value": metrics.get("total_value_est", 0),
            "unrealized_pnl": metrics.get("unrealized_pnl", 0),
            "timestamp": metrics.get("as_of"),
            "status": "error" if "error" in holdings else "ok",
        }

    def can_trade(self, symbol: str, side: str, quantity: int) -> Tuple[bool, str]:
        """Check whether a trade is feasible given current IBKR portfolio state."""
        try:
            preview = self.preview_order(symbol, side, quantity)
            if "error" in preview:
                return False, preview["error"]
            holdings = self.get_holdings()
            cash = holdings.get("cash", 0)
            estimated_total = preview.get("estimated_total", 0)
            if side.lower() == "buy" and cash < estimated_total:
                return False, f"Insufficient cash: {cash:.2f} < {estimated_total:.2f}"
            if side.lower() == "sell":
                pos = next(
                    (h for h in holdings.get("holdings", []) if h["symbol"] == symbol.upper()),
                    None,
                )
                held = pos["quantity"] if pos else 0
                if held < quantity:
                    return False, f"Insufficient position: need {quantity}, have {held}"
            return True, "Trade feasible"
        except Exception as exc:
            return False, f"Trade check failed: {exc}"


# ─────────────────────────────────────────────────────────────────────────────
# Module-level factory (backward-compatible API)
# ─────────────────────────────────────────────────────────────────────────────

_instances: Dict[str, "UniversalPortfolioManager"] = {}


def get_portfolio_manager(agent_name: str = "DefaultAgent") -> "UniversalPortfolioManager":
    """Return a per-agent ``UniversalPortfolioManager`` instance (singleton cache)."""
    if agent_name not in _instances:
        _instances[agent_name] = UniversalPortfolioManager(agent_name)
    return _instances[agent_name]
