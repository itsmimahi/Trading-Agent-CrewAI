"""
Enhanced Base Agent with Full LLM Capabilities using CrewAI Framework
Hybrid Plus Approach: Mathematical Core + LLM Reasoning + Tools + Memory + Knowledge Base
"""
import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
import traceback
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
import json
import sqlite3
from pathlib import Path

# Try to import numpy and pandas, with fallbacks
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False
    pd = None

# LLM and Agent Frameworks
try:
    from crewai import Agent, Task, Crew, Process, LLM
    from crewai.tools import BaseTool
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    Agent = Task = Crew = Process = BaseTool = None

# LangChain imports for LLM and embeddings (optional — wrapped for CrewAI 1.x compatibility)
try:
    from langchain_community.chat_models import AzureChatOpenAI
    from langchain_community.embeddings import HuggingFaceEmbeddings
    from langchain_community.vectorstores import FAISS
    from langchain_community.document_loaders import TextLoader
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    LANGCHAIN_AVAILABLE = True
except (ImportError, Exception):
    LANGCHAIN_AVAILABLE = False
    AzureChatOpenAI = HuggingFaceEmbeddings = FAISS = TextLoader = RecursiveCharacterTextSplitter = None
# Fallback: TF-IDF
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from config.settings import get_settings

logger = logging.getLogger(__name__)

class CustomJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder to handle NumPy and Pandas data types"""
    def default(self, obj):
        # Handle NumPy types if available
        if HAS_NUMPY and np is not None:
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif hasattr(obj, 'item') and callable(getattr(obj, 'item')):  # For numpy scalars
                return obj.item()
        
        # Handle Pandas types if available
        if HAS_PANDAS and pd is not None:
            if isinstance(obj, pd.Series):
                return obj.tolist()
            elif isinstance(obj, pd.DataFrame):
                return obj.to_dict()
        
        # Handle any object with __dict__
        if hasattr(obj, '__dict__'):
            return obj.__dict__
            
        return super(CustomJSONEncoder, self).default(obj)


def safe_json_dumps(data, indent=2):
    """Safely serialize data to JSON string handling numpy/pandas types"""
    try:
        return json.dumps(data, indent=indent, cls=CustomJSONEncoder)
    except (TypeError, ValueError) as e:
        # Fallback: convert problematic types to string
        try:
            # Convert numpy/pandas types to native Python types
            if isinstance(data, dict):
                cleaned_data = {}
                for k, v in data.items():
                    # Handle different data types safely
                    if HAS_NUMPY and np is not None:
                        if isinstance(v, (np.integer, np.int64)):
                            cleaned_data[k] = int(v)
                        elif isinstance(v, (np.floating, np.float64)):
                            cleaned_data[k] = float(v)
                        elif isinstance(v, np.ndarray):
                            cleaned_data[k] = v.tolist()
                        else:
                            cleaned_data[k] = v
                    else:
                        cleaned_data[k] = v
                    
                    if HAS_PANDAS and pd is not None:
                        if isinstance(v, pd.Series):
                            cleaned_data[k] = v.tolist()
                        elif isinstance(v, pd.DataFrame):
                            cleaned_data[k] = v.to_dict()
                
                return json.dumps(cleaned_data, indent=indent)
            else:
                return json.dumps(str(data), indent=indent)
        except Exception:
            return json.dumps({"serialization_error": "Could not serialize data", "data_type": str(type(data))}, indent=indent)

class AgentCapability(Enum):
    """Agent capabilities for dynamic task assignment"""
    MATHEMATICAL_ANALYSIS = "mathematical_analysis"
    PATTERN_RECOGNITION = "pattern_recognition"
    NATURAL_LANGUAGE_PROCESSING = "natural_language_processing"
    DATA_INTERPRETATION = "data_interpretation"
    CONTEXTUAL_REASONING = "contextual_reasoning"
    RISK_ASSESSMENT = "risk_assessment"
    TREND_ANALYSIS = "trend_analysis"

@dataclass
class AgentMemory:
    """Agent memory structure for learning and context"""
    short_term: List[Dict[str, Any]] = field(default_factory=list)
    long_term: Dict[str, Any] = field(default_factory=dict)
    experiences: List[Dict[str, Any]] = field(default_factory=list)
    patterns: Dict[str, Any] = field(default_factory=dict)
    performance_metrics: Dict[str, float] = field(default_factory=dict)

@dataclass
class AgentTool:
    """Agent tool definition"""
    name: str
    description: str
    function: callable
    parameters: Dict[str, Any] = field(default_factory=dict)


class KnowledgeBase:
    """Agent knowledge base with vector storage and retrieval, with fallback to TF-IDF."""

    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.kb_path = Path(f"data/knowledge_base/{agent_name}")
        self.kb_path.mkdir(parents=True, exist_ok=True)
        self.use_transformer = False
        self.vector_store = None
        self.tfidf_vectorizer = None
        self.tfidf_matrix = None
        self.tfidf_texts = []

        # Try to use HuggingFace embeddings
        try:
            self.embeddings = HuggingFaceEmbeddings(
                model_name=r"C:\Users\MWanve\OneDrive - CBRE, Inc\Desktop\Trading-CrewAI-Agent\hf_models\all-mpneet-base-v2"
            )
            self.use_transformer = True
        except Exception as e:
            logger.warning(f"Could not load HuggingFace embeddings, falling back to TF-IDF: {e}")
            self.embeddings = None
            self.use_transformer = False

        self._load_knowledge_base()

    def _load_knowledge_base(self):
        """Load existing knowledge base or create new one"""
        if self.use_transformer:
            try:
                kb_file = self.kb_path / "knowledge_base.index"
                if kb_file.exists():
                    self.vector_store = FAISS.load_local(
                        str(kb_file.parent),
                        self.embeddings,
                        index_name="knowledge_base"
                    )
                else:
                    self.vector_store = FAISS.from_texts(
                        ["Agent knowledge base initialized"],
                        self.embeddings
                    )
                    self.save_knowledge_base()
            except Exception as e:
                logger.error(f"Error loading transformer knowledge base: {e}")
                self.use_transformer = False

        if not self.use_transformer:
            # Initialize empty TF-IDF store
            self.tfidf_vectorizer = TfidfVectorizer()
            self.tfidf_texts = ["Agent knowledge base initialized"]
            self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(self.tfidf_texts)

    def add_knowledge(self, texts: List[str], metadatas: List[Dict] = None):
        """Add new knowledge to the knowledge base"""
        if self.use_transformer and self.vector_store:
            self.vector_store.add_texts(texts, metadatas=metadatas)
            self.save_knowledge_base()
        else:
            # Add to TF-IDF store
            self.tfidf_texts.extend(texts)
            self.tfidf_matrix = self.tfidf_vectorizer.fit_transform(self.tfidf_texts)

    def query_knowledge(self, query: str, k: int = 3) -> List[str]:
        """Query knowledge base for relevant information"""
        if self.use_transformer and self.vector_store:
            docs = self.vector_store.similarity_search(query, k=k)
            return [doc.page_content for doc in docs]
        else:
            # TF-IDF fallback
            query_vec = self.tfidf_vectorizer.transform([query])
            similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
            top_indices = similarities.argsort()[-k:][::-1]
            return [self.tfidf_texts[i] for i in top_indices]

    def save_knowledge_base(self):
        """Save knowledge base to disk (only for transformer/FAISS)"""
        if self.use_transformer and self.vector_store:
            self.vector_store.save_local(
                str(self.kb_path),
                index_name="knowledge_base"
            )

class EnhancedBaseAgent(ABC):
    """
    Base class for all enhanced agents in the system using CrewAI framework.
    Provides core functionalities like LLM interaction, memory, tools, and knowledge base.
    """
    # --- LLM/memory stub methods for subclasses ---
    async def _get_llm_response(self, prompt: str, context: str = None) -> dict:
        """Get LLM response using CrewAI framework with standardized handling across all agents. Always returns a dict. Robust error handling and logging."""
        try:
            if not self.use_llm:
                self.logger.error(f"[{self.name}] LLM not available for prompt: {prompt[:100]}")
                return {"error": "LLM not available"}

            if not CREWAI_AVAILABLE:
                self.logger.error(f"[{self.name}] CrewAI not available for prompt: {prompt[:100]}")
                return {"error": "CrewAI not available"}

            if not hasattr(self, 'crewai_agent') or self.crewai_agent is None:
                self.logger.warning(f"[{self.name}] CrewAI agent not initialized, attempting initialization...")
                self._initialize_crewai_agent()
                if not hasattr(self, 'crewai_agent') or self.crewai_agent is None:
                    self.logger.error(f"[{self.name}] CrewAI agent initialization failed for prompt: {prompt[:100]}")
                    return {"error": "CrewAI agent initialization failed"}

            # Format prompt with context if provided
            formatted_prompt = f"Context: {context}\n\n{prompt}" if context else prompt

            # Use CrewAI agent to get response
            try:
                task = Task(
                    description=formatted_prompt,
                    agent=self.crewai_agent,
                    expected_output="Comprehensive analysis and insights"
                )
                
                crew = Crew(
                    agents=[self.crewai_agent],
                    tasks=[task],
                    process=Process.sequential,
                    verbose=False
                )
                
                result = crew.kickoff()
                if isinstance(result, str) and result.strip():
                    return {"response": result}
                else:
                    self.logger.warning(f"[{self.name}] CrewAI returned empty or non-string response for prompt: {prompt[:100]}")
                    
            except Exception as e:
                self.logger.error(f"[{self.name}] Error in CrewAI agent execution: {e}\nPrompt: {prompt[:100]}\nContext: {context}", exc_info=True)

            # Fallback to direct Azure OpenAI call if CrewAI fails
            try:
                from openai import AsyncAzureOpenAI
                client = AsyncAzureOpenAI(
                    api_key=self.settings.ai.azure_openai_api_key,
                    azure_endpoint=self.settings.ai.azure_openai_endpoint,
                    api_version=self.settings.ai.azure_openai_api_version
                )
                chat_response = await client.chat.completions.create(
                    model=self.settings.ai.azure_openai_deployment,
                    messages=[
                        {"role": "system", "content": f"You are {self.name}, an AI agent specializing in {self.description}"},
                        {"role": "user", "content": formatted_prompt}
                    ]
                )
                # Defensive: check structure
                content = None
                try:
                    content = chat_response.choices[0].message.content
                except Exception as e:
                    self.logger.error(f"[{self.name}] AzureOpenAI response structure error: {e}")
                if content and isinstance(content, str):
                    return {"response": content}
                else:
                    self.logger.error(f"[{self.name}] AzureOpenAI returned no content for prompt: {prompt[:100]}")
            except Exception as e:
                self.logger.error(f"[{self.name}] Error in AzureOpenAI direct call: {e}\nPrompt: {prompt[:100]}\nContext: {context}", exc_info=True)

            # If all fail, return error
            self.logger.error(f"[{self.name}] All LLM response methods failed for prompt: {prompt[:100]}")
            return {"error": "All LLM response methods failed"}
        except Exception as e:
            self.logger.error(f"[{self.name}] Fatal error in _get_llm_response: {e}\nPrompt: {prompt[:100]}\nContext: {context}", exc_info=True)
            return {"error": f"Error in LLM response: {str(e)}"}

    async def _store_analysis_in_memory(self, analysis_data=None, symbol=None, *args, **kwargs):
        """Stub for storing analysis in memory. Provides basic implementation with optional override."""
        if analysis_data and self.use_memory:
            try:
                # Basic memory storage implementation
                memory_entry = {
                    "timestamp": datetime.now().isoformat(),
                    "symbol": symbol,
                    "analysis": analysis_data,
                    "agent": self.name
                }
                self.agent_memory.short_term.append(memory_entry)
                
                # Keep only recent entries (last 50)
                if len(self.agent_memory.short_term) > 50:
                    self.agent_memory.short_term = self.agent_memory.short_term[-50:]
                
                # Save to disk
                self._save_memory()
                return True
            except Exception as e:
                self.logger.error(f"Error storing analysis in memory for {self.name}: {e}")
                return False
        elif not analysis_data:
            # Only log debug message if no data provided
            self.logger.debug(f"_store_analysis_in_memory called on {self.name} with no data.")
        return None


    """
    Enhanced Base Agent with Full LLM Capabilities using CrewAI Framework
    Implements Hybrid Plus Approach: Math + LLM + Tools + Memory + KB
    """
    
    def __init__(
        self,
        name: str,
        description: str,
        capabilities: List[AgentCapability],
        weight: float = 1.0,
        use_llm: bool = True,
        use_memory: bool = True,
        use_knowledge_base: bool = True,
        role: Optional[str] = None,
        goal: Optional[str] = None,
        backstory: Optional[str] = None,
        **kwargs
    ):
        self.name: str = name
        self.description: str = description
        self.capabilities = capabilities
        self.weight = weight
        self.use_llm = use_llm
        self.use_memory = use_memory
        self.use_knowledge_base = use_knowledge_base
        self.role = role if role is not None else name
        self.goal = goal if goal is not None else ""
        self.backstory = backstory if backstory is not None else ""
        
        self.settings = get_settings()

        # Initialize logger
        self.logger = logging.getLogger(f"{__name__}.{self.name}")

        # Initialize tools
        self.tools: List[AgentTool] = []
        self._initialize_tools()

        # Initialize CrewAI agent
        if self.use_llm and CREWAI_AVAILABLE:
            self._initialize_crewai_agent()

        # Initialize memory
        if self.use_memory:
            self._initialize_memory()

        # Initialize knowledge base
        if self.use_knowledge_base:
            self.knowledge_base = KnowledgeBase(self.name)

        # Performance tracking
        self.performance_history = []
        self.last_analysis_time = None
        
    def _initialize_crewai_agent(self):
        """Initialize CrewAI agent with Azure OpenAI LLM"""
        try:
            # Create Azure OpenAI LLM
            # self.azure_llm = AzureChatOpenAI(
            #     azure_endpoint=self.settings.ai.azure_openai_endpoint,
            #     openai_api_key=self.settings.ai.azure_openai_api_key,
            #     openai_api_version=self.settings.ai.azure_openai_api_version,
            #     deployment_name=self.settings.ai.azure_openai_deployment,
            #     temperature=0.1,
            #     max_tokens=2000
            # )
            
            self.llm = LLM(
                model=self.settings.ai.azure_openai_deployment,  
                azure=True,
                base_url=self.settings.ai.azure_openai_endpoint,
                api_key=self.settings.ai.azure_openai_api_key,
                api_version=self.settings.ai.azure_openai_api_version,
                temperature=0.1,
                max_tokens=2000
            )
            
            # Convert tools to CrewAI format
            crewai_tools = self._convert_tools_to_crewai()
            
            # Create CrewAI agent
            self.crewai_agent = Agent(
                role=self.role,
                goal=self.goal,
                backstory=self.backstory,
                tools=crewai_tools,
                llm=self.llm,
                allow_delegation=True,
                verbose=False
            )
            
            self.logger.info(f"Successfully initialized CrewAI agent: {self.name}")
            
        except Exception as e:
            self.logger.error(f"Error initializing CrewAI agent for {self.name}: {e}")
            self.use_llm = False

    def _convert_tools_to_crewai(self) -> List[BaseTool]:
        """Convert agent tools to CrewAI BaseTool format"""
        crewai_tools = []
        
        for tool in self.tools:
            if hasattr(tool, 'name') and hasattr(tool, 'function'):
                # Convert AgentTool dataclass to CrewAI BaseTool
                crewai_tool = self._create_crewai_tool(tool)
                crewai_tools.append(crewai_tool)
        
        return crewai_tools

    def _create_crewai_tool(self, agent_tool) -> BaseTool:
        """Create CrewAI BaseTool from AgentTool"""
        class CrewAITool(BaseTool):
            name: str = agent_tool.name
            description: str = agent_tool.description
            
            def _run(self, **kwargs):
                return agent_tool.function(**kwargs)
        
        return CrewAITool()
    
    def _initialize_memory(self):
        """Initialize agent memory systems"""
        try:
            # Custom agent memory (keeping existing structure)
            self.agent_memory = AgentMemory()
            
            # Load existing memory from disk
            self._load_memory()
            
        except Exception as e:
            self.logger.error(f"Error initializing memory for {self.name}: {e}")
            self.use_memory = False
    
    def _initialize_tools(self):
        """Initialize agent tools - to be overridden by subclasses"""
        # Base tools available to all agents
        self.tools.extend([
            AgentTool(
                name="calculate_percentage_change",
                description="Calculate percentage change between two values",
                function=self._calculate_percentage_change
            ),
            AgentTool(
                name="analyze_trend",
                description="Analyze trend direction and strength",
                function=self._analyze_trend
            ),
            AgentTool(
                name="assess_confidence",
                description="Assess confidence level in analysis",
                function=self._assess_confidence
            )
        ])
    

    
    # Core mathematical computation methods
    def _calculate_percentage_change(self, old_value: float, new_value: float) -> float:
        """Calculate percentage change between two values"""
        if old_value == 0:
            return 0
        return ((new_value - old_value) / old_value) * 100
    
    def _analyze_trend(self, values: List[float]) -> Dict[str, Any]:
        """Analyze trend direction and strength"""
        if len(values) < 2:
            return {"direction": "neutral", "strength": 0}
        
        # Calculate simple trend
        first_half = sum(values[:len(values)//2]) / (len(values)//2)
        second_half = sum(values[len(values)//2:]) / (len(values) - len(values)//2)
        
        change = (second_half - first_half) / first_half * 100
        
        if change > 2:
            direction = "upward"
        elif change < -2:
            direction = "downward"
        else:
            direction = "neutral"
        
        strength = min(abs(change) / 10, 1.0)  # Normalize to 0-1
        
        return {
            "direction": direction,
            "strength": strength,
            "change_percentage": change
        }
    
    def _assess_confidence(self, analysis_results: Dict[str, Any]) -> float:
        """Assess confidence level in analysis results"""
        # Base confidence assessment - to be overridden by subclasses
        factors = []
        
        if "data_quality" in analysis_results:
            factors.append(analysis_results["data_quality"])
        
        if "signal_strength" in analysis_results:
            factors.append(analysis_results["signal_strength"])
        
        if "market_conditions" in analysis_results:
            factors.append(analysis_results["market_conditions"])
        
        if factors:
            return sum(factors) / len(factors)
        return 0.5  # Default neutral confidence
    
    # Memory management methods
    def _load_memory(self):
        """Load agent memory from disk"""
        try:
            memory_file = Path(f"data/memory/{self.name}_memory.json")
            if memory_file.exists():
                with open(memory_file, 'r') as f:
                    memory_data = json.load(f)
                    self.agent_memory.long_term = memory_data.get("long_term", {})
                    self.agent_memory.patterns = memory_data.get("patterns", {})
                    self.agent_memory.performance_metrics = memory_data.get("performance_metrics", {})
        except Exception as e:
            self.logger.error(f"Error loading memory for {self.name}: {e}")
    
    def _save_memory(self):
        """Save agent memory to disk"""
        try:
            memory_file = Path(f"data/memory/{self.name}_memory.json")
            memory_file.parent.mkdir(parents=True, exist_ok=True)
            
            memory_data = {
                "long_term": self.agent_memory.long_term,
                "patterns": self.agent_memory.patterns,
                "performance_metrics": self.agent_memory.performance_metrics,
                "last_updated": datetime.now().isoformat()
            }
            
            # Use safe JSON dumps to handle any numpy/pandas types
            with open(memory_file, 'w') as f:
                json.dump(memory_data, f, indent=2, cls=CustomJSONEncoder)
                
        except Exception as e:
            self.logger.error(f"Error saving memory for {self.name}: {e}")
            # Try fallback without custom encoder
            try:
                with open(memory_file, 'w') as f:
                    # Convert any problematic types to strings
                    safe_memory_data = {
                        "long_term": {},
                        "patterns": {},
                        "performance_metrics": {},
                        "last_updated": datetime.now().isoformat(),
                        "error": "Memory data converted due to serialization issues"
                    }
                    json.dump(safe_memory_data, f, indent=2)
            except Exception:
                pass  # If even fallback fails, just continue
    
    def add_experience(self, experience: Dict[str, Any]):
        """Add learning experience to agent memory"""
        if self.use_memory:
            self.agent_memory.experiences.append({
                "timestamp": datetime.now().isoformat(),
                "experience": experience
            })
            
            # Keep only recent experiences
            if len(self.agent_memory.experiences) > 100:
                self.agent_memory.experiences = self.agent_memory.experiences[-100:]
            
            self._save_memory()
    
    def get_relevant_experiences(self, context: str) -> List[Dict[str, Any]]:
        """Get relevant experiences based on context"""
        if not self.use_memory:
            return []
        
        # Simple relevance matching - can be enhanced with embeddings
        relevant = []
        for exp in self.agent_memory.experiences:
            if any(keyword in str(exp).lower() for keyword in context.lower().split()):
                relevant.append(exp)
        
        return relevant[-5:]  # Return last 5 relevant experiences
    
    # LLM-powered analysis methods using CrewAI
    async def llm_analyze(self, data: Dict[str, Any], context: str, question: str) -> Dict[str, Any]:
        """Use CrewAI agent for complex analysis and interpretation"""
        if not self.use_llm or not CREWAI_AVAILABLE or not hasattr(self, 'crewai_agent') or self.crewai_agent is None:
            return {"error": "CrewAI agent not available"}
        
        try:
            # Get relevant knowledge
            relevant_knowledge = []
            if self.use_knowledge_base:
                relevant_knowledge = self.knowledge_base.query_knowledge(question)
            
            # Prepare context with knowledge
            enhanced_context = f"{context}\n\nRelevant Knowledge:\n" + "\n".join(relevant_knowledge)
            
            # Safely serialize data to JSON
            data_json = safe_json_dumps(data)
            
            # Create analysis prompt
            analysis_prompt = f"""
            You are an expert {self.description} in financial markets with deep analytical capabilities.
            
            Context: {enhanced_context}
            Market Data: {data_json}
            Analysis Question: {question}
            
            Please provide a comprehensive analysis that includes:
            1. Key observations from the data
            2. Contextual interpretation considering market conditions
            3. Potential risks and opportunities
            4. Confidence level in your analysis
            5. Actionable insights
            
            Be precise, data-driven, and provide reasoning for your conclusions.
            """
            
            # Use CrewAI agent for analysis
            task = Task(
                description=analysis_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive analysis with actionable insights"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            return {
                "analysis": str(result),
                "confidence": self._assess_confidence(data),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI analysis for {self.name}: {e}")
            return {"error": str(e)}
    
    async def llm_reason(self, mathematical_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Use CrewAI agent for reasoning about mathematical results"""
        if not self.use_llm or not CREWAI_AVAILABLE or not hasattr(self, 'crewai_agent') or self.crewai_agent is None:
            return {"error": "CrewAI agent not available"}
        
        try:
            # Get historical patterns
            historical_patterns = self.agent_memory.patterns if self.use_memory else {}
            
            # Safely serialize data to JSON
            mathematical_results_json = safe_json_dumps(mathematical_results)
            historical_patterns_json = safe_json_dumps(historical_patterns)
            
            # Create reasoning prompt
            reasoning_prompt = f"""
            You are an expert {self.description} tasked with interpreting mathematical analysis results in market context.
            
            Mathematical Results: {mathematical_results_json}
            Market Context: {market_context}
            Historical Patterns: {historical_patterns_json}
            
            Please provide intelligent reasoning that:
            1. Interprets the mathematical results in current market context
            2. Identifies patterns and anomalies
            3. Assesses reliability and confidence levels
            4. Suggests adaptive strategies based on market regime
            5. Provides forward-looking insights
            
            Focus on actionable intelligence that combines quantitative precision with contextual understanding.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Intelligent reasoning and forward-looking insights"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            return {
                "reasoning": str(result),
                "confidence": self._assess_confidence(mathematical_results),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI reasoning for {self.name}: {e}")
            return {"error": str(e)}
    
    # Abstract methods to be implemented by subclasses
    @abstractmethod
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Perform mathematical/quantitative analysis - implemented by subclasses"""
        pass
    
    @abstractmethod
    async def analyze(self, symbol: str, timeframe: str = "1d") -> Dict[str, Any]:
        """Main analysis method combining math and LLM - implemented by subclasses"""
        pass
    
    # === A2A Communication Methods ===
    async def handle_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle incoming A2A messages from other agents.
        This is the main entry point for agent-to-agent communication.
        """
        try:
            message_type = message.get("type", "request")
            action = message.get("action", "analyze")
            data = message.get("data", {})
            from_agent = message.get("from", "unknown")
            
            self.logger.info(f"[{self.name}] Received {message_type} from {from_agent}: {action}")
            
            # Handle different message types
            if message_type == "request":
                return await self._handle_request(action, data, from_agent)
            elif message_type == "notification":
                return await self._handle_notification(action, data, from_agent)
            elif message_type == "broadcast":
                return await self._handle_broadcast(action, data, from_agent)
            else:
                return {
                    "success": False,
                    "error": f"Unsupported message type: {message_type}",
                    "agent": self.name
                }
                
        except Exception as e:
            self.logger.error(f"[{self.name}] Error handling message: {e}")
            return {
                "success": False,
                "error": str(e),
                "agent": self.name
            }
    
    async def _handle_request(self, action: str, data: Dict[str, Any], from_agent: str) -> Dict[str, Any]:
        """Handle request messages from other agents"""
        try:
            # Route to appropriate method based on action
            if action == "analyze" or action == "process_query":
                # Extract symbol and other parameters
                symbol = data.get("symbol", data.get("query", ""))
                timeframe = data.get("timeframe", "1d")
                
                # If query contains a symbol, extract it
                if "symbol" not in data and "query" in data:
                    query = data["query"].upper()
                    # Simple symbol extraction - look for common patterns
                    import re
                    symbol_match = re.search(r'\b([A-Z]{1,5})\b', query)
                    if symbol_match:
                        symbol = symbol_match.group(1)
                    else:
                        symbol = "SPY"  # Default symbol
                
                # Perform analysis
                result = await self.analyze(symbol=symbol, timeframe=timeframe)
                
                return {
                    "success": True,
                    "response": result,
                    "agent": self.name,
                    "action": action,
                    "symbol": symbol
                }
                
            elif action == "get_capabilities":
                return {
                    "success": True,
                    "response": {
                        "capabilities": self.get_capabilities(),
                        "description": self.description,
                        "weight": self.weight
                    },
                    "agent": self.name,
                    "action": action
                }
                
            elif action == "get_performance":
                return {
                    "success": True,
                    "response": self.get_performance_metrics(),
                    "agent": self.name,
                    "action": action
                }
                
            elif action == "ping":
                return {
                    "success": True,
                    "response": "pong",
                    "agent": self.name,
                    "action": action,
                    "timestamp": datetime.now().isoformat()
                }
                
            else:
                # Try to call method directly if it exists
                if hasattr(self, action):
                    method = getattr(self, action)
                    if asyncio.iscoroutinefunction(method):
                        result = await method(**data)
                    else:
                        result = method(**data)
                    
                    return {
                        "success": True,
                        "response": result,
                        "agent": self.name,
                        "action": action
                    }
                else:
                    return {
                        "success": False,
                        "error": f"Unknown action: {action}",
                        "agent": self.name,
                        "action": action
                    }
                    
        except Exception as e:
            self.logger.error(f"[{self.name}] Error handling request {action}: {e}")
            return {
                "success": False,
                "error": str(e),
                "agent": self.name,
                "action": action
            }
    
    async def _handle_notification(self, action: str, data: Dict[str, Any], from_agent: str) -> Dict[str, Any]:
        """Handle notification messages (one-way, no response expected)"""
        try:
            self.logger.info(f"[{self.name}] Received notification from {from_agent}: {action}")
            
            # Store notification in memory if enabled
            if self.use_memory:
                notification_entry = {
                    "type": "notification",
                    "from": from_agent,
                    "action": action,
                    "data": data,
                    "timestamp": datetime.now().isoformat()
                }
                self.agent_memory.experiences.append(notification_entry)
                self._save_memory()
            
            return {
                "success": True,
                "response": "notification_received",
                "agent": self.name
            }
            
        except Exception as e:
            self.logger.error(f"[{self.name}] Error handling notification: {e}")
            return {
                "success": False,
                "error": str(e),
                "agent": self.name
            }
    
    async def _handle_broadcast(self, action: str, data: Dict[str, Any], from_agent: str) -> Dict[str, Any]:
        """Handle broadcast messages (sent to multiple agents)"""
        try:
            self.logger.info(f"[{self.name}] Received broadcast from {from_agent}: {action}")
            
            # Store broadcast in memory if enabled
            if self.use_memory:
                broadcast_entry = {
                    "type": "broadcast",
                    "from": from_agent,
                    "action": action,
                    "data": data,
                    "timestamp": datetime.now().isoformat()
                }
                self.agent_memory.experiences.append(broadcast_entry)
                self._save_memory()
            
            # Some broadcasts might require analysis response
            if action == "market_update" or action == "analyze_broadcast":
                symbol = data.get("symbol", "SPY")
                result = await self.analyze(symbol=symbol)
                return {
                    "success": True,
                    "response": result,
                    "agent": self.name,
                    "action": action
                }
            else:
                return {
                    "success": True,
                    "response": "broadcast_received",
                    "agent": self.name
                }
                
        except Exception as e:
            self.logger.error(f"[{self.name}] Error handling broadcast: {e}")
            return {
                "success": False,
                "error": str(e),
                "agent": self.name
            }
    
    def register_with_registry(self, registry, agent_type: str = None, endpoint: str = ""):
        """
        Register this agent with the agent registry for A2A communication.
        """
        try:
            from mcp_servers.base_server import AgentInfo
            
            agent_info = AgentInfo(
                id=self.name,
                name=self.name,
                type=agent_type or self.__class__.__name__,
                capabilities=self.get_capabilities(),
                status="active",
                last_heartbeat=datetime.now(),
                endpoint=endpoint
            )
            
            # Add reference to this agent instance
            agent_info.instance = self
            
            success = registry.register_agent(agent_info)
            if success:
                self.logger.info(f"[{self.name}] Successfully registered with agent registry")
            else:
                self.logger.error(f"[{self.name}] Failed to register with agent registry")
                
            return success
            
        except Exception as e:
            self.logger.error(f"[{self.name}] Error registering with registry: {e}")
            return False
    



    
    # Utility methods
    def get_capabilities(self) -> List[str]:
        """Get agent capabilities"""
        return [cap.value for cap in self.capabilities]
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get agent performance metrics"""
        try:
            # Safe knowledge base size calculation
            kb_size = 0
            if self.use_knowledge_base and hasattr(self, 'knowledge_base'):
                try:
                    if self.knowledge_base.use_transformer and self.knowledge_base.vector_store:
                        if hasattr(self.knowledge_base.vector_store, 'docstore') and hasattr(self.knowledge_base.vector_store.docstore, '_dict'):
                            kb_size = len(self.knowledge_base.vector_store.docstore._dict)
                    else:
                        kb_size = len(self.knowledge_base.tfidf_texts) if self.knowledge_base.tfidf_texts else 0
                except Exception:
                    kb_size = 0
            
            return {
                "weight": self.weight,
                "capabilities": self.get_capabilities(),
                "performance_history": self.performance_history[-10:],  # Last 10 records
                "memory_usage": len(self.agent_memory.experiences) if self.use_memory else 0,
                "knowledge_base_size": kb_size,
                "crewai_available": CREWAI_AVAILABLE
            }
        except Exception as e:
            self.logger.error(f"Error getting performance metrics for {self.name}: {e}")
            return {
                "weight": self.weight,
                "capabilities": self.get_capabilities(),
                "performance_history": [],
                "memory_usage": 0,
                "knowledge_base_size": 0,
                "crewai_available": CREWAI_AVAILABLE
            }
    
    def update_performance(self, metrics: Dict[str, Any]):
        """Update agent performance metrics"""
        self.performance_history.append({
            "timestamp": datetime.now().isoformat(),
            "metrics": metrics
        })
        
        # Update memory with performance data
        if self.use_memory:
            self.agent_memory.performance_metrics.update(metrics)
            self._save_memory()
    
    def __str__(self) -> str:
        return f"Agent({self.name}, {self.description})"
    
    def __repr__(self) -> str:
        return f"Agent(name='{self.name}', capabilities={self.get_capabilities()})"
