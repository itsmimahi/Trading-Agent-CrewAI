"""
Lightweight compatibility endpoints for the CrewAI RL bridge HTTP fallback.
Exposes:
- GET /api/learning_insights
- GET /api/insights   (alias)
- GET /api/get_weight_updates

These are minimal shims so upstream components don't 404 when the full RL stack
isn't providing these routes. Replace implementations with real logic as needed.
"""
from flask import Blueprint, jsonify
from datetime import datetime

bridge_api = Blueprint('bridge_api', __name__, url_prefix='/api')

@bridge_api.route('/learning_insights', methods=['GET'])
def learning_insights():
    # TODO: Replace with real insights pulled from RL agent state
    return jsonify({
        'source': 'bridge_api',
        'available': True,
        'insights': [],
        'summary': 'No insights available yet',
        'timestamp': datetime.utcnow().isoformat() + 'Z'
    })

@bridge_api.route('/insights', methods=['GET'])
def insights_alias():
    # Alias to support older clients
    return learning_insights()

@bridge_api.route('/get_weight_updates', methods=['GET'])
def get_weight_updates():
    # TODO: Replace with real dynamic weights if available
    # Returning has_updates=False avoids forcing defaults silently
    return jsonify({
        'has_updates': False,
        'agent_weights': {},
        'confidence': 0.0,
        'reasoning': 'No updates available',
        'timestamp': datetime.utcnow().isoformat() + 'Z'
    })
