import uuid
from datetime import datetime
from typing import Any, Dict

from flask import Blueprint, request, jsonify
from sqlalchemy import Column, String, DateTime, Text
from sqlalchemy.dialects.sqlite import JSON as SQLiteJSON

from user import db
from integration.event_bus import make_default_event_bus


class ApprovalRequest(db.Model):
    __tablename__ = 'approval_requests'
    id = Column(String, primary_key=True)
    correlation_id = Column(String, index=True, nullable=True)
    reply_to = Column(String, nullable=True)
    type = Column(String, nullable=False)
    summary = Column(String, nullable=True)
    payload = Column(SQLiteJSON, nullable=False)
    status = Column(String, default='pending')  # pending | approved | rejected
    decision = Column(String, nullable=True)
    approver = Column(String, nullable=True)
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    decided_at = Column(DateTime, nullable=True)


approvals_bp = Blueprint('approvals', __name__)


@approvals_bp.route('/api/approvals', methods=['POST'])
def create_approval():
    data = request.get_json(force=True, silent=True) or {}
    appr = ApprovalRequest(
        id=str(uuid.uuid4()),
        correlation_id=data.get('correlation_id'),
        reply_to=data.get('reply_to'),
        type=data.get('type') or 'generic',
        summary=data.get('summary'),
        payload=data.get('payload') or {},
        status='pending',
    )
    db.session.add(appr)
    db.session.commit()
    return jsonify({
        'id': appr.id,
        'status': appr.status,
        'correlation_id': appr.correlation_id,
        'reply_to': appr.reply_to,
        'type': appr.type,
        'summary': appr.summary,
        'created_at': appr.created_at.isoformat(),
    }), 201


@approvals_bp.route('/api/approvals', methods=['GET'])
def list_approvals():
    items = ApprovalRequest.query.order_by(ApprovalRequest.created_at.desc()).limit(200).all()
    return jsonify([
        {
            'id': i.id,
            'status': i.status,
            'summary': i.summary,
            'type': i.type,
            'created_at': i.created_at.isoformat(),
            'decided_at': i.decided_at.isoformat() if i.decided_at else None,
        } for i in items
    ])


@approvals_bp.route('/api/approvals/<id>', methods=['GET'])
def get_approval(id: str):
    i = ApprovalRequest.query.get_or_404(id)
    return jsonify({
        'id': i.id,
        'status': i.status,
        'summary': i.summary,
        'type': i.type,
        'payload': i.payload,
        'correlation_id': i.correlation_id,
        'reply_to': i.reply_to,
        'approver': i.approver,
        'reason': i.reason,
        'decision': i.decision,
        'created_at': i.created_at.isoformat(),
        'decided_at': i.decided_at.isoformat() if i.decided_at else None,
    })


@approvals_bp.route('/api/approvals/<id>/decision', methods=['POST'])
def decide_approval(id: str):
    data = request.get_json(force=True, silent=True) or {}
    approve = bool(data.get('approved'))
    reason = data.get('reason')
    approver = data.get('approver', 'UI')
    i = ApprovalRequest.query.get_or_404(id)
    i.status = 'approved' if approve else 'rejected'
    i.decision = i.status
    i.approver = approver
    i.reason = reason
    i.decided_at = datetime.utcnow()
    db.session.add(i)
    db.session.commit()

    # If reply_to present, publish decision
    try:
        if i.reply_to:
            bus = make_default_event_bus()
            bus.publish(i.reply_to, {
                'approved': approve,
                'approver': approver,
                'reason': reason,
                'correlation_id': i.correlation_id,
            })
    except Exception:
        pass

    return jsonify({'id': i.id, 'status': i.status}), 200


def create_ui_approval(summary: str, payload: Dict[str, Any], *, correlation_id: str | None, reply_to: str | None) -> Dict[str, Any]:
    appr = ApprovalRequest(
        id=str(uuid.uuid4()),
        correlation_id=correlation_id,
        reply_to=reply_to,
        type='ui',
        summary=summary,
        payload=payload,
        status='pending',
    )
    db.session.add(appr)
    db.session.commit()
    return {'id': appr.id, 'status': appr.status, 'summary': appr.summary}
