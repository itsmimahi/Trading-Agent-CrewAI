import os
import threading
from typing import Optional, Dict, Any
from getpass import getpass

from .base import MarketDataAdapter

try:
    # Shoonya/Finvasia Noren API
    from NorenRestApiPy.NorenApi import NorenApi as ShoonyaApi  # type: ignore
except Exception:
    ShoonyaApi = None  # type: ignore

# Optional pyotp for dynamic TOTP generation from base32 secret
try:
    import pyotp  # type: ignore
    _pyotp_available = True
except Exception:
    pyotp = None  # type: ignore
    _pyotp_available = False


class ShoonyaAdapter(MarketDataAdapter):
    name = "SHOONYA"

    def __init__(self) -> None:
        # Env creds (placeholders supported). Real login may require all fields.
        self.user = os.getenv("SHOONYA_USER", "")
        self.password = os.getenv("SHOONYA_PASSWORD", "")
        # 2FA options
        self.static_totp = os.getenv("SHOONYA_TOTP", "")
        self.totp_secret = os.getenv("SHOONYA_TOTP_SECRET", "")
        self.totp_prompt = (os.getenv("SHOONYA_TOTP_PROMPT") or "false").strip().lower() in {"1", "true", "yes", "y"}
        self.vendor_code = os.getenv("SHOONYA_VENDOR_CODE", "")
        self.api_key = os.getenv("SHOONYA_API_KEY", "")  # app key / api secret
        self.imei = os.getenv("SHOONYA_IMEI", "")

        # Endpoints (only api.shoonya.com) based on SHOONYA_ENV
        env_mode = (os.getenv("SHOONYA_ENV") or "paper").strip().lower()
        if env_mode == "live":
            self._host = "https://api.shoonya.com/NorenWClient"
            self._ws = "wss://api.shoonya.com/NorenWS"
        else:
            self._host = "https://api.shoonya.com/NorenWClientTP"
            self._ws = "wss://api.shoonya.com/NorenWSTP"

        self._api = None
        self._ws_connected = False
        self._lock = threading.Lock()
        self._last_ticks: Dict[str, float] = {}
        # Mapping between Yahoo style and Shoonya style codes
        self._symbol_to_code: Dict[str, str] = {}
        self._code_to_symbol: Dict[str, str] = {}

        # Lazy API init: try to create API instance and login; ignore failures
        if ShoonyaApi:
            try:
                api = ShoonyaApi(host=self._host, websocket=self._ws)  # type: ignore[call-arg]
                twofa = self._get_twofa_code()
                # Login: user, pwd, twoFA, vendor_code, api_secret, imei
                login_res = api.login(
                    userid=self.user,
                    password=self.password,
                    twoFA=twofa,
                    vendor_code=self.vendor_code,
                    api_secret=self.api_key,
                    imei=self.imei,
                )  # type: ignore[attr-defined]
                if isinstance(login_res, dict) and login_res.get('stat') == 'Ok':
                    self._api = api
                else:
                    self._api = None
            except Exception:
                self._api = None

    def _is_base32(self, s: str) -> bool:
        import re
        return bool(s) and re.fullmatch(r"[A-Z2-7=]+", s.upper()) is not None

    def _get_twofa_code(self) -> str:
        # 1) Prompt if explicitly requested
        if self.totp_prompt:
            return getpass("Enter current 6-digit TOTP (Shoonya): ").strip()
        # 2) Static code if provided
        if self.static_totp:
            return self.static_totp.strip()
        # 3) Generate from base32 secret if available
        if _pyotp_available and self.totp_secret:
            try:
                if not self._is_base32(self.totp_secret):
                    return getpass("Enter current 6-digit TOTP (Shoonya): ").strip()
                return pyotp.TOTP(self.totp_secret).now()  # type: ignore[arg-type]
            except Exception:
                return getpass("Enter current 6-digit TOTP (Shoonya): ").strip()
        # 4) Last resort: prompt
        return getpass("Enter current 6-digit TOTP (Shoonya): ").strip()

    def info(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "ws": bool(self._ws_connected),
            "rest": bool(self._api is not None),
        }

    def _map_symbol(self, symbol: str) -> str:
        # RELIANCE.NS -> NSE|RELIANCE-EQ (simplified)
        s = symbol.upper()
        if s.endswith('.NS'):
            base = s[:-3]
        else:
            base = s
        code = f"NSE|{base}-EQ"
        # maintain mapping for reverse lookup
        self._symbol_to_code[s] = code
        self._code_to_symbol[code] = f"{base}.NS"
        return code

    def add_subscription_symbols(self, symbols: list[str]) -> list[str]:
        added: list[str] = []
        try:
            codes = [self._map_symbol(sym) for sym in symbols]
            if self._ws_connected and self._api and hasattr(self._api, 'subscribe'):
                try:
                    # subscribe expects list of codes like 'NSE|RELIANCE-EQ'
                    self._api.subscribe(codes)  # type: ignore[attr-defined]
                except Exception:
                    pass
            added = symbols
        except Exception:
            added = []
        return added

    def poll_price(self, symbol: str) -> Optional[float]:
        s = symbol.upper()
        with self._lock:
            if s in self._last_ticks:
                return self._last_ticks[s]
        if not self._api:
            return None
        try:
            code = self._symbol_to_code.get(s) or self._map_symbol(s)
            # Try REST quote; different API versions vary; handle common fields
            if hasattr(self._api, 'get_quotes'):
                q = self._api.get_quotes(exchange=code.split('|')[0], token=code.split('|')[1])  # type: ignore[attr-defined]
            elif hasattr(self._api, 'get_quote'):
                q = self._api.get_quote(code)  # type: ignore[attr-defined]
            else:
                q = None
            if isinstance(q, dict):
                lp = q.get('lp') or q.get('last_price') or q.get('ltp')
                if lp is not None:
                    p = float(lp)
                    with self._lock:
                        self._last_ticks[s] = p
                    return p
        except Exception:
            return None
        return None

    def ws_connect(self) -> bool:
        if not (self._api and hasattr(self._api, 'start_websocket')):
            self._ws_connected = False
            return False

        def on_open():
            self._ws_connected = True

        def on_disconnect():
            self._ws_connected = False

        def on_error(ex):
            self._ws_connected = False

        def on_message(tick: Dict[str, Any]):
            try:
                # Shoonya tick example: {'e':'nse_cm', 'tk':'2885', 'lp':'2615.55', 'ts':'RELIANCE', ...}
                lp = tick.get('lp') or tick.get('ltp')
                ts = tick.get('ts')  # tradingsymbol
                if lp and ts:
                    sym = f"{str(ts).upper()}.NS"
                    with self._lock:
                        self._last_ticks[sym] = float(lp)
            except Exception:
                pass

        try:
            # Start websocket in a background thread
            th = threading.Thread(
                target=lambda: self._safe_ws_run(on_open, on_disconnect, on_error, on_message),
                daemon=True,
            )
            th.start()
            return True
        except Exception:
            self._ws_connected = False
            return False

    def _safe_ws_run(self, on_open, on_disconnect, on_error, on_message):
        try:
            self._api.start_websocket(order_update_callback=None, subscribe_callback=on_message, socket_open_callback=on_open, socket_close_callback=on_disconnect, socket_error_callback=on_error)  # type: ignore[attr-defined]
        except Exception:
            self._ws_connected = False

    def close(self) -> None:
        try:
            if self._api and hasattr(self._api, 'close_websocket'):
                self._api.close_websocket()  # type: ignore[attr-defined]
        except Exception:
            pass
