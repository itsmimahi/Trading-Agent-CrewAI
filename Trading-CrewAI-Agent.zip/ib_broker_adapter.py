"""Interactive Brokers adapter for universal portfolio management.

This adapter is intentionally defensive:
- It only connects when explicitly enabled via environment variables.
- It supports read operations by default.
- Order placement is blocked unless IB_ALLOW_TRADES=1.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import os
import time
import logging


try:
    from ib_insync import IB, Stock, MarketOrder  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    IB = None  # type: ignore
    Stock = None  # type: ignore
    MarketOrder = None  # type: ignore


logger = logging.getLogger(__name__)


@dataclass
class IBConfig:
    enabled: bool = os.getenv("IB_ENABLED", "0") == "1"
    host: str = os.getenv("IB_HOST", "127.0.0.1")
    port: int = int(os.getenv("IB_PORT", "7497"))
    client_id: int = int(os.getenv("IB_CLIENT_ID", "108"))
    account: str = os.getenv("IB_ACCOUNT", "")
    exchange: str = os.getenv("IB_EXCHANGE", "SMART")
    currency: str = os.getenv("IB_CURRENCY", "USD")
    market_data_type: int = int(os.getenv("IB_MARKET_DATA_TYPE", "1"))
    connect_timeout: float = float(os.getenv("IB_CONNECT_TIMEOUT", "4"))
    allow_trades: bool = os.getenv("IB_ALLOW_TRADES", "0") == "1"


class InteractiveBrokersAdapter:
    """Broker adapter implementing the portfolio client interface for IB."""

    broker_name = "ib"

    def __init__(self) -> None:
        self.config = IBConfig()
        self._ib = None
        self._last_error: Optional[str] = None

        if not self.config.enabled:
            self._last_error = "IB adapter disabled (set IB_ENABLED=1)"
            return
        if IB is None:
            self._last_error = "ib_insync not installed"
            return

        try:
            self._ib = IB()
            self._ib.connect(
                host=self.config.host,
                port=self.config.port,
                clientId=self.config.client_id,
                timeout=self.config.connect_timeout,
                account=self.config.account or None,
            )
            try:
                self._ib.reqMarketDataType(self.config.market_data_type)
            except Exception:
                pass
            logger.info("IB adapter connected | host=%s port=%s client_id=%s", self.config.host, self.config.port, self.config.client_id)
        except Exception as e:
            self._last_error = str(e)
            logger.warning("IB adapter connect failed: %s", e)
            self._ib = None

    def is_available(self) -> bool:
        return self._ib is not None and bool(self._ib.isConnected())

    def _error(self, message: str) -> Dict[str, Any]:
        return {"error": message, "broker": self.broker_name}

    def _ensure_ready(self) -> Optional[Dict[str, Any]]:
        if not self.config.enabled:
            return self._error("IB adapter disabled")
        if IB is None:
            return self._error("ib_insync not installed")
        if not self.is_available():
            detail = self._last_error or "not connected"
            return self._error(f"IB unavailable: {detail}")
        return None

    def _build_stock_contract(self, symbol: str):
        if Stock is None:
            return None
        return Stock(symbol.upper(), self.config.exchange, self.config.currency)

    def holdings(self) -> Dict[str, Any]:
        err = self._ensure_ready()
        if err:
            return err
        try:
            positions = self._ib.positions()
            portfolio = []
            for p in positions:
                portfolio.append(
                    {
                        "symbol": getattr(getattr(p, "contract", None), "symbol", ""),
                        "quantity": int(getattr(p, "position", 0) or 0),
                        "avg_price": float(getattr(p, "avgCost", 0.0) or 0.0),
                    }
                )

            cash = 0.0
            summary = self._ib.accountSummary()
            for row in summary:
                if getattr(row, "tag", "") == "AvailableFunds":
                    try:
                        cash = float(getattr(row, "value", 0.0) or 0.0)
                        break
                    except Exception:
                        continue

            return {
                "broker": self.broker_name,
                "cash": cash,
                "holdings": portfolio,
                "as_of": time.time(),
            }
        except Exception as e:
            return self._error(f"holdings failed: {e}")

    def margins(self) -> Dict[str, Any]:
        err = self._ensure_ready()
        if err:
            return err
        try:
            available = 0.0
            net = 0.0
            used = 0.0
            summary = self._ib.accountSummary()
            for row in summary:
                tag = getattr(row, "tag", "")
                try:
                    val = float(getattr(row, "value", 0.0) or 0.0)
                except Exception:
                    continue
                if tag == "AvailableFunds":
                    available = val
                elif tag == "NetLiquidation":
                    net = val
                elif tag == "MaintMarginReq":
                    used = val

            return {
                "broker": self.broker_name,
                "available": available,
                "used": used,
                "net": net,
                "as_of": time.time(),
            }
        except Exception as e:
            return self._error(f"margins failed: {e}")

    def metrics(self) -> Dict[str, Any]:
        h = self.holdings()
        if "error" in h:
            return h
        m = self.margins()
        if "error" in m:
            return m
        return {
            "broker": self.broker_name,
            "cash": h.get("cash", 0.0),
            "total_value_est": m.get("net", 0.0),
            "unrealized_pnl": 0.0,
            "as_of": time.time(),
        }

    def get_last_price(self, symbol: str) -> Dict[str, Any]:
        err = self._ensure_ready()
        if err:
            return err
        try:
            contract = self._build_stock_contract(symbol)
            if contract is None:
                return self._error("Stock contract unavailable")
            self._ib.qualifyContracts(contract)
            ticker = self._ib.reqMktData(contract, "", False, False)
            self._ib.sleep(0.8)
            price = float(ticker.marketPrice() or 0.0)
            return {"broker": self.broker_name, "symbol": symbol.upper(), "last_price": price}
        except Exception as e:
            return self._error(f"last_price failed: {e}")

    def preview_order(self, symbol: str, side: str, quantity: int) -> Dict[str, Any]:
        if quantity <= 0:
            return self._error("quantity must be > 0")
        last_px = self.get_last_price(symbol)
        if "error" in last_px:
            return last_px
        est = float(last_px.get("last_price", 0.0)) * int(quantity)
        # Keep conservative fixed placeholder for preview-only estimate.
        fee = max(1.0, est * 0.0005)
        return {
            "broker": self.broker_name,
            "symbol": symbol.upper(),
            "side": side.lower(),
            "quantity": int(quantity),
            "last_price": float(last_px.get("last_price", 0.0)),
            "estimated_total": est + fee,
            "estimated_fees": fee,
            "preview": True,
        }

    def place_order(self, symbol: str, side: str, quantity: int, idempotency_key: Optional[str] = None) -> Dict[str, Any]:
        err = self._ensure_ready()
        if err:
            return err
        if not self.config.allow_trades:
            return self._error("IB live order placement blocked (set IB_ALLOW_TRADES=1)")
        if MarketOrder is None:
            return self._error("MarketOrder unavailable")
        if quantity <= 0:
            return self._error("quantity must be > 0")
        try:
            contract = self._build_stock_contract(symbol)
            if contract is None:
                return self._error("Stock contract unavailable")
            self._ib.qualifyContracts(contract)
            action = "BUY" if str(side).lower() == "buy" else "SELL"
            order = MarketOrder(action, int(quantity))
            trade = self._ib.placeOrder(contract, order)
            self._ib.sleep(1.2)

            status = getattr(getattr(trade, "orderStatus", None), "status", "Submitted")
            return {
                "broker": self.broker_name,
                "status": status,
                "idempotency_key": idempotency_key,
                "order": {
                    "symbol": symbol.upper(),
                    "side": side.lower(),
                    "quantity": int(quantity),
                },
            }
        except Exception as e:
            return self._error(f"place_order failed: {e}")

    def list_orders(self) -> List[Dict[str, Any]]:
        err = self._ensure_ready()
        if err:
            return [err]
        try:
            out: List[Dict[str, Any]] = []
            for tr in self._ib.trades():
                c = getattr(tr, "contract", None)
                o = getattr(tr, "order", None)
                s = getattr(tr, "orderStatus", None)
                out.append(
                    {
                        "broker": self.broker_name,
                        "symbol": getattr(c, "symbol", ""),
                        "side": "buy" if str(getattr(o, "action", "")).upper() == "BUY" else "sell",
                        "quantity": int(getattr(o, "totalQuantity", 0) or 0),
                        "status": getattr(s, "status", ""),
                    }
                )
            return out
        except Exception as e:
            return [self._error(f"list_orders failed: {e}")]
