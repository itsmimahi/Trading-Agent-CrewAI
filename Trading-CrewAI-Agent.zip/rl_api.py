"""
API Routes for RL Trading Agent
Provides endpoints for training, evaluation, backtesting, and integration with CrewAI.
"""

from flask import Blueprint, request, jsonify, current_app
import numpy as np
import pandas as pd
import json
import os
import traceback
from datetime import datetime, timedelta
import sys
from typing import Dict, List, Any, Optional
import threading
import time

from RL_Agent.rl_agent import RLTradingAgent
from RL_Agent.trading_environment import TradingEnvironment

rl_api = Blueprint('rl_api', __name__, url_prefix='/api/rl')

# Global variables to store agent instances and training status
agents = {}
training_status = {}
training_threads = {}
# Thread-safe job progress map
train_jobs: Dict[str, Dict[str, Any]] = {}
train_jobs_lock = threading.Lock()


@rl_api.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    details = {
        'service': 'RL Trading Agent',
        'version': '1.0.0',
        'timestamp': datetime.now().isoformat(),
        'python_version': sys.version if 'sys' in globals() else None,
        'dependencies': {
            'numpy': True,
            'pandas': True,
        },
        'agents_loaded': len(agents),
    }
    try:
        import torch  # type: ignore
        details['dependencies']['torch'] = True
        details['device'] = 'cuda' if torch.cuda.is_available() else 'cpu'
    except Exception:
        details['dependencies']['torch'] = False
        details['device'] = 'cpu'
    try:
        import stable_baselines3  # type: ignore
        details['dependencies']['stable_baselines3'] = True
    except Exception:
        details['dependencies']['stable_baselines3'] = False
    return jsonify({'status': 'healthy', **details})


@rl_api.route('/agents', methods=['GET'])
def list_agents():
    """List all available RL agents."""
    agent_list = []
    for agent_id, agent in agents.items():
        agent_info = {
            'agent_id': agent_id,
            'algorithm': agent.algorithm,
            'symbol': agent.symbol,
            'initial_balance': agent.initial_balance,
            'start_date': agent.start_date,
            'end_date': agent.end_date,
            'is_trained': agent.model is not None,
            'training_status': training_status.get(agent_id, 'idle')
        }
        agent_list.append(agent_info)
    
    return jsonify({
        'agents': agent_list,
        'total_count': len(agent_list)
    })


@rl_api.route('/agents', methods=['POST'])
def create_agent():
    """Create a new RL agent."""
    try:
        data = request.get_json()
        
        # Validate required parameters
        required_params = ['agent_id', 'algorithm', 'symbol']
        for param in required_params:
            if param not in data:
                return jsonify({'error': f'Missing required parameter: {param}'}), 400
        
        agent_id = data['agent_id']
        
        # Check if agent already exists
        if agent_id in agents:
            return jsonify({'error': f'Agent {agent_id} already exists'}), 400
        
        # Create agent
        agent = RLTradingAgent(
            algorithm=data['algorithm'],
            symbol=data['symbol'],
            initial_balance=data.get('initial_balance', 100000.0),
            start_date=data.get('start_date', '2020-01-01'),
            end_date=data.get('end_date', '2023-12-31'),
            lookback_window=data.get('lookback_window', 20),
            model_dir=os.path.join('models', agent_id),
            log_dir=os.path.join('logs', agent_id)
        )
        
        agents[agent_id] = agent
        training_status[agent_id] = 'idle'
        
        return jsonify({
            'message': f'Agent {agent_id} created successfully',
            'agent_id': agent_id,
            'algorithm': agent.algorithm,
            'symbol': agent.symbol
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>', methods=['GET'])
def get_agent_info(agent_id):
    """Get information about a specific agent."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    agent = agents[agent_id]
    
    return jsonify({
        'agent_id': agent_id,
        'algorithm': agent.algorithm,
        'symbol': agent.symbol,
        'initial_balance': agent.initial_balance,
        'start_date': agent.start_date,
        'end_date': agent.end_date,
        'lookback_window': agent.lookback_window,
        'is_trained': agent.model is not None,
        'training_status': training_status.get(agent_id, 'idle'),
        'training_history': agent.training_history
    })


@rl_api.route('/agents/<agent_id>', methods=['DELETE'])
def delete_agent(agent_id):
    """Delete an agent."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    # Stop training if in progress
    if agent_id in training_threads and training_threads[agent_id].is_alive():
        training_status[agent_id] = 'stopping'
        # Note: In a production environment, you'd want a more graceful way to stop training
    
    # Remove agent
    del agents[agent_id]
    if agent_id in training_status:
        del training_status[agent_id]
    if agent_id in training_threads:
        del training_threads[agent_id]
    
    return jsonify({'message': f'Agent {agent_id} deleted successfully'})


def train_agent_async(agent_id: str, total_timesteps: int, eval_freq: int, algo_params: Optional[Dict[str, Any]] = None):
    """Asynchronous training function."""
    try:
        training_status[agent_id] = 'training'
        agent = agents[agent_id]
        # Initialize progress snapshot
        with train_jobs_lock:
            train_jobs[agent_id] = {
                'status': 'training',
                'started_at': datetime.now().isoformat(),
                'total_timesteps': int(total_timesteps),
                'timesteps': 0,
                'n_calls': 0,
                'last_update': datetime.now().isoformat()
            }
        
        # Train the agent
        # Wire a lightweight progress callback
        def _progress_cb(timesteps: int, payload: Dict[str, Any]):
            with train_jobs_lock:
                job = train_jobs.get(agent_id)
                if job is not None:
                    job['timesteps'] = int(timesteps)
                    job['n_calls'] = int(payload.get('n_calls', job.get('n_calls', 0)))
                    job['last_update'] = datetime.now().isoformat()
        results = agent.train(
            total_timesteps=total_timesteps,
            eval_freq=eval_freq,
            progress_cb=_progress_cb,
            progress_report_freq=max(1000, total_timesteps // 100),
            algo_params=algo_params or {}
        )
        
        training_status[agent_id] = 'completed'
        with train_jobs_lock:
            if agent_id in train_jobs:
                train_jobs[agent_id].update({
                    'status': 'completed',
                    'completed_at': datetime.now().isoformat(),
                    'timesteps': int(total_timesteps)
                })
        
        # Store results (in a production environment, you'd want to persist this)
        agent.training_results = results
        
    except Exception as e:
        training_status[agent_id] = 'failed'
        agent.training_error = str(e)
        with train_jobs_lock:
            if agent_id in train_jobs:
                train_jobs[agent_id].update({
                    'status': 'failed',
                    'error': str(e),
                    'failed_at': datetime.now().isoformat()
                })
        print(f"Training failed for agent {agent_id}: {e}")
        traceback.print_exc()


@rl_api.route('/agents/<agent_id>/train', methods=['POST'])
def train_agent(agent_id):
    """Start training an agent."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    if training_status.get(agent_id) == 'training':
        return jsonify({'error': f'Agent {agent_id} is already training'}), 400
    
    try:
        data = request.get_json() or {}
        total_timesteps = data.get('total_timesteps', 50000)
        eval_freq = data.get('eval_freq', 5000)
        algo_params = data.get('algo_params') or {}

        # Start training in a separate thread
        training_thread = threading.Thread(
            target=train_agent_async,
            args=(agent_id, total_timesteps, eval_freq, algo_params)
        )
        training_thread.start()
        training_threads[agent_id] = training_thread

        return jsonify({
            'message': f'Training started for agent {agent_id}',
            'total_timesteps': total_timesteps,
            'eval_freq': eval_freq
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/training/status', methods=['GET'])
def get_training_status(agent_id):
    """Get training status for an agent."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    status = training_status.get(agent_id, 'idle')
    agent = agents[agent_id]

    # Read a shallow, non-blocking snapshot
    with train_jobs_lock:
        job = train_jobs.get(agent_id, {}).copy()

    response = {
        'agent_id': agent_id,
        'status': status,
        'job': job,
        'training_history': agent.training_history
    }

    if status == 'failed' and hasattr(agent, 'training_error'):
        response['error'] = agent.training_error
    if status == 'completed' and hasattr(agent, 'training_results'):
        response['results'] = agent.training_results
    return jsonify(response)


@rl_api.route('/agents/<agent_id>/training/stop', methods=['POST'])
def stop_training(agent_id):
    """Request to stop training (best-effort)."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    if training_status.get(agent_id) != 'training':
        return jsonify({'message': 'No active training'}), 200
    training_status[agent_id] = 'stopping'
    with train_jobs_lock:
        if agent_id in train_jobs:
            train_jobs[agent_id]['status'] = 'stopping'
            train_jobs[agent_id]['last_update'] = datetime.now().isoformat()
    return jsonify({'message': 'Stop requested'}), 202


@rl_api.route('/agents/<agent_id>/evaluate', methods=['POST'])
def evaluate_agent(agent_id):
    """Evaluate a trained agent."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    agent = agents[agent_id]
    
    if agent.model is None:
        return jsonify({'error': f'Agent {agent_id} is not trained'}), 400
    
    try:
        data = request.get_json() or {}
        n_episodes = data.get('n_episodes', 5)
        
        # Run evaluation
        eval_stats = agent.evaluate(n_episodes=n_episodes)
        
        return jsonify({
            'agent_id': agent_id,
            'evaluation_stats': eval_stats,
            'n_episodes': n_episodes,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/backtest', methods=['POST'])
def backtest_agent(agent_id):
    """Run a backtest for a trained agent."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    agent = agents[agent_id]
    
    if agent.model is None:
        return jsonify({'error': f'Agent {agent_id} is not trained'}), 400
    
    try:
        data = request.get_json()
        
        # Validate required parameters
        if 'start_date' not in data or 'end_date' not in data:
            return jsonify({'error': 'start_date and end_date are required'}), 400
        
        start_date = data['start_date']
        end_date = data['end_date']
        
        # Run backtest
        backtest_results = agent.backtest(start_date, end_date)
        
        return jsonify({
            'agent_id': agent_id,
            'backtest_results': {
                'stats': backtest_results['stats'],
                'start_date': backtest_results['start_date'],
                'end_date': backtest_results['end_date'],
                'total_actions': len(backtest_results['actions']),
                'final_portfolio_value': backtest_results['portfolio_values'][-1] if backtest_results['portfolio_values'] else 0
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/predict', methods=['POST'])
def predict_action(agent_id):
    """Get action prediction from a trained agent."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    agent = agents[agent_id]
    
    if agent.model is None:
        return jsonify({'error': f'Agent {agent_id} is not trained'}), 400
    
    try:
        data = request.get_json()
        
        if 'observation' not in data:
            return jsonify({'error': 'observation is required'}), 400
        
        observation = np.array(data['observation'], dtype=np.float32)
        deterministic = data.get('deterministic', True)
        
        # Get prediction
        action, confidence = agent.predict(observation, deterministic=deterministic)
        
        # Get explanation
        explanation = agent.get_action_explanation(observation, action)
        
        action_names = ['HOLD', 'BUY', 'SELL', 'CLOSE_POSITION']
        
        return jsonify({
            'agent_id': agent_id,
            'action': int(action),
            'action_name': action_names[action],
            'confidence': float(confidence),
            'explanation': explanation,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/simulate_strategy', methods=['POST'])
def simulate_strategy(agent_id):
    """Simulate a strategy using the RL agent (for CrewAI integration)."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    agent = agents[agent_id]
    
    if agent.model is None:
        return jsonify({'error': f'Agent {agent_id} is not trained'}), 400
    
    try:
        data = request.get_json()
        
        # Extract strategy parameters
        strategy_description = data.get('strategy_description', '')
        symbol = data.get('symbol', agent.symbol)
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        initial_balance = data.get('initial_balance', agent.initial_balance)
        
        if not start_date or not end_date:
            return jsonify({'error': 'start_date and end_date are required'}), 400
        
        # Create a temporary environment for simulation
        sim_env = TradingEnvironment(
            symbol=symbol,
            initial_balance=initial_balance,
            start_date=start_date,
            end_date=end_date,
            lookback_window=agent.lookback_window
        )
        
        # Run simulation
        obs, _ = sim_env.reset()
        done = False
        actions = []
        portfolio_values = []
        explanations = []
        
        while not done:
            action, confidence = agent.predict(obs, deterministic=True)
            explanation = agent.get_action_explanation(obs, action)
            
            obs, reward, done, _, info = sim_env.step(action)
            
            actions.append(int(action))
            portfolio_values.append(info['portfolio_value'])
            explanations.append(explanation)
        
        # Get final statistics
        final_stats = sim_env.get_portfolio_stats()
        
        # Generate performance report
        performance_report = {
            'strategy_description': strategy_description,
            'symbol': symbol,
            'start_date': start_date,
            'end_date': end_date,
            'initial_balance': initial_balance,
            'final_portfolio_value': portfolio_values[-1] if portfolio_values else initial_balance,
            'total_return': final_stats.get('total_return', 0),
            'annualized_return': final_stats.get('annualized_return', 0),
            'sharpe_ratio': final_stats.get('sharpe_ratio', 0),
            'max_drawdown': final_stats.get('max_drawdown', 0),
            'volatility': final_stats.get('volatility', 0),
            'win_rate': final_stats.get('win_rate', 0),
            'total_trades': final_stats.get('total_trades', 0),
            'action_distribution': {
                'HOLD': actions.count(0),
                'BUY': actions.count(1),
                'SELL': actions.count(2),
                'CLOSE_POSITION': actions.count(3)
            }
        }
        
        return jsonify({
            'agent_id': agent_id,
            'simulation_results': performance_report,
            'sample_explanations': explanations[:10],  # First 10 explanations
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/feedback', methods=['POST'])
def provide_feedback(agent_id):
    """Provide feedback to the RL agent (for CrewAI integration)."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    try:
        data = request.get_json()
        
        feedback_type = data.get('feedback_type')  # 'performance', 'market_regime', 'strategy_validation'
        feedback_data = data.get('feedback_data', {})
        
        # Store feedback (in a production environment, this would be used for continuous learning)
        agent = agents[agent_id]
        
        if not hasattr(agent, 'feedback_history'):
            agent.feedback_history = []
        
        feedback_entry = {
            'timestamp': datetime.now().isoformat(),
            'feedback_type': feedback_type,
            'feedback_data': feedback_data
        }
        
        agent.feedback_history.append(feedback_entry)
        
        # Process feedback based on type
        response = {'message': 'Feedback received'}
        
        if feedback_type == 'performance':
            # Performance feedback from CrewAI's Risk Agent
            performance_metrics = feedback_data.get('performance_metrics', {})
            response['analysis'] = f"Performance feedback processed. Key metrics: {performance_metrics}"
            
        elif feedback_type == 'market_regime':
            # Market regime change signal
            regime = feedback_data.get('regime', 'unknown')
            confidence = feedback_data.get('confidence', 0.5)
            response['analysis'] = f"Market regime change detected: {regime} (confidence: {confidence})"
            
        elif feedback_type == 'strategy_validation':
            # Strategy validation results
            strategy_performance = feedback_data.get('strategy_performance', {})
            response['analysis'] = f"Strategy validation completed: {strategy_performance}"
        
        return jsonify({
            'agent_id': agent_id,
            'feedback_processed': True,
            'response': response,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/learned_rules', methods=['GET'])
def get_learned_rules(agent_id):
    """Extract learned rules from the RL agent (advanced feature)."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    agent = agents[agent_id]
    
    if agent.model is None:
        return jsonify({'error': f'Agent {agent_id} is not trained'}), 400
    
    try:
        # This is a simplified version of rule extraction
        # In practice, you'd use techniques like LIME or SHAP for more sophisticated analysis
        
        # Analyze recent feedback and actions to extract patterns
        learned_rules = []
        
        if hasattr(agent, 'feedback_history') and agent.feedback_history:
            # Analyze feedback patterns
            performance_feedbacks = [f for f in agent.feedback_history if f['feedback_type'] == 'performance']
            
            if performance_feedbacks:
                avg_sharpe = np.mean([f['feedback_data'].get('performance_metrics', {}).get('sharpe_ratio', 0) 
                                    for f in performance_feedbacks])
                
                if avg_sharpe > 1.0:
                    learned_rules.append({
                        'rule': 'High Sharpe Ratio Strategy',
                        'description': f'Agent consistently achieves Sharpe ratio above 1.0 (avg: {avg_sharpe:.2f})',
                        'confidence': 0.8,
                        'evidence': f'Based on {len(performance_feedbacks)} performance evaluations'
                    })
        
        # Add some example rules based on training history
        if agent.training_history.get('episode_rewards'):
            recent_rewards = agent.training_history['episode_rewards'][-100:]  # Last 100 episodes
            if recent_rewards and np.mean(recent_rewards) > 0:
                learned_rules.append({
                    'rule': 'Positive Expected Return',
                    'description': f'Agent learned to generate positive expected returns (avg: {np.mean(recent_rewards):.2f})',
                    'confidence': 0.7,
                    'evidence': f'Based on last {len(recent_rewards)} training episodes'
                })
        
        # Default rules if no specific patterns found
        if not learned_rules:
            learned_rules = [
                {
                    'rule': 'Risk Management',
                    'description': 'Agent learned basic risk management through drawdown penalties',
                    'confidence': 0.6,
                    'evidence': 'Inferred from reward function design'
                },
                {
                    'rule': 'Transaction Cost Awareness',
                    'description': 'Agent considers transaction costs in decision making',
                    'confidence': 0.7,
                    'evidence': 'Built into reward function'
                }
            ]
        
        return jsonify({
            'agent_id': agent_id,
            'learned_rules': learned_rules,
            'extraction_method': 'simplified_pattern_analysis',
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/save', methods=['POST'])
def save_agent_model(agent_id):
    """Save the trained model."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    agent = agents[agent_id]
    
    if agent.model is None:
        return jsonify({'error': f'Agent {agent_id} is not trained'}), 400
    
    try:
        data = request.get_json() or {}
        filename = data.get('filename', f'{agent_id}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip')
        
        filepath = os.path.join(agent.model_dir, filename)
        agent.save_model(filepath)
        
        return jsonify({
            'message': f'Model saved successfully',
            'filepath': filepath,
            'agent_id': agent_id
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rl_api.route('/agents/<agent_id>/load', methods=['POST'])
def load_agent_model(agent_id):
    """Load a trained model."""
    if agent_id not in agents:
        return jsonify({'error': f'Agent {agent_id} not found'}), 404
    
    try:
        data = request.get_json()
        
        if 'filepath' not in data:
            return jsonify({'error': 'filepath is required'}), 400
        
        filepath = data['filepath']
        
        if not os.path.exists(filepath):
            return jsonify({'error': f'Model file not found: {filepath}'}), 404
        
        agent = agents[agent_id]
        agent.load_model(filepath)
        
        return jsonify({
            'message': f'Model loaded successfully',
            'filepath': filepath,
            'agent_id': agent_id
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

