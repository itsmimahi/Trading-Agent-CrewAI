# IBKR Integration

> **Source**: `agents/ibkr_portfolio_service.py`, `agents/universal_portfolio_manager.py`,  
> `main_advisory_agent/main_advisory_agent.py`

---

## Overview

The system connects exclusively to an Interactive Brokers paper-trading account via
`ib_insync`. There is **no fallback** to any other portfolio data source.

When `IB_ENABLED=0` (the default), all portfolio methods return safe error dicts and
`is_connected()` returns `False`. The advisory flow continues normally but without
live holdings data.

```mermaid
flowchart LR
    ENV[.env / env vars] -->|IB_ENABLED=1| SVC

    subgraph IBKRPortfolioService
        SVC["connect()\nIB.connect(host, port, clientId)"]
        PUSH[Push events\naccountValueEvent\npositionEvent]
        CACHE[TTL cache\nholdings + metrics\nTTL=30s]
        SVC --> PUSH
        SVC --> CACHE
    end

    TWS[(TWS / IB Gateway\nPort 7497 / 4002)] <-->|ib_insync| SVC

    UPM[UniversalPortfolioManager] -->|delegates| SVC
    MAA[MainAdvisoryAgent\n_portfolio_*() methods] --> UPM
    AF[AdvisoryFlow\nexecution_step refresh] --> MAA
```

---

## Activation guide

### Step 1 — Install `ib_insync`

```bash
# Using the project virtual environment
.\crewenv\Scripts\Activate.ps1
pip install ib_insync
```

### Step 2 — Start TWS (Trader Workstation)

1. Download TWS from [interactivebrokers.com](https://www.interactivebrokers.com/en/trading/tws.php)
2. Log in with your **paper trading** credentials
3. *File → Global Configuration → API → Settings*:
   - ✅ Enable ActiveX and Socket Clients
   - Socket port: `7497`
   - ❌ Uncheck "Read-Only API" (required for order placement)
   - ✅ Allow connections from localhost (127.0.0.1)

### Step 3 — Set environment variables

```dotenv
IB_ENABLED=1
IB_HOST=127.0.0.1
IB_PORT=7497
IB_CLIENT_ID=108
IB_ACCOUNT=DU123456          # your paper account number
IB_ALLOW_TRADES=1            # set to 1 to enable order placement
IB_PORTFOLIO_TTL=30          # cache TTL in seconds
```

### Step 4 — Verify connection

```python
from agents.ibkr_portfolio_service import get_ibkr_service

svc = get_ibkr_service()
print("Connected:", svc.is_connected())
print("Holdings:", svc.get_holdings())
print("Metrics:", svc.get_metrics())
```

---

## `IBKRPortfolioService` — API reference

### Constructor (via `get_ibkr_service()`)

Do not instantiate directly — use the module-level singleton factory:

```python
from agents.ibkr_portfolio_service import get_ibkr_service, IBKRPortfolioService

svc: IBKRPortfolioService = get_ibkr_service()
```

`get_ibkr_service()` is thread-safe (uses `threading.Lock`) and creates at most
one `IBKRPortfolioService` instance per process.

### `connect() → bool`

- Calls `IB.connect(host, port, clientId=client_id, timeout=10, account=account)`
- Subscribes to push events:
  - `ib.accountValueEvent += self._on_account_value`
  - `ib.positionEvent += self._on_position`
- Calls `ib.reqAccountUpdates(subscribe=True)` to start streaming
- Warms cache with `_refresh_cache()`
- Returns `True` on success, `False` on any exception

### `is_connected() → bool`

Returns `self._ib.isConnected()`. Fast — no network call.

### `get_holdings() → Dict[str, Any]`

Returns cached holdings dict. Refreshes cache if TTL expired.

```python
{
    "positions": [
        {
            "symbol": "RELIANCE.NS",
            "quantity": 50,
            "avg_cost": 2810.0,
            "market_price": 2850.0,
            "market_value": 142_500.0,
            "unrealized_pnl": 2_000.0,
        },
        ...
    ],
    "total_value": 500_000.0,
    "cash": 200_000.0,
    "n_positions": 3,
    "last_updated": 1737000000.0,
}
```

Returns `{"error": "IBKR not connected"}` when disconnected.

### `get_metrics() → Dict[str, Any]`

```python
{
    "net_liquidation": 500_000.0,
    "available_funds": 200_000.0,
    "unrealized_pnl": 12_500.0,
    "realized_pnl": 3_200.0,
    "maint_margin_req": 0.0,
    "last_updated": 1737000000.0,
}
```

### `get_margins() → Dict[str, Any]`

```python
{
    "initial_margin_req": 0.0,
    "maint_margin_req": 0.0,
    "available_funds": 200_000.0,
    "excess_liquidity": 200_000.0,
}
```

### `get_snapshot() → Dict[str, Any]`

Merges `get_holdings()` and `get_metrics()` into a single dict. Preferred for
passing to Crew agents.

### `get_last_price(symbol: str) → Optional[float]`

Requests a snapshot market data quote for `symbol`. Returns `None` if unavailable.

### `preview_order(symbol, side, quantity) → Dict[str, Any]`

Returns estimated cost / proceeds without placing an order.

```python
{
    "symbol": "RELIANCE.NS",
    "side": "BUY",
    "quantity": 10,
    "estimated_price": 2850.0,
    "estimated_value": 28_500.0,
    "commission": 28.5,
}
```

### `place_order(symbol, side, quantity, order_type="MKT", limit_price=None, idempotency_key=None) → Dict[str, Any]`

Requires `IB_ALLOW_TRADES=1`. Returns error dict otherwise.

```python
{
    "order_id": 142,
    "symbol": "RELIANCE.NS",
    "side": "BUY",
    "quantity": 10,
    "status": "Submitted",
    "idempotency_key": "conv_abc_1737000000",
}
```

Invalidates the portfolio cache after placement so the next `get_holdings()` returns
fresh data.

### `list_orders() → List[Dict[str, Any]]`

Returns all open/pending orders from `IB.trades()`.

---

## Push events and real-time cache

When connected, IB streams account and position updates:

| Event | Handler | Updates |
|-------|---------|---------|
| `accountValueEvent` | `_on_account_value(account_value)` | `AvailableFunds`, `NetLiquidation`, `UnrealizedPnL`, `RealizedPnL`, `MaintMarginReq` |
| `positionEvent` | `_on_position(position)` | `_rt_positions` list |

These are used to keep `_cache_metrics` and `_rt_positions` continuously fresh.
On a TTL cache miss, `_refresh_cache()` is called which does a blocking
`IB.sleep(0.3)` + `IB.positions()` + `IB.accountSummary()`.

---

## Auto-reconnect

If `IB.isConnected()` returns `False` during a cache refresh, `_refresh_cache()`
automatically calls `connect()` once. If that also fails, an error dict is returned
and the error is logged at `WARNING` level — the flow continues without portfolio data.

---

## `UniversalPortfolioManager`

> **Source**: `agents/universal_portfolio_manager.py`

This class is the single portfolio interface for all agent code outside
`MainAdvisoryAgent`. It delegates entirely to `IBKRPortfolioService`:

```python
from agents.universal_portfolio_manager import get_portfolio_manager

pm = get_portfolio_manager(agent_name="risk_assessment")
holdings = pm.get_holdings()
```

`get_portfolio_manager(agent_name)` returns a cached instance per agent name.
All instances share the same underlying `IBKRPortfolioService` singleton.

### Methods

Same as `IBKRPortfolioService` above, plus:

| Method | Description |
|--------|-------------|
| `get_portfolio_summary()` | Returns `get_snapshot()` |
| `can_trade()` | `IB_ALLOW_TRADES=1` and `is_connected()` |
| `is_available()` | `is_connected()` |

---

## Env var reference

| Variable | Default | Description |
|----------|---------|-------------|
| `IB_ENABLED` | `0` | `1` to connect on startup |
| `IB_HOST` | `127.0.0.1` | TWS / Gateway host |
| `IB_PORT` | `7497` | TWS paper trading port (4002 for IB Gateway paper) |
| `IB_CLIENT_ID` | `108` | Unique client ID (0–999) |
| `IB_ACCOUNT` | `""` | Paper account number (e.g. `DU123456`) |
| `IB_ALLOW_TRADES` | `0` | `1` to enable order placement |
| `IB_PORTFOLIO_TTL` | `30` | Seconds before cache refresh |
| `IB_EXCHANGE` | `SMART` | Default exchange for orders |
| `IB_CURRENCY` | `USD` | Default currency |
