"""
CrewAI Integration Service
Handles communication between the RL Trading Agent and the CrewAI multi-agent advisory system.
"""

import requests
import json
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
import asyncio
import aiohttp

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class StrategyRequest:
    """Data class for strategy simulation requests from CrewAI."""
    strategy_description: str
    symbol: str
    start_date: str
    end_date: str
    initial_balance: float = 100000.0
    agent_id: str = "default"
    requester_agent: str = "unknown"


@dataclass
class FeedbackData:
    """Data class for feedback from CrewAI to RL agent."""
    feedback_type: str  # 'performance', 'market_regime', 'strategy_validation'
    feedback_data: Dict[str, Any]
    source_agent: str
    timestamp: str
    confidence: float = 0.5


class CrewAIIntegrationService:
    """
    Service class for integrating RL Trading Agent with CrewAI system.
    
    This service acts as a bridge between the RL agent and the CrewAI multi-agent
    advisory system, enabling bidirectional communication and feedback loops.
    """
    
    def __init__(self, 
                 rl_agent_base_url: str = "http://localhost:5000",
                 crewai_base_url: str = "http://localhost:5001",
                 default_agent_id: str = "main_rl_agent"):
        """
        Initialize the integration service.
        
        Args:
            rl_agent_base_url: Base URL for the RL agent API
            crewai_base_url: Base URL for the CrewAI advisory system
            default_agent_id: Default RL agent ID to use
        """
        self.rl_agent_base_url = rl_agent_base_url.rstrip('/')
        self.crewai_base_url = crewai_base_url.rstrip('/')
        self.default_agent_id = default_agent_id
        
        # Track communication history
        self.communication_history = []
        self.feedback_history = []
        
        # Performance tracking
        self.performance_metrics = {
            'total_strategy_simulations': 0,
            'successful_simulations': 0,
            'total_feedback_sent': 0,
            'average_response_time': 0.0
        }
    
    def _log_communication(self, action: str, data: Dict[str, Any], success: bool = True):
        """Log communication events for debugging and monitoring."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'success': success,
            'data_summary': {k: str(v)[:100] for k, v in data.items()},  # Truncate for logging
        }
        self.communication_history.append(log_entry)
        
        # Keep only last 100 entries
        if len(self.communication_history) > 100:
            self.communication_history = self.communication_history[-100:]
    
    def check_rl_agent_health(self) -> bool:
        """Check if the RL agent is healthy and responsive."""
        try:
            response = requests.get(f"{self.rl_agent_base_url}/api/rl/health", timeout=5)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"RL agent health check failed: {e}")
            return False
    
    def check_crewai_health(self) -> bool:
        """Check if the CrewAI system is healthy and responsive."""
        try:
            response = requests.get(f"{self.crewai_base_url}/api/advisory/health", timeout=5)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"CrewAI health check failed: {e}")
            return False
    
    def create_rl_agent(self, 
                       agent_id: str,
                       algorithm: str = "PPO",
                       symbol: str = "AAPL",
                       **kwargs) -> Dict[str, Any]:
        """Create a new RL agent for trading."""
        try:
            payload = {
                'agent_id': agent_id,
                'algorithm': algorithm,
                'symbol': symbol,
                **kwargs
            }
            
            response = requests.post(
                f"{self.rl_agent_base_url}/api/rl/agents",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_communication('create_agent', payload, True)
                logger.info(f"Successfully created RL agent: {agent_id}")
                return result
            else:
                error_msg = f"Failed to create RL agent: {response.text}"
                logger.error(error_msg)
                self._log_communication('create_agent', payload, False)
                return {'error': error_msg}
                
        except Exception as e:
            error_msg = f"Error creating RL agent: {e}"
            logger.error(error_msg)
            self._log_communication('create_agent', {'agent_id': agent_id}, False)
            return {'error': error_msg}
    
    def train_rl_agent(self, 
                      agent_id: str,
                      total_timesteps: int = 50000,
                      eval_freq: int = 5000) -> Dict[str, Any]:
        """Start training an RL agent."""
        try:
            payload = {
                'total_timesteps': total_timesteps,
                'eval_freq': eval_freq
            }
            
            response = requests.post(
                f"{self.rl_agent_base_url}/api/rl/agents/{agent_id}/train",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_communication('train_agent', payload, True)
                logger.info(f"Started training RL agent: {agent_id}")
                return result
            else:
                error_msg = f"Failed to start training: {response.text}"
                logger.error(error_msg)
                self._log_communication('train_agent', payload, False)
                return {'error': error_msg}
                
        except Exception as e:
            error_msg = f"Error starting training: {e}"
            logger.error(error_msg)
            self._log_communication('train_agent', {'agent_id': agent_id}, False)
            return {'error': error_msg}
    
    def get_training_status(self, agent_id: str) -> Dict[str, Any]:
        """Get the training status of an RL agent."""
        try:
            response = requests.get(
                f"{self.rl_agent_base_url}/api/rl/agents/{agent_id}/training/status",
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return {'error': f"Failed to get training status: {response.text}"}
                
        except Exception as e:
            return {'error': f"Error getting training status: {e}"}
    
    def simulate_strategy_for_crewai(self, strategy_request: StrategyRequest) -> Dict[str, Any]:
        """
        Simulate a trading strategy using the RL agent for CrewAI.
        
        This is the main integration point where CrewAI agents can request
        strategy simulations from the RL agent.
        """
        start_time = datetime.now()
        
        try:
            # Prepare the simulation request
            payload = {
                'strategy_description': strategy_request.strategy_description,
                'symbol': strategy_request.symbol,
                'start_date': strategy_request.start_date,
                'end_date': strategy_request.end_date,
                'initial_balance': strategy_request.initial_balance
            }
            
            # Send request to RL agent
            response = requests.post(
                f"{self.rl_agent_base_url}/api/rl/agents/{strategy_request.agent_id}/simulate_strategy",
                json=payload,
                timeout=60  # Longer timeout for simulation
            )
            
            # Calculate response time
            response_time = (datetime.now() - start_time).total_seconds()
            
            if response.status_code == 200:
                result = response.json()
                
                # Update performance metrics
                self.performance_metrics['total_strategy_simulations'] += 1
                self.performance_metrics['successful_simulations'] += 1
                self._update_average_response_time(response_time)
                
                # Log successful communication
                self._log_communication('simulate_strategy', payload, True)
                
                # Format result for CrewAI consumption
                formatted_result = self._format_simulation_result_for_crewai(result, strategy_request)
                
                logger.info(f"Successfully simulated strategy for {strategy_request.requester_agent}")
                return formatted_result
                
            else:
                error_msg = f"RL agent simulation failed: {response.text}"
                logger.error(error_msg)
                self._log_communication('simulate_strategy', payload, False)
                
                self.performance_metrics['total_strategy_simulations'] += 1
                
                return {
                    'success': False,
                    'error': error_msg,
                    'strategy_request': strategy_request.__dict__
                }
                
        except Exception as e:
            error_msg = f"Error during strategy simulation: {e}"
            logger.error(error_msg)
            self._log_communication('simulate_strategy', strategy_request.__dict__, False)
            
            self.performance_metrics['total_strategy_simulations'] += 1
            
            return {
                'success': False,
                'error': error_msg,
                'strategy_request': strategy_request.__dict__
            }
    
    def _format_simulation_result_for_crewai(self, 
                                           rl_result: Dict[str, Any], 
                                           strategy_request: StrategyRequest) -> Dict[str, Any]:
        """Format RL agent simulation results for CrewAI consumption."""
        simulation_results = rl_result.get('simulation_results', {})
        
        # Extract key performance metrics
        performance_summary = {
            'total_return': simulation_results.get('total_return', 0),
            'annualized_return': simulation_results.get('annualized_return', 0),
            'sharpe_ratio': simulation_results.get('sharpe_ratio', 0),
            'max_drawdown': simulation_results.get('max_drawdown', 0),
            'volatility': simulation_results.get('volatility', 0),
            'win_rate': simulation_results.get('win_rate', 0),
            'total_trades': simulation_results.get('total_trades', 0)
        }
        
        # Create recommendation based on performance
        recommendation = self._generate_recommendation(performance_summary)
        
        # Format for CrewAI
        formatted_result = {
            'success': True,
            'strategy_request': {
                'description': strategy_request.strategy_description,
                'symbol': strategy_request.symbol,
                'period': f"{strategy_request.start_date} to {strategy_request.end_date}",
                'requester': strategy_request.requester_agent
            },
            'performance_metrics': performance_summary,
            'recommendation': recommendation,
            'action_distribution': simulation_results.get('action_distribution', {}),
            'sample_explanations': rl_result.get('sample_explanations', []),
            'rl_agent_id': rl_result.get('agent_id'),
            'simulation_timestamp': rl_result.get('timestamp'),
            'confidence_score': self._calculate_confidence_score(performance_summary)
        }
        
        return formatted_result
    
    def _generate_recommendation(self, performance_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Generate a recommendation based on performance metrics."""
        sharpe_ratio = performance_metrics.get('sharpe_ratio', 0)
        max_drawdown = performance_metrics.get('max_drawdown', 0)
        total_return = performance_metrics.get('total_return', 0)
        win_rate = performance_metrics.get('win_rate', 0)
        
        # Simple recommendation logic
        if sharpe_ratio > 1.5 and max_drawdown < 0.1 and total_return > 0.1:
            recommendation_type = "STRONG_BUY"
            confidence = 0.9
            reasoning = "Excellent risk-adjusted returns with low drawdown"
        elif sharpe_ratio > 1.0 and max_drawdown < 0.15 and total_return > 0.05:
            recommendation_type = "BUY"
            confidence = 0.7
            reasoning = "Good risk-adjusted returns with acceptable drawdown"
        elif sharpe_ratio > 0.5 and max_drawdown < 0.2:
            recommendation_type = "HOLD"
            confidence = 0.6
            reasoning = "Moderate performance with manageable risk"
        elif total_return > 0 and max_drawdown < 0.25:
            recommendation_type = "WEAK_HOLD"
            confidence = 0.4
            reasoning = "Positive returns but with concerns about risk management"
        else:
            recommendation_type = "AVOID"
            confidence = 0.8
            reasoning = "Poor risk-adjusted returns or excessive drawdown"
        
        return {
            'type': recommendation_type,
            'confidence': confidence,
            'reasoning': reasoning,
            'key_metrics': {
                'sharpe_ratio': sharpe_ratio,
                'max_drawdown': max_drawdown,
                'total_return': total_return,
                'win_rate': win_rate
            }
        }
    
    def _calculate_confidence_score(self, performance_metrics: Dict[str, float]) -> float:
        """Calculate a confidence score for the simulation results."""
        # Simple confidence calculation based on multiple factors
        sharpe_ratio = performance_metrics.get('sharpe_ratio', 0)
        total_trades = performance_metrics.get('total_trades', 0)
        win_rate = performance_metrics.get('win_rate', 0)
        
        # Base confidence on Sharpe ratio
        confidence = min(abs(sharpe_ratio) / 2.0, 1.0)
        
        # Adjust for number of trades (more trades = more confidence in statistics)
        if total_trades > 50:
            confidence *= 1.1
        elif total_trades < 10:
            confidence *= 0.7
        
        # Adjust for win rate
        if 0.4 <= win_rate <= 0.6:  # Balanced win rate
            confidence *= 1.05
        elif win_rate < 0.3 or win_rate > 0.8:  # Extreme win rates might be less reliable
            confidence *= 0.9
        
        return min(confidence, 1.0)
    
    def send_feedback_to_rl_agent(self, 
                                 agent_id: str,
                                 feedback_data: FeedbackData) -> Dict[str, Any]:
        """Send feedback from CrewAI to the RL agent."""
        try:
            payload = {
                'feedback_type': feedback_data.feedback_type,
                'feedback_data': feedback_data.feedback_data
            }
            
            response = requests.post(
                f"{self.rl_agent_base_url}/api/rl/agents/{agent_id}/feedback",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Track feedback
                self.feedback_history.append({
                    'timestamp': feedback_data.timestamp,
                    'type': feedback_data.feedback_type,
                    'source': feedback_data.source_agent,
                    'success': True
                })
                
                self.performance_metrics['total_feedback_sent'] += 1
                self._log_communication('send_feedback', payload, True)
                
                logger.info(f"Successfully sent feedback to RL agent {agent_id}")
                return result
                
            else:
                error_msg = f"Failed to send feedback: {response.text}"
                logger.error(error_msg)
                self._log_communication('send_feedback', payload, False)
                return {'error': error_msg}
                
        except Exception as e:
            error_msg = f"Error sending feedback: {e}"
            logger.error(error_msg)
            self._log_communication('send_feedback', feedback_data.__dict__, False)
            return {'error': error_msg}
    
    def get_learned_rules_from_rl_agent(self, agent_id: str) -> Dict[str, Any]:
        """Get learned rules from the RL agent for CrewAI knowledge enhancement."""
        try:
            response = requests.get(
                f"{self.rl_agent_base_url}/api/rl/agents/{agent_id}/learned_rules",
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_communication('get_learned_rules', {'agent_id': agent_id}, True)
                
                # Format rules for CrewAI consumption
                formatted_rules = self._format_learned_rules_for_crewai(result)
                
                logger.info(f"Successfully retrieved learned rules from RL agent {agent_id}")
                return formatted_rules
                
            else:
                error_msg = f"Failed to get learned rules: {response.text}"
                logger.error(error_msg)
                self._log_communication('get_learned_rules', {'agent_id': agent_id}, False)
                return {'error': error_msg}
                
        except Exception as e:
            error_msg = f"Error getting learned rules: {e}"
            logger.error(error_msg)
            self._log_communication('get_learned_rules', {'agent_id': agent_id}, False)
            return {'error': error_msg}
    
    def _format_learned_rules_for_crewai(self, rl_result: Dict[str, Any]) -> Dict[str, Any]:
        """Format learned rules from RL agent for CrewAI knowledge base."""
        learned_rules = rl_result.get('learned_rules', [])
        
        # Categorize rules by confidence and type
        high_confidence_rules = [rule for rule in learned_rules if rule.get('confidence', 0) > 0.7]
        medium_confidence_rules = [rule for rule in learned_rules if 0.5 <= rule.get('confidence', 0) <= 0.7]
        low_confidence_rules = [rule for rule in learned_rules if rule.get('confidence', 0) < 0.5]
        
        # Create actionable insights for CrewAI agents
        actionable_insights = []
        for rule in high_confidence_rules:
            insight = {
                'insight': rule.get('description', ''),
                'confidence': rule.get('confidence', 0),
                'applicable_agents': self._determine_applicable_agents(rule),
                'implementation_suggestion': self._generate_implementation_suggestion(rule)
            }
            actionable_insights.append(insight)
        
        formatted_result = {
            'total_rules': len(learned_rules),
            'high_confidence_rules': high_confidence_rules,
            'medium_confidence_rules': medium_confidence_rules,
            'actionable_insights': actionable_insights,
            'extraction_timestamp': rl_result.get('timestamp'),
            'rl_agent_id': rl_result.get('agent_id'),
            'knowledge_update_recommendations': self._generate_knowledge_update_recommendations(learned_rules)
        }
        
        return formatted_result
    
    def _determine_applicable_agents(self, rule: Dict[str, Any]) -> List[str]:
        """Determine which CrewAI agents could benefit from a learned rule."""
        rule_description = rule.get('description', '').lower()
        applicable_agents = []
        
        if 'risk' in rule_description or 'drawdown' in rule_description:
            applicable_agents.append('Risk Assessment Agent')
        
        if 'sharpe' in rule_description or 'return' in rule_description:
            applicable_agents.extend(['Fundamental Research Agent', 'Trade & Strategy Planner Agent'])
        
        if 'transaction' in rule_description or 'cost' in rule_description:
            applicable_agents.append('Trade & Strategy Planner Agent')
        
        if 'timing' in rule_description or 'entry' in rule_description or 'exit' in rule_description:
            applicable_agents.append('Timing Agent')
        
        if not applicable_agents:
            applicable_agents.append('All Agents')
        
        return applicable_agents
    
    def _generate_implementation_suggestion(self, rule: Dict[str, Any]) -> str:
        """Generate implementation suggestions for CrewAI agents based on learned rules."""
        rule_description = rule.get('description', '').lower()
        
        if 'risk' in rule_description:
            return "Consider incorporating this risk management insight into position sizing and stop-loss strategies."
        elif 'return' in rule_description:
            return "Use this return pattern to refine expected return calculations and strategy recommendations."
        elif 'transaction' in rule_description:
            return "Factor this cost consideration into trade frequency and position sizing recommendations."
        else:
            return "Evaluate how this insight can enhance current analysis and recommendation processes."
    
    def _generate_knowledge_update_recommendations(self, learned_rules: List[Dict[str, Any]]) -> List[str]:
        """Generate recommendations for updating CrewAI knowledge base."""
        recommendations = []
        
        high_confidence_count = sum(1 for rule in learned_rules if rule.get('confidence', 0) > 0.7)
        
        if high_confidence_count > 0:
            recommendations.append(f"Update knowledge base with {high_confidence_count} high-confidence insights from RL agent")
        
        risk_rules = [rule for rule in learned_rules if 'risk' in rule.get('description', '').lower()]
        if risk_rules:
            recommendations.append("Review and update risk management protocols based on RL agent learnings")
        
        return_rules = [rule for rule in learned_rules if 'return' in rule.get('description', '').lower()]
        if return_rules:
            recommendations.append("Consider updating return expectation models with RL agent insights")
        
        if not recommendations:
            recommendations.append("No immediate knowledge base updates recommended")
        
        return recommendations
    
    def _update_average_response_time(self, new_response_time: float):
        """Update the average response time metric."""
        current_avg = self.performance_metrics['average_response_time']
        total_sims = self.performance_metrics['total_strategy_simulations']
        
        if total_sims == 1:
            self.performance_metrics['average_response_time'] = new_response_time
        else:
            # Calculate running average
            self.performance_metrics['average_response_time'] = (
                (current_avg * (total_sims - 1) + new_response_time) / total_sims
            )
    
    def get_integration_status(self) -> Dict[str, Any]:
        """Get the current status of the integration service."""
        return {
            'rl_agent_healthy': self.check_rl_agent_health(),
            'crewai_healthy': self.check_crewai_health(),
            'performance_metrics': self.performance_metrics,
            'recent_communications': self.communication_history[-10:],  # Last 10 communications
            'recent_feedback': self.feedback_history[-10:],  # Last 10 feedback entries
            'service_uptime': datetime.now().isoformat()
        }
    
    async def async_simulate_strategy(self, strategy_request: StrategyRequest) -> Dict[str, Any]:
        """Asynchronous version of strategy simulation for better performance."""
        start_time = datetime.now()
        
        try:
            payload = {
                'strategy_description': strategy_request.strategy_description,
                'symbol': strategy_request.symbol,
                'start_date': strategy_request.start_date,
                'end_date': strategy_request.end_date,
                'initial_balance': strategy_request.initial_balance
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.rl_agent_base_url}/api/rl/agents/{strategy_request.agent_id}/simulate_strategy",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=60)
                ) as response:
                    
                    response_time = (datetime.now() - start_time).total_seconds()
                    
                    if response.status == 200:
                        result = await response.json()
                        
                        # Update metrics
                        self.performance_metrics['total_strategy_simulations'] += 1
                        self.performance_metrics['successful_simulations'] += 1
                        self._update_average_response_time(response_time)
                        
                        # Format and return result
                        formatted_result = self._format_simulation_result_for_crewai(result, strategy_request)
                        logger.info(f"Successfully simulated strategy (async) for {strategy_request.requester_agent}")
                        return formatted_result
                    
                    else:
                        error_text = await response.text()
                        error_msg = f"RL agent simulation failed: {error_text}"
                        logger.error(error_msg)
                        
                        self.performance_metrics['total_strategy_simulations'] += 1
                        
                        return {
                            'success': False,
                            'error': error_msg,
                            'strategy_request': strategy_request.__dict__
                        }
        
        except Exception as e:
            error_msg = f"Error during async strategy simulation: {e}"
            logger.error(error_msg)
            
            self.performance_metrics['total_strategy_simulations'] += 1
            
            return {
                'success': False,
                'error': error_msg,
                'strategy_request': strategy_request.__dict__
            }

