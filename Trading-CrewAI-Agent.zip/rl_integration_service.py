"""
RL Integration Service for CrewAI Advisory Agent
Handles communication with the RL Trading Agent for strategy validation and feedback.
"""

import requests
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class StrategyValidationRequest:
    """Data class for strategy validation requests to RL agent."""
    strategy_description: str
    symbol: str
    timeframe: str
    confidence: float
    requesting_agent: str
    additional_context: Dict[str, Any] = None


@dataclass
class PerformanceFeedback:
    """Data class for performance feedback to RL agent."""
    metrics: Dict[str, float]
    benchmark_comparison: Dict[str, float]
    risk_assessment: Dict[str, Any]
    recommendations: List[str]


class RLIntegrationService:
    """
    Service for integrating CrewAI Advisory Agent with RL Trading Agent.
    
    This service enables the main advisory agent to:
    1. Request strategy simulations from the RL agent
    2. Send performance feedback to the RL agent
    3. Retrieve learned insights from the RL agent
    4. Signal market regime changes to the RL agent
    """
    
    def __init__(self, rl_agent_url: str = "http://localhost:5000"):
        """
        Initialize the RL integration service.
        
        Args:
            rl_agent_url: Base URL for the RL Trading Agent API
        """
        self.rl_agent_url = rl_agent_url.rstrip('/')
        self.integration_history = []
        self.last_learned_rules = None
        self.last_rules_update = None
        
    def _log_interaction(self, action: str, data: Dict[str, Any], success: bool = True):
        """Log interactions for monitoring and debugging."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'success': success,
            'data_summary': {k: str(v)[:100] for k, v in data.items()}
        }
        self.integration_history.append(log_entry)
        
        # Keep only last 50 entries
        if len(self.integration_history) > 50:
            self.integration_history = self.integration_history[-50:]
    
    def check_rl_agent_availability(self) -> bool:
        """Check if the RL agent is available and responsive."""
        try:
            response = requests.get(
                f"{self.rl_agent_url}/api/integration/health",
                timeout=5
            )
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"RL agent not available: {e}")
            return False
    
    def validate_strategy_with_rl_agent(self, 
                                      validation_request: StrategyValidationRequest,
                                      start_date: str = None,
                                      end_date: str = None) -> Dict[str, Any]:
        """
        Request strategy validation from the RL agent.
        
        This method is called by CrewAI agents (e.g., Technical Analysis Agent,
        Strategy Planner Agent) to validate their proposed strategies.
        """
        try:
            # Set default date range if not provided
            if not end_date:
                end_date = datetime.now().strftime('%Y-%m-%d')
            if not start_date:
                start_date = (datetime.now() - timedelta(days=365)).strftime('%Y-%m-%d')
            
            # Prepare request payload
            payload = {
                'strategy_description': validation_request.strategy_description,
                'symbol': validation_request.symbol,
                'start_date': start_date,
                'end_date': end_date,
                'initial_balance': 100000.0,
                'agent_id': 'main_rl_agent',
                'requester_agent': validation_request.requesting_agent
            }
            
            # Send request to RL agent
            response = requests.post(
                f"{self.rl_agent_url}/api/integration/crewai/simulate_strategy",
                json=payload,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_interaction('validate_strategy', payload, True)
                
                # Format result for CrewAI consumption
                formatted_result = self._format_validation_result(result, validation_request)
                
                logger.info(f"Strategy validation completed for {validation_request.requesting_agent}")
                return formatted_result
            
            else:
                error_msg = f"Strategy validation failed: {response.text}"
                logger.error(error_msg)
                self._log_interaction('validate_strategy', payload, False)
                
                return {
                    'success': False,
                    'error': error_msg,
                    'fallback_recommendation': self._generate_fallback_recommendation(validation_request)
                }
        
        except Exception as e:
            error_msg = f"Error during strategy validation: {e}"
            logger.error(error_msg)
            self._log_interaction('validate_strategy', validation_request.__dict__, False)
            
            return {
                'success': False,
                'error': error_msg,
                'fallback_recommendation': self._generate_fallback_recommendation(validation_request)
            }
    
    def _format_validation_result(self, 
                                rl_result: Dict[str, Any], 
                                validation_request: StrategyValidationRequest) -> Dict[str, Any]:
        """Format RL agent validation result for CrewAI agents."""
        if not rl_result.get('success', True):
            return rl_result
        
        performance_metrics = rl_result.get('performance_metrics', {})
        recommendation = rl_result.get('recommendation', {})
        
        # Create comprehensive validation result
        validation_result = {
            'success': True,
            'strategy_validation': {
                'original_strategy': validation_request.strategy_description,
                'symbol': validation_request.symbol,
                'requesting_agent': validation_request.requesting_agent,
                'validation_timestamp': datetime.now().isoformat()
            },
            'rl_performance_analysis': {
                'total_return': performance_metrics.get('total_return', 0),
                'annualized_return': performance_metrics.get('annualized_return', 0),
                'sharpe_ratio': performance_metrics.get('sharpe_ratio', 0),
                'max_drawdown': performance_metrics.get('max_drawdown', 0),
                'volatility': performance_metrics.get('volatility', 0),
                'win_rate': performance_metrics.get('win_rate', 0),
                'total_trades': performance_metrics.get('total_trades', 0)
            },
            'rl_recommendation': {
                'action': recommendation.get('type', 'HOLD'),
                'confidence': recommendation.get('confidence', 0.5),
                'reasoning': recommendation.get('reasoning', 'No specific reasoning provided'),
                'key_factors': recommendation.get('key_metrics', {})
            },
            'integration_insights': {
                'rl_agent_confidence': rl_result.get('confidence_score', 0.5),
                'action_distribution': rl_result.get('action_distribution', {}),
                'sample_explanations': rl_result.get('sample_explanations', [])[:3]  # Top 3 explanations
            },
            'advisory_recommendations': self._generate_advisory_recommendations(performance_metrics, recommendation)
        }
        
        return validation_result
    
    def _generate_advisory_recommendations(self, 
                                         performance_metrics: Dict[str, float],
                                         rl_recommendation: Dict[str, Any]) -> List[str]:
        """Generate advisory recommendations based on RL agent results."""
        recommendations = []
        
        sharpe_ratio = performance_metrics.get('sharpe_ratio', 0)
        max_drawdown = performance_metrics.get('max_drawdown', 0)
        total_return = performance_metrics.get('total_return', 0)
        win_rate = performance_metrics.get('win_rate', 0)
        
        # Performance-based recommendations
        if sharpe_ratio > 1.5:
            recommendations.append("Excellent risk-adjusted returns - consider increasing position size")
        elif sharpe_ratio < 0.5:
            recommendations.append("Poor risk-adjusted returns - consider strategy refinement")
        
        if max_drawdown > 0.2:
            recommendations.append("High drawdown risk - implement stronger risk management")
        elif max_drawdown < 0.05:
            recommendations.append("Low drawdown - strategy shows good risk control")
        
        if win_rate > 0.7:
            recommendations.append("High win rate - consider momentum-based enhancements")
        elif win_rate < 0.4:
            recommendations.append("Low win rate - review entry/exit criteria")
        
        # RL recommendation integration
        rl_action = rl_recommendation.get('type', 'HOLD')
        if rl_action == 'STRONG_BUY':
            recommendations.append("RL agent strongly recommends this strategy - consider implementation")
        elif rl_action == 'AVOID':
            recommendations.append("RL agent advises against this strategy - seek alternatives")
        
        if not recommendations:
            recommendations.append("Strategy shows mixed results - proceed with caution")
        
        return recommendations
    
    def _generate_fallback_recommendation(self, 
                                        validation_request: StrategyValidationRequest) -> Dict[str, Any]:
        """Generate fallback recommendation when RL agent is unavailable."""
        return {
            'action': 'HOLD',
            'confidence': 0.3,
            'reasoning': 'RL agent unavailable - using conservative fallback recommendation',
            'recommendations': [
                'RL validation service unavailable',
                'Proceed with enhanced caution',
                'Consider manual backtesting',
                'Monitor RL agent availability for future validations'
            ]
        }
    
    def send_performance_feedback(self, 
                                feedback: PerformanceFeedback,
                                agent_id: str = 'main_rl_agent') -> Dict[str, Any]:
        """
        Send performance feedback to the RL agent.
        
        This method is called by the Risk Assessment Agent to provide
        performance feedback to the RL agent for continuous learning.
        """
        try:
            payload = {
                'agent_id': agent_id,
                'performance_metrics': feedback.metrics,
                'benchmark_comparison': feedback.benchmark_comparison,
                'source_agent': 'Risk Assessment Agent'
            }
            
            response = requests.post(
                f"{self.rl_agent_url}/api/integration/crewai/performance_feedback",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_interaction('send_performance_feedback', payload, True)
                
                logger.info("Performance feedback sent successfully to RL agent")
                return {
                    'success': True,
                    'message': 'Performance feedback delivered to RL agent',
                    'rl_response': result
                }
            
            else:
                error_msg = f"Failed to send performance feedback: {response.text}"
                logger.error(error_msg)
                self._log_interaction('send_performance_feedback', payload, False)
                
                return {
                    'success': False,
                    'error': error_msg
                }
        
        except Exception as e:
            error_msg = f"Error sending performance feedback: {e}"
            logger.error(error_msg)
            self._log_interaction('send_performance_feedback', feedback.__dict__, False)
            
            return {
                'success': False,
                'error': error_msg
            }
    
    def signal_market_regime_change(self, 
                                  regime: str,
                                  confidence: float,
                                  indicators: Dict[str, Any],
                                  source_agent: str = 'Macroeconomy Specialist Agent',
                                  agent_id: str = 'main_rl_agent') -> Dict[str, Any]:
        """
        Signal market regime change to the RL agent.
        
        This method is called by the Macroeconomy Specialist Agent or
        Sentiment Analysis Agent to inform the RL agent about market regime changes.
        """
        try:
            payload = {
                'agent_id': agent_id,
                'regime': regime,
                'confidence': confidence,
                'indicators': indicators,
                'source_agent': source_agent
            }
            
            response = requests.post(
                f"{self.rl_agent_url}/api/integration/crewai/market_regime_signal",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_interaction('signal_market_regime', payload, True)
                
                logger.info(f"Market regime signal sent: {regime} (confidence: {confidence})")
                return {
                    'success': True,
                    'message': f'Market regime change ({regime}) signaled to RL agent',
                    'rl_response': result
                }
            
            else:
                error_msg = f"Failed to send market regime signal: {response.text}"
                logger.error(error_msg)
                self._log_interaction('signal_market_regime', payload, False)
                
                return {
                    'success': False,
                    'error': error_msg
                }
        
        except Exception as e:
            error_msg = f"Error sending market regime signal: {e}"
            logger.error(error_msg)
            self._log_interaction('signal_market_regime', {'regime': regime}, False)
            
            return {
                'success': False,
                'error': error_msg
            }
    
    def get_learned_insights(self, agent_id: str = 'main_rl_agent') -> Dict[str, Any]:
        """
        Retrieve learned insights from the RL agent.
        
        This method is called periodically to update the CrewAI knowledge base
        with insights learned by the RL agent.
        """
        try:
            response = requests.get(
                f"{self.rl_agent_url}/api/integration/crewai/learned_rules",
                params={'agent_id': agent_id},
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_interaction('get_learned_insights', {'agent_id': agent_id}, True)
                
                # Cache the results
                self.last_learned_rules = result.get('learned_rules', {})
                self.last_rules_update = datetime.now()
                
                logger.info("Successfully retrieved learned insights from RL agent")
                return {
                    'success': True,
                    'learned_insights': self.last_learned_rules,
                    'update_timestamp': self.last_rules_update.isoformat(),
                    'knowledge_updates': self._process_learned_insights(self.last_learned_rules)
                }
            
            else:
                error_msg = f"Failed to get learned insights: {response.text}"
                logger.error(error_msg)
                self._log_interaction('get_learned_insights', {'agent_id': agent_id}, False)
                
                return {
                    'success': False,
                    'error': error_msg,
                    'cached_insights': self.last_learned_rules if self.last_learned_rules else {}
                }
        
        except Exception as e:
            error_msg = f"Error getting learned insights: {e}"
            logger.error(error_msg)
            self._log_interaction('get_learned_insights', {'agent_id': agent_id}, False)
            
            return {
                'success': False,
                'error': error_msg,
                'cached_insights': self.last_learned_rules if self.last_learned_rules else {}
            }
    
    def _process_learned_insights(self, learned_rules: Dict[str, Any]) -> Dict[str, List[str]]:
        """Process learned insights and generate knowledge updates for different agents."""
        if not learned_rules:
            return {}
        
        knowledge_updates = {
            'Technical Analysis Agent': [],
            'Risk Assessment Agent': [],
            'Timing Agent': [],
            'Strategy Planner Agent': [],
            'All Agents': []
        }
        
        # Process actionable insights
        actionable_insights = learned_rules.get('actionable_insights', [])
        
        for insight in actionable_insights:
            insight_text = insight.get('insight', '')
            applicable_agents = insight.get('applicable_agents', ['All Agents'])
            implementation = insight.get('implementation_suggestion', '')
            
            update_text = f"{insight_text} - {implementation}"
            
            for agent in applicable_agents:
                if agent in knowledge_updates:
                    knowledge_updates[agent].append(update_text)
        
        # Process high confidence rules
        high_confidence_rules = learned_rules.get('high_confidence_rules', [])
        
        for rule in high_confidence_rules:
            rule_description = rule.get('description', '')
            confidence = rule.get('confidence', 0)
            
            update_text = f"High confidence insight (confidence: {confidence:.2f}): {rule_description}"
            knowledge_updates['All Agents'].append(update_text)
        
        return knowledge_updates
    
    def request_rl_prediction(self, 
                            observation: List[float],
                            requesting_agent: str,
                            agent_id: str = 'main_rl_agent') -> Dict[str, Any]:
        """
        Request action prediction from the RL agent.
        
        This method can be called by the Timing Agent to get RL-based
        timing recommendations.
        """
        try:
            payload = {
                'agent_id': agent_id,
                'observation': observation,
                'deterministic': True,
                'requester_agent': requesting_agent
            }
            
            response = requests.post(
                f"{self.rl_agent_url}/api/integration/crewai/predict",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_interaction('request_prediction', payload, True)
                
                prediction = result.get('prediction', {})
                
                formatted_result = {
                    'success': True,
                    'rl_prediction': {
                        'action': prediction.get('action_name', 'HOLD'),
                        'confidence': prediction.get('confidence', 0.5),
                        'explanation': prediction.get('explanation', 'No explanation provided'),
                        'raw_action': prediction.get('action', 0)
                    },
                    'requesting_agent': requesting_agent,
                    'timestamp': prediction.get('timestamp', datetime.now().isoformat())
                }
                
                logger.info(f"RL prediction provided to {requesting_agent}")
                return formatted_result
            
            else:
                error_msg = f"Failed to get RL prediction: {response.text}"
                logger.error(error_msg)
                self._log_interaction('request_prediction', payload, False)
                
                return {
                    'success': False,
                    'error': error_msg,
                    'fallback_prediction': {
                        'action': 'HOLD',
                        'confidence': 0.3,
                        'explanation': 'RL agent unavailable - using conservative fallback'
                    }
                }
        
        except Exception as e:
            error_msg = f"Error requesting RL prediction: {e}"
            logger.error(error_msg)
            self._log_interaction('request_prediction', {'requesting_agent': requesting_agent}, False)
            
            return {
                'success': False,
                'error': error_msg,
                'fallback_prediction': {
                    'action': 'HOLD',
                    'confidence': 0.3,
                    'explanation': 'Error occurred - using conservative fallback'
                }
            }
    
    def get_integration_status(self) -> Dict[str, Any]:
        """Get the current status of the RL integration."""
        return {
            'rl_agent_available': self.check_rl_agent_availability(),
            'last_rules_update': self.last_rules_update.isoformat() if self.last_rules_update else None,
            'cached_rules_count': len(self.last_learned_rules) if self.last_learned_rules else 0,
            'recent_interactions': self.integration_history[-5:],  # Last 5 interactions
            'integration_health': 'healthy' if self.check_rl_agent_availability() else 'degraded'
        }
    
    def run_strategy_backtest(self, 
                            strategy_description: str,
                            symbol: str,
                            start_date: str,
                            end_date: str,
                            requesting_agent: str,
                            agent_id: str = 'main_rl_agent') -> Dict[str, Any]:
        """
        Run a backtest for a specific strategy using the RL agent.
        
        This method provides more detailed backtesting capabilities
        for strategy evaluation.
        """
        try:
            payload = {
                'agent_id': agent_id,
                'start_date': start_date,
                'end_date': end_date,
                'requester_agent': requesting_agent
            }
            
            response = requests.post(
                f"{self.rl_agent_url}/api/integration/crewai/backtest",
                json=payload,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                self._log_interaction('run_backtest', payload, True)
                
                backtest_results = result.get('backtest_results', {})
                
                formatted_result = {
                    'success': True,
                    'backtest_summary': {
                        'strategy': strategy_description,
                        'symbol': symbol,
                        'period': f"{start_date} to {end_date}",
                        'requesting_agent': requesting_agent
                    },
                    'performance_metrics': backtest_results.get('stats', {}),
                    'final_portfolio_value': backtest_results.get('final_portfolio_value', 0),
                    'total_actions': backtest_results.get('total_actions', 0),
                    'timestamp': result.get('timestamp', datetime.now().isoformat())
                }
                
                logger.info(f"Backtest completed for {requesting_agent}")
                return formatted_result
            
            else:
                error_msg = f"Backtest failed: {response.text}"
                logger.error(error_msg)
                self._log_interaction('run_backtest', payload, False)
                
                return {
                    'success': False,
                    'error': error_msg
                }
        
        except Exception as e:
            error_msg = f"Error running backtest: {e}"
            logger.error(error_msg)
            self._log_interaction('run_backtest', {'strategy': strategy_description}, False)
            
            return {
                'success': False,
                'error': error_msg
            }

