from typing import Optional, Dict, Any

class MarketDataAdapter:
    """Abstract adapter for broker market data.
    Implement ws_connect(), poll_price(symbol), and close().
    """
    name: str = "base"

    def ws_connect(self) -> bool:  # pragma: no cover - to be implemented
        return False

    def poll_price(self, symbol: str) -> Optional[float]:  # pragma: no cover
        return None

    def close(self) -> None:  # pragma: no cover
        pass

    def info(self) -> Dict[str, Any]:
        return {"name": self.name, "ws": False}
