# RL Agent v2

> **Sources**: `RL_Agent/rl_agent_v2.py`, `RL_Agent/portfolio_trading_env.py`,  
> `RL_Agent/regime_classifier.py`, `RL_Agent/risk_metrics.py`  
> **Phase**: RL v2 (added after Phase 6)

---

## Overview

RL Agent v2 is a self-contained reinforcement-learning module that:

1. **Trains** a PPO or SAC policy on historical multi-asset portfolio data
2. **Classifies** the current market regime (Bull/Bear/Sideways/High-Vol)
3. **Validates** a synthesis recommendation with risk-adjusted position sizing
4. **Outputs** a `ValidationResult` with per-asset confidence bands and a no-trade override flag

```mermaid
flowchart TD
    HD[Historical price data] --> ENV[PortfolioTradingEnv]
    ENV --> PPO[PPO / SAC policy\noffline_train]
    PPO --> CKPT[.zip checkpoint]
    CKPT --> VA[validate_strategy]
    SYNTH[synthesis_text\nmarket_results\ncurrent_weights] --> VA
    VA --> VR[ValidationResult]
    VR --> ACB[analysis_crew_builder\nrl_a2a_validate_v2]
    ACB --> ANN[Annotated synthesis]
```

---

## Module layout

| File | Exports |
|------|---------|
| `RL_Agent/risk_metrics.py` | `RiskSnapshot`, `compute_sharpe`, `compute_max_drawdown`, `compute_var_historical`, `compute_cvar`, `compute_turnover`, `compute_calmar`, `risk_aware_reward`, `build_risk_snapshot` |
| `RL_Agent/regime_classifier.py` | `MarketRegime`, `RegimeClassifier` |
| `RL_Agent/portfolio_trading_env.py` | `PortfolioTradingEnv` |
| `RL_Agent/rl_agent_v2.py` | `RLAgentV2`, `ValidationResult`, `PositionRecommendation` |
| `RL_Agent/__init__.py` | All of the above + v1 backward-compat aliases |

---

## Risk Metrics (`risk_metrics.py`)

### `RiskSnapshot` dataclass

```python
@dataclass
class RiskSnapshot:
    sharpe: float
    max_drawdown: float
    var_95: float
    cvar_95: float
    turnover: float
    calmar: float
```

### Risk-aware reward formula

$$R = r_p \times 100 - \lambda_{dd} \cdot \max(0,\, dd - 0.10) - \lambda_{tc} \cdot |t| - \lambda_{var} \cdot \max(0,\, v) + \lambda_{sh} \cdot S \times 0.1$$

Where:

| Symbol | Meaning | Default |
|--------|---------|---------|
| $r_p$ | Portfolio return for the step | — |
| $dd$ | Rolling max drawdown | — |
| $t$ | Turnover (sum of absolute weight deltas) | — |
| $v$ | VaR breach amount (positive when loss > VaR) | — |
| $S$ | Rolling Sharpe ratio | — |
| $\lambda_{dd}$ | Drawdown penalty weight | 2.0 |
| $\lambda_{tc}$ | Transaction cost penalty weight | 0.001 |
| $\lambda_{var}$ | VaR breach penalty weight | 3.0 |
| $\lambda_{sh}$ | Sharpe bonus weight | 0.5 |
| 0.10 | Drawdown-free zone (10%) | fixed |

### Function signatures

```python
compute_sharpe(returns, risk_free=0.0, annualize=True, periods_per_year=252) → float
compute_max_drawdown(portfolio_values) → float            # positive fraction, e.g. 0.082
compute_var_historical(returns, confidence=0.95) → float  # positive loss, e.g. 0.018
compute_cvar(returns, confidence=0.95) → float            # conditional (tail) loss
compute_turnover(weights_old, weights_new) → float        # sum |Δw|
compute_calmar(portfolio_values) → float                  # annualised return / max_drawdown

risk_aware_reward(
    portfolio_return, drawdown, turnover, var_breach, rolling_sharpe,
    *, lambda_dd=2.0, lambda_tc=0.001, lambda_var=3.0, lambda_sharpe=0.5,
    drawdown_free_zone=0.10,
) → float

build_risk_snapshot(
    returns_history,    # list of per-step portfolio returns
    portfolio_values,   # list of cumulative portfolio values
    weights_old,        # previous asset weights (numpy array)
    weights_new,        # proposed asset weights (numpy array)
) → RiskSnapshot
```

---

## Regime Classifier (`regime_classifier.py`)

### `MarketRegime` enum

```python
class MarketRegime(IntEnum):
    BULL     = 0
    BEAR     = 1
    SIDEWAYS = 2
    HIGH_VOL = 3
```

### `RegimeClassifier`

```python
RegimeClassifier(
    vol_lookback: int = 20,            # rolling vol window
    trend_lookback: int = 20,          # cumulative return window for BULL/BEAR
    high_vol_multiplier: float = 2.0,  # ratio of recent vol to historical vol
    bull_threshold: float = 0.05,      # min cumulative return for BULL (+5%)
    bear_threshold: float = -0.05,     # max cumulative return for BEAR (-5%)
    history_lookback: int = 252,       # baseline vol lookback (1 year)
    min_persistence: int = 3,          # consecutive signals before regime changes
)
```

### Classification algorithm (two-pass)

**Pass 1 — Volatility gate**:

$$\text{rolling\_vol} = \text{std}(\Delta\ln P_{t-20:t}) \times \sqrt{252}$$
$$\text{hist\_vol} = \text{std}(\Delta\ln P_{t-252:t}) \times \sqrt{252}$$

If $\text{rolling\_vol} \ge 2 \times \text{hist\_vol}$ → **HIGH_VOL**

**Pass 2 — Trend gate** (only if not HIGH_VOL):

$$\text{cumret} = \frac{P_t - P_{t-20}}{P_{t-20}}$$

| Condition | Regime |
|-----------|--------|
| $\text{cumret} \ge 0.05$ | **BULL** |
| $\text{cumret} \le -0.05$ | **BEAR** |
| otherwise | **SIDEWAYS** |

**Min-persistence filter**: a new regime signal must appear for at least
`min_persistence=3` consecutive steps before the classifier confirms the regime change.

### Methods

```python
classify(prices: np.ndarray) → MarketRegime
classify_multi_asset(prices_dict: Dict[str, np.ndarray]) → MarketRegime  # majority vote
to_one_hot(regime: MarketRegime) → np.ndarray   # shape (4,)
reset()                                          # clear persistence state
```

---

## Portfolio Trading Environment (`portfolio_trading_env.py`)

### `PortfolioTradingEnv(gym.Env)`

```python
PortfolioTradingEnv(
    symbols: List[str],
    initial_balance: float = 100_000,
    lookback: int = 20,
    max_weight_per_asset: float = 0.40,
    max_delta: float = 0.20,            # max weight change per step
    transaction_cost: float = 0.001,    # 0.1% per trade
    max_drawdown: float = 0.25,         # kill-switch at 25% drawdown
    start_date: str = None,
    end_date: str = None,
    data_dict: Optional[Dict[str, pd.DataFrame]] = None,   # mock-data mode
    regime_classifier: Optional[RegimeClassifier] = None,
    reward_kwargs: Optional[dict] = None,   # override risk_aware_reward params
)
```

### Observation space

Shape: `(n_assets × lookback × 11  +  n_assets  +  4  +  5,)`

For defaults (5 assets, lookback=20):  
$(5 \times 20 \times 11) + 5 + 4 + 5 = 1100 + 14 = 1114$

**11 per-asset features** (`_N_FEATURES = 11`):

| Index | Feature | Description |
|-------|---------|-------------|
| 0 | `Close_norm` | Normalised close price |
| 1 | `High_norm` | Normalised high |
| 2 | `Low_norm` | Normalised low |
| 3 | `Volume_norm` | Normalised volume |
| 4 | `SMA5` | 5-period simple moving average |
| 5 | `SMA20` | 20-period simple moving average |
| 6 | `RSI` | 14-period RSI (normalised to [0,1]) |
| 7 | `MACD` | MACD signal |
| 8 | `ATR` | Average True Range |
| 9 | `BB_width` | Bollinger Band width |
| 10 | `Price_chg5` | 5-period price change |

**Portfolio state** (appended to obs):
- `n_assets` current weights
- `4` regime one-hot
- `5`: cash fraction, portfolio return, rolling Sharpe, max_drawdown, step normalised

### Action space

`Box(-max_delta, max_delta, shape=(n_assets,), dtype=float32)`

Weight adjustments are clipped, then normalised to sum to 1 (remaining allocated to cash).

### Drawdown kill-switch

When `portfolio_value` drops below `initial_balance × (1 - max_drawdown)`,
the episode ends immediately with `terminated=True` and a large negative reward penalty.

---

## `RLAgentV2`

```python
RLAgentV2(
    symbols: List[str],
    algorithm: str = "PPO",          # "PPO" or "SAC"
    device: str = "cpu",
    lookback: int = 20,
    max_weight_per_asset: float = 0.40,
    uncertainty_threshold: float = 0.30,   # entropy above this triggers no-trade
    n_envs: int = 1,                        # parallel envs (DummyVecEnv)
    env_kwargs: Optional[dict] = None,
)
```

### Training pipeline

```python
# 1. Train offline on historical data
result = agent.offline_train(
    start_date="2020-01-01",
    end_date="2024-12-31",
    n_timesteps=200_000,
    data_dict=None,           # None = fetch from yfinance
    verbose=1,
)
# result = {"mean_reward": float, "std_reward": float, "n_timesteps": int}

# 2. Save checkpoint
agent.save("checkpoints/portfolio_v2.zip")

# 3. Load and continue training (online finetune)
loaded = RLAgentV2.load("checkpoints/portfolio_v2.zip", symbols=["^NSEI", ...])
loaded.online_finetune(experience=experience_buffer, n_update_steps=1024)
```

**PPO hyperparameters** (defaults):

| Param | Value |
|-------|-------|
| `net_arch` | `[256, 256, 128]` |
| `learning_rate` | `3e-4` |
| `n_steps` | `2048` |
| `batch_size` | `64` |
| `n_epochs` | `10` |
| `gamma` | `0.99` |

**Online finetune**: skips update if experience buffer < 64 samples; reduces lr to `1e-4`.

### `validate_strategy(...) → ValidationResult`

```python
result = agent.validate_strategy(
    synthesis_text: str,                     # advisory synthesis text
    market_context: Dict[str, Any],          # market_results from flow
    current_weights: Optional[Dict[str, float]] = None,  # current IBKR positions
) → ValidationResult
```

### `ValidationResult` dataclass

```python
@dataclass
class ValidationResult:
    regime: MarketRegime                            # detected regime
    positions: List[PositionRecommendation]         # per-asset recommendations
    portfolio_confidence: float                     # mean action confidence
    no_trade_override: bool                         # True if entropy > threshold
    risk_snapshot: RiskSnapshot                     # risk metrics
    synthesis_annotation: str                       # markdown annotation string
```

### `PositionRecommendation` dataclass

```python
@dataclass
class PositionRecommendation:
    symbol: str
    current_weight: float           # current IBKR position fraction
    recommended_weight: float       # RL-suggested weight
    weight_delta: float             # recommended - current
    confidence_lower: float         # 5th percentile of n_samples draws
    confidence_upper: float         # 95th percentile of n_samples draws
    no_trade: bool                  # True if confidence_upper - lower > 2×uncertainty_threshold
```

### No-trade override logic

```python
# Compute mean Shannon entropy over n_samples=20 stochastic forward passes
entropies = [entropy(policy.get_distribution(obs).distribution) for _ in range(20)]
mean_entropy = np.mean(entropies)

if mean_entropy > uncertainty_threshold:  # default 0.30
    result.no_trade_override = True
    # all position.no_trade = True; weight_delta = 0
```

---

## Dependency flags

| Import | Flag | Behaviour when absent |
|--------|------|-----------------------|
| `stable_baselines3` | `_SB3_AVAILABLE` | `offline_train` raises `RuntimeError`; `validate_strategy` returns dummy result |
| `gymnasium` | checked at import | `PortfolioTradingEnv` unavailable |
| `ta` (TA-Lib) | checked per-feature | Missing features filled with zeros |

---

## Tests

`scripts/test_rl_v2.py` — **68 tests**

| Group | Tests |
|-------|-------|
| `risk_metrics` | 13 |
| `regime_classifier` | 10 |
| `portfolio_env` | 8 |
| `rl_agent_v2` | 8 |
| Integration | 29 |
