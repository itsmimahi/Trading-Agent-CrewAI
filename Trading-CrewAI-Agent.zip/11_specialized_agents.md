# Specialised Agents

> **Sources**: `agents/`, `agents/base_agent.py`, `agents/enhanced_base_agent.py`

---

## Agent hierarchy

```mermaid
classDiagram
    class BaseAgent {
        +llm: LLM
        +tools: list
        +name: str
        +role: str
        +goal: str
        +backstory: str
        +build_agent() Agent
        +build_task(description, expected_output) Task
    }

    class EnhancedBaseAgent {
        +memory_store: MemoryStore
        +portfolio_manager: UniversalPortfolioManager
        +agent_id: str
        +build_enhanced_agent() Agent
        +recall_context(query) dict
        +write_result(result) None
    }

    class EnhancedResearchAgent
    class EnhancedTechnicalAgent
    class EnhancedSentimentAgent
    class EnhancedRiskAgent
    class EnhancedMacroAgent
    class EnhancedTimingAgent
    class EnhancedTradeStrategyPlanner
    class EnhancedPerformanceAgent
    class EnhancedPTAAgent
    class EnhancedPortfolioManager
    class OrchestratorAgent

    BaseAgent <|-- EnhancedBaseAgent
    EnhancedBaseAgent <|-- EnhancedResearchAgent
    EnhancedBaseAgent <|-- EnhancedTechnicalAgent
    EnhancedBaseAgent <|-- EnhancedSentimentAgent
    EnhancedBaseAgent <|-- EnhancedRiskAgent
    EnhancedBaseAgent <|-- EnhancedMacroAgent
    EnhancedBaseAgent <|-- EnhancedTimingAgent
    EnhancedBaseAgent <|-- EnhancedTradeStrategyPlanner
    EnhancedBaseAgent <|-- EnhancedPerformanceAgent
    EnhancedBaseAgent <|-- EnhancedPTAAgent
    EnhancedBaseAgent <|-- EnhancedPortfolioManager
    EnhancedBaseAgent <|-- OrchestratorAgent
```

---

## Agent capability table

| Agent class | File | Primary role | Key tools |
|------------|------|--------------|-----------|
| `EnhancedResearchAgent` | `enhanced_research_agent.py` | Fundamental analysis (earnings, financials, valuation) | `StockQuoteTool`, `FundamentalsTool`, A2A |
| `EnhancedTechnicalAgent` | `enhanced_technical_agent.py` | Technical chart analysis, signals, entry/exit levels | `TechnicalIndicatorTool`, `MarketDataTool` |
| `EnhancedSentimentAgent` | `enhanced_sentiment_agent.py` | News sentiment, social media buzz, analyst ratings | `NewsTool` |
| `EnhancedRiskAgent` | `enhanced_risk_agent.py` | Risk metrics, VaR, drawdown, position sizing | portfolio tools, `MarketDataTool` |
| `EnhancedMacroAgent` | `enhanced_macro_agent.py` | Macro regime, interest rates, currency, GDP | `EconomicDataTool` |
| `EnhancedTimingAgent` | `enhanced_timing_agent.py` | Entry/exit timing, market hours, momentum | `TechnicalIndicatorTool` |
| `EnhancedTradeStrategyPlanner` | `enhanced_trade_strategy_planner.py` | End-to-end trade plans with risk/reward | portfolio + technical tools |
| `EnhancedPerformanceAgent` | `enhanced_performance_agent.py` | Portfolio performance attribution | `analytics/performance_collector.py` |
| `EnhancedPTAAgent` | `enhanced_pta_agent.py` | Paper-trading order lifecycle | `IBKRPortfolioService` via `UniversalPortfolioManager` |
| `EnhancedPortfolioManager` | `enhanced_portfolio_manager.py` | Portfolio rebalancing, allocation optimisation | `UniversalPortfolioManager` |
| `EnhancedDividendsYieldOptimizer` | `enhanced_dividends_yield_optimizer.py` | Dividend screening and yield analysis | `FundamentalsTool` |
| `OrchestratorAgent` | `orchestrator_agent.py` | Route requests to appropriate specialists | A2A registry |

---

## `BaseAgent`

```python
class BaseAgent:
    def __init__(
        self,
        llm: LLM,
        tools: list = None,
        verbose: bool = False,
    ): ...

    def build_agent(self) -> Agent:
        """Returns a CrewAI Agent instance ready for use in a Crew."""

    def build_task(
        self,
        description: str,
        expected_output: str,
        agent: Optional[Agent] = None,
        context: Optional[List[Task]] = None,
    ) -> Task:
        """Build a CrewAI Task linked to this agent."""
```

---

## `EnhancedBaseAgent`

Extends `BaseAgent` with:

```python
class EnhancedBaseAgent(BaseAgent):
    def __init__(
        self,
        llm: LLM,
        tools: list = None,
        verbose: bool = False,
        memory_store: Optional[MemoryStore] = None,
        portfolio_manager: Optional[UniversalPortfolioManager] = None,
        agent_id: str = "",
    ): ...

    def recall_context(self, query: str, top_k: int = 3) -> Dict[str, Any]:
        """Recall relevant prior analyses from LanceDB."""

    def write_result(self, result_text: str, result_type: str = "analysis") -> None:
        """Persist agent output to LanceDB memory."""

    def build_enhanced_agent(self, extra_backstory: str = "") -> Agent:
        """Build agent with recalled context embedded in backstory."""
```

---

## Agent-to-Agent (A2A) protocol

Agents communicate via the `A2AClientTool` — a CrewAI tool that calls other agents
over a lightweight HTTP API exposed by `agent_registry.py`.

### A2A call flow

```mermaid
sequenceDiagram
    participant Caller as Calling Agent (e.g. OrchestratorAgent)
    participant TOOL as A2AClientTool
    participant REG as AgentRegistry
    participant Target as Target Agent (e.g. RiskAgent)

    Caller->>TOOL: call_agent(agent_id="risk_assessment", query="...", context={})
    TOOL->>REG: GET /agents/risk_assessment/endpoint
    REG-->>TOOL: {"url": "http://localhost:8100/agents/risk_assessment"}
    TOOL->>Target: POST /agents/risk_assessment {"query": "...", "context": {}}
    Target-->>TOOL: {"result": "Risk analysis...", "agent_id": "risk_assessment"}
    TOOL-->>Caller: "Risk analysis..."
```

### `AgentRegistry`

> **Source**: `agent_registry.py` (root), `main_advisory_agent/agent_registry.py`

```python
registry = AgentRegistry()
registry.register(agent_id="risk_assessment", url="http://localhost:8100/agents/risk")
endpoint = registry.get_endpoint("risk_assessment")
all_agents = registry.list_agents()
```

Agents self-register on startup by calling `POST /registry/register`.

---

## `OrchestratorAgent`

The orchestrator does not perform analysis itself. Its role is to:

1. Classify the request (delegates to `IntentClassifier`)
2. Select the most appropriate specialist agent(s)
3. Fan out via A2A calls (parallel when multiple agents are needed)
4. Aggregate and return results

It is bypassed in Phase 1+ by the `AdvisoryFlow` which orchestrates market Crews
directly for performance reasons.

---

## Specialised agent selection by intent

| Intent | Primary agent | Secondary agents |
|--------|--------------|-----------------|
| `fundamental_analysis` | `EnhancedResearchAgent` | `EnhancedMacroAgent` |
| `technical_analysis` | `EnhancedTechnicalAgent` | `EnhancedTimingAgent` |
| `sentiment_analysis` | `EnhancedSentimentAgent` | `EnhancedResearchAgent` |
| `risk_assessment` | `EnhancedRiskAgent` | `EnhancedMacroAgent`, `EnhancedPerformanceAgent` |
| `timing` | `EnhancedTimingAgent` | `EnhancedTechnicalAgent` |
| `strategy` | `EnhancedTradeStrategyPlanner` | `EnhancedRiskAgent`, `EnhancedPortfolioManager` |
| `general_advice` | All | — |

---

## Paper-trading adapter

`paper_trading_portfolio_adapter.py` provides a `PaperTradingPortfolioAdapter` class
that previously bridged `UniversalPortfolioManager` to the legacy paper trading HTTP
service. It is retained for backward compatibility but is no longer called in the main
advisory path — all portfolio access goes through `IBKRPortfolioService`.
