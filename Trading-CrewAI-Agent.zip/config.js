// Configuration - API endpoints and settings
const CONFIG = {
    // API Endpoints
    MAIN_AGENT_URL: 'http://localhost:8000',
    RL_AGENT_URL: 'http://localhost:5500',
    // Resolve Web UI base from current origin by default
    WEB_UI_URL: (typeof window !== 'undefined' && window.location && window.location.origin) ? window.location.origin : 'http://localhost:5000',
    
    // Cloud/Providers
    azure: {
        enabled: false // set to true if Azure OpenAI is configured; when false, UI will hide/ignore Azure status
    },

    // Market defaults (Indian market)
    market: {
        country: 'IN',
        currencySymbol: '₹',
        indices: ['NIFTY50', 'SENSEX', 'BANKNIFTY']
    },
    
    // API Endpoints (legacy paths kept for backward compatibility but not used by new code)
    endpoints: {
        mainAgent: {
            chat: '/chat',
            health: '/health',
            status: '/status',
            integration: '/integration/status'
        },
        rlAgent: {
            predict: '/predict',
            health: '/health', 
            status: '/status',
            insights: '/insights'
        }
    },
    
    // Settings
    settings: {
        chatMaxLength: 500,
        typingDelay: 1000,
        statusCheckInterval: 60000, // 60 seconds
        metricsUpdateInterval: 60000, // 60 seconds
        retryAttempts: 3,
        retryDelay: 1000,
    requestTimeout: 60000, // 60 seconds default
    chatRequestTimeout: 120000 // 120 seconds for chat completions
    },
    
    // UI Settings
    ui: {
        animationDuration: 300,
        toastDuration: 5000,
        loadingTimeout: 30000
    },
    
    // Message Types
    messageTypes: {
        USER: 'user',
        ASSISTANT: 'assistant',
        SYSTEM: 'system',
        ERROR: 'error'
    },
    
    // Status Types
    statusTypes: {
        ONLINE: 'online',
        OFFLINE: 'offline',
        WARNING: 'warning',
        CHECKING: 'checking'
    },
    
    // Toast Types
    toastTypes: {
        SUCCESS: 'success',
        ERROR: 'error',
        WARNING: 'warning',
        INFO: 'info'
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
} else {
    window.CONFIG = CONFIG;
}
