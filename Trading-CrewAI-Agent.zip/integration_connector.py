"""
Integration connector for Main Advisory Agent
Connects the Main Advisory Agent Flask API to the existing integration bridge
"""

import os
import sys
import asyncio
import logging
from typing import Dict, Any, Optional

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from integration.crewai_rl_bridge import CrewAIRLBridge, StrategyData
from integration.rl_enhanced_orchestrator import RLEnhancedOrchestratorAgent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MainAgentIntegrationConnector:
    """
    Connector that integrates Main Advisory Agent with the existing bridge system
    """
    
    def __init__(self):
        self.bridge = None
        self.orchestrator = None
        self.is_connected = False
        
    async def initialize(self):
        """Initialize connection to integration bridge"""
        try:
            # Initialize bridge
            self.bridge = CrewAIRLBridge()
            await self.bridge.start()
            
            # Initialize orchestrator
            self.orchestrator = RLEnhancedOrchestratorAgent()
            
            self.is_connected = True
            logger.info("✅ Main Agent Integration Connector initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize integration connector: {e}")
            self.is_connected = False
            return False
    
    async def process_user_query(self, query: str, context: Dict = None) -> Dict:
        """
        Process user query through the integrated system
        """
        if not self.is_connected:
            return {
                'error': 'Integration bridge not connected',
                'fallback_response': 'Using standalone mode'
            }
            
        try:
            # Step 1: Process through orchestrator to get strategy
            orchestrator_result = await self.orchestrator.process_trading_query(
                query, context or {}
            )
            
            if 'strategy' in orchestrator_result:
                # Step 2: Validate through RL bridge if available
                strategy_data = StrategyData(
                    symbol=orchestrator_result.get('symbol', 'UNKNOWN'),
                    strategy_type=orchestrator_result.get('strategy', {}).get('type', 'general'),
                    signals=orchestrator_result.get('signals', {}),
                    confidence=orchestrator_result.get('confidence', 0.7)
                )
                
                # Attempt RL validation
                rl_validation = await self.bridge.validate_strategy(strategy_data)
                
                return {
                    'query': query,
                    'orchestrator_analysis': orchestrator_result,
                    'rl_validation': rl_validation,
                    'integrated_response': self._create_integrated_response(
                        orchestrator_result, rl_validation
                    ),
                    'integration_status': 'success',
                    'timestamp': orchestrator_result.get('timestamp')
                }
            else:
                return {
                    'query': query,
                    'orchestrator_analysis': orchestrator_result,
                    'integration_status': 'partial',
                    'note': 'No strategy generated, providing general analysis'
                }
                
        except Exception as e:
            logger.error(f"Error processing integrated query: {e}")
            return {
                'error': str(e),
                'integration_status': 'failed',
                'fallback_response': 'Error in integrated processing'
            }
    
    def _create_integrated_response(self, orchestrator_result: Dict, rl_validation: Dict) -> Dict:
        """Create a comprehensive integrated response"""
        
        # Base response from orchestrator
        response = {
            'recommendation': orchestrator_result.get('recommendation', 'No specific recommendation'),
            'confidence': orchestrator_result.get('confidence', 0.7),
            'analysis': orchestrator_result.get('analysis', {}),
            'integration_score': 0.8  # Base integration score
        }
        
        # Enhance with RL validation if available
        if rl_validation and not rl_validation.get('error'):
            rl_confidence = rl_validation.get('confidence', 0.7)
            
            # Weighted confidence combining both systems
            combined_confidence = (response['confidence'] * 0.6) + (rl_confidence * 0.4)
            response['confidence'] = combined_confidence
            response['rl_insights'] = rl_validation
            response['integration_score'] = 0.95  # High score for full integration
            
            # Add RL-specific recommendations
            if 'recommendation' in rl_validation:
                response['rl_recommendation'] = rl_validation['recommendation']
        else:
            response['note'] = 'RL validation unavailable, using CrewAI analysis only'
            response['integration_score'] = 0.7  # Lower score without RL
            
        return response
    
    async def send_performance_feedback(self, strategy_id: str, performance_data: Dict) -> bool:
        """Send performance feedback to the RL system"""
        if not self.is_connected:
            return False
            
        try:
            from analytics.performance_collector import PerformanceCollector
            
            # Record performance
            collector = PerformanceCollector()
            await collector.record_strategy_execution(strategy_id, performance_data)
            
            return True
            
        except Exception as e:
            logger.error(f"Error sending performance feedback: {e}")
            return False
    
    async def get_system_health(self) -> Dict:
        """Get health status of the integrated system"""
        health = {
            'connector_status': self.is_connected,
            'bridge_status': False,
            'orchestrator_status': False,
            'rl_agent_status': False
        }
        
        if self.bridge:
            health['bridge_status'] = True
            # Check RL agent connectivity
            rl_health = await self.bridge.health_check()
            health['rl_agent_status'] = not rl_health.get('error', True)
            
        if self.orchestrator:
            orch_health = await self.orchestrator.get_health_status()
            health['orchestrator_status'] = orch_health.get('orchestrator', False)
            
        health['overall_health'] = all([
            health['connector_status'],
            health['bridge_status'],
            health['orchestrator_status']
        ])
        
        return health
    
    async def shutdown(self):
        """Shutdown the integration connector"""
        if self.bridge:
            await self.bridge.stop()
        if self.orchestrator:
            await self.orchestrator.shutdown()
        self.is_connected = False
        logger.info("🔒 Main Agent Integration Connector shutdown complete")

# Global connector instance
integration_connector = MainAgentIntegrationConnector()
