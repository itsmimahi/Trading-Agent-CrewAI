"""
Paper Trading Agent Portfolio Integration
Updates the enhanced paper trading agent to use the new Portfolio Management System
instead of the backtrader simulation.
"""
import os
import sys
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

# Add project root to path
project_root = os.path.dirname(os.path.dirname(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from agents.universal_portfolio_manager import get_portfolio_manager
except ImportError:
    def get_portfolio_manager(name):
        return None

logger = logging.getLogger("PTAPortfolio")


class PaperTradingPortfolioAdapter:
    """
    Adapter to migrate paper trading agent from backtrader to PMS.
    Provides backtrader-like interface using the Portfolio Management System.
    """
    
    def __init__(self, agent_name: str = "PaperTradingAgent"):
        self.agent_name = agent_name
        self.portfolio_manager = get_portfolio_manager(agent_name)
        self.logger = logging.getLogger(f"PTA.{agent_name}")
        
        # Trading state tracking
        self.active_strategies = []
        self.trade_history = []
        self.performance_cache = {}
        
    def is_available(self) -> bool:
        """Check if portfolio integration is available."""
        return self.portfolio_manager is not None and self.portfolio_manager.is_available()
    
    def get_portfolio_value(self) -> float:
        """Get current portfolio total value."""
        if not self.is_available():
            return 50000.0  # Default starting value
            
        try:
            metrics = self.portfolio_manager.get_metrics()
            return float(metrics.get("total_value_est", 50000.0))
        except Exception as e:
            self.logger.error(f"Portfolio value failed: {e}")
            return 50000.0
    
    def get_cash(self) -> float:
        """Get available cash for trading."""
        if not self.is_available():
            return 50000.0
            
        try:
            holdings = self.portfolio_manager.get_holdings()
            return float(holdings.get("cash", 50000.0))
        except Exception as e:
            self.logger.error(f"Get cash failed: {e}")
            return 50000.0
    
    def get_positions(self) -> List[Dict[str, Any]]:
        """Get current positions (backtrader-style format)."""
        if not self.is_available():
            return []
            
        try:
            holdings = self.portfolio_manager.get_holdings()
            positions = []
            
            for holding in holdings.get("holdings", []):
                positions.append({
                    "symbol": holding.get("symbol", ""),
                    "size": holding.get("quantity", 0),
                    "price": holding.get("avg_price", 0),
                    "value": holding.get("quantity", 0) * holding.get("avg_price", 0)
                })
            
            return positions
        except Exception as e:
            self.logger.error(f"Get positions failed: {e}")
            return []
    
    def place_order(self, symbol: str, action: str, size: int, price: Optional[float] = None) -> Dict[str, Any]:
        """
        Place trading order (backtrader-style interface).
        
        Args:
            symbol: Stock symbol
            action: 'BUY' or 'SELL'
            size: Number of shares
            price: Optional limit price (ignored for market orders)
        """
        if not self.is_available():
            return {"status": "error", "message": "Portfolio manager unavailable"}
        
        try:
            # Convert backtrader action to PMS side
            side = "buy" if action.upper() == "BUY" else "sell"
            
            # Check if trade is feasible
            can_trade, reason = self.portfolio_manager.can_trade(symbol, side, size)
            if not can_trade:
                return {"status": "rejected", "message": reason}
            
            # Execute order
            result = self.portfolio_manager.place_order(symbol, side, size)
            
            if "error" in result:
                return {"status": "error", "message": result["error"]}
            else:
                # Record trade
                self.trade_history.append({
                    "timestamp": datetime.now(),
                    "symbol": symbol,
                    "action": action,
                    "size": size,
                    "result": result
                })
                
                return {
                    "status": "executed",
                    "order_id": result.get("order_id", ""),
                    "message": f"{action} {size} shares of {symbol}",
                    "result": result
                }
        except Exception as e:
            self.logger.error(f"Place order failed: {e}")
            return {"status": "error", "message": str(e)}
    
    def buy(self, symbol: str, size: int) -> Dict[str, Any]:
        """Buy shares (backtrader-style convenience method)."""
        return self.place_order(symbol, "BUY", size)
    
    def sell(self, symbol: str, size: int) -> Dict[str, Any]:
        """Sell shares (backtrader-style convenience method)."""
        return self.place_order(symbol, "SELL", size)
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get comprehensive performance metrics."""
        if not self.is_available():
            return {"error": "Portfolio manager unavailable"}
        
        try:
            # Get portfolio metrics
            metrics = self.portfolio_manager.get_metrics()
            holdings = self.portfolio_manager.get_holdings()
            
            # Calculate additional PTA-specific metrics
            total_value = metrics.get("total_value_est", 0)
            cash = holdings.get("cash", 0)
            invested_value = total_value - cash
            
            return {
                "total_value": total_value,
                "cash": cash,
                "invested_value": invested_value,
                "unrealized_pnl": metrics.get("unrealized_pnl", 0),
                "positions_count": len(holdings.get("holdings", [])),
                "trades_executed": len(self.trade_history),
                "portfolio_utilization": (invested_value / total_value) if total_value > 0 else 0,
                "available_margin": metrics.get("available_margin", 0)
            }
        except Exception as e:
            self.logger.error(f"Performance metrics failed: {e}")
            return {"error": str(e)}
    
    def get_trade_history(self) -> List[Dict[str, Any]]:
        """Get trading history for analysis."""
        return self.trade_history.copy()
    
    def reset_simulation(self) -> Dict[str, Any]:
        """Reset simulation state (clear trade history)."""
        self.trade_history.clear()
        self.performance_cache.clear()
        self.active_strategies.clear()
        
        # Get fresh portfolio state
        if self.is_available():
            try:
                holdings = self.portfolio_manager.get_holdings()
                metrics = self.portfolio_manager.get_metrics()
                return {
                    "status": "reset",
                    "cash": holdings.get("cash", 0),
                    "total_value": metrics.get("total_value_est", 0)
                }
            except Exception as e:
                return {"status": "error", "message": str(e)}
        
        return {"status": "reset", "message": "Simulation reset (portfolio unavailable)"}
    
    def add_strategy(self, strategy_name: str, strategy_config: Dict[str, Any]) -> Dict[str, Any]:
        """Add a trading strategy to track."""
        strategy = {
            "name": strategy_name,
            "config": strategy_config,
            "added_at": datetime.now(),
            "trades": []
        }
        
        self.active_strategies.append(strategy)
        return {"status": "added", "strategy": strategy_name}
    
    def execute_strategy_trade(self, strategy_name: str, symbol: str, action: str, size: int) -> Dict[str, Any]:
        """Execute a trade for a specific strategy."""
        result = self.place_order(symbol, action, size)
        
        # Track strategy-specific trade
        for strategy in self.active_strategies:
            if strategy["name"] == strategy_name:
                strategy["trades"].append({
                    "timestamp": datetime.now(),
                    "symbol": symbol,
                    "action": action,
                    "size": size,
                    "result": result
                })
                break
        
        return result
    
    def get_strategy_performance(self, strategy_name: str) -> Dict[str, Any]:
        """Get performance metrics for a specific strategy."""
        for strategy in self.active_strategies:
            if strategy["name"] == strategy_name:
                trades = strategy["trades"]
                return {
                    "strategy": strategy_name,
                    "trades_count": len(trades),
                    "first_trade": trades[0]["timestamp"].isoformat() if trades else None,
                    "last_trade": trades[-1]["timestamp"].isoformat() if trades else None,
                    "trades": trades
                }
        
        return {"error": f"Strategy {strategy_name} not found"}


# Global instance factory
_pta_instances = {}

def get_paper_trading_adapter(agent_name: str = "PaperTradingAgent") -> PaperTradingPortfolioAdapter:
    """Get or create paper trading portfolio adapter for an agent."""
    if agent_name not in _pta_instances:
        _pta_instances[agent_name] = PaperTradingPortfolioAdapter(agent_name)
    return _pta_instances[agent_name]


# Helper function for existing paper trading agent migration
def migrate_to_portfolio_system(agent_instance, adapter_name: str = None):
    """
    Helper to migrate existing paper trading agent to use PMS.
    
    Args:
        agent_instance: The enhanced paper trading agent instance
        adapter_name: Optional name for the adapter
    """
    if adapter_name is None:
        adapter_name = getattr(agent_instance, 'name', 'PaperTradingAgent')
    
    # Replace backtrader interface with portfolio adapter
    adapter = get_paper_trading_adapter(adapter_name)
    
    # Add adapter methods to agent
    agent_instance.portfolio_adapter = adapter
    agent_instance.get_portfolio_value = adapter.get_portfolio_value
    agent_instance.get_cash = adapter.get_cash
    agent_instance.get_positions = adapter.get_positions
    agent_instance.buy = adapter.buy
    agent_instance.sell = adapter.sell
    agent_instance.get_performance_metrics = adapter.get_performance_metrics
    
    return adapter
