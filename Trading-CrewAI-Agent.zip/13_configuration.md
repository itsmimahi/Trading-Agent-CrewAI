# Configuration Reference

All settings are read from environment variables (loaded from `.env` at startup via
`python-dotenv`). `config/settings.py` centralises the reads.

---

## Azure OpenAI

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AZURE_OPENAI_API_KEY` | ✅ | — | Azure OpenAI API key |
| `AZURE_OPENAI_ENDPOINT` | ✅ | — | e.g. `https://your-resource.openai.azure.com/` |
| `AZURE_OPENAI_API_VERSION` | ✅ | `2024-12-01-preview` | API version string |
| `AZURE_OPENAI_DEPLOYMENT` | | `gpt-4.1` | Model deployment name |

---

## IBKR paper trading

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `IB_ENABLED` | | `0` | `1` to connect to TWS / IB Gateway |
| `IB_HOST` | | `127.0.0.1` | TWS host |
| `IB_PORT` | | `7497` | Port (7497 = TWS paper; 4002 = IB Gateway paper) |
| `IB_CLIENT_ID` | | `108` | ib_insync client ID (unique per connection) |
| `IB_ACCOUNT` | | `""` | Paper account number (e.g. `DU123456`) |
| `IB_ALLOW_TRADES` | | `0` | `1` to enable actual order placement |
| `IB_PORTFOLIO_TTL` | | `30` | Cache TTL in seconds |
| `IB_EXCHANGE` | | `SMART` | Default exchange for market orders |
| `IB_CURRENCY` | | `USD` | Default currency for contracts |

---

## Advisory agent

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ADVISORY_VERBOSE` | | `0` | `1` to enable CrewAI verbose logging |
| `ADVISORY_APPEND_DISCLAIMER` | | `1` | Append risk disclaimer to responses |
| `ADVISORY_ENFORCE_MARKET_HOURS` | | `1` | Block trade orders outside market hours |
| `DEFAULT_MARKET` | | `IN` | Default market code when none detected |
| `MAX_POSITION_SIZE` | | `0.20` | Max fraction of portfolio for one position |
| `MAX_ORDER_RISK_FRACTION` | | `0.05` | Max order value as fraction of portfolio |
| `APPROVAL_TIMEOUT_MINUTES` | | `30` | Minutes before pending approval expires |
| `IDEMPOTENCY_WINDOW_MINUTES` | | `30` | Dedup window for idempotent order keys |

---

## Advisory flow approval

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ENABLE_ADVISORY_APPROVAL` | | `0` | `1` to require human approval for synthesis before execution |

---

## Persistence (SQLite checkpoints)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ADVISORY_CHECKPOINT_DB` | | `data/advisory_checkpoints.db` | SQLite path for flow checkpoints and approval store |

Set to empty string to disable checkpointing.

---

## Memory (LanceDB)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `LANCEDB_URI` | | `data/memory/lancedb` | LanceDB directory |
| `LOCAL_EMBEDDINGS_MODEL_DIR` | | `hf_models/all-mpneet-base-v2` | Local HuggingFace embedding model directory |
| `MEMORY_TOP_K` | | `5` | Max recall results per query |

---

## RL validation

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ENABLE_RL_VALIDATION` | | `0` | `1` to enable RL v1 HTTP A2A validation |
| `ENABLE_RL_VALIDATION_V2` | | `0` | `1` to enable RL v2 local inference validation |
| `RL_V2_CHECKPOINT` | | `""` | Path to trained `RLAgentV2` `.zip` checkpoint |
| `RL_V2_SYMBOLS` | | `""` | Comma-separated list of symbols for `RLAgentV2` |
| `RL_V2_ALGORITHM` | | `PPO` | `PPO` or `SAC` |
| `RL_V2_UNCERTAINTY_THRESHOLD` | | `0.30` | Entropy above this triggers no-trade override |
| `ENABLE_RL_ORCHESTRATOR` | | `0` | `1` to use distributed RL via EventBus |

---

## Market data

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ALPHA_VANTAGE_API_KEY` | | `""` | Alpha Vantage API key (market data tools) |

Without a key, market data tools fall back to `yfinance` for available data.

---

## Redis / EventBus

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `REDIS_URL` | | `redis://localhost:6379/0` | Redis connection URL |
| `AGENT_WORKER_CONSUMER` | | `worker_01` | Consumer name for Redis Streams groups |

---

## API server

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `HOST` | | `0.0.0.0` | FastAPI bind host |
| `PORT` | | `8000` | FastAPI bind port |
| `API_WORKERS` | | `1` | Number of uvicorn workers |

---

## Logging

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `LOG_LEVEL` | | `INFO` | Python logging level (`DEBUG`/`INFO`/`WARNING`/`ERROR`) |
| `LOG_FORMAT` | | `json` | `json` (structured) or `text` |

---

## `config/settings.py`

All variables above are read once at module import time:

```python
from config.settings import settings

# Access any setting
print(settings.IB_ENABLED)
print(settings.AZURE_OPENAI_API_KEY)
print(settings.ADVISORY_CHECKPOINT_DB)
```

`settings` is a `pydantic_settings.BaseSettings` instance that:
- Reads from the OS environment
- Falls back to `.env` via `env_file = ".env"`
- Validates types (booleans, ints, floats) at startup
- Raises `ValidationError` for missing required fields

---

## `config/integration_config.json`

Static configuration for the integration layer (service discovery, stream names):

```json
{
    "event_streams": {
        "regime_change": "advisory.regime_change",
        "performance": "advisory.performance",
        "weight_updates": "advisory.weight_updates"
    },
    "agent_registry": {
        "host": "localhost",
        "port": 8100
    },
    "market_hours": {
        "IN":    { "open": "09:15", "close": "15:30", "tz": "Asia/Kolkata" },
        "US":    { "open": "09:30", "close": "16:00", "tz": "America/New_York" },
        "EU":    { "open": "08:00", "close": "16:30", "tz": "Europe/London" },
        "APAC":  { "open": "09:00", "close": "15:00", "tz": "Asia/Tokyo" },
        "CRYPTO": null
    }
}
```

---

## Minimal `.env` for local development

```dotenv
AZURE_OPENAI_API_KEY=<your-key>
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-12-01-preview

IB_ENABLED=0
ADVISORY_CHECKPOINT_DB=data/advisory_checkpoints.db
LANCEDB_URI=data/memory/lancedb
ENABLE_RL_VALIDATION_V2=0
LOG_LEVEL=INFO
```
