"""
Enhanced Performance Agent using CrewAI Framework - Hybrid Plus Approach
Evaluate how well strategies performed and track performance metrics
"""

import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass

try:
    from .universal_portfolio_manager import get_portfolio_manager
except ImportError:
    # Fallback for different directory structures
    def get_portfolio_manager(name):
        return None

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from config.settings import config
from crewai import Task, Crew, Process

logger = logging.getLogger(__name__)

class EnhancedPerformanceAgent(EnhancedBaseAgent):
    """
    Enhanced Performance Agent using CrewAI Framework with Hybrid Plus Approach
    
    Mathematical Core: ROI calculations, Sharpe ratio, performance metrics
    LLM Reasoning: Performance analysis, strategy evaluation, optimization insights
    Tools: ROI calculator, performance chart generator, performance diagnostics
    Memory: Historical performance, strategy success rates, optimization history
    Knowledge Base: Performance benchmarks, risk metrics, optimization strategies
    """
    
    def __init__(self, name: str = "EnhancedPerformanceAgent", description: str = "Performance Agent for evaluating strategy performance and tracking metrics", role: str = "Performance Analyst", goal: str = "Evaluate how well strategies performed and provide optimization insights", backstory: str = "Expert in performance analysis and strategy optimization with deep knowledge of risk metrics and portfolio management", capabilities: Optional[List[Any]] = None, weight: float = 0.15, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        super().__init__(name=name, description=description, role=role, goal=goal, backstory=backstory, capabilities=capabilities, weight=weight, use_llm=use_llm, use_memory=use_memory, use_knowledge_base=use_knowledge_base, **kwargs)
        
        # Initialize portfolio management client
        self.portfolio_manager = get_portfolio_manager(name)
        
        # Performance tracking
        self.performance_history = []
        self.benchmark_data = {}
        self.risk_metrics = {}
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.TREND_ANALYSIS,
                AgentCapability.RISK_ASSESSMENT,
                AgentCapability.CONTEXTUAL_REASONING
            ]
        super().__init__(
            name=name,
            description=description,
            capabilities=capabilities,
            weight=weight,
            use_llm=use_llm,
            use_memory=use_memory,
            use_knowledge_base=use_knowledge_base,
            role=role,
            goal=goal,
            backstory=backstory,
            **kwargs
        )
        
        # Performance thresholds
        self.performance_thresholds = {
            'min_sharpe_ratio': 1.0,
            'max_drawdown_limit': 0.20,  # 20% max drawdown
            'min_win_rate': 0.50,  # 50% minimum win rate
            'min_profit_factor': 1.5,  # 1.5 minimum profit factor
            'min_total_return': 0.10  # 10% minimum total return
        }
        
        # Load performance knowledge
        self._load_performance_knowledge()
    
    def _load_performance_knowledge(self):
        """Load performance analysis knowledge into knowledge base"""
        try:
            performance_knowledge = [
                "Total Return: Overall percentage gain/loss over the period",
                "Sharpe Ratio: Risk-adjusted return measure, higher is better",
                "Maximum Drawdown: Largest peak-to-trough decline in portfolio value",
                "Win Rate: Percentage of profitable trades",
                "Profit Factor: Ratio of gross profit to gross loss",
                "Average Win/Loss: Mean profit and loss per trade",
                "Volatility: Standard deviation of returns, measure of risk",
                "Beta: Sensitivity to market movements",
                "Alpha: Excess return relative to benchmark",
                "Risk-Adjusted Returns: Evaluate returns relative to risk taken",
                "Benchmark Comparison: Compare performance against market indices",
                "Strategy Attribution: Analyze which strategies contribute most to returns",
                "Parameter Optimization: Adjust strategy parameters for better performance",
                "Risk Management: Implement position sizing and stop-loss improvements",
                "Strategy Diversification: Combine multiple strategies for better results"
            ]
            
            if self.use_knowledge_base:
                self.knowledge_base.add_knowledge(performance_knowledge)
                
        except Exception as e:
            self.logger.error(f"Error loading performance knowledge: {e}")
    
    async def analyze(self, symbol: str, performance_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Main analysis method for performance evaluation"""
        try:
            self.logger.info(f"Starting CrewAI comprehensive performance analysis for {symbol}")
            
            # Use provided performance data or create mock data
            if performance_data is None:
                performance_data = self._create_mock_performance_data(symbol)
            
            # 1. Mathematical Analysis (Performance metrics and risk analysis)
            math_results = await self.mathematical_analysis(symbol, {'performance_data': performance_data})
            if "error" in math_results:
                return math_results
            
            # 2. Get market context for CrewAI reasoning
            market_context = await self._get_market_context(symbol)
            
            # 3. CrewAI Reasoning (Performance analysis and optimization insights)
            if self.use_llm:
                crewai_reasoning = await self._get_crewai_performance_reasoning(math_results, market_context)
            else:
                crewai_reasoning = {"reasoning": "CrewAI analysis not available"}
            
            # 4. Final Synthesis
            final_analysis = {
                "agent_name": self.name,
                "symbol": symbol,
                "analysis_timestamp": datetime.now().isoformat(),
                "mathematical_analysis": math_results,
                "crewai_reasoning": crewai_reasoning,
                "market_context": market_context,
                "confidence_score": math_results.get('performance_score', 0.5),
                "recommendation": math_results.get('optimization_recommendation', 'HOLD'),
                "agent_weight": self.weight
            }
            
            return final_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI comprehensive analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Perform mathematical/quantitative performance analysis"""
        try:
            performance_data = data.get('performance_data', {})
            
            # Calculate performance metrics
            performance_metrics = self._calculate_performance_metrics(performance_data)
            
            # Calculate risk metrics
            risk_metrics = self._calculate_risk_metrics(performance_data)
            
            # Generate optimization recommendations
            optimization_recommendation = self._generate_optimization_recommendation(performance_metrics, risk_metrics)
            
            return {
                "symbol": symbol,
                "performance_metrics": performance_metrics,
                "risk_metrics": risk_metrics,
                "optimization_recommendation": optimization_recommendation,
                "calculation_timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in mathematical analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    def _calculate_performance_metrics(self, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate comprehensive performance metrics"""
        try:
            # Extract basic performance data
            returns = performance_data.get('returns', [0.01, 0.02, -0.01, 0.03, 0.01])  # Mock returns
            trades = performance_data.get('trades', [])
            
            # Calculate basic metrics
            total_return = sum(returns)
            avg_return = np.mean(returns) if returns else 0
            volatility = np.std(returns) if len(returns) > 1 else 0
            
            # Calculate Sharpe ratio (assuming risk-free rate of 3%)
            risk_free_rate = 0.03
            sharpe_ratio = (avg_return - risk_free_rate) / volatility if volatility > 0 else 0
            
            # Calculate drawdown
            cumulative_returns = np.cumprod([1 + r for r in returns])
            running_max = np.maximum.accumulate(cumulative_returns)
            drawdown = (cumulative_returns - running_max) / running_max
            max_drawdown = abs(np.min(drawdown)) if len(drawdown) > 0 else 0
            
            # Calculate trade-based metrics
            if trades:
                winning_trades = [t for t in trades if t.get('pnl', 0) > 0]
                losing_trades = [t for t in trades if t.get('pnl', 0) < 0]
                
                win_rate = len(winning_trades) / len(trades) if trades else 0
                avg_win = np.mean([t.get('pnl', 0) for t in winning_trades]) if winning_trades else 0
                avg_loss = np.mean([t.get('pnl', 0) for t in losing_trades]) if losing_trades else 0
                
                gross_profit = sum([t.get('pnl', 0) for t in winning_trades])
                gross_loss = abs(sum([t.get('pnl', 0) for t in losing_trades]))
                profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
            else:
                win_rate = 0.5  # Mock value
                avg_win = 0.02  # Mock value
                avg_loss = -0.01  # Mock value
                profit_factor = 2.0  # Mock value
            
            return {
                "total_return": total_return,
                "avg_return": avg_return,
                "volatility": volatility,
                "sharpe_ratio": sharpe_ratio,
                "max_drawdown": max_drawdown,
                "win_rate": win_rate,
                "avg_win": avg_win,
                "avg_loss": avg_loss,
                "profit_factor": profit_factor,
                "total_trades": len(trades),
                "winning_trades": len([t for t in trades if t.get('pnl', 0) > 0]),
                "losing_trades": len([t for t in trades if t.get('pnl', 0) < 0])
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating performance metrics: {e}")
            return {
                "total_return": 0,
                "avg_return": 0,
                "volatility": 0,
                "sharpe_ratio": 0,
                "max_drawdown": 0,
                "win_rate": 0.5,
                "avg_win": 0,
                "avg_loss": 0,
                "profit_factor": 0,
                "total_trades": 0,
                "winning_trades": 0,
                "losing_trades": 0
            }
    
    def _calculate_risk_metrics(self, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate risk metrics"""
        try:
            returns = performance_data.get('returns', [0.01, 0.02, -0.01, 0.03, 0.01])
            
            if not returns:
                return {
                    "volatility": 0,
                    "beta": 1.0,
                    "alpha": 0,
                    "sortino_ratio": 0,
                    "calmar_ratio": 0
                }
            
            # Calculate volatility
            volatility = np.std(returns)
            
            # Calculate beta (mock calculation)
            beta = 1.0  # Default beta
            
            # Calculate alpha
            risk_free_rate = 0.03
            market_return = 0.01  # Mock market return
            expected_return = risk_free_rate + beta * (market_return - risk_free_rate)
            actual_return = np.mean(returns)
            alpha = actual_return - expected_return
            
            # Calculate Sortino ratio
            downside_returns = [r for r in returns if r < 0]
            downside_deviation = np.std(downside_returns) if downside_returns else 0
            sortino_ratio = (actual_return - risk_free_rate) / downside_deviation if downside_deviation > 0 else 0
            
            # Calculate Calmar ratio
            total_return = sum(returns)
            max_drawdown = abs(min(returns)) if returns else 0.01
            calmar_ratio = total_return / max_drawdown if max_drawdown > 0 else 0
            
            return {
                "volatility": volatility,
                "beta": beta,
                "alpha": alpha,
                "sortino_ratio": sortino_ratio,
                "calmar_ratio": calmar_ratio
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating risk metrics: {e}")
            return {
                "volatility": 0,
                "beta": 1.0,
                "alpha": 0,
                "sortino_ratio": 0,
                "calmar_ratio": 0
            }
    
    def _generate_optimization_recommendation(self, performance_metrics: Dict[str, Any], risk_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Generate optimization recommendations based on performance"""
        try:
            sharpe_ratio = performance_metrics.get('sharpe_ratio', 0)
            max_drawdown = performance_metrics.get('max_drawdown', 0)
            win_rate = performance_metrics.get('win_rate', 0)
            profit_factor = performance_metrics.get('profit_factor', 0)
            total_return = performance_metrics.get('total_return', 0)
            
            # Determine overall performance score
            performance_score = 0.0
            
            # Sharpe ratio contribution (40%)
            if sharpe_ratio >= self.performance_thresholds['min_sharpe_ratio']:
                performance_score += 0.4
            elif sharpe_ratio >= 0.5:
                performance_score += 0.2
            
            # Drawdown contribution (25%)
            if max_drawdown <= self.performance_thresholds['max_drawdown_limit']:
                performance_score += 0.25
            elif max_drawdown <= 0.30:
                performance_score += 0.15
            
            # Win rate contribution (20%)
            if win_rate >= self.performance_thresholds['min_win_rate']:
                performance_score += 0.20
            elif win_rate >= 0.40:
                performance_score += 0.10
            
            # Profit factor contribution (15%)
            if profit_factor >= self.performance_thresholds['min_profit_factor']:
                performance_score += 0.15
            elif profit_factor >= 1.2:
                performance_score += 0.08
            
            # Generate recommendations
            recommendations = []
            
            if sharpe_ratio < self.performance_thresholds['min_sharpe_ratio']:
                recommendations.append("Improve risk-adjusted returns by reducing volatility or increasing returns")
            
            if max_drawdown > self.performance_thresholds['max_drawdown_limit']:
                recommendations.append("Implement better risk management to reduce maximum drawdown")
            
            if win_rate < self.performance_thresholds['min_win_rate']:
                recommendations.append("Focus on improving trade selection and entry/exit timing")
            
            if profit_factor < self.performance_thresholds['min_profit_factor']:
                recommendations.append("Optimize position sizing and risk-reward ratios")
            
            # Determine overall recommendation
            if performance_score >= 0.8:
                recommendation = "EXCELLENT"
                reasoning = "Strategy performing above all thresholds"
            elif performance_score >= 0.6:
                recommendation = "GOOD"
                reasoning = "Strategy performing well with minor improvements possible"
            elif performance_score >= 0.4:
                recommendation = "NEEDS_IMPROVEMENT"
                reasoning = "Strategy needs optimization in several areas"
            else:
                recommendation = "POOR"
                reasoning = "Strategy requires significant improvements"
            
            return {
                "recommendation": recommendation,
                "reasoning": reasoning,
                "performance_score": performance_score,
                "optimization_suggestions": recommendations
            }
            
        except Exception as e:
            self.logger.error(f"Error generating optimization recommendation: {e}")
            return {
                "recommendation": "NEEDS_IMPROVEMENT",
                "reasoning": "Unable to generate recommendation",
                "performance_score": 0.5,
                "optimization_suggestions": ["Review strategy parameters"]
            }
    
    def _create_mock_performance_data(self, symbol: str) -> Dict[str, Any]:
        """Create mock performance data for testing"""
        return {
            "returns": [0.02, 0.03, -0.01, 0.04, 0.01, -0.02, 0.03, 0.02, -0.01, 0.02],
            "trades": [
                {"pnl": 0.02, "strategy": "momentum"},
                {"pnl": 0.03, "strategy": "momentum"},
                {"pnl": -0.01, "strategy": "reversal"},
                {"pnl": 0.04, "strategy": "momentum"},
                {"pnl": 0.01, "strategy": "technical"}
            ],
            "period": "6_months",
            "strategy_type": "MOMENTUM",
            "total_trades": 50,
            "winning_trades": 32,
            "losing_trades": 18
        }
    
    async def _get_market_context(self, symbol: str) -> str:
        """Get current market context for CrewAI reasoning"""
        try:
            return f"""
            Performance analysis context for {symbol}:
            - Market conditions during the analysis period
            - Sector performance and relative strength
            - Economic environment and its impact on strategy performance
            - Volatility regime and its effect on risk metrics
            - Interest rate environment and its influence on returns
            - Market sentiment and its impact on strategy effectiveness
            """
        except Exception as e:
            self.logger.error(f"Error getting market context: {e}")
            return "Market context not available"

    async def _get_crewai_performance_reasoning(self, math_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Get CrewAI-based performance reasoning for optimization insights"""
        try:
            reasoning_prompt = f"""
            You are an expert performance analyst with deep knowledge of strategy optimization and risk management.
            
            Performance Analysis Results:
            {math_results}
            
            Market Context:
            {market_context}
            
            Based on this comprehensive performance analysis, provide:
            1. Performance Assessment - Overall strategy performance evaluation
            2. Risk Analysis - Risk metrics and their implications
            3. Optimization Opportunities - Areas for improvement and optimization
            4. Strategy Recommendations - Specific recommendations for enhancement
            5. Implementation Plan - Step-by-step optimization plan
            
            Provide comprehensive performance analysis that combines quantitative metrics with strategic insights.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive performance reasoning and optimization analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            return {"reasoning": str(result)}
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI performance reasoning: {str(e)}")
            return {"error": str(e)}

    async def evaluate_performance(self, symbol: str, performance_data: Dict[str, Any] = None) -> dict:
        """Main method for performance evaluation. Calls analyze method."""
        try:
            return await self.analyze(symbol, performance_data)
        except Exception as e:
            self.logger.error(f"Error in evaluate_performance: {e}")
            return {"error": str(e)} 
        
        