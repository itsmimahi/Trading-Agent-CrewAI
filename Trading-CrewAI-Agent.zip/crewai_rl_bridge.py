"""
CrewAI-RL Integration Bridge
Core integration service for connecting the CrewAI Advisory System with the RL Agent

v2 additions
------------
* ``RegimeData``           — structured regime-change notification (4-state).
* ``PortfolioWeightUpdate``— per-asset weight recommendations with confidence bands.
* ``PerformanceMetricsV2`` — per-asset breakdown of realized metrics.
* ``send_performance_feedback_v2()`` — sends per-asset metrics to RL.
* ``notify_regime_change_v2()``      — sends structured regime data.
* ``get_portfolio_weights()``        — retrieves multi-asset weight recommendations.
"""

import asyncio
import json
import logging
import aiohttp
import os
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict, field
from enum import Enum
from integration.event_bus import RedisStreamsEventBus

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MessageType(Enum):
    """Types of messages exchanged between systems"""
    STRATEGY_VALIDATION = "strategy_validation"
    PERFORMANCE_FEEDBACK = "performance_feedback"
    WEIGHT_UPDATE = "weight_update"
    REGIME_CHANGE = "regime_change"
    LEARNING_INSIGHT = "learning_insight"
    # v2
    PORTFOLIO_WEIGHT_UPDATE = "portfolio_weight_update"
    REGIME_CHANGE_V2 = "regime_change_v2"


@dataclass
class StrategyData:
    """Strategy data structure for RL validation"""
    symbol: str
    timeframe: str
    strategy_type: str
    signals: Dict[str, Any]
    risk_parameters: Dict[str, float]
    confidence: float
    generated_by: List[str]  # Contributing agents
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class PerformanceMetrics:
    """Performance metrics for RL learning"""
    strategy_id: str
    total_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    avg_trade_duration: float
    total_trades: int
    agent_contributions: Dict[str, float]  # Agent contribution scores
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class WeightUpdate:
    """Agent weight updates from RL"""
    agent_weights: Dict[str, float]
    confidence: float
    reasoning: str
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


# ─────────────────────────────────────────────────────────────────────────────
# v2 data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RegimeData:
    """Structured market-regime notification for RL v2.

    Attributes:
        regime:           One of "BULL", "BEAR", "SIDEWAYS", "HIGH_VOL".
        regime_index:     Integer index (BULL=0, BEAR=1, SIDEWAYS=2, HIGH_VOL=3).
        one_hot:          4-element list encoding of the regime.
        source_markets:   Markets contributing to this regime classification.
        volatility:       Annualised realised portfolio volatility.
        confidence:       Classifier confidence in [0, 1].
    """
    regime: str
    regime_index: int
    one_hot: List[float]
    source_markets: List[str]
    volatility: float = 0.0
    confidence: float = 1.0
    timestamp: datetime = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class AssetMetrics:
    """Per-asset realized performance metrics for v2 feedback."""
    symbol: str
    realized_return: float
    sharpe_ratio: float
    max_drawdown: float
    var_95: float
    turnover: float
    weight_actual: float   # actual allocation fraction realized


@dataclass
class PerformanceMetricsV2:
    """Multi-asset performance metrics for RL v2 online learning.

    Attributes:
        strategy_id:     Unique identifier for this evaluation window.
        portfolio_return: Total portfolio return (fraction).
        portfolio_sharpe: Portfolio-level Sharpe ratio.
        portfolio_drawdown: Maximum drawdown (fraction).
        per_asset:       Per-asset breakdown.
        regime_at_start: Regime when the period started.
        regime_at_end:   Regime when the period ended.
    """
    strategy_id: str
    portfolio_return: float
    portfolio_sharpe: float
    portfolio_drawdown: float
    per_asset: List[AssetMetrics] = field(default_factory=list)
    regime_at_start: str = "SIDEWAYS"
    regime_at_end: str = "SIDEWAYS"
    timestamp: datetime = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class PortfolioWeightUpdate:
    """Per-asset target weights returned by RL v2.

    Attributes:
        weights:           Dict mapping symbol → recommended weight fraction.
        confidence_lower:  Lower confidence band per symbol.
        confidence_upper:  Upper confidence band per symbol.
        regime:            Regime used for this recommendation.
        no_trade_override: True when agent uncertainty is too high.
        portfolio_confidence: Scalar mean confidence across all assets.
    """
    weights: Dict[str, float]
    confidence_lower: Dict[str, float] = field(default_factory=dict)
    confidence_upper: Dict[str, float] = field(default_factory=dict)
    regime: str = "SIDEWAYS"
    no_trade_override: bool = False
    portfolio_confidence: float = 0.5
    timestamp: datetime = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


class CrewAIRLBridge:
    """
    Integration bridge between CrewAI Advisory System and RL Agent
    
    This bridge handles:
    1. Strategy validation requests to RL
    2. Performance feedback to RL for learning
    3. Weight updates from RL to advisory system
    4. Market regime notifications
    5. Learning insights extraction
    """
    
    def __init__(self, 
                 rl_agent_url: str = "http://localhost:5000",
                 advisory_agent_url: str = "http://localhost:8000",
                 use_event_bus: bool = True,
                 redis_url: Optional[str] = None):
        # Allow env override for RL agent URL
        env_rl = os.environ.get('RL_AGENT_URL') or os.environ.get('RL_API_URL')
        if env_rl:
            rl_agent_url = env_rl
        self.rl_agent_url = rl_agent_url
        self.advisory_agent_url = advisory_agent_url
        self.use_event_bus = use_event_bus
        self.redis_url = redis_url
        self.session = None
        self.message_queue = asyncio.Queue()
        self.is_connected = False
        # EventBus if REDIS_URL present
        self._bus: RedisStreamsEventBus | None = None
        if os.environ.get("REDIS_URL"):
            try:
                self._bus = RedisStreamsEventBus()
                logging.getLogger(__name__).info("CrewAIRLBridge: EventBus enabled for RL communication")
            except Exception as e:
                logging.getLogger(__name__).warning(f"CrewAIRLBridge: EventBus init failed, will use HTTP fallback: {e}")

    async def start(self):
        """Initialize the bridge and establish connections.
        In EventBus mode, do not fail if HTTP endpoints are unavailable.
        """
        try:
            # Session is useful for HTTP fallback even in bus mode
            if self.session is None:
                self.session = aiohttp.ClientSession()
            if self._bus is not None:
                # Best-effort HTTP checks; do not fail bridge when bus is present
                try:
                    await self._test_connections()
                except Exception as e:
                    logger.warning(f"HTTP endpoints unavailable, proceeding with EventBus-only mode: {e}")
                self.is_connected = True
                logger.info("CrewAI-RL Bridge started (EventBus mode)")
                return
            # No bus, require HTTP
            await self._test_connections()
            self.is_connected = True
            logger.info("CrewAI-RL Bridge started (HTTP mode)")
        except Exception as e:
            logger.error(f"Failed to start bridge: {e}")
            raise
    
    async def stop(self):
        """Clean shutdown of the bridge"""
        if self.session:
            await self.session.close()
        self.is_connected = False
        logger.info("CrewAI-RL Bridge stopped")
    
    async def _test_connections(self):
        """Test connections to both systems"""
        # Test RL Agent connection
        try:
            async with self.session.get(f"{self.rl_agent_url}/health") as response:
                if response.status != 200:
                    raise ConnectionError(f"RL Agent health check failed: {response.status}")
        except Exception as e:
            logger.error(f"Cannot connect to RL Agent: {e}")
            raise
        
        # Test Advisory Agent connection
        try:
            async with self.session.get(f"{self.advisory_agent_url}/api/advisory/health") as response:
                if response.status != 200:
                    raise ConnectionError(f"Advisory Agent health check failed: {response.status}")
        except Exception as e:
            logger.error(f"Cannot connect to Advisory Agent: {e}")
            raise
        
        logger.info("All connections verified successfully")
    
    async def send_strategy_for_validation(self, strategy: StrategyData) -> Dict[str, Any]:
        """
        Send strategy to RL agent for validation and optimization
        
        Args:
            strategy: Strategy data to validate
            
        Returns:
            Dict with RL validation results and optimization suggestions
        """
        if self._bus:
            try:
                resp = await self._bus.request("rl:validate_strategy", {"strategy": asdict(strategy)}, timeout_ms=15000)
                # If RL worker replies with placeholder error, use HTTP fallback
                if not resp or (isinstance(resp, dict) and not resp.get("success", True)):
                    raise RuntimeError(resp.get("error", "validate_strategy not available on EventBus"))
                return resp
            except Exception as e:
                logger.warning(f"EventBus validate_strategy not available, falling back to HTTP: {e}")
        # HTTP fallback with retries/timeouts
        # Prefer integration endpoint; if not available, fallback to rl_api simulate_strategy
        # Build a default date window (last 365 days) if not provided
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=365)).strftime('%Y-%m-%d')
        integration_payload = {
            "strategy_description": strategy.strategy_type,
            "symbol": strategy.symbol,
            "start_date": start_date,
            "end_date": end_date,
            "initial_balance": 100000,
            "agent_id": "main_rl_agent",
            "requester_agent": ",".join(strategy.generated_by) if strategy.generated_by else "AdvisorySystem"
        }
        try:
            resp = await self._http_retry_post(f"{self.rl_agent_url}/api/integration/crewai/simulate_strategy", integration_payload, timeout=90, retries=2)
            if resp.status == 200:
                result = await resp.json()
                logger.info("Strategy validation via integration endpoint succeeded")
                return result
            # If 404/405, try rl_api simulate_strategy
            logger.warning(f"Integration endpoint returned {resp.status}; trying rl_api simulate_strategy")
        except Exception as e:
            logger.warning(f"Integration endpoint call failed: {e}; trying rl_api simulate_strategy")
        # Fallback to rl_api simulate_strategy
        rl_payload = {
            "strategy_description": strategy.strategy_type,
            "symbol": strategy.symbol,
            "start_date": start_date,
            "end_date": end_date,
            "initial_balance": 100000
        }
        try:
            resp2 = await self._http_retry_post(f"{self.rl_agent_url}/api/rl/agents/main_rl_agent/simulate_strategy", rl_payload, timeout=90, retries=2)
            if resp2.status == 200:
                result = await resp2.json()
                logger.info("Strategy validation via rl_api simulate_strategy succeeded")
                return result
            error_msg = f"Strategy validation failed: {resp2.status}"
            logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            logger.error(f"Error sending strategy for validation: {e}")
            raise
    
    async def _http_retry_post(self, url: str, payload: Dict[str, Any], *, timeout: int = 60, retries: int = 2, backoff: float = 0.5) -> aiohttp.ClientResponse:
        if self.session is None:
            self.session = aiohttp.ClientSession()
        last_exc: Exception | None = None
        for attempt in range(retries + 1):
            try:
                return await self.session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=timeout))
            except Exception as e:
                last_exc = e
                await asyncio.sleep(backoff * (2 ** attempt))
        raise last_exc if last_exc else RuntimeError("HTTP POST failed")

    async def send_performance_feedback(self, metrics: PerformanceMetrics) -> bool:
        """
        Send performance feedback to RL agent for learning
        Prefer EventBus; fallback to HTTP.
        """
        if self._bus:
            try:
                payload = {"data": asdict(metrics)}
                await self._bus.request("rl:performance_feedback", payload, timeout_ms=15000)
                logger.info(f"Performance feedback sent via EventBus for {metrics.strategy_id}")
                return True
            except Exception as e:
                logger.warning(f"EventBus feedback failed, trying HTTP: {e}")
        # HTTP fallback
        if not self.is_connected:
            raise ConnectionError("Bridge not connected")
        
        payload = {
            "message_type": MessageType.PERFORMANCE_FEEDBACK.value,
            "metrics": asdict(metrics),
            "timestamp": datetime.now().isoformat()
        }
        
        try:
            async with self.session.post(
                f"{self.rl_agent_url}/api/performance_feedback",
                json=payload
            ) as response:
                if response.status == 200:
                    logger.info(f"Performance feedback sent successfully for strategy {metrics.strategy_id}")
                    return True
                else:
                    logger.error(f"Performance feedback failed: {response.status}")
                    return False
                    
        except Exception as e:
            logger.error(f"Error sending performance feedback: {e}")
            return False
    
    async def notify_regime_change(self, regime_data: Dict[str, Any]) -> bool:
        """
        Notify RL agent of market regime changes
        
        Args:
            regime_data: Market regime information
            
        Returns:
            Success status
        """
        if self._bus:
            try:
                payload = {"regime_data": regime_data}
                await self._bus.request("rl:regime_change", payload, timeout_ms=15000)
                logger.info("Regime change sent via EventBus")
                return True
            except Exception as e:
                logger.warning(f"EventBus regime_change failed, trying HTTP: {e}")
        # HTTP fallback
        if not self.is_connected:
            raise ConnectionError("Bridge not connected")
        payload = {
            "message_type": MessageType.REGIME_CHANGE.value,
            "regime_data": regime_data,
            "timestamp": datetime.now().isoformat()
        }
        
        try:
            async with self.session.post(
                f"{self.rl_agent_url}/api/regime_change",
                json=payload
            ) as response:
                if response.status == 200:
                    logger.info("Regime change notification sent successfully")
                    return True
                else:
                    logger.error(f"Regime change notification failed: {response.status}")
                    return False
                    
        except Exception as e:
            logger.error(f"Error sending regime change notification: {e}")
            return False
    
    async def get_weight_updates(self) -> Optional[WeightUpdate]:
        """
        Get agent weight updates from RL agent
        
        Returns:
            WeightUpdate object or None if no updates available
        """
        if self._bus:
            try:
                resp = await self._bus.request("rl:get_weight_updates", {"data": {}}, timeout_ms=10000)
                if resp and resp.get("has_updates"):
                    wu = WeightUpdate(
                        agent_weights=resp.get("agent_weights", {}),
                        confidence=resp.get("confidence", 0.0),
                        reasoning=resp.get("reasoning", "")
                    )
                    logger.info("Received weight updates via EventBus")
                    return wu
                return None
            except Exception as e:
                logger.warning(f"EventBus get_weight_updates failed, trying HTTP: {e}")
        # HTTP fallback
        if not self.is_connected:
            raise ConnectionError("Bridge not connected")
        
        try:
            async with self.session.get(
                f"{self.rl_agent_url}/api/get_weight_updates"
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("has_updates", False):
                        weight_update = WeightUpdate(
                            agent_weights=data["agent_weights"],
                            confidence=data["confidence"],
                            reasoning=data["reasoning"]
                        )
                        logger.info("Received weight updates from RL agent")
                        return weight_update
                    return None
                else:
                    logger.error(f"Failed to get weight updates: {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error getting weight updates: {e}")
            return None
    
    async def get_learning_insights(self) -> Optional[Dict[str, Any]]:
        """
        Get learning insights from RL agent
        
        Returns:
            Learning insights or None if unavailable
        """
        if self._bus:
            try:
                resp = await self._bus.request("rl:get_learning_insights", {"data": {}}, timeout_ms=10000)
                logger.info("Retrieved learning insights via EventBus")
                return resp
            except Exception as e:
                logger.warning(f"EventBus get_learning_insights failed, trying HTTP: {e}")
        # HTTP fallback
        if not self.is_connected:
            raise ConnectionError("Bridge not connected")
        
        try:
            async with self.session.get(
                f"{self.rl_agent_url}/api/learning_insights"
            ) as response:
                if response.status == 200:
                    insights = await response.json()
                    logger.info("Retrieved learning insights from RL agent")
                    return insights
                else:
                    logger.error(f"Failed to get learning insights: {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error getting learning insights: {e}")
            return None
    
    async def health_check(self) -> Dict[str, bool]:
        """
        Check health of both connected systems
        
        Returns:
            Health status of both systems
        """
        health_status = {
            "rl_agent": False,
            "advisory_agent": False,
            "bridge": self.is_connected
        }
        
        if not self.session:
            return health_status
        
        # Check RL Agent
        try:
            async with self.session.get(f"{self.rl_agent_url}/health") as response:
                health_status["rl_agent"] = response.status == 200
        except:
            pass
        
        # Check Advisory Agent
        try:
            async with self.session.get(f"{self.advisory_agent_url}/api/advisory/health") as response:
                health_status["advisory_agent"] = response.status == 200
        except:
            pass
        
        return health_status

    # ── v2 methods ─────────────────────────────────────────────────────────

    async def notify_regime_change_v2(self, regime_data: "RegimeData") -> bool:
        """Send a structured v2 regime-change notification to the RL agent.

        Args:
            regime_data: Populated ``RegimeData`` instance.

        Returns:
            True on success (best-effort; False on any error).
        """
        payload = asdict(regime_data)
        payload["timestamp"] = regime_data.timestamp.isoformat()
        payload["type"] = MessageType.REGIME_CHANGE_V2.value

        if self._bus:
            try:
                await self._bus.publish("rl:regime_change_v2", payload)
                logger.info(
                    "CrewAIRLBridge:notify_regime_change_v2 | regime=%s | via=EventBus",
                    regime_data.regime,
                )
                return True
            except Exception as exc:
                logger.warning(
                    "CrewAIRLBridge:notify_regime_change_v2 | EventBus failed, HTTP fallback: %s", exc
                )

        if self.session and self.is_connected:
            try:
                async with self.session.post(
                    f"{self.rl_agent_url}/api/v2/regime_change",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    success = resp.status in (200, 201, 202)
                    logger.info(
                        "CrewAIRLBridge:notify_regime_change_v2 | regime=%s | http=%d",
                        regime_data.regime, resp.status,
                    )
                    return success
            except Exception as exc:
                logger.debug("CrewAIRLBridge:notify_regime_change_v2 | HTTP error: %s", exc)
        return False

    async def send_performance_feedback_v2(
        self, metrics: "PerformanceMetricsV2"
    ) -> bool:
        """Send per-asset performance metrics to RL v2 for online learning.

        Args:
            metrics: Populated ``PerformanceMetricsV2`` instance.

        Returns:
            True on success (best-effort).
        """
        payload = {
            "type": MessageType.PERFORMANCE_FEEDBACK.value,
            "version": 2,
            "strategy_id": metrics.strategy_id,
            "portfolio_return": metrics.portfolio_return,
            "portfolio_sharpe": metrics.portfolio_sharpe,
            "portfolio_drawdown": metrics.portfolio_drawdown,
            "regime_at_start": metrics.regime_at_start,
            "regime_at_end": metrics.regime_at_end,
            "per_asset": [asdict(a) for a in metrics.per_asset],
            "timestamp": metrics.timestamp.isoformat(),
        }

        if self._bus:
            try:
                await self._bus.publish("rl:performance_feedback_v2", payload)
                logger.info(
                    "CrewAIRLBridge:send_performance_feedback_v2 | id=%s | return=%.3f",
                    metrics.strategy_id, metrics.portfolio_return,
                )
                return True
            except Exception as exc:
                logger.warning(
                    "CrewAIRLBridge:send_performance_feedback_v2 | EventBus failed: %s", exc
                )

        if self.session and self.is_connected:
            try:
                async with self.session.post(
                    f"{self.rl_agent_url}/api/v2/performance_feedback",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    return resp.status in (200, 201, 202)
            except Exception as exc:
                logger.debug(
                    "CrewAIRLBridge:send_performance_feedback_v2 | HTTP error: %s", exc
                )
        return False

    async def get_portfolio_weights(
        self,
        symbols: Optional[List[str]] = None,
        regime: str = "SIDEWAYS",
    ) -> Optional["PortfolioWeightUpdate"]:
        """Retrieve multi-asset target weights from RL v2.

        Args:
            symbols:  Asset symbols to request weights for.
            regime:   Current market regime label (passed as context).

        Returns:
            ``PortfolioWeightUpdate`` or ``None`` when unavailable.
        """
        request_payload: Dict[str, Any] = {
            "symbols": symbols or [],
            "regime": regime,
            "timestamp": datetime.utcnow().isoformat(),
        }

        if self._bus:
            try:
                resp = await self._bus.request(
                    "rl:get_portfolio_weights", request_payload, timeout_ms=10_000
                )
                if resp and isinstance(resp, dict) and "weights" in resp:
                    return PortfolioWeightUpdate(
                        weights=resp.get("weights", {}),
                        confidence_lower=resp.get("confidence_lower", {}),
                        confidence_upper=resp.get("confidence_upper", {}),
                        regime=resp.get("regime", regime),
                        no_trade_override=resp.get("no_trade_override", False),
                        portfolio_confidence=resp.get("portfolio_confidence", 0.5),
                    )
            except Exception as exc:
                logger.warning(
                    "CrewAIRLBridge:get_portfolio_weights | EventBus failed: %s", exc
                )

        if self.session and self.is_connected:
            try:
                async with self.session.post(
                    f"{self.rl_agent_url}/api/v2/portfolio_weights",
                    json=request_payload,
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return PortfolioWeightUpdate(
                            weights=data.get("weights", {}),
                            confidence_lower=data.get("confidence_lower", {}),
                            confidence_upper=data.get("confidence_upper", {}),
                            regime=data.get("regime", regime),
                            no_trade_override=data.get("no_trade_override", False),
                            portfolio_confidence=data.get("portfolio_confidence", 0.5),
                        )
            except Exception as exc:
                logger.debug(
                    "CrewAIRLBridge:get_portfolio_weights | HTTP error: %s", exc
                )
        return None
async def main():
    """Example usage of the CrewAI-RL Bridge"""
    bridge = CrewAIRLBridge()
    
    try:
        await bridge.start()
        
        # Test strategy validation
        test_strategy = StrategyData(
            symbol="AAPL",
            timeframe="1D",
            strategy_type="momentum",
            signals={"rsi": 65, "macd": "bullish"},
            risk_parameters={"stop_loss": 0.02, "take_profit": 0.05},
            confidence=0.75,
            generated_by=["TechnicalAgent", "SentimentAgent"]
        )
        
        validation_result = await bridge.send_strategy_for_validation(test_strategy)
        print(f"Validation result: {validation_result}")
        
        # Test performance feedback
        test_metrics = PerformanceMetrics(
            strategy_id="test_strategy_001",
            total_return=0.08,
            sharpe_ratio=1.2,
            max_drawdown=0.05,
            win_rate=0.65,
            avg_trade_duration=3.5,
            total_trades=20,
            agent_contributions={"TechnicalAgent": 0.6, "SentimentAgent": 0.4}
        )
        
        feedback_success = await bridge.send_performance_feedback(test_metrics)
        print(f"Feedback sent: {feedback_success}")
        
        # Test weight updates
        weight_updates = await bridge.get_weight_updates()
        if weight_updates:
            print(f"Received weight updates: {weight_updates}")
        
        # Test health check
        health = await bridge.health_check()
        print(f"System health: {health}")
        
    finally:
        await bridge.stop()


if __name__ == "__main__":
    asyncio.run(main())
