/**
 * Service Worker for AI Trading Advisory System
 * Provides offline capability, caching, and background sync
 */

const CACHE_NAME = 'ai-trading-advisory-v1.0.1';
const API_CACHE_NAME = 'ai-trading-api-v1.0.1';

// Resources to cache immediately
const CORE_RESOURCES = [
    '/',
    '/css/main.css',
    '/css/components.css',
    '/js/config.js',
    '/js/performance.js',
    '/js/security.js',
    '/js/api.js',
    '/js/chat.js',
    '/js/monitoring.js',
    '/js/main.js',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css',
    'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'
];

// API endpoints to cache
const CACHEABLE_API_PATTERNS = [
    /\/api\/health$/,
    /\/api\/system\/status$/,
    /\/api\/metrics$/,
    /\/api\/proxy\/rl\/insights$/
];

// Install event - cache core resources
self.addEventListener('install', event => {
    console.log('Service Worker: Installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Service Worker: Caching core resources');
                return cache.addAll(CORE_RESOURCES);
            })
            .then(() => {
                console.log('Service Worker: Core resources cached successfully');
                return self.skipWaiting();
            })
            .catch(error => {
                console.error('Service Worker: Failed to cache core resources', error);
            })
    );
});

// Activate event - cleanup old caches
self.addEventListener('activate', event => {
    console.log('Service Worker: Activating...');
    
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames
                        .filter(cacheName => {
                            return cacheName !== CACHE_NAME && cacheName !== API_CACHE_NAME;
                        })
                        .map(cacheName => {
                            console.log('Service Worker: Deleting old cache', cacheName);
                            return caches.delete(cacheName);
                        })
                );
            })
            .then(() => {
                console.log('Service Worker: Activated successfully');
                return self.clients.claim();
            })
    );
});

// Fetch event - implement caching strategies
self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);
    
    // Skip non-GET requests
    if (request.method !== 'GET') {
        return;
    }
    
    // Handle different types of requests
    if (request.url.includes('/api/')) {
        event.respondWith(handleApiRequest(request));
    } else {
        event.respondWith(handleStaticRequest(request));
    }
});

/**
 * Handle API requests with network-first strategy
 */
async function handleApiRequest(request) {
    const url = new URL(request.url);
    const isCacheable = CACHEABLE_API_PATTERNS.some(pattern => pattern.test(url.pathname));
    
    if (isCacheable) {
        try {
            // Try network first
            const networkResponse = await fetch(request);
            
            if (networkResponse.ok) {
                // Cache successful response
                const cache = await caches.open(API_CACHE_NAME);
                cache.put(request, networkResponse.clone());
                return networkResponse;
            }
            
            // If network fails, try cache
            const cachedResponse = await caches.match(request);
            if (cachedResponse) {
                console.log('Service Worker: Serving API from cache', request.url);
                return cachedResponse;
            }
            
            return networkResponse;
            
        } catch (error) {
            console.log('Service Worker: Network failed, trying cache', request.url);
            
            // Network failed, try cache
            const cachedResponse = await caches.match(request);
            if (cachedResponse) {
                return cachedResponse;
            }
            
            // Return offline response
            return new Response(
                JSON.stringify({
                    success: false,
                    error: 'Offline - cached data not available',
                    offline: true,
                    timestamp: new Date().toISOString()
                }),
                {
                    status: 503,
                    statusText: 'Service Unavailable',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            );
        }
    } else {
        // For non-cacheable API requests, just go to network
        return fetch(request);
    }
}

/**
 * Handle static resources with cache-first strategy
 */
async function handleStaticRequest(request) {
    try {
        // Try cache first
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            console.log('Service Worker: Serving from cache', request.url);
            return cachedResponse;
        }
        
        // If not in cache, try network
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            // Cache successful response
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
        
    } catch (error) {
        console.log('Service Worker: Network failed for static resource', request.url);
        
        // If it's the main page and we're offline, return cached version or offline page
        if (request.url.endsWith('/') || request.url.includes('index.html')) {
            const cachedIndex = await caches.match('/');
            if (cachedIndex) {
                return cachedIndex;
            }
            
            // Return basic offline page
            return new Response(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>AI Trading Advisory - Offline</title>
                    <style>
                        body { 
                            font-family: Inter, sans-serif; 
                            text-align: center; 
                            padding: 50px; 
                            background: #f5f5f5; 
                        }
                        .offline-message {
                            background: white;
                            padding: 40px;
                            border-radius: 8px;
                            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                            max-width: 500px;
                            margin: 0 auto;
                        }
                        .offline-icon {
                            font-size: 48px;
                            color: #007bff;
                            margin-bottom: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="offline-message">
                        <div class="offline-icon">📡</div>
                        <h1>You're Offline</h1>
                        <p>The AI Trading Advisory System is currently unavailable.</p>
                        <p>Please check your internet connection and try again.</p>
                        <button onclick="window.location.reload()">Retry</button>
                    </div>
                </body>
                </html>
            `, {
                headers: { 'Content-Type': 'text/html' }
            });
        }
        
        // For other static resources, return a basic error
        return new Response('Resource not available offline', {
            status: 503,
            statusText: 'Service Unavailable'
        });
    }
}

// Background sync for offline actions
self.addEventListener('sync', event => {
    console.log('Service Worker: Background sync triggered', event.tag);
    
    if (event.tag === 'background-sync-chat') {
        event.waitUntil(syncOfflineChatMessages());
    }
});

/**
 * Sync offline chat messages when connection is restored
 */
async function syncOfflineChatMessages() {
    try {
        // Get offline messages from IndexedDB
        const offlineMessages = await getOfflineMessages();
        
        for (const message of offlineMessages) {
            try {
                const response = await fetch('/api/proxy/chat', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(message)
                });
                
                if (response.ok) {
                    // Remove from offline storage
                    await removeOfflineMessage(message.id);
                    console.log('Service Worker: Synced offline message', message.id);
                }
            } catch (error) {
                console.error('Service Worker: Failed to sync message', message.id, error);
            }
        }
        
        // Notify main thread about sync completion
        const clients = await self.clients.matchAll();
        clients.forEach(client => {
            client.postMessage({
                type: 'SYNC_COMPLETE',
                data: { messagesProcessed: offlineMessages.length }
            });
        });
        
    } catch (error) {
        console.error('Service Worker: Background sync failed', error);
    }
}

/**
 * Get offline messages from IndexedDB (placeholder implementation)
 */
async function getOfflineMessages() {
    // This would connect to IndexedDB to get stored offline messages
    // For now, returning empty array
    return [];
}

/**
 * Remove offline message from storage (placeholder implementation)
 */
async function removeOfflineMessage(messageId) {
    // This would remove the message from IndexedDB
    console.log('Service Worker: Removing offline message', messageId);
}

// Message handling for communication with main thread
self.addEventListener('message', event => {
    const { type, data } = event.data;
    
    switch (type) {
        case 'SKIP_WAITING':
            self.skipWaiting();
            break;
            
        case 'CACHE_API_RESPONSE':
            cacheApiResponse(data.request, data.response);
            break;
            
        case 'CLEAR_CACHE':
            clearAllCaches();
            break;
            
        default:
            console.log('Service Worker: Unknown message type', type);
    }
});

/**
 * Cache API response manually
 */
async function cacheApiResponse(request, response) {
    try {
        const cache = await caches.open(API_CACHE_NAME);
        await cache.put(request, response);
        console.log('Service Worker: Manually cached API response');
    } catch (error) {
        console.error('Service Worker: Failed to cache API response', error);
    }
}

/**
 * Clear all caches
 */
async function clearAllCaches() {
    try {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
        console.log('Service Worker: All caches cleared');
    } catch (error) {
        console.error('Service Worker: Failed to clear caches', error);
    }
}

console.log('Service Worker: Script loaded successfully');
