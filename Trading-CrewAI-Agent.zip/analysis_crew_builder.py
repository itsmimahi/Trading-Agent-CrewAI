"""
Phase 3 — AnalysisCrewBuilder
==============================
Builds the synthesis Crew that reconciles outputs from all 5 market Crews
(IN / US / EU / APAC / CRYPTO) and produces a single unified advisory
recommendation with conviction scores and actionable trade ideas.

3-agent sequential pipeline
────────────────────────────
    1. CrossMarketCorrelationsAgent  — correlations, divergences, macro theme
    2. RiskAggregationAgent          — portfolio-level risk, position sizing
    3. SynthesisStrategistAgent      — final unified advisory with trade ideas

RL A2A validation (optional)
──────────────────────────────
v1 (HTTP): rl_a2a_validate() POSTs synthesis to a running RL HTTP service.
    ENABLE_RL_VALIDATION=1    (default: disabled)
    RL_AGENT_URL              (default: http://localhost:5000)

v2 (local): rl_a2a_validate_v2() uses RLAgentV2 directly — no network call,
    offline-capable, regime-conditioned, multi-asset position recommendations.
    ENABLE_RL_VALIDATION_V2=1 (default: disabled)
    RL_V2_CHECKPOINT          (optional path to saved model checkpoint)

Usage (inside advisory_flow.synthesis_step):
    from analysis_crew_builder import AnalysisCrewBuilder, rl_a2a_validate_v2
    builder = AnalysisCrewBuilder(llm=self._llm, verbose=self._verbose)
    crew    = builder.build(market_results=s.market_results,
                            portfolio_snapshot=s.portfolio_snapshot)
    raw     = crew.kickoff()
    s.synthesis_result = rl_a2a_validate_v2(str(raw), s.market_results)
"""

from __future__ import annotations

import json
import logging
import os
import textwrap
from datetime import datetime
from typing import Any, Dict, List, Optional

from crewai import Agent, Crew, Process, Task
from crewai.llm import LLM

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Builder
# ─────────────────────────────────────────────────────────────────────────────

class AnalysisCrewBuilder:
    """
    Builds the AnalysisCrew (Phase 3).

    The crew accepts a dict of per-market results from Phase 1/2, runs three
    specialist agents in sequence, and returns a unified advisory report as its
    CrewOutput.
    """

    def __init__(
        self,
        llm: LLM,
        verbose: bool = False,
        max_iter: int = 8,
    ) -> None:
        self._llm = llm
        self._verbose = verbose
        self._max_iter = max_iter

    # ── Public API ────────────────────────────────────────────────────────────

    def build(
        self,
        market_results: Dict[str, Any],
        portfolio_snapshot: Optional[Dict[str, Any]] = None,
    ) -> Crew:
        """
        Build and return the AnalysisCrew.

        Args:
            market_results: Per-market results from MarketCrewBuilder.
                            Keys: "IN" | "US" | "EU" | "APAC" | "CRYPTO"
                            Values: {"raw": "...", "market": "...", "intent": "..."}
            portfolio_snapshot: Optional pre-fetched portfolio state.

        Returns:
            A crewai.Crew ready to kickoff().
        """
        market_ctx = self._format_market_results(market_results)
        agents = self._build_agents()
        tasks = self._build_tasks(agents, market_ctx, portfolio_snapshot)

        crew = Crew(
            agents=list(agents.values()),
            tasks=tasks,
            process=Process.sequential,
            verbose=self._verbose,
            memory=False,  # Disabled: CrewAI 1.14.5 memory bugs cause noise; no cross-session recall loss
            planning=True,
            planning_llm=self._llm,
        )
        logger.info(
            "AnalysisCrewBuilder | markets=%s | agents=%d | tasks=%d",
            list(market_results.keys()), len(agents), len(tasks),
        )
        return crew

    # ── Context serialiser ────────────────────────────────────────────────────

    @staticmethod
    def _format_market_results(market_results: Dict[str, Any]) -> str:
        """Serialise per-market crew outputs into a readable context block."""
        if not market_results:
            return "No individual market analyses are available."

        parts: List[str] = []
        for market, result in market_results.items():
            if isinstance(result, dict):
                raw = result.get("raw") or json.dumps(result, default=str)
            else:
                raw = str(result)
            # Cap each market block at 3 000 chars to stay within LLM context
            parts.append(f"### {market} Market Analysis\n{raw[:3000]}")

        return "\n\n".join(parts)

    # ── Agent factory ─────────────────────────────────────────────────────────

    def _build_agents(self) -> Dict[str, Agent]:
        """Build the 3 analysis agents."""

        def _agent(role: str, goal: str, backstory: str) -> Agent:
            return Agent(
                role=role,
                goal=goal,
                backstory=backstory,
                verbose=self._verbose,
                allow_delegation=False,
                memory=False,  # Crew-level Memory(llm=...) handles shared memory
                reasoning=True,
                max_reasoning_attempts=2,
                max_iter=self._max_iter,
                llm=self._llm,
            )

        return {
            "correlations": _agent(
                role="Cross-Market Correlation Analyst",
                goal=(
                    "Identify the strongest cross-market correlations, notable divergences, "
                    "and the dominant global macro theme from individual market analyses."
                ),
                backstory=(
                    "You are a global macro strategist who specialises in spotting hidden "
                    "linkages between equity, crypto, commodity, and FX markets. You detect "
                    "risk-on/risk-off regime shifts, capital rotation patterns, and inter-market "
                    "contagion. Your analysis reveals the invisible threads connecting markets "
                    "that most analysts miss."
                ),
            ),
            "risk": _agent(
                role="Portfolio Risk Aggregator",
                goal=(
                    "Consolidate individual market risk signals into a unified portfolio-level "
                    "risk assessment covering regime, top risks, position sizing, and hedging."
                ),
                backstory=(
                    "You are a quantitative risk manager at a multi-asset hedge fund. You receive "
                    "individual market risk reports and synthesise them into actionable guidance "
                    "on overall portfolio risk, tail risks, VaR, and optimal position sizing. "
                    "You are known for your blunt, numbers-driven risk assessment."
                ),
            ),
            "synthesis": _agent(
                role="Advisory Synthesis Strategist",
                goal=(
                    "Produce the final unified investment advisory with ranked trade ideas, "
                    "conviction scores, clear rationale, and concrete action items."
                ),
                backstory=(
                    "You are the head of multi-asset investment strategy at a leading advisory "
                    "firm. You receive research from your market analysts and risk team, then "
                    "synthesise it into a concise, client-ready recommendation. Your output "
                    "directly drives portfolio decisions. You balance conviction with discipline, "
                    "always anchoring recommendations in risk-adjusted returns."
                ),
            ),
        }

    # ── Task factory ──────────────────────────────────────────────────────────

    def _build_tasks(
        self,
        agents: Dict[str, Agent],
        market_ctx: str,
        portfolio_snapshot: Optional[Dict[str, Any]],
    ) -> List[Task]:
        """Build the 3 sequential tasks with proper context chaining."""
        ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

        portfolio_note = ""
        if portfolio_snapshot:
            cash = portfolio_snapshot.get("cash", "N/A")
            n_pos = len(portfolio_snapshot.get("holdings", []) or [])
            portfolio_note = (
                f"\n\n**Current Portfolio Context**: cash={cash}, "
                f"open_positions={n_pos}"
            )

        # Task 1: Cross-Market Correlations
        correlations_task = Task(
            description=textwrap.dedent(f"""
                Timestamp: {ts}

                You have received individual market analyses from the following market crews:

                {market_ctx}

                Your analysis tasks:
                1. Identify the 3-5 strongest cross-market correlations (with direction and strength).
                2. Flag any notable divergences — markets moving in opposite directions — with your interpretation.
                3. State the single dominant global macro theme driving all these markets today.
                4. List up to 3 event risks or catalysts that could simultaneously affect multiple markets.

                Format your response as structured bullet points. Be specific and concise.
            """).strip(),
            expected_output=(
                "Structured bullet-point analysis covering: (a) top 3-5 cross-market correlations, "
                "(b) notable divergences with interpretations, (c) dominant macro theme, "
                "(d) cross-market event risks."
            ),
            agent=agents["correlations"],
        )

        # Task 2: Risk Aggregation
        risk_task = Task(
            description=textwrap.dedent(f"""
                Using the individual market analyses and the cross-market correlation findings:

                {market_ctx}{portfolio_note}

                Provide a portfolio-level risk assessment covering:
                1. **Risk regime**: Is the current environment risk-on / risk-off / neutral?
                   Provide brief justification.
                2. **Top 3 risk factors**: What are the three most important risks to monitor
                   over the next 5-10 trading days? Rank them by probability × impact.
                3. **Position sizing**: Recommended maximum per-trade size as % of portfolio,
                   given the current volatility environment.
                4. **Avoid list**: Any specific markets, sectors, or instruments to avoid entering
                   new long positions in right now, and why.
                5. **Stop-loss guidance**: Recommended stop-loss buffer (% below entry price) for
                   new positions in the current regime.

                Be quantitative wherever possible (e.g. "max 3% per trade", "VIX >25 = reduce risk").
            """).strip(),
            expected_output=(
                "Portfolio risk assessment with: risk regime, top 3 risks ranked, position sizing "
                "recommendation, avoid list, and stop-loss guidance. Quantitative where possible."
            ),
            agent=agents["risk"],
            context=[correlations_task],
        )

        # Task 3: Synthesis (context from both prior tasks)
        synthesis_task = Task(
            description=textwrap.dedent(f"""
                Timestamp: {ts}

                You have access to:
                - Individual market analyses from all active market crews
                - Cross-market correlation analysis
                - Portfolio-level risk assessment

                Synthesise everything into a final advisory report with the following structure:

                ## Executive Summary
                2-3 sentences capturing the overall market outlook and dominant theme.

                ## Top Trade Recommendations
                List 3-5 specific, actionable trade ideas, ranked by conviction (highest first):
                For each idea include:
                - Instrument/Symbol (with market suffix if applicable, e.g. RELIANCE.NS, AAPL)
                - Market: IN / US / EU / APAC / CRYPTO
                - Action: BUY / SELL / HOLD / WATCH
                - Entry zone or current price range
                - Target price or % upside/downside
                - Stop-loss level (absolute or % from entry)
                - Conviction: HIGH / MEDIUM / LOW (with a 1-line rationale)
                - Time horizon: SHORT (1-5 days) / MEDIUM (1-4 weeks) / LONG (1-3 months)

                ## Markets to Watch
                2-3 bullet points on key indicators, events, or price levels to monitor.

                ## Risk Warnings
                2-3 specific, actionable risk warnings. Not generic disclaimers.

                ## Action Items
                A numbered list of 3-5 concrete steps the user should take now.

                Keep the tone professional and direct. No filler text.
            """).strip(),
            expected_output=(
                "Complete advisory report with Executive Summary, Top Trade Recommendations "
                "(3-5 ranked), Markets to Watch, Risk Warnings, and numbered Action Items."
            ),
            agent=agents["synthesis"],
            context=[correlations_task, risk_task],
        )

        return [correlations_task, risk_task, synthesis_task]


# ─────────────────────────────────────────────────────────────────────────────
# RL A2A Validation (optional post-processing)
# ─────────────────────────────────────────────────────────────────────────────

def rl_a2a_validate(
    synthesis_text: str,
    market_results: Dict[str, Any],
    timeout_seconds: int = 5,
) -> str:
    """
    Optionally enhance the advisory synthesis with RL-agent confidence calibration.

    This function implements the A2A (agent-to-agent) bridge between the
    AnalysisCrew and the RL Trading Agent.  It is a no-op unless both:
        ENABLE_RL_VALIDATION=1   is set in the environment
        RL_AGENT_URL             points to a running RL agent service

    Args:
        synthesis_text:   The raw advisory synthesis from AnalysisCrew.
        market_results:   Per-market crew outputs (for context).
        timeout_seconds:  HTTP request timeout.  Default 5 s.

    Returns:
        The (possibly enhanced) synthesis text.  If the RL agent is
        unreachable or returns an error, the original text is returned
        unchanged — no exceptions are propagated.
    """
    if os.getenv("ENABLE_RL_VALIDATION", "0") != "1":
        return synthesis_text

    rl_url = os.getenv("RL_AGENT_URL", "http://localhost:5000")

    try:
        import requests  # optional dependency — may not be in all envs

        payload = {
            "synthesis": synthesis_text[:2000],   # cap for API payload size
            "market_results_summary": {
                market: (
                    str(result.get("raw", ""))[:500]
                    if isinstance(result, dict)
                    else str(result)[:500]
                )
                for market, result in market_results.items()
            },
            "timestamp": datetime.utcnow().isoformat(),
        }

        resp = requests.post(
            f"{rl_url}/api/strategy/validate",
            json=payload,
            timeout=timeout_seconds,
        )
        resp.raise_for_status()
        data = resp.json()

        adjustment = data.get("adjustment", "")
        confidence_delta = data.get("confidence_delta", 0)

        if adjustment:
            synthesis_text = (
                f"{synthesis_text}\n\n"
                f"---\n"
                f"**RL Agent Validation** (Δconfidence={confidence_delta:+.2f}):\n"
                f"{adjustment}"
            )
            logger.info(
                "rl_a2a_validate | applied | confidence_delta=%s", confidence_delta
            )
        else:
            logger.info("rl_a2a_validate | no adjustment returned")

        return synthesis_text

    except Exception as exc:
        logger.debug("rl_a2a_validate | unavailable or error: %s", exc)
        return synthesis_text


# ─────────────────────────────────────────────────────────────────────────────
# RL v2 A2A Validation — local, offline-capable, regime-conditioned
# ─────────────────────────────────────────────────────────────────────────────

# Module-level singleton so we don't re-instantiate on every call
_rl_v2_agent: Optional[Any] = None


def rl_a2a_validate_v2(
    synthesis_text: str,
    market_results: Dict[str, Any],
    current_weights: Optional[Any] = None,
    checkpoint_path: Optional[str] = None,
) -> str:
    """Enhance advisory synthesis using the local RLAgentV2 (no HTTP call).

    This is the v2 replacement for ``rl_a2a_validate()``.  It runs entirely
    in-process — no running RL service is required.  The agent uses
    ``validate_strategy()`` to detect the market regime and produce
    per-asset position recommendations with confidence bands.

    Activation:
        Set ``ENABLE_RL_VALIDATION_V2=1`` in the environment.

    Args:
        synthesis_text:   Raw advisory synthesis from AnalysisCrew.
        market_results:   Per-market crew outputs (``s.market_results``).
        current_weights:  Current portfolio weights array (n_assets,).
                          Pass ``None`` when unknown (agent assumes zero).
        checkpoint_path:  Override path to a saved v2 checkpoint (.zip).
                          Falls back to ``RL_V2_CHECKPOINT`` env var.

    Returns:
        The (possibly annotated) synthesis text.  Returns original text
        unchanged on any error — no exceptions are propagated.
    """
    if os.getenv("ENABLE_RL_VALIDATION_V2", "0") != "1":
        return synthesis_text

    global _rl_v2_agent

    try:
        import sys
        import os as _os
        # Ensure RL_Agent is importable
        _root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
        if _root not in sys.path:
            sys.path.insert(0, _root)

        from RL_Agent.rl_agent_v2 import RLAgentV2

        # Build or reuse agent singleton
        if _rl_v2_agent is None:
            _rl_v2_agent = RLAgentV2()
            ckpt = checkpoint_path or os.getenv("RL_V2_CHECKPOINT", "")
            if ckpt and os.path.exists(ckpt):
                _rl_v2_agent.load(ckpt)
                logger.info("rl_a2a_validate_v2 | loaded checkpoint: %s", ckpt)
            else:
                logger.info("rl_a2a_validate_v2 | no checkpoint — using untrained agent (degraded mode)")

        result = _rl_v2_agent.validate_strategy(
            synthesis_text=synthesis_text,
            market_context=market_results,
            current_weights=current_weights,
        )

        if result.synthesis_annotation:
            synthesis_text = f"{synthesis_text}\n\n{result.synthesis_annotation}"
            logger.info(
                "rl_a2a_validate_v2 | applied | regime=%s | confidence=%.2f | no_trade=%s",
                result.regime,
                result.portfolio_confidence,
                result.no_trade_override,
            )

        return synthesis_text

    except Exception as exc:
        logger.debug("rl_a2a_validate_v2 | error: %s", exc)
        return synthesis_text
