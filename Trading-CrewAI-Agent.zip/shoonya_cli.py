"""
Shoonya CLI (dotenv-based)

This script replaces the old YAML-based demo and loads credentials from a .env file.

Expected .env entries at repository root:
  SHOONYA_USER=...
  SHOONYA_PASSWORD=...
  SHOONYA_TOTP=...
  SHOONYA_VENDOR_CODE=...
  SHOONYA_API_KEY=...
  SHOONYA_IMEI=...

Usage (from repo root):
  python scripts/shoonya_cli.py
"""

from __future__ import annotations

import os
import sys
import time
import logging
from datetime import datetime, timedelta
from typing import Any, Dict

try:
    # Locate and load .env from repo root automatically
    from dotenv import load_dotenv, find_dotenv
except Exception as e:
    print("python-dotenv is required. Install with: pip install python-dotenv")
    raise

try:
    from NorenRestApiPy.NorenApi import NorenApi as ShoonyaApi
except Exception as e:
    print("NorenRestApiPy is required. Install with: pip install NorenRestApiPy")
    raise

import pandas as pd


# ---------- Logging ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("shoonya-cli")


# ---------- Helpers ----------
def epoch(dt: datetime) -> int:
    return int(dt.timestamp())


def load_credentials() -> Dict[str, str]:
    load_dotenv(find_dotenv(), override=False)
    creds = {
        "user": os.getenv("SHOONYA_USER"),
        "password": os.getenv("SHOONYA_PASSWORD"),
        "totp": os.getenv("SHOONYA_TOTP"),
        "vendor_code": os.getenv("SHOONYA_VENDOR_CODE"),
        "api_key": os.getenv("SHOONYA_API_KEY"),
        "imei": os.getenv("SHOONYA_IMEI"),
    }

    missing = [k for k, v in creds.items() if not v]
    if missing:
        print("\n[ERROR] Missing required .env variables:")
        for k in missing:
            print(f"  - SHOONYA_{k.upper()}")
        print("\nCreate or update the .env file at the repo root and try again.")
        sys.exit(1)
    return creds


def print_menu() -> None:
    print("\nMenu:")
    print("  f => find symbol")
    print("  m => get quotes")
    print("  p => security info")
    print("  v => historical data (sample)")
    print("  t => today's 1-min data (sample)")
    print("  d => daily series (RELIANCE-EQ)")
    print("  o => option chain sample (MCX CRUDEOIL)")
    print("  s => start websocket")
    print("  q => logout & quit")


def main() -> None:
    creds = load_credentials()

    # Initialize API (try standard endpoints)
    api = ShoonyaApi(
        host="https://api.shoonya.com/NorenWClientTP/",
        websocket="wss://api.shoonya.com/NorenWSTP/",
    )

    # ----- Callbacks -----
    socket_opened = {"flag": False}

    def on_order_update(msg: Dict[str, Any]):
        print("order event:", msg)

    def on_quote_update(msg: Dict[str, Any]):
        ts = time.strftime("%d-%m-%Y %H:%M:%S")
        print(f"quote event: {ts} {msg}")

    def on_socket_open():
        socket_opened["flag"] = True
        print("app is connected; subscribing to NSE|11630")
        try:
            api.subscribe("NSE|11630")
        except Exception as e:
            print("subscribe error:", e)

    # ----- Login -----
    print("\nLogging in to Shoonya...")
    resp = api.login(
        userid=creds["user"],
        password=creds["password"],
        twoFA=creds["totp"],
        vendor_code=creds["vendor_code"],
        api_secret=creds["api_key"],
        imei=creds["imei"],
    )

    if not resp or (isinstance(resp, dict) and resp.get("stat") != "Ok"):
        print("\n[ERROR] Login failed.")
        print("Response:", resp)
        sys.exit(1)

    print("Login successful.")

    try:
        while True:
            print_menu()
            choice = input("what shall we do? ").strip().lower()

            if choice == "v":
                # Sample: 4-minute candles for NSE token 22 over a fixed window
                start = datetime.now() - timedelta(days=2)
                end = datetime.now()
                try:
                    ret = api.get_time_price_series(
                        exchange="NSE",
                        token="22",
                        starttime=epoch(start),
                        endtime=epoch(end),
                        interval="4",
                    )
                    if isinstance(ret, list) and ret:
                        df = pd.DataFrame(ret)
                        print(df.head())
                        print(f"rows: {len(df)}")
                    else:
                        print(ret)
                except Exception as e:
                    print("historical error:", e)

            elif choice == "t":
                try:
                    ret = api.get_time_price_series(exchange="NFO", token="71321")
                    if isinstance(ret, list) and ret:
                        df = pd.DataFrame(ret)
                        print(df.head())
                        print(f"rows: {len(df)}")
                    else:
                        print(ret)
                except Exception as e:
                    print("today 1-min error:", e)

            elif choice == "f":
                exch = input("exchange [NSE]: ").strip().upper() or "NSE"
                query = input("search text [RELIANCE]: ").strip() or "RELIANCE"
                try:
                    ret = api.searchscrip(exchange=exch, searchtext=query)
                    # API may return list or dict with 'values'
                    rows = []
                    if isinstance(ret, dict) and "values" in ret:
                        rows = ret.get("values", [])
                    elif isinstance(ret, list):
                        rows = ret
                    print(f"found {len(rows)} matches")
                    for r in rows[:10]:
                        print(r)
                except Exception as e:
                    print("search error:", e)

            elif choice == "d":
                try:
                    ret = api.get_daily_price_series(
                        exchange="NSE", tradingsymbol="RELIANCE-EQ", startdate=0
                    )
                    if isinstance(ret, list) and ret:
                        df = pd.DataFrame(ret)
                        print(df.tail())
                        print(f"rows: {len(df)}")
                    else:
                        print(ret)
                except Exception as e:
                    print("daily error:", e)

            elif choice == "p":
                try:
                    ret = api.get_security_info(exchange="NSE", token="22")
                    print(ret)
                except Exception as e:
                    print("security info error:", e)

            elif choice == "m":
                try:
                    ret = api.get_quotes(exchange="NSE", token="22")
                    print(ret)
                except Exception as e:
                    print("quotes error:", e)

            elif choice == "o":
                try:
                    chain = api.get_option_chain(
                        exchange="MCX", tradingsymbol="CRUDEOIL18FEB22", strikeprice=4150, count=2
                    )
                    chainscrips = []
                    values = chain.get("values", []) if isinstance(chain, dict) else []
                    for scrip in values:
                        try:
                            scripdata = api.get_quotes(exchange=scrip.get("exch"), token=scrip.get("token"))
                            chainscrips.append(scripdata)
                        except Exception as inner:
                            print("quote fetch failed for leg:", scrip, inner)
                    print(chainscrips)
                except Exception as e:
                    print("option chain error:", e)

            elif choice == "s":
                if socket_opened["flag"]:
                    print("websocket already opened")
                    continue
                try:
                    api.start_websocket(
                        order_update_callback=on_order_update,
                        subscribe_callback=on_quote_update,
                        socket_open_callback=on_socket_open,
                    )
                    print("websocket started")
                except Exception as e:
                    print("websocket error:", e)

            elif choice == "q":
                try:
                    out = api.logout()
                    print(out)
                finally:
                    print("Fin")
                break

            else:
                print("Unknown choice. Try again.")

    finally:
        # Ensure logout on unexpected exit
        try:
            api.logout()
        except Exception:
            pass


if __name__ == "__main__":
    main()
