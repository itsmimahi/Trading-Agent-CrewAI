from __future__ import annotations

import json
import os
import pathlib
import tempfile
import threading
from typing import Any, Dict, Tuple

_lock = threading.Lock()


def _default_state_path() -> str:
    # Default under repo root data/ folder
    try:
        root = pathlib.Path(__file__).resolve().parents[2]
    except Exception:
        root = pathlib.Path.cwd()
    data_dir = root / 'data'
    data_dir.mkdir(parents=True, exist_ok=True)
    return str(data_dir / 'pta_paper_state.json')


def _state_file() -> str:
    return os.getenv('PTA_STATE_FILE') or _default_state_path()


def _atomic_write(path: str, payload: Dict[str, Any]) -> None:
    tmp_dir = os.path.dirname(path) or '.'
    with tempfile.NamedTemporaryFile('w', delete=False, dir=tmp_dir, encoding='utf-8') as tf:
        json.dump(payload, tf, ensure_ascii=False, indent=2)
        tmp_name = tf.name
    os.replace(tmp_name, path)


def load_state() -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Return (portfolio, meta) where portfolio has 'cash' and 'positions'.
    meta may contain 'orders' (list of orders) and 'order_seq' (int).
    """
    path = _state_file()
    if not os.path.exists(path):
        start_cash = 50_000.0
        try:
            env_cash = os.environ.get('PTA_STARTING_CASH')
            if env_cash:
                start_cash = float(env_cash)
        except Exception:
            pass
        return {'cash': start_cash, 'positions': {}}, {'orders': [], 'order_seq': 1}
    try:
        with _lock:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        portfolio = data.get('portfolio') or {'cash': 50_000.0, 'positions': {}}
        meta = {
            'orders': data.get('orders') or [],
            'order_seq': int(data.get('order_seq') or 1),
        }
        # Coerce shapes
        if 'cash' not in portfolio or 'positions' not in portfolio:
            start_cash = 50_000.0
            try:
                env_cash = os.environ.get('PTA_STARTING_CASH')
                if env_cash:
                    start_cash = float(env_cash)
            except Exception:
                pass
            portfolio = {'cash': start_cash, 'positions': {}}
        if not isinstance(meta.get('orders'), list):
            meta['orders'] = []
        if not isinstance(meta.get('order_seq'), int) or meta['order_seq'] < 1:
            meta['order_seq'] = 1
        return portfolio, meta
    except Exception:
        # Corrupt file or parse error: start fresh
        start_cash = 50_000.0
        try:
            env_cash = os.environ.get('PTA_STARTING_CASH')
            if env_cash:
                start_cash = float(env_cash)
        except Exception:
            pass
        return {'cash': start_cash, 'positions': {}}, {'orders': [], 'order_seq': 1}


def save_state(portfolio: Dict[str, Any], orders: list[Dict[str, Any]], order_seq: int) -> None:
    path = _state_file()
    payload = {
        'portfolio': portfolio,
        'orders': orders,
        'order_seq': order_seq,
    }
    with _lock:
        _atomic_write(path, payload)
