# Getting Started

---

## Prerequisites

| Requirement | Version | Notes |
|-------------|---------|-------|
| Python | 3.11 | Strictly required (TA-Lib wheel is compiled for cp311) |
| Git | any | For cloning |
| Azure OpenAI | — | `gpt-4.1` deployment; needs API key + endpoint |
| Interactive Brokers | — | Optional for live portfolio; TWS or IB Gateway running locally |
| Redis | 6+ | Optional; only needed if using the EventBus integration layer |

---

## 1. Clone and enter the project

```bash
git clone <repo-url> Trading-CrewAI-Agent
cd Trading-CrewAI-Agent
```

---

## 2. Create the virtual environment

The project ships with `crewenv/` already committed (Windows). To recreate it:

```bash
# Windows
python -m venv crewenv
.\crewenv\Scripts\Activate.ps1

# macOS / Linux
python3.11 -m venv crewenv
source crewenv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt

# TA-Lib (pre-built wheel for Python 3.11 Windows is included)
pip install ta_lib-0.6.4-cp311-cp311-win_amd64.whl
```

---

## 3. Environment variables (`.env`)

Copy the example and fill in your values:

```bash
copy .env.example .env      # Windows
cp .env.example .env        # macOS/Linux
```

Minimum required variables:

```dotenv
# ── Azure OpenAI ─────────────────────────────────────────────────────────────
AZURE_OPENAI_API_KEY=your-key-here
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-12-01-preview

# ── Advisory agent ───────────────────────────────────────────────────────────
ADVISORY_VERBOSE=0                    # 1 = enable CrewAI verbose logging
ADVISORY_APPEND_DISCLAIMER=1         # append risk disclaimer to responses
ADVISORY_ENFORCE_MARKET_HOURS=1      # block orders outside trading hours
DEFAULT_MARKET=IN                    # default market (IN/US/EU/APAC/CRYPTO)

# ── IBKR paper trading (optional; set IB_ENABLED=0 to disable) ───────────────
IB_ENABLED=0                         # 1 = connect to TWS/Gateway
IB_HOST=127.0.0.1
IB_PORT=7497                         # 7497 = TWS paper; 4002 = IB Gateway paper
IB_CLIENT_ID=108
IB_ACCOUNT=DU123456                  # your paper account number
IB_ALLOW_TRADES=0                    # 1 = actually place orders
IB_PORTFOLIO_TTL=30                  # portfolio cache TTL in seconds

# ── Persistence & memory ─────────────────────────────────────────────────────
ADVISORY_CHECKPOINT_DB=data/advisory_checkpoints.db   # SQLite checkpoint path
LANCEDB_URI=data/memory/lancedb                       # LanceDB directory

# ── RL v2 (optional; disable both for pure advisory mode) ────────────────────
ENABLE_RL_VALIDATION=0               # v1 HTTP A2A validation
ENABLE_RL_VALIDATION_V2=0            # v2 local PPO/SAC validation
RL_V2_CHECKPOINT=                    # path to trained model .zip

# ── Market data ──────────────────────────────────────────────────────────────
ALPHA_VANTAGE_API_KEY=               # free key from alphavantage.co

# ── Redis (EventBus) — optional ──────────────────────────────────────────────
REDIS_URL=redis://localhost:6379/0
```

Full variable reference: [Configuration Reference](13_configuration.md)

---

## 4. Verify the installation

```bash
# Quick import smoke test (should print PASS)
python -c "
from main_advisory_agent.advisory_flow import AdvisoryFlow, AdvisoryFlowState
from agents.ibkr_portfolio_service import IBKRPortfolioService
from RL_Agent import RLAgentV2, RegimeClassifier
print('PASS — all core imports OK')
"
```

---

## 5. Run the test suite

```bash
# Individual phase tests
python scripts/test_advisory_flow_topology.py   # Phase 0  (17 tests)
python scripts/test_market_crews.py             # Phase 1  (26 tests)
python scripts/test_mcp_data_layer.py           # Phase 2  (18 tests)
python scripts/test_analysis_crew.py            # Phase 3  (20 tests)
python scripts/test_execution_crew.py           # Phase 4  (55 tests)
python scripts/test_memory_system.py            # Phase 5  (51 tests)
python scripts/test_flow_persistence.py         # Phase 6  (41 tests)
python scripts/test_rl_v2.py                    # RL v2    (68 tests)
```

All 296 should pass before making any code changes.

---

## 6. Start the advisory API

```bash
python main_advisory_agent/main.py
# API available at http://localhost:8000
```

With Docker (see [Operations](15_operations.md)):

```bash
docker-compose up advisory_agent
```

---

## 7. Enable IBKR paper trading

1. Download and install [TWS](https://www.interactivebrokers.com/en/trading/tws.php)
2. Log in to your **paper trading** account
3. Enable API access: *File → Global Configuration → API → Settings*
   - Check "Enable ActiveX and Socket Clients"
   - Socket port: `7497`
   - Uncheck "Read-Only API"
4. Set env vars and restart:
   ```dotenv
   IB_ENABLED=1
   IB_ACCOUNT=DU123456
   IB_PORT=7497
   IB_ALLOW_TRADES=1
   ```
5. Full guide: [IBKR Integration](10_ibkr_integration.md)

---

## 8. Train the RL agent (optional)

```python
from RL_Agent import RLAgentV2

agent = RLAgentV2(
    symbols=["^NSEI", "^NSEBANK", "^GSPC", "GLD", "NVDA"],
    algorithm="PPO",
)
result = agent.offline_train(
    start_date="2020-01-01",
    end_date="2024-12-31",
    n_timesteps=200_000,
)
agent.save("checkpoints/portfolio_v2.zip")
print(result)
```

Then point the advisory agent at the checkpoint:

```dotenv
ENABLE_RL_VALIDATION_V2=1
RL_V2_CHECKPOINT=checkpoints/portfolio_v2.zip
```

Full guide: [RL Agent v2](09_rl_agent_v2.md#training-pipeline)

---

## Development workflow

```
main_advisory_agent/   ← advisory flow, crew builders, memory
agents/                ← specialised agents + IBKR service
RL_Agent/              ← RL v2 environment, training, validation
integration/           ← EventBus, CrewAI-RL bridge
config/                ← settings.py, integration_config.json
scripts/               ← test scripts (one per phase)
docs/                  ← this documentation
```

- Branch naming: `feat/<description>`, `fix/<description>`
- Test before committing: `python scripts/test_<phase>.py`
- Never commit to `main` directly
