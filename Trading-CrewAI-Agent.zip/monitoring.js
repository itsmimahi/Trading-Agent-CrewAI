// Monitoring Module - Real-time system monitoring and status updates
class SystemMonitor {
    constructor() {
        this.isRunning = false;
        this.intervals = {
            status: null,
            metrics: null
        };
        
        this.sse = null;
        
        this.initializeElements();
        this.bindStatusCallbacks();
        this.startMonitoring();
        this.initSSE();
    }

    // Initialize DOM elements
    initializeElements() {
        this.elements = {
            // System status indicators
            systemStatus: document.getElementById('systemStatus'),
            statusIndicator: document.getElementById('statusIndicator'),
            statusText: document.getElementById('statusText'),
            
            // Service status indicators
            mainAgentStatus: document.getElementById('mainAgentStatus'),
            rlAgentStatus: document.getElementById('rlAgentStatus'),
            bridgeStatus: document.getElementById('bridgeStatus'),
            azureStatus: document.getElementById('azureStatus'),
            
            // Overview status indicators
            mainAgentOverview: document.getElementById('mainAgentOverview'),
            rlAgentOverview: document.getElementById('rlAgentOverview'),
            
            // Performance metrics
            responseTime: document.getElementById('responseTime'),
            successRate: document.getElementById('successRate'),
            activeSessions: document.getElementById('activeSessions'),
            integrationHealth: document.getElementById('integrationHealth'),
            
            // RL Insights
            rlInsights: document.getElementById('rlInsights'),
            
            // Market data
            marketData: document.getElementById('marketData'),
            
            // Portfolio summary
            portfolioSummary: document.getElementById('portfolioSummary'),

            // Telemetry panel
            telemetryStatus: document.getElementById('telemetryStatus'),
            telemetryLastTs: document.getElementById('telemetryLastTs'),
            telemetryMain: document.getElementById('telemetryMain'),
            telemetryRL: document.getElementById('telemetryRL'),
            telemetryReqId: document.getElementById('telemetryReqId')
        };
        // Hide Azure card if not enabled
        try {
            if (typeof CONFIG !== 'undefined' && CONFIG.azure && CONFIG.azure.enabled === false) {
                const azureCard = this.elements.azureStatus?.closest('.service-status');
                if (azureCard) azureCard.style.display = 'none';
            }
        } catch {}
    }

    // Bind status change callbacks
    bindStatusCallbacks() {
        if (window.serviceStatusManager) {
            window.serviceStatusManager.onStatusChange((service, status) => {
                this.updateServiceStatus(service, status);
                this.updateOverallStatus();
            });
        }
    }

    // Start monitoring
    startMonitoring() {
        if (this.isRunning) return;
        
        this.isRunning = true;
        console.log('Starting system monitoring...');
        
        // Initial status check
        this.performStatusCheck();
        
        // Set up periodic checks
        this.intervals.status = setInterval(() => {
            this.performStatusCheck();
        }, CONFIG.settings.statusCheckInterval);
        
        this.intervals.metrics = setInterval(() => {
            this.updateMetrics();
        }, CONFIG.settings.metricsUpdateInterval);
        
        // Initial metrics update
        this.updateMetrics();
    }

    // Stop monitoring
    stopMonitoring() {
        if (!this.isRunning) return;
        
        this.isRunning = false;
        console.log('Stopping system monitoring...');
        
        // Clear intervals
        Object.values(this.intervals).forEach(interval => {
            if (interval) clearInterval(interval);
        });
        
        this.intervals = { status: null, metrics: null };
    }

    // Perform comprehensive status check
    async performStatusCheck() {
        try {
            console.log('Performing status check...');
            
            // Check all services
            const statusResults = await window.enhancedAPI.healthCheck();
            
            // Update UI based on results
            Object.entries(statusResults).forEach(([service, status]) => {
                this.updateServiceStatus(service, status);
            });
            
            this.updateOverallStatus();
            
        } catch (error) {
            console.error('Status check failed:', error);
            this.setAllServicesOffline();
        }
    }

    // Update individual service status
    updateServiceStatus(service, status) {
        const indicators = this.getServiceIndicators(service);
        
        indicators.forEach(indicator => {
            if (indicator.element) {
                const dot = indicator.element.querySelector('.indicator-dot, .status-dot');
                const text = indicator.element.querySelector('span');
                
                if (dot) {
                    // Remove all status classes
                    dot.classList.remove('online', 'offline', 'warning');
                    dot.classList.add(status);
                }
                
                if (text && indicator.showText) {
                    text.textContent = this.getStatusText(status);
                }
            }
        });
        
        console.log(`Service ${service} status: ${status}`);
    }

    // Get service indicators for a given service
    getServiceIndicators(service) {
        const indicators = [];
        
        switch (service) {
            case 'mainAgent':
                indicators.push(
                    { element: this.elements.mainAgentStatus, showText: true },
                    { element: this.elements.mainAgentOverview, showText: false }
                );
                break;
            case 'rlAgent':
                indicators.push(
                    { element: this.elements.rlAgentStatus, showText: true },
                    { element: this.elements.rlAgentOverview, showText: false }
                );
                break;
            case 'integration':
                indicators.push(
                    { element: this.elements.bridgeStatus, showText: true }
                );
                break;
            case 'azure':
                indicators.push(
                    { element: this.elements.azureStatus, showText: true }
                );
                break;
        }
        
        return indicators.filter(indicator => indicator.element);
    }

    // Update overall system status
    updateOverallStatus() {
        if (!window.serviceStatusManager) return;
        
        const overallHealth = window.serviceStatusManager.getSystemHealth();
        
        if (this.elements.statusIndicator) {
            this.elements.statusIndicator.classList.remove('online', 'offline', 'warning');
            this.elements.statusIndicator.classList.add(overallHealth);
        }
        
        if (this.elements.statusText) {
            this.elements.statusText.textContent = this.getStatusText(overallHealth);
        }
    }

    // Get status text for display
    getStatusText(status) {
        switch (status) {
            case CONFIG.statusTypes.ONLINE:
                return 'Online';
            case CONFIG.statusTypes.OFFLINE:
                return 'Offline';
            case CONFIG.statusTypes.WARNING:
                return 'Warning';
            case CONFIG.statusTypes.CHECKING:
                return 'Checking...';
            default:
                return 'Unknown';
        }
    }

    // Set all services offline (fallback)
    setAllServicesOffline() {
        const services = ['mainAgent', 'rlAgent', 'integration', 'azure'];
        
        services.forEach(service => {
            if (window.serviceStatusManager) {
                window.serviceStatusManager.updateStatus(service, CONFIG.statusTypes.OFFLINE);
            }
        });
    }

    // Update performance metrics
    updateMetrics() {
        if (!window.enhancedAPI) return;
        
        try {
            const metrics = window.enhancedAPI.getMetrics();
            const systemStatus = window.enhancedAPI.getSystemStatus();
            
            // Update response time
            if (this.elements.responseTime) {
                this.elements.responseTime.textContent = `${metrics.lastResponseTime || 0} ms`;
            }
            
            // Update success rate
            if (this.elements.successRate) {
                this.elements.successRate.textContent = `${metrics.successRate || 0}%`;
            }
            
            // Update active sessions (simulated)
            if (this.elements.activeSessions) {
                this.elements.activeSessions.textContent = systemStatus.activeRequests || 0;
            }
            
            // Update integration health
            if (this.elements.integrationHealth) {
                const overall = window.serviceStatusManager ? window.serviceStatusManager.getSystemHealth() : (systemStatus && systemStatus.overall ? systemStatus.overall : CONFIG.statusTypes.CHECKING);
                this.elements.integrationHealth.textContent = this.getStatusText(overall);
                this.elements.integrationHealth.className = `metric-value ${overall}`;
            }
            
        } catch (error) {
            console.error('Metrics update failed:', error);
        }
    }

    // Update portfolio summary (placeholder for future implementation)
    updatePortfolioSummary() {
        if (!this.elements.portfolioSummary) return;
        const currency = (CONFIG.market && CONFIG.market.currencySymbol) ? CONFIG.market.currencySymbol : '$';
        const portfolioData = {
            totalValue: `${currency}125,430.50`,
            change: `${currency}+2,340.25 (+1.9%)`,
            positions: 12
        };
        
        const stats = this.elements.portfolioSummary.querySelectorAll('.portfolio-stat');
        
        if (stats[0]) {
            const valueElement = stats[0].querySelector('.stat-value');
            if (valueElement) valueElement.textContent = portfolioData.totalValue;
        }
        
        if (stats[1]) {
            const changeElement = stats[1].querySelector('.stat-value');
            if (changeElement) {
                changeElement.textContent = portfolioData.change;
                changeElement.className = 'stat-value change-positive';
            }
        }
        
        if (stats[2]) {
            const positionsElement = stats[2].querySelector('.stat-value');
            if (positionsElement) positionsElement.textContent = portfolioData.positions;
        }
    }

    // Update market data
    async updateMarketData() {
        if (!this.elements.marketData) return;

        try {
            // Use the PTA's last_price endpoint for NIFTY and SENSEX.
            const symbols = ['NIFTY50', 'SENSEX'];
            const marketItems = this.elements.marketData.querySelectorAll('.market-item');

            for (let i = 0; i < symbols.length; i++) {
                const symbol = symbols[i];
                const item = marketItems[i];
                if (!item) continue;

                const valueEl = item.querySelector('.market-value');
                const changeEl = item.querySelector('.market-change');

                try {
                    // Use the new API method
                    const res = await window.enhancedAPI.getLastPrice(symbol);
                    if (res && res.success && res.data) {
                        const price = res.data.last_price || 0;
                        const change = res.data.change || 0;
                        const pChange = res.data.p_change || 0;

                        valueEl.textContent = this.formatNumber(price, 2);
                        changeEl.textContent = `${change >= 0 ? '+' : ''}${this.formatNumber(change, 2)} (${this.formatNumber(pChange, 2)}%)`;
                        
                        changeEl.classList.remove('positive', 'negative');
                        if (change > 0) {
                            changeEl.classList.add('positive');
                        } else if (change < 0) {
                            changeEl.classList.add('negative');
                        }
                    } else {
                        valueEl.textContent = 'N/A';
                        changeEl.textContent = '--';
                    }
                } catch (error) {
                    console.warn(`Failed to fetch market data for ${symbol}:`, error);
                    valueEl.textContent = 'Error';
                    changeEl.textContent = '--';
                }
            }
        } catch (error) {
            console.error('Failed to update market data:', error);
        }
    }

    // Initialize SSE client for telemetry
    initSSE() {
        try {
            const { telemetryStatus, telemetryLastTs, telemetryMain, telemetryRL, telemetryReqId } = this.elements;
            // Use current origin by default; allow CONFIG.WEB_UI_URL override if provided
            const base = (typeof CONFIG !== 'undefined' && typeof CONFIG.WEB_UI_URL !== 'undefined' && CONFIG.WEB_UI_URL)
                ? CONFIG.WEB_UI_URL
                : (window.location && window.location.origin ? window.location.origin : 'http://localhost:5000');
            const url = `${base}/api/sse/telemetry`;
            this.sse = new EventSource(url, { withCredentials: true });
            telemetryStatus && (telemetryStatus.textContent = 'connecting...');
            this.sse.onopen = () => { telemetryStatus && (telemetryStatus.textContent = 'connected'); };
            this.sse.onerror = () => { telemetryStatus && (telemetryStatus.textContent = 'disconnected'); };
            this.sse.addEventListener('telemetry', (ev) => {
                telemetryLastTs && (telemetryLastTs.textContent = new Date().toLocaleTimeString());
                try {
                    const data = JSON.parse(ev.data);
                    const main = data?.services?.mainAgent?.status || 'unknown';
                    const rl = data?.services?.rlAgent?.status || 'unknown';
                    if (telemetryMain) telemetryMain.innerHTML = `<span class="telemetry-dot ${this._dotClass(main)}"></span>${main}`;
                    if (telemetryRL) telemetryRL.innerHTML = `<span class="telemetry-dot ${this._dotClass(rl)}"></span>${rl}`;
                } catch {}
            });
            window.addEventListener('ui:lastRequestId', (e) => {
                if (telemetryReqId) telemetryReqId.textContent = e.detail?.requestId || '-';
            });
        } catch (e) {
            console.warn('SSE init failed', e);
        }
    }

    _dotClass(status) {
        switch (status) {
            case 'online': return 'dot-online';
            case 'offline': return 'dot-offline';
            default: return 'dot-warning';
        }
    }

    // Get monitoring status
    getMonitoringStatus() {
        return {
            isRunning: this.isRunning,
            intervals: Object.keys(this.intervals).map(key => ({
                name: key,
                active: this.intervals[key] !== null
            })),
            lastStatusCheck: this.lastStatusCheck,
            lastMetricsUpdate: this.lastMetricsUpdate
        };
    }
}

// RL Insights Manager
class RLInsightsManager {
    constructor() {
        this.insights = [];
        this.maxInsights = 5;
        this.initializeElements();
    }

    // Initialize DOM elements
    initializeElements() {
        this.elements = {
            rlInsights: document.getElementById('rlInsights')
        };
    }

    // Add new insight
    addInsight(insightData) {
        const insight = {
            id: Date.now(),
            title: insightData.title || 'RL Insight',
            content: insightData.content || insightData.message || 'New insight available',
            confidence: insightData.confidence || Math.random() * 100,
            timestamp: new Date(),
            data: insightData
        };
        
        this.insights.unshift(insight);
        
        // Keep only recent insights
        if (this.insights.length > this.maxInsights) {
            this.insights = this.insights.slice(0, this.maxInsights);
        }
        
        this.renderInsights();
        
        console.log('New RL insight added:', insight);
    }

    // Render insights in UI
    renderInsights() {
        if (!this.elements.rlInsights) return;
        
        if (this.insights.length === 0) {
            this.elements.rlInsights.innerHTML = `
                <div class="insight-placeholder">
                    <i class="fas fa-chart-line"></i>
                    <p>RL insights will appear here during conversations</p>
                </div>
            `;
            return;
        }
        
        const insightsHTML = this.insights.map(insight => `
            <div class="insight-item" data-insight-id="${insight.id}">
                <div class="insight-title">${this.escapeHtml(insight.title)}</div>
                <div class="insight-content">${this.escapeHtml(insight.content)}</div>
                <div class="insight-confidence">
                    <span>Confidence:</span>
                    <div class="confidence-bar">
                        <div class="confidence-fill" style="width: ${insight.confidence}%"></div>
                    </div>
                    <span>${Math.round(insight.confidence)}%</span>
                </div>
            </div>
        `).join('');
        
        this.elements.rlInsights.innerHTML = insightsHTML;
    }

    // Escape HTML to prevent XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Clear all insights
    clearInsights() {
        this.insights = [];
        this.renderInsights();
    }

    // Get insights count
    getInsightsCount() {
        return this.insights.length;
    }
}

// Initialize monitors
const systemMonitor = new SystemMonitor();
const rlInsightsManager = new RLInsightsManager();

// Export for global use
window.systemMonitor = systemMonitor;
window.rlInsightsManager = rlInsightsManager;

// Update portfolio and market data periodically
setInterval(() => {
    systemMonitor.updatePortfolioSummary();
    systemMonitor.updateMarketData();
}, 60000); // Update every minute

// Initial update
setTimeout(() => {
    systemMonitor.updatePortfolioSummary();
    systemMonitor.updateMarketData();
}, 1000);

// (function(){
//   const statusEl = document.getElementById('telemetryStatus');
//   const lastTsEl = document.getElementById('telemetryLastTs');
//   const mainEl = document.getElementById('telemetryMain');
//   const rlEl = document.getElementById('telemetryRL');
//   const reqIdEl = document.getElementById('telemetryReqId');

//   function setStatus(text, cls) {
//     if (!statusEl) return;
//     statusEl.textContent = text;
//     statusEl.className = `value ${cls||''}`.trim();
//   }

//   // SSE subscription (keeps prior behavior)
//   try {
//     const ev = new EventSource('/api/sse/telemetry');
//     setStatus('connecting...', 'text-muted');

//     ev.onopen = () => setStatus('connected', 'text-success');

//     ev.onerror = () => setStatus('disconnected', 'text-danger');

//     ev.onmessage = (msg) => {
//       try {
//         const data = JSON.parse(msg.data);
//         if (lastTsEl) lastTsEl.textContent = new Date().toLocaleTimeString();
//         if (mainEl) mainEl.innerHTML = `${data.main?.ok ? '<span class=\"telemetry-dot dot-ok\"></span>OK' : '<span class=\"telemetry-dot dot-error\"></span>Err'}`;
//         if (rlEl) rlEl.innerHTML = `${data.rl?.ok ? '<span class=\"telemetry-dot dot-ok\"></span>OK' : '<span class=\"telemetry-dot dot-error\"></span>Err'}`;
//       } catch {}
//     };
//   } catch {}

//   // Listen for last request id events from api.js
//   window.addEventListener('ui:lastRequestId', (e) => {
//     if (!reqIdEl) return;
//     const id = e.detail?.requestId;
//     reqIdEl.textContent = id || '-';
//   });
// })();
