// Enhanced Portfolio Dashboard with WebSocket support
(function(){
  const api = new APIClient();
  const currency = CONFIG.market?.currencySymbol || '₹';
  let ws = null;
  let isConnected = false;

  function fmt(n){
    try { return new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(n); } catch { return n; }
  }

  async function fetchHoldings(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/holdings');
    return res && res.success ? res.data : { cash: 0, holdings: [] };
  }

  async function fetchMargins(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/margins');
    return res && res.success ? res.data : { available: 0, used: 0, net: 0 };
  }

  async function fetchMetrics(){
    const res = await api.makeRequest('/api/proxy/pta/portfolio/metrics');
    return res && res.success ? res.data : {};
  }

  async function lastPrice(sym){
    const res = await api.makeRequest(`/api/proxy/pta/market/last_price/${encodeURIComponent(sym)}`, { skipCache: true });
    return res && res.success ? res.data?.last_price : null;
  }

  function el(id){ return document.getElementById(id); }

  function updateConnectionStatus() {
    const statusEl = el('connectionStatus');
    if (statusEl) {
      statusEl.textContent = isConnected ? 'Live' : 'Polling';
      statusEl.className = isConnected ? 'status-connected' : 'status-disconnected';
    }
  }

  function connectWebSocket() {
    try {
      // Connect to portfolio WebSocket for real-time updates
      ws = new WebSocket('ws://localhost:8091');
      
      ws.onopen = () => {
        console.log('Portfolio WebSocket connected');
        isConnected = true;
        updateConnectionStatus();
      };
      
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        } catch (e) {
          console.error('Failed to parse WebSocket message:', e);
        }
      };
      
      ws.onclose = () => {
        console.log('Portfolio WebSocket disconnected');
        isConnected = false;
        updateConnectionStatus();
        // Reconnect after 5 seconds
        setTimeout(() => connectWebSocket(), 5000);
      };
      
      ws.onerror = (error) => {
        console.error('Portfolio WebSocket error:', error);
        isConnected = false;
        updateConnectionStatus();
      };
    } catch (e) {
      console.log('WebSocket not available, using HTTP polling');
      isConnected = false;
      updateConnectionStatus();
    }
  }

  function handleWebSocketMessage(data) {
    switch (data.type) {
      case 'initial_state':
        if (data.holdings) {
          updateFromHoldings(data.holdings);
        }
        if (data.metrics) {
          updateFromMetrics(data.metrics);
        }
        break;
      case 'portfolio_update':
        if (data.event) {
          handlePortfolioEvent(data.event);
        }
        break;
    }
  }

  function handlePortfolioEvent(event) {
    switch (event.type) {
      case 'order_filled':
        console.log('Order filled:', event.order);
        // Show notification
        showNotification(`Order filled: ${event.order.side} ${event.order.quantity} ${event.order.symbol}`, 'success');
        // Refresh data
        init();
        break;
      case 'position_update':
        console.log('Position updated:', event.symbol, event.position);
        break;
      case 'valuation_update':
        if (event.metrics) {
          updateFromMetrics(event.metrics);
        }
        break;
    }
  }

  function showNotification(message, type = 'info') {
    // Simple notification - could be enhanced with a proper notification system
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed; top: 20px; right: 20px; z-index: 1000;
      background: ${type === 'success' ? '#4CAF50' : '#2196F3'};
      color: white; padding: 12px 20px; border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      transition: opacity 0.3s ease;
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
      notification.style.opacity = '0';
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  async function updateFromHoldings(holdingsData) {
    const holdings = holdingsData.holdings || [];
    const cash = holdingsData.cash || 0;
    await renderSummary(cash, holdings);
    await renderTable(holdings);
  }

  function updateFromMetrics(metrics) {
    // Update metrics display if elements exist
    const metricsContainer = el('portfolioMetrics');
    if (metricsContainer) {
      const unrealizedEl = metricsContainer.querySelector('.unrealized-pnl');
      const totalValueEl = metricsContainer.querySelector('.total-value');
      
      if (unrealizedEl && metrics.unrealized_pnl !== undefined) {
        unrealizedEl.textContent = `${currency} ${fmt(metrics.unrealized_pnl)}`;
        unrealizedEl.className = `unrealized-pnl ${metrics.unrealized_pnl >= 0 ? 'positive' : 'negative'}`;
      }
      
      if (totalValueEl && metrics.total_value_est !== undefined) {
        totalValueEl.textContent = `${currency} ${fmt(metrics.total_value_est)}`;
      }
    }
  }

  async function renderSummary(cash, holdings, metrics){
    const container = el('portfolioSummary');
    if (!container) return;
    const stats = container.querySelectorAll('.portfolio-stat .stat-value');
    // Defensive: always show something
    const totalValue = metrics && metrics.total_value_est !== undefined ? metrics.total_value_est : 0;
    const dayChange = metrics && metrics.day_change !== undefined ? metrics.day_change : 0;
    const dayChangePct = metrics && metrics.day_change_pct !== undefined ? metrics.day_change_pct : 0;
    const positionsCount = metrics && metrics.positions_count !== undefined ? metrics.positions_count : 0;
    if (stats && stats.length >= 3) {
      // Total Value
      stats[0].textContent = `${currency} ${fmt(totalValue)}`;
      // Today's Change
      const sign = dayChange >= 0 ? '+' : '';
      stats[1].textContent = `${currency} ${sign}${fmt(dayChange)} (${sign}${fmt(dayChangePct)}%)`;
      // Active Positions
      stats[2].textContent = `${fmt(positionsCount)}`;
    }
  }

  // On landing page we only maintain the summary widget; full table lives on portfolio.html
  async function renderTable(holdings){ return; }

  async function init(){
    try {
      const [hold, marg, metrics] = await Promise.all([fetchHoldings(), fetchMargins(), fetchMetrics()]);
      const holdings = hold.holdings || [];
      await renderSummary(hold.cash || marg.available || 0, holdings, metrics);
      await renderTable(holdings); // no-op on landing page
      updateFromMetrics(metrics);
      // Attempt adapter subscribe for current symbols to improve LTP updates
      const symbols = holdings.map(h => h.symbol);
      if (symbols.length){
        await api.makeRequest('/api/proxy/pta/adapter/subscribe', { method: 'POST', body: JSON.stringify({ symbols }) });
      }
    } catch (e){ console.warn('Portfolio init failed', e); }
  }

  // Connect WebSocket on load
  connectWebSocket();

  // Fallback polling if WebSocket fails
  setInterval(() => {
    if (!isConnected) {
      init();
    }
  }, 30000);

  // Lazy start when DOM ready
  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else { init(); }
})();
