# AI Trading Advisory System Configuration

import os
from typing import Dict, List
from dataclasses import dataclass
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


@dataclass
class DatabaseConfig:
    """Database configuration settings"""
    sqlite_path: str = "data/storage/trading_agent.db"
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0

@dataclass
class AIConfig:
    """AI and LLM configuration settings"""
    # Azure OpenAI Configuration
    azure_openai_endpoint: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    azure_openai_api_key: str = os.getenv("AZURE_OPENAI_API_KEY", "")
    azure_openai_api_version: str = os.getenv("AZURE_OPENAI_API_VERSION", "")
    azure_openai_deployment: str = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")
    azure_openai_model: str = os.getenv("AZURE_OPENAI_MODEL", "gpt-4.1")
    # Use a modern default, but this MUST be the Azure deployment name, not the base model id
    azure_openai_embedding_model: str = os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")
    
    # Model settings
    temperature: float = 0.1
    max_tokens: int = 2000
    top_p: float = 0.95

@dataclass
class DataConfig:
    """Data source configuration"""
    # API Keys
    alpha_vantage_api_key: str = os.getenv("ALPHA_VANTAGE_API_KEY", "")
    news_api_key: str = os.getenv("NEWS_API_KEY", "")
    
    # Data refresh rates (in minutes)
    market_data_refresh: int = 5
    news_data_refresh: int = 15
    sentiment_data_refresh: int = 30
    
    # Data sources
    yahoo_finance_enabled: bool = True
    alpha_vantage_enabled: bool = True
    news_api_enabled: bool = True

@dataclass
class TradingConfig:
    """Trading and portfolio configuration"""
    # Portfolio settings
    initial_capital: float = 5000.0
    max_position_size: float = 0.20  # 20% max per stock
    max_portfolio_risk: float = 0.05  # 5% daily VaR
    stop_loss_threshold: float = 0.08  # 8% stop loss

    # Broker policy (Phase 2)
    broker_priority: str = os.getenv("PORTFOLIO_BROKER_PRIORITY", "ib")
    portfolio_fallback_enabled: bool = os.getenv("PORTFOLIO_FALLBACK_ENABLED", "0") == "1"

    # Interactive Brokers connectivity
    ib_enabled: bool = os.getenv("IB_ENABLED", "0") == "1"
    ib_host: str = os.getenv("IB_HOST", "127.0.0.1")
    ib_port: int = int(os.getenv("IB_PORT", "7497"))
    ib_client_id: int = int(os.getenv("IB_CLIENT_ID", "108"))
    ib_account: str = os.getenv("IB_ACCOUNT", "")
    ib_exchange: str = os.getenv("IB_EXCHANGE", "SMART")
    ib_currency: str = os.getenv("IB_CURRENCY", "USD")
    ib_allow_trades: bool = os.getenv("IB_ALLOW_TRADES", "0") == "1"
    
    # Agent weights for decision making
    agent_weights: Dict[str, float] = None
    
    def __post_init__(self):
        if self.agent_weights is None:
            self.agent_weights = {
                'research': 0.25,
                'technical': 0.20,
                'sentiment': 0.15,
                'risk': 0.25,
                'macro': 0.10,
                'timing': 0.05
            }

@dataclass
class SystemConfig:
    """System configuration"""
    # Logging
    log_level: str = "INFO"
    log_file: str = "logs/trading_agent.log"
    
    # Performance
    max_concurrent_requests: int = 10
    request_timeout: int = 30
    
    # Dashboard
    streamlit_host: str = "localhost"
    streamlit_port: int = 8501

class Config:
    """Main configuration class"""
    
    def __init__(self):
        self.database = DatabaseConfig()
        self.ai = AIConfig()
        self.data = DataConfig()
        self.trading = TradingConfig()
        self.system = SystemConfig()
        
        # Stock universe (Indian market focus)
        self.stock_universe = [
            "RELIANCE.NS",
            "TCS.NS", 
            "HDFCBANK.NS",
            "INFY.NS",
            "HINDUNILVR.NS",
            "ICICIBANK.NS",
            "KOTAKBANK.NS",
            "BHARTIARTL.NS",
            "ITC.NS",
            "LT.NS",
            "SBIN.NS",
            "BAJFINANCE.NS",
            "MARUTI.NS",
            "ASIANPAINT.NS",
            "HCLTECH.NS"
        ]
        
        # Market hours (IST)
        self.market_hours = {
            "open": "09:15",
            "close": "15:30",
            "timezone": "Asia/Kolkata"
        }
    
    def validate_config(self) -> bool:
        """Validate configuration settings"""
        errors = []
        
        # Check Azure OpenAI configuration
        if not self.ai.azure_openai_endpoint:
            errors.append("Azure OpenAI endpoint not configured")
        if not self.ai.azure_openai_api_key:
            errors.append("Azure OpenAI API key not configured")
        # Embedding deployment name must be set for Azure (avoid runtime NoneType errors)
        if self.ai.azure_openai_endpoint and self.ai.azure_openai_api_key:
            if not self.ai.azure_openai_embedding_model:
                errors.append("Azure OpenAI embeddings deployment not configured (set AZURE_OPENAI_EMBEDDING_MODEL to your Azure deployment name)")
            else:
                # Heuristic: if user left an OpenAI base model id, warn/fail fast for Azure usage
                if self.ai.azure_openai_embedding_model.strip() in ("text-embedding-ada-002",):
                    errors.append("AZURE_OPENAI_EMBEDDING_MODEL appears to be an OpenAI base model id. Set it to your Azure embeddings DEPLOYMENT name (e.g. the name you created in Azure for text-embedding-3-small).")
        
        # Check data API keys
        if not self.data.alpha_vantage_api_key:
            print("Warning: Alpha Vantage API key not configured")
        if not self.data.news_api_key:
            print("Warning: News API key not configured")

        # Broker policy guidance
        if self.trading.ib_enabled and self.trading.ib_port <= 0:
            errors.append("IB_PORT must be a positive integer when IB is enabled")
        if self.trading.ib_allow_trades and not self.trading.ib_enabled:
            errors.append("IB_ALLOW_TRADES=1 requires IB_ENABLED=1")
        
        if errors:
            print("Configuration errors:")
            for error in errors:
                print(f"  - {error}")
            return False
        
        return True

# Global configuration instance
config = Config()

# Environment setup helper
def setup_environment():
    """Setup environment variables and validate configuration"""
    print("🔧 Setting up AI Trading Advisory System...")
    
    # Create necessary directories
    os.makedirs("data/storage", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    os.makedirs("models", exist_ok=True)
    
    # Validate configuration
    if config.validate_config():
        print("✅ Configuration validated successfully")
        return True
    else:
        print("❌ Configuration validation failed")
        return False

def get_settings():
    """Get the global configuration instance"""
    return config

if __name__ == "__main__":
    setup_environment()
