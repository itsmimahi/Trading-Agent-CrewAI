"""
Communication Protocol for Agent-to-Agent interactions.

This module implements the standardized communication protocol for A2A (Agent-to-Agent) 
interactions in the AI Trading Advisory System.
"""

import asyncio
import json
import logging
import os
from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import uuid

# Use top-level agent_registry instead of a non-existent relative module
from agent_registry import AgentRegistry  # type: ignore
from integration.event_bus import make_default_event_bus, RedisStreamsEventBus

@dataclass
class Message:
    """Standard message format for agent communication."""
    id: str
    sender: str
    recipient: str
    message_type: str
    content: Dict[str, Any]
    timestamp: datetime
    priority: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary format."""
        return {
            **asdict(self),
            'timestamp': self.timestamp.isoformat()
        }

class MessageType(Enum):
    """Standard message types for agent communication."""
    REQUEST = "request"
    RESPONSE = "response"
    NOTIFICATION = "notification"
    BROADCAST = "broadcast"
    HEARTBEAT = "heartbeat"
    ERROR = "error"
    PING = "ping"
    PONG = "pong"


class Priority(Enum):
    """Message priority levels."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class RequestMessage:
    """Structured request message for agent communication."""
    request_id: str
    request_type: str
    parameters: Dict[str, Any]
    requires_response: bool = True
    timeout_seconds: int = 30
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ResponseMessage:
    """Structured response message for agent communication."""
    request_id: str
    success: bool
    data: Dict[str, Any]
    error_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class CommunicationProtocol:
    """
    Standardized communication protocol for agent-to-agent interactions.
    
    This class provides high-level communication primitives that agents can use
    to interact with each other through the MCP infrastructure.
    """
    
    def __init__(self, agent_registry: AgentRegistry):
        """
        Initialize the communication protocol.
        
        Args:
            agent_registry: Registry for agent discovery and management
        """
        self.agent_registry = agent_registry
        self.logger = logging.getLogger("communication_protocol")
        
        # Track pending requests
        self.pending_requests: Dict[str, Dict[str, Any]] = {}
        
        # Response callbacks
        self.response_callbacks: Dict[str, Callable] = {}
        
        # Subscription handlers
        self.subscription_handlers: Dict[str, List[Callable]] = {}
        
        # Transport via Redis Streams EventBus when available
        self.event_bus: Optional[RedisStreamsEventBus] = make_default_event_bus()
        if not self.event_bus:
            self.logger.warning("EventBus not configured (set REDIS_URL). Falling back to in-memory simulation.")
        # Default request stream naming
        self.request_stream_prefix = os.environ.get("A2A_REQUEST_STREAM_PREFIX", "agents")
    
    async def send_request(self, 
                          from_agent: str,
                          to_agent: str, 
                          request_type: str,
                          parameters: Dict[str, Any],
                          timeout_seconds: int = 30) -> Dict[str, Any]:
        """
        Send a request to another agent and wait for response.
        
        Args:
            from_agent: ID of the requesting agent
            to_agent: ID of the target agent
            request_type: Type of request
            parameters: Request parameters
            timeout_seconds: Request timeout
            
        Returns:
            Response data from the target agent
        """
        request_id = str(uuid.uuid4())
        
        # Create request message
        request_msg = RequestMessage(
            request_id=request_id,
            request_type=request_type,
            parameters=parameters,
            requires_response=True,
            timeout_seconds=timeout_seconds
        )
        
        # Store pending request
        self.pending_requests[request_id] = {
            'from_agent': from_agent,
            'to_agent': to_agent,
            'timestamp': datetime.now(),
            'timeout': timeout_seconds
        }
        
        try:
            # Get target agent info
            target_agent = self.agent_registry.get_agent(to_agent)
            if not target_agent:
                raise ValueError(f"Agent {to_agent} not found in registry")
            # If EventBus available, prefer Redis Streams transport
            if self.event_bus:
                stream = f"{self.request_stream_prefix}:{to_agent}:requests"
                msg = {
                    "from": from_agent,
                    "to": to_agent,
                    "type": MessageType.REQUEST.value,
                    "request_type": request_type,
                    "action": request_type,
                    "data": parameters,
                }
                response = await self.event_bus.request(stream, msg, timeout_ms=int(timeout_seconds * 1000))
                return response
            
            # Send request through MCP
            success = await self._send_mcp_message(
                from_agent,
                to_agent,
                MessageType.REQUEST.value,
                request_msg.to_dict(),
                Priority.NORMAL.value
            )
            
            if not success:
                raise Exception(f"Failed to send request to {to_agent}")
            
            # Wait for response
            response = await self._wait_for_response(request_id, timeout_seconds)
            
            # Clean up pending request
            if request_id in self.pending_requests:
                del self.pending_requests[request_id]
            
            return response
            
        except Exception as e:
            # Clean up on error
            if request_id in self.pending_requests:
                del self.pending_requests[request_id]
            raise e

    async def send_response(self,
                           from_agent: str,
                           to_agent: str,
                           request_id: str,
                           success: bool,
                           data: Dict[str, Any],
                           error_message: Optional[str] = None):
        """
        Send a response to a previous request.
        
        Args:
            from_agent: ID of the responding agent
            to_agent: ID of the original requester
            request_id: ID of the original request
            success: Whether the request was successful
            data: Response data
            error_message: Error message if unsuccessful
        """
        response_msg = ResponseMessage(
            request_id=request_id,
            success=success,
            data=data,
            error_message=error_message
        )
        
        # If using EventBus, responses are published by workers; no-op here
        if self.event_bus:
            return True
        
        # MCP fallback
        return await self._send_mcp_message(
            from_agent,
            to_agent,
            MessageType.RESPONSE.value,
            response_msg.to_dict(),
            Priority.NORMAL.value
        )

    async def send_notification(self,
                               from_agent: str,
                               to_agent: str,
                               notification_type: str,
                               data: Dict[str, Any],
                               priority: Priority = Priority.NORMAL):
        """
        Send a notification (one-way message) to another agent.
        
        Args:
            from_agent: ID of the sending agent
            to_agent: ID of the target agent
            notification_type: Type of notification
            data: Notification data
            priority: Message priority
        """
        # Prefer EventBus
        if self.event_bus:
            stream = f"{self.request_stream_prefix}:{to_agent}:notifications"
            msg = {
                "from": from_agent,
                "to": to_agent,
                "type": MessageType.NOTIFICATION.value,
                "notification_type": notification_type,
                "data": data,
            }
            self.event_bus.publish(stream, msg)
            return
        
        notification_data = {
            'notification_type': notification_type,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        await self._send_mcp_message(
            from_agent,
            to_agent,
            MessageType.NOTIFICATION.value,
            notification_data,
            priority.value
        )
    
    async def broadcast_message(self,
                               from_agent: str,
                               message_type: str,
                               data: Dict[str, Any],
                               agent_types: Optional[List[str]] = None,
                               capabilities: Optional[List[str]] = None):
        """
        Broadcast a message to multiple agents.
        
        Args:
            from_agent: ID of the sending agent
            message_type: Type of message
            data: Message data
            agent_types: Filter by agent types (optional)
            capabilities: Filter by capabilities (optional)
        """
        # Resolve target agents
        target_agents: List[Any] = []
        if capabilities:
            for capability in capabilities:
                agents = self.agent_registry.find_agents_by_capability(capability)
                target_agents.extend(agents)
        else:
            if hasattr(self.agent_registry, 'get_all_agents'):
                target_agents = list(self.agent_registry.get_all_agents())
            elif hasattr(self.agent_registry, 'list_agents'):
                target_agents = list(self.agent_registry.list_agents())
        if agent_types:
            target_agents = [a for a in target_agents if getattr(a, 'type', None) in agent_types]
        
        if self.event_bus:
            # Publish via EventBus to each agent's broadcast stream
            uniq: Dict[str, Any] = {}
            for a in target_agents:
                aid = getattr(a, 'id', None) or getattr(a, 'agent_id', None)
                if aid and aid != from_agent:
                    uniq[aid] = a
            for aid in uniq:
                stream = f"{self.request_stream_prefix}:{aid}:broadcasts"
                msg = {"from": from_agent, "type": message_type, "data": data}
                self.event_bus.publish(stream, msg)
            return
        
        # MCP fallback: remove duplicates and exclude sender
        unique_agents = {}
        for a in target_agents:
            aid = getattr(a, 'id', None) or getattr(a, 'agent_id', None)
            if aid and aid != from_agent:
                unique_agents[aid] = a
        
        # Send broadcast to each target
        broadcast_data = {
            'broadcast_type': message_type,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        for aid, agent in unique_agents.items():
            await self._send_mcp_message(
                from_agent,
                aid,
                MessageType.BROADCAST.value,
                broadcast_data,
                Priority.NORMAL.value
            )
    
    async def subscribe_to_notifications(self,
                                       agent_id: str,
                                       notification_type: str,
                                       handler: Callable[[Dict[str, Any]], None]):
        """
        Subscribe to notifications of a specific type.
        
        Args:
            agent_id: ID of the subscribing agent
            notification_type: Type of notifications to subscribe to
            handler: Function to handle notifications
        """
        if notification_type not in self.subscription_handlers:
            self.subscription_handlers[notification_type] = []
        
        self.subscription_handlers[notification_type].append(handler)
        self.logger.info(f"Agent {agent_id} subscribed to {notification_type} notifications")
    
    async def send_group_request(self, from_agent: str, agent_ids: List[str], request_type: str, parameters: Dict[str, Any], timeout_seconds: int = 30):
        """
        Send a request to a group of agents and collect their responses.
        Returns a dict of agent_id: response.
        """
        results = {}
        for agent_id in agent_ids:
            try:
                result = await self.send_request(from_agent, agent_id, request_type, parameters, timeout_seconds)
                results[agent_id] = result
            except Exception as e:
                results[agent_id] = {"error": str(e)}
        return results
    
    def set_debug(self, debug: bool):
        """
        Enable or disable debug logging for sent/received messages.
        """
        self.debug = debug
    
    def log_message(self, msg: str):
        """
        Log or print a message if debug is enabled.
        """
        if hasattr(self, 'debug') and self.debug:
            print(f"[DEBUG] {msg}")
    
    def validate_message(self, message: Dict[str, Any], required_keys: List[str]) -> bool:
        """
        Validate that a message contains all required keys.
        """
        return all(key in message for key in required_keys)
    
    async def _send_mcp_message(self,
                               from_agent: str,
                               to_agent: str,
                               message_type: str,
                               content: Dict[str, Any],
                               priority: int) -> bool:
        """
        Send a message through MCP infrastructure.
        
        Args:
            from_agent: ID of sending agent
            to_agent: ID of target agent
            message_type: Type of message
            content: Message content
            priority: Message priority
            
        Returns:
            True if message sent successfully
        """
        try:
            # This would interface with the actual MCP server
            # For now, we'll simulate the message sending
            message = Message(
                id=str(uuid.uuid4()),
                sender=from_agent,
                recipient=to_agent,
                message_type=message_type,
                content=content,
                timestamp=datetime.now(),
                priority=priority
            )
            
            # In a real implementation, this would send through MCP
            self.logger.debug(f"Sending message {message.id} from {from_agent} to {to_agent}")
            
            # Simulate processing delay
            await asyncio.sleep(0.1)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error sending MCP message: {e}")
            return False
    
    async def _wait_for_response(self, request_id: str, timeout_seconds: int) -> Dict[str, Any]:
        """
        Wait for a response to a specific request.
        
        Args:
            request_id: ID of the request
            timeout_seconds: Timeout in seconds
            
        Returns:
            Response data
        """
        start_time = datetime.now()
        timeout_time = start_time + timedelta(seconds=timeout_seconds)
        
        while datetime.now() < timeout_time:
            # Check if response is available
            if request_id in self.response_callbacks:
                response = self.response_callbacks[request_id]
                del self.response_callbacks[request_id]
                return response
            
            # Small delay before checking again
            await asyncio.sleep(0.1)
        
        raise TimeoutError(f"Request {request_id} timed out after {timeout_seconds} seconds")
    
    def handle_incoming_message(self, message: Message):
        """
        Handle incoming messages from other agents.
        
        Args:
            message: Incoming message
        """
        try:
            if message.message_type == MessageType.RESPONSE.value:
                # Handle response
                response_data = message.content
                request_id = response_data.get('request_id')
                
                if request_id and request_id in self.pending_requests:
                    self.response_callbacks[request_id] = response_data
            
            elif message.message_type == MessageType.NOTIFICATION.value:
                # Handle notification
                notification_type = message.content.get('notification_type')
                
                if notification_type in self.subscription_handlers:
                    for handler in self.subscription_handlers[notification_type]:
                        try:
                            handler(message.content)
                        except Exception as e:
                            self.logger.error(f"Error in notification handler: {e}")
            
            elif message.message_type == MessageType.BROADCAST.value:
                # Handle broadcast
                broadcast_type = message.content.get('broadcast_type')
                
                if broadcast_type in self.subscription_handlers:
                    for handler in self.subscription_handlers[broadcast_type]:
                        try:
                            handler(message.content)
                        except Exception as e:
                            self.logger.error(f"Error in broadcast handler: {e}")
            
        except Exception as e:
            self.logger.error(f"Error handling incoming message: {e}")
    
    def get_communication_stats(self) -> Dict[str, Any]:
        """
        Get statistics about communication activity.
        
        Returns:
            Dictionary with communication statistics
        """
        return {
            'pending_requests': len(self.pending_requests),
            'active_subscriptions': {
                notification_type: len(handlers)
                for notification_type, handlers in self.subscription_handlers.items()
            },
            'timestamp': datetime.now().isoformat()
        }
    
    async def cleanup_expired_requests(self, max_age_minutes: int = 10):
        """
        Clean up expired requests that haven't received responses.
        
        Args:
            max_age_minutes: Maximum age for requests in minutes
        """
        cutoff_time = datetime.now() - timedelta(minutes=max_age_minutes)
        
        expired_requests = []
        for request_id, request_info in self.pending_requests.items():
            if request_info['timestamp'] < cutoff_time:
                expired_requests.append(request_id)
        
        for request_id in expired_requests:
            del self.pending_requests[request_id]
            if request_id in self.response_callbacks:
                del self.response_callbacks[request_id]
        
        if expired_requests:
            self.logger.info(f"Cleaned up {len(expired_requests)} expired requests")
