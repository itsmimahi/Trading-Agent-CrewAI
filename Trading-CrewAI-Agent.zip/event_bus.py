"""
Redis Streams-based Event Bus for A2A (Agent-to-Agent) communication.
Provides publish, request-reply, and consumer group processing with retries and DLQ.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from typing import Any, Awaitable, Callable, Dict, Optional, List

try:
    import redis  # type: ignore
except Exception:  # pragma: no cover
    redis = None  # Will be validated at runtime


class EventBusError(Exception):
    pass


class _AsciiSanitizer(logging.Filter):
    """Sanitize log records to be ASCII-safe for Windows consoles.
    Replaces characters that can't be encoded with '?'.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            # Coerce message to a safe representation without raising
            if isinstance(record.msg, str):
                record.msg = record.msg.encode("ascii", errors="replace").decode("ascii")
            # Ensure args are safe if present
            if record.args:
                safe_args = []
                for a in record.args:
                    if isinstance(a, str):
                        safe_args.append(a.encode("ascii", errors="replace").decode("ascii"))
                    else:
                        safe_args.append(a)
                record.args = tuple(safe_args)
        except Exception:
            # Never block logging
            pass
        return True


class RedisStreamsEventBus:
    def __init__(
        self,
        redis_url: Optional[str] = None,
        *,
        password: Optional[str] = None,
        stream_prefix: str = "a2a",
        default_maxlen: int = 10000,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        if redis is None:
            raise EventBusError("redis-py is not installed. Please install 'redis>=4.6.0'.")
        self.redis_url = redis_url or os.environ.get("REDIS_URL", "redis://localhost:6379/0")
        self.password = password or os.environ.get("REDIS_PASSWORD")
        self.stream_prefix = stream_prefix.rstrip(":")
        self.default_maxlen = default_maxlen
        self.log = logger or logging.getLogger("EventBus")
        # Attach ASCII sanitizer to avoid UnicodeEncodeError on Windows terminals/handlers
        try:
            self.log.addFilter(_AsciiSanitizer())
        except Exception:
            pass
        self._r = redis.Redis.from_url(self.redis_url, password=self.password, decode_responses=True)
        # Track running consumer tasks to allow graceful shutdown
        self._consumer_tasks: Dict[str, asyncio.Task] = {}
        self._stop = asyncio.Event()

    # Utility names
    def stream(self, name: str) -> str:
        return f"{self.stream_prefix}:{name}"

    def dlq(self, name: str) -> str:
        return f"{self.stream_prefix}:dlq:{name}"

    # Core ops
    def publish(self, stream: str, message: Dict[str, Any], *, maxlen: Optional[int] = None) -> str:
        s = self.stream(stream) if not stream.startswith(self.stream_prefix + ":") else stream
        fields = {"payload": json.dumps(message)}
        msg_id = self._r.xadd(s, fields, maxlen=maxlen or self.default_maxlen, approximate=True)
        return msg_id

    async def request(
        self,
        stream: str,
        message: Dict[str, Any],
        *,
        timeout_ms: int = 30000,
    ) -> Dict[str, Any]:
        """
        Simple request-reply using a unique reply stream per request.
        Caller writes to <stream>; waits on reply_to with correlation_id.
        """
        corr_id = message.get("correlation_id") or str(uuid.uuid4())
        reply_stream = message.get("reply_to") or self.stream(f"reply:{corr_id}")
        message = {**message, "correlation_id": corr_id, "reply_to": reply_stream}
        # Publish request
        self.publish(stream, message)
        # Wait for reply
        start = time.time()
        block = max(1, min(timeout_ms, 60000))  # cap per call; loop for longer waits
        last_id = "0-0"
        while True:
            if (time.time() - start) * 1000 >= timeout_ms:
                raise TimeoutError(f"Request {corr_id} timed out after {timeout_ms} ms")
            resp = self._r.xread({reply_stream: last_id}, block=block, count=1)
            if not resp:
                continue
            # resp format: [(stream, [(id, {field: val})])]
            _, entries = resp[0]
            for entry_id, fields in entries:
                last_id = entry_id
                try:
                    payload = json.loads(fields.get("payload", "{}"))
                except Exception:
                    continue
                if payload.get("correlation_id") == corr_id:
                    return payload

    def _ensure_group(self, stream: str, group: str) -> None:
        s = self.stream(stream) if not stream.startswith(self.stream_prefix + ":") else stream
        try:
            self._r.xgroup_create(s, group, id="$", mkstream=True)
        except Exception as e:
            # BUSYGROUP means it already exists
            if "BUSYGROUP" in str(e):
                return
            # If stream doesn't exist, mkstream=True handles it; other errors re-raise
            if "ERR unknown command" in str(e):
                raise

    def start_consumer(
        self,
        *,
        stream: str,
        group: str,
        consumer_name: Optional[str],
        handler: Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]] | Awaitable[None] | Dict[str, Any] | None],
        auto_ack: bool = True,
        max_retries: int = 3,
        concurrency: int = 1,
        block_ms: int = 5000,
    ) -> None:
        s = self.stream(stream) if not stream.startswith(self.stream_prefix + ":") else stream
        g = group
        self._ensure_group(s, g)

        async def worker_task(idx: int):
            cname = consumer_name or f"{os.getpid()}-{idx}"
            self.log.info(f"Consumer started: stream={s} group={g} consumer={cname}")
            while not self._stop.is_set():
                try:
                    resp = self._r.xreadgroup(g, cname, {s: ">"}, count=10, block=block_ms)
                    if not resp:
                        continue
                    _, entries = resp[0]
                    for entry_id, fields in entries:
                        try:
                            payload = json.loads(fields.get("payload", "{}"))
                            attempt = int(payload.get("attempt", 0))
                            result = handler(payload)
                            if asyncio.iscoroutine(result):
                                await result
                            if auto_ack:
                                self._r.xack(s, g, entry_id)
                        except Exception as e:  # noqa: BLE001
                            self.log.exception(f"Handler error on {s} {entry_id}: {e}")
                            # Retry or DLQ
                            if attempt + 1 <= max_retries:
                                payload["attempt"] = attempt + 1
                                self.publish(s, payload)
                            else:
                                self.publish(self.dlq(stream), {"error": str(e), "payload": payload})
                            # Ack the failed entry to avoid blocking PEL
                            try:
                                self._r.xack(s, g, entry_id)
                            except Exception:
                                pass
                except Exception as e:  # noqa: BLE001
                    self.log.exception(f"Consumer loop error on {s}: {e}")
                    await asyncio.sleep(1)

        # Launch workers
        for i in range(max(1, concurrency)):
            task = asyncio.create_task(worker_task(i))
            self._consumer_tasks[f"{s}:{g}:{i}"] = task

    async def stop(self) -> None:
        self._stop.set()
        for key, task in list(self._consumer_tasks.items()):
            try:
                await asyncio.wait_for(task, timeout=3)
            except Exception:
                task.cancel()
            finally:
                self._consumer_tasks.pop(key, None)
        self.log.info("EventBus stopped")

    # Diagnostics helpers
    def xinfo_stream(self, stream: str) -> Optional[Dict[str, Any]]:
        try:
            s = self.stream(stream) if not stream.startswith(self.stream_prefix + ":") else stream
            return self._r.xinfo_stream(s)
        except Exception as e:
            self.log.debug(f"xinfo_stream error for {stream}: {e}")
            return None

    def xinfo_groups(self, stream: str) -> List[Dict[str, Any]]:
        try:
            s = self.stream(stream) if not stream.startswith(self.stream_prefix + ":") else stream
            return self._r.xinfo_groups(s)
        except Exception as e:
            self.log.debug(f"xinfo_groups error for {stream}: {e}")
            return []

    def xlen(self, stream: str) -> int:
        try:
            s = self.stream(stream) if not stream.startswith(self.stream_prefix + ":") else stream
            return int(self._r.xlen(s))
        except Exception as e:
            self.log.debug(f"xlen error for {stream}: {e}")
            return 0

    def xpending(self, stream: str, group: str) -> Optional[Dict[str, Any]]:
        try:
            s = self.stream(stream) if not stream.startswith(self.stream_prefix + ":") else stream
            return self._r.xpending(s, group)
        except Exception as e:
            self.log.debug(f"xpending error for {stream}/{group}: {e}")
            return None


def make_default_event_bus() -> Optional[RedisStreamsEventBus]:
    """Factory based on env vars; returns None if REDIS_URL not set."""
    url = os.environ.get("REDIS_URL")
    if not url:
        return None
    try:
        return RedisStreamsEventBus(redis_url=url)
    except Exception as e:
        logging.getLogger("EventBus").warning(f"Failed to init EventBus: {e}")
        return None
