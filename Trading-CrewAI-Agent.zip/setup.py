"""
Setup script for AI Trading Advisory System
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"🔧 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed:")
        print(f"Error: {e.stderr}")
        return False

def check_python_version():
    """Check if Python version is compatible"""
    print("🐍 Checking Python version...")
    
    version = sys.version_info
    if version.major == 3 and version.minor >= 8:
        print(f"✅ Python {version.major}.{version.minor}.{version.micro} is compatible")
        return True
    else:
        print(f"❌ Python {version.major}.{version.minor}.{version.micro} is not compatible")
        print("Please upgrade to Python 3.8 or higher")
        return False

def install_packages():
    """Install required packages"""
    print("📦 Installing required packages...")
    
    # Read requirements.txt
    requirements_file = Path("requirements.txt")
    if not requirements_file.exists():
        print("❌ requirements.txt not found!")
        return False
    
    # Install packages
    command = f"{sys.executable} -m pip install -r requirements.txt"
    return run_command(command, "Installing packages from requirements.txt")

def setup_directories():
    """Setup necessary directories"""
    print("📁 Setting up directories...")
    
    directories = [
        "data/storage",
        "logs",
        "models",
        "config"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"✅ Created directory: {directory}")
    
    return True

def setup_environment_file():
    """Setup environment file"""
    print("🔧 Setting up environment file...")
    
    env_template = Path(".env.template")
    env_file = Path(".env")
    
    if env_template.exists() and not env_file.exists():
        # Copy template to .env
        with open(env_template, 'r') as template:
            content = template.read()
        
        with open(env_file, 'w') as env:
            env.write(content)
        
        print("✅ Created .env file from template")
        print("⚠️  Please edit .env file with your API keys")
        return True
    elif env_file.exists():
        print("✅ .env file already exists")
        return True
    else:
        print("❌ .env.template not found")
        return False

def test_installation():
    """Test if installation is working"""
    print("🧪 Testing installation...")
    
    try:
        # Test importing key modules
        import yfinance
        import pandas
        import streamlit
        print("✅ Core packages import successfully")
        
        # Test data collection
        import asyncio
        sys.path.append(os.getcwd())
        from data.collectors.market_data import market_data_collector
        print("✅ Data collector module loaded successfully")
        
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    """Main setup function"""
    print("🚀 AI Trading Advisory System Setup")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        return False
    
    # Setup directories
    if not setup_directories():
        return False
    
    # Setup environment file
    if not setup_environment_file():
        return False
    
    # Install packages
    if not install_packages():
        return False
    
    # Test installation
    if not test_installation():
        return False
    
    print("\n🎉 Setup completed successfully!")
    print("\nNext steps:")
    print("1. Edit .env file with your API keys:")
    print("   - AZURE_OPENAI_ENDPOINT")
    print("   - AZURE_OPENAI_API_KEY")
    print("   - ALPHA_VANTAGE_API_KEY (optional)")
    print("   - NEWS_API_KEY (optional)")
    print("\n2. Test the system:")
    print("   python main.py")
    print("\n3. Start the dashboard:")
    print("   streamlit run ui/dashboard.py")
    print("\n4. Start building individual agents!")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
