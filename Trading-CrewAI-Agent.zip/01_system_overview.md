# System Overview

> **Last updated**: Phase 6 + RL v2 + IBKR integration complete

---

## What the system does

The Trading CrewAI Agent is an **AI-powered trading advisory system** that:

1. Accepts natural-language queries from a user (e.g. "What's the outlook for NIFTY this week?", "Buy 100 shares of TCS")
2. Classifies intent and routes the request through a multi-step CrewAI Flow
3. Runs **parallel market-analysis crews** across up to 5 global markets simultaneously
4. Synthesises the results using an AnalysisCrew and optionally validates them with a trained RL agent
5. Presents the synthesis for human approval before any trade is placed
6. Submits approved orders directly to an **Interactive Brokers paper account** via `ib_insync`
7. Persists conversation memory in **LanceDB** and flow checkpoints in **SQLite** for crash-recovery

---

## Architecture

```mermaid
graph LR
    subgraph User["User Interface"]
        UI[HTTP API<br/>main_advisory_agent/main.py]
    end

    subgraph Core["Core — main_advisory_agent/"]
        MAA[MainAdvisoryAgent<br/>tools · NLU · routing]
        AF[AdvisoryFlow<br/>CrewAI Flow]
        MCB[MarketCrewBuilder<br/>5 markets]
        ACB[AnalysisCrewBuilder<br/>synthesis + RL]
        ECB[ExecutionCrewBuilder<br/>trade execution]
        MEM[MemoryStore<br/>LanceDB]
        CHK[SQLiteFlowPersistence<br/>checkpoints]
    end

    subgraph Agents["agents/"]
        IB[IBKRPortfolioService<br/>live portfolio]
        UPM[UniversalPortfolioManager<br/>→ IBKR only]
        SA12[12 Specialised Agents<br/>Research·Technical·Sentiment…]
    end

    subgraph RL["RL_Agent/"]
        RLv2[RLAgentV2<br/>PPO / SAC]
        ENV[PortfolioTradingEnv<br/>gymnasium]
        RC[RegimeClassifier<br/>4 states]
        RM[risk_metrics<br/>Sharpe·VaR·CVaR…]
    end

    subgraph Integration["integration/"]
        EB[EventBus<br/>Redis Streams]
        BRG[CrewAI-RL Bridge v2<br/>regime · weights · feedback]
    end

    UI --> MAA --> AF
    AF --> MCB --> SA12
    AF --> ACB --> RLv2
    AF --> ECB --> IB
    AF --> MEM
    AF --> CHK
    RLv2 --> ENV --> RC
    ENV --> RM
    IB --> UPM
    AF <--> EB
    EB <--> BRG
    BRG <--> RLv2
```

---

## Technology stack

| Layer | Technology | Version / Notes |
|-------|-----------|-----------------|
| **AI Orchestration** | [CrewAI](https://github.com/joaomdmoura/crewAI) | 1.14.5 — Flow + Crew |
| **LLM** | Azure OpenAI GPT-4.1 | `azure/gpt-4.1` via LiteLLM |
| **RL Training** | Stable-Baselines3 | PPO (default) or SAC |
| **RL Environment** | Gymnasium | Multi-asset portfolio env |
| **Vector Memory** | LanceDB | Hierarchical conversation memory |
| **Flow Persistence** | SQLite (via CrewAI) | WAL mode, crash-safe |
| **Broker API** | ib_insync (IBKR) | Paper account, real-time push |
| **Embeddings** | HuggingFace sentence-transformers | `all-mpnet-base-v2` (local) |
| **Data** | yfinance, Alpha Vantage | Market data tools |
| **Event Bus** | Redis Streams | Async agent coordination |
| **Runtime** | Python 3.11 | `crewenv` virtual environment |
| **Containers** | Docker / docker-compose | Production deployment |

---

## Implementation phases

The system was built incrementally. Each phase added capability without breaking prior tests.

| Phase | Description | Tests |
|-------|-------------|-------|
| **0** | CrewAI 1.14.5 Flow topology migration (`AdvisoryFlow`, `AdvisoryFlowState`) | 17 |
| **1** | `MarketCrewBuilder` — parallel per-market crews (IN/US/EU/APAC/CRYPTO) | 26 |
| **2** | MCP Data Layer — `build_data_tools`, Alpha Vantage integration | 18 |
| **3** | `AnalysisCrewBuilder` + RL A2A validation (`rl_a2a_validate`) | 20 |
| **4** | `ExecutionCrewBuilder` + `AdvisoryApprovalProvider` (human-in-the-loop) | 55 |
| **5** | LanceDB hierarchical memory (`MemoryStore`, `advisory_memory_hooks`) | 51 |
| **6** | `SQLiteFlowPersistence` checkpoint/resume | 41 |
| **RL v2** | Multi-asset RL redesign (risk metrics, regime classifier, gym env, PPO/SAC) | 68 |
| **IBKR** | `IBKRPortfolioService` — IBKR-only portfolio data + order placement | — |
| **Total** | | **296 / 296** |

---

## Key design decisions

### 1. CrewAI Flow over plain Crew
`AdvisoryFlow` uses CrewAI's **Flow** primitive (not just Crew) so that:
- Each step has a clearly typed shared state (`AdvisoryFlowState`)
- Steps can be independently checkpointed to SQLite for crash recovery
- The router pattern (`@router`) makes execution paths explicit and testable

### 2. IBKR as the single portfolio source
The paper-trading HTTP service (`paper_trading_agent/`) was superseded by
`IBKRPortfolioService`. Benefits:
- Real-time account state pushed by IBKR (no polling)
- Same code works for paper *and* live accounts (just change port)
- No separate service to keep running

### 3. RL v2 as advisory validator, not executor
`RLAgentV2.validate_strategy()` is called *after* the advisory synthesis and *before*
the approval gate. It annotates the synthesis with per-asset position recommendations
and a **no-trade override** when policy entropy is too high. It does not place orders
itself — that is always done by `ExecutionCrewBuilder` + IBKR.

### 4. Fallbacks removed by design
`UniversalPortfolioManager` previously had a three-tier fallback (IBKR → DirectClient →
PTAClientTool). This was simplified to IBKR-only so errors surface immediately and the
advisory agent always knows the true portfolio state.

### 5. Local embeddings
Sentence-transformer embeddings run fully locally (`hf_models/all-mpnet-base-v2`).
This keeps memory queries fast (no API latency) and avoids embedding API costs.

---

## Data flows

### Advisory query (read-only)
```
User query → NLU (intent + entities) → market_router → market_analysis_step
  → [parallel: IN crew, US crew, EU crew, APAC crew, CRYPTO crew]
  → synthesis_step (AnalysisCrew + RL validation)
  → approval_gate (auto-approve or human)
  → execution_step (ExecutionCrew — builds trade plan)
  → final_response returned to user
```

### Trade order
```
"Buy 100 TCS" → parse_order_request → portfolio_gate_step
  → validate (risk limits, market hours, cash check via IBKR)
  → create approval request (APPROVE <id> / REJECT <id>)
  → user confirms → _execute_approval_decision
  → IBKRPortfolioService.place_order()
  → final_response (fill confirmation)
```

### Checkpoint / resume
```
After each step → _persist_step(method_name)
  → SQLiteFlowPersistence.save_state(conv_id, method_name, state)

On crash / retry → resume_from_checkpoint=True
  → _restore_from_checkpoint(state)
  → SQLiteFlowPersistence.load_state(conv_id)
  → skip expensive steps that already completed
```
