#!/usr/bin/env python3
"""
Startup Script for Three-Tier AI Trading Advisory System
"""

import asyncio
import logging
import signal
import sys
from pathlib import Path
import argparse

# Ensure UTF-8 encoding for stdout/stderr on Windows consoles
try:
    sys.stdout.reconfigure(encoding='utf-8')  # type: ignore[attr-defined]
    sys.stderr.reconfigure(encoding='utf-8')  # type: ignore[attr-defined]
except Exception:
    pass

class _AsciiSanitizer(logging.Filter):
    """Sanitize log records to be ASCII-safe for Windows consoles.
    Replaces characters that can't be encoded with '?'.
    """
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            if isinstance(record.msg, str):
                record.msg = record.msg.encode('ascii', errors='replace').decode('ascii')
            if record.args:
                safe_args = []
                for a in record.args:
                    if isinstance(a, str):
                        safe_args.append(a.encode('ascii', errors='replace').decode('ascii'))
                    else:
                        safe_args.append(a)
                record.args = tuple(safe_args)
        except Exception:
            pass
        return True

# Add project root to path
sys.path.append(str(Path(__file__).parent))

from integration.crewai_rl_bridge import CrewAIRLBridge
from integration.rl_enhanced_orchestrator import RLEnhancedOrchestratorAgent
from analytics.performance_collector import PerformanceCollector
from integration.event_bus import make_default_event_bus, RedisStreamsEventBus
from integration.agent_worker import AgentWorker

# ── Centralised logging setup ─────────────────────────────────────────────────
from config.logging_config import setup_logging as _setup_logging  # noqa: E402
_setup_logging()

# Attach Windows-safe ASCII sanitizer to root so all handlers benefit
try:
    logging.getLogger().addFilter(_AsciiSanitizer())
except Exception:
    pass

logger = logging.getLogger("SystemStartup")


def _resolve_agent_class(agent_id: str):
    """Return the agent class given an ID string, or None if unknown."""
    try:
        if agent_id == "EnhancedTechnicalAgent":
            from agents.enhanced_technical_agent import EnhancedTechnicalAgent as C
            return C
        if agent_id == "EnhancedSentimentAgent":
            from agents.enhanced_sentiment_agent import EnhancedSentimentAgent as C
            return C
        if agent_id == "EnhancedResearchAgent":
            from agents.enhanced_research_agent import EnhancedResearchAgent as C
            return C
        if agent_id == "EnhancedMacroAgent":
            from agents.enhanced_macro_agent import EnhancedMacroAgent as C
            return C
        if agent_id == "EnhancedTimingAgent":
            from agents.enhanced_timing_agent import EnhancedTimingAgent as C
            return C
        if agent_id == "EnhancedTradeStrategyPlannerAgent":
            from agents.enhanced_trade_strategy_planner import EnhancedTradeStrategyPlanner as C
            return C
        if agent_id == "EnhancedPerformanceAgent":
            from agents.enhanced_performance_agent import EnhancedPerformanceAgent as C
            return C
        if agent_id == "EnhancedPTAAgent":
            from agents.enhanced_pta_agent import EnhancedPTAAgent as C
            return C
        if agent_id == "EnhancedPortfolioManagerAgent":
            from agents.enhanced_portfolio_manager import EnhancedPortfolioManager as C
            return C
        if agent_id == "EnhancedRiskAgent":
            from agents.enhanced_risk_agent import EnhancedRiskAgent as C
            return C
        if agent_id == "EnhancedDividendsYieldOptimizerAgent":
            try:
                from agents.enhanced_dividends_yield_optimizer import EnhancedDividendsYieldOptimizer as C
                return C
            except Exception:
                return None
    except Exception:
        return None
    return None


async def run_smoke_test(agent_id: str, action: str, symbol: str, timeframe: str, timeout_ms: int, auto_worker: bool = False) -> None:
    """Send a single request to the specified agent stream and print the reply.
    If auto_worker=True, start a temporary worker for this agent in-process.
    """
    bus = None
    stream = f"agents:{agent_id}:requests"
    try:
        bus = RedisStreamsEventBus()
        if auto_worker:
            AgentClass = _resolve_agent_class(agent_id)
            if AgentClass is None:
                print(f"Cannot auto-start worker: unknown or unavailable agent '{agent_id}'")
                return
            instance = AgentClass()
            worker = AgentWorker(agent_id=agent_id, agent_instance=instance, bus=bus, stream=stream)
            worker.start(concurrency=1)
            # small delay to ensure consumer group is created before sending
            await asyncio.sleep(0.2)
        payload = {"action": action, "data": {"symbol": symbol, "timeframe": timeframe}}
        print(f"Sending request to {stream}: {payload}")
        resp = await bus.request(stream, payload, timeout_ms=timeout_ms)
        print("Smoke test reply:")
        print(resp)
    except Exception as e:
        print(f"Smoke test via Redis failed: {e}")
        # Fallback: direct in-process method call if possible
        AgentClass = _resolve_agent_class(agent_id)
        if AgentClass is None:
            print(f"Cannot run fallback direct call: unknown or unavailable agent '{agent_id}'")
        else:
            try:
                instance = AgentClass()
                if hasattr(instance, action):
                    method = getattr(instance, action)
                elif hasattr(instance, "analyze"):
                    method = getattr(instance, "analyze")
                else:
                    print(f"Fallback failed: agent has no method '{action}' or 'analyze'")
                    method = None
                if method is not None:
                    print("Running direct in-process call (no Redis)...")
                    res = method(symbol=symbol, timeframe=timeframe)
                    if asyncio.iscoroutine(res):
                        res = await res
                    print({"success": True, "data": res})
            except Exception as e2:
                print(f"Fallback direct call failed: {e2}")
    finally:
        if bus is not None:
            try:
                await bus.stop()
            except Exception:
                pass


def run_bus_diagnostics(agent_ids: list[str]) -> None:
    """Print Redis Streams diagnostics for each agent request stream and its DLQ."""
    try:
        bus = RedisStreamsEventBus()
        for aid in agent_ids:
            stream = f"agents:{aid}:requests"
            size = bus.xlen(stream)
            groups = bus.xinfo_groups(stream)
            dlq_len = bus.xlen(bus.dlq(stream))
            group_summaries = [
                {
                    "name": g.get("name"),
                    "consumers": g.get("consumers"),
                    "pending": g.get("pending"),
                    "last_delivered_id": g.get("last-delivered-id"),
                }
                for g in groups
            ]
            print(f"{stream} -> size={size} groups={group_summaries} dlq={dlq_len}")
    except Exception as e:
        print(f"Bus diagnostics failed: {e}")


class ThreeTierSystem:
    """Main system coordinator"""
    
    def __init__(self):
        self.bridge = None
        self.orchestrator = None
        self.performance_collector = None
        self.event_bus = None
        self.running = False
        self._workers = []  # track AgentWorker instances
        self._agent_ids = []  # track bound agent IDs for diagnostics
    
    async def start(self):
        """Start the integrated system"""
        try:
            logger.info("🚀 Starting Three-Tier AI Trading Advisory System...")
            
            # Initialize components
            self.bridge = CrewAIRLBridge()
            self.performance_collector = PerformanceCollector()
            
            # Import actual registry when available
            from agent_registry import agent_registry
            
            self.orchestrator = RLEnhancedOrchestratorAgent(
                registry=agent_registry,
                debug=False,
                use_llm=True
            )
            
            # Start RL bridge (optional). If unavailable, continue without RL.
            try:
                await self.bridge.start()
                logger.info("RL Bridge connected; enabling RL feedback features")
                self.performance_collector.set_rl_bridge(self.bridge)
            except Exception as e:
                logger.warning(f"RL Bridge unavailable, continuing without RL: {e}")
                self.bridge = None
            
            # Initialize orchestrator RL integration (handles its own errors and degrades gracefully)
            await self.orchestrator.initialize_rl_integration()
            
            # Initialize EventBus (optional)
            self.event_bus = make_default_event_bus()
            if self.event_bus:
                logger.info("EventBus initialized (Redis Streams). A2A transport ready.")
            else:
                logger.info("EventBus not configured (set REDIS_URL). Running without Redis A2A transport.")
            
            # Bootstrap and bind enhanced agents; start workers if EventBus available
            await self._bootstrap_agents_and_workers(agent_registry)
            
            # Log EventBus diagnostics once at startup
            if self.event_bus:
                self._log_bus_diagnostics()
            
            self.running = True
            logger.info("✅ System started successfully!")
            
            # Start monitoring loop
            await self._monitoring_loop()
            
        except Exception as e:
            logger.error(f"❌ System startup failed: {e}")
            await self.stop()
            raise
    
    async def stop(self):
        """Stop the system gracefully"""
        logger.info("🛑 Stopping system...")
        self.running = False
        
        # Attempt to stop EventBus consumers
        try:
            if self.event_bus:
                await self.event_bus.stop()
        except Exception:
            pass
        
        if self.bridge:
            await self.bridge.stop()
        
        if self.orchestrator:
            await self.orchestrator.shutdown()
        
        logger.info("✅ System stopped")
    
    async def _monitoring_loop(self):
        """Main monitoring and maintenance loop"""
        while self.running:
            try:
                # Check system health
                health = await self.orchestrator.get_system_health()
                logger.info(f"System health: {health}")
                
                # Update weights from RL
                await self.orchestrator.update_weights_from_rl()
                
                # Wait before next check
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(60)

    def _log_bus_diagnostics(self):
        """Log Redis Streams diagnostics for each agent stream (length, groups, pending, DLQ)."""
        try:
            if not self.event_bus or not self._agent_ids:
                return
            for aid in self._agent_ids:
                stream = f"agents:{aid}:requests"
                _ = self.event_bus.xinfo_stream(stream)
                groups = self.event_bus.xinfo_groups(stream)
                size = self.event_bus.xlen(stream)
                dlq_len = self.event_bus.xlen(self.event_bus.dlq(stream))
                group_summaries = [
                    {
                        "name": g.get("name"),
                        "consumers": g.get("consumers"),
                        "pending": g.get("pending"),
                        "last_delivered_id": g.get("last-delivered-id"),
                    }
                    for g in groups
                ]
                logger.info(
                    f"A2A stream diagnostics for {aid}: size={size}, groups={group_summaries}, dlq={dlq_len}"
                )
        except Exception as e:
            logger.warning(f"Diagnostics logging failed: {e}")

    async def _bootstrap_agents_and_workers(self, registry):
        """Instantiate enhanced agents, bind into registry, and start AgentWorkers when EventBus is configured."""
        # Import agent classes
        from agents.enhanced_technical_agent import EnhancedTechnicalAgent
        from agents.enhanced_sentiment_agent import EnhancedSentimentAgent
        from agents.enhanced_research_agent import EnhancedResearchAgent
        from agents.enhanced_macro_agent import EnhancedMacroAgent
        from agents.enhanced_timing_agent import EnhancedTimingAgent
        from agents.enhanced_trade_strategy_planner import EnhancedTradeStrategyPlanner
        from agents.enhanced_pta_agent import EnhancedPTAAgent
        from agents.enhanced_performance_agent import EnhancedPerformanceAgent
        from agents.enhanced_portfolio_manager import EnhancedPortfolioManager
        from agents.enhanced_risk_agent import EnhancedRiskAgent
        # Optional dividend/yield optimizer if used
        try:
            from agents.enhanced_dividends_yield_optimizer import EnhancedDividendsYieldOptimizer
        except Exception:  # not mandatory
            EnhancedDividendsYieldOptimizer = None
        
        # Create agent instances
        agents = [
            ("EnhancedTechnicalAgent", EnhancedTechnicalAgent()),
            ("EnhancedSentimentAgent", EnhancedSentimentAgent()),
            ("EnhancedResearchAgent", EnhancedResearchAgent()),
            ("EnhancedMacroAgent", EnhancedMacroAgent()),
            ("EnhancedTimingAgent", EnhancedTimingAgent()),
            ("EnhancedTradeStrategyPlannerAgent", EnhancedTradeStrategyPlanner()),
            ("EnhancedPTAAgent", EnhancedPTAAgent()),
            ("EnhancedPerformanceAgent", EnhancedPerformanceAgent()),
            ("EnhancedPortfolioManagerAgent", EnhancedPortfolioManager()),
            ("EnhancedRiskAgent", EnhancedRiskAgent()),
        ]
        if EnhancedDividendsYieldOptimizer:
            agents.append(("EnhancedDividendsYieldOptimizerAgent", EnhancedDividendsYieldOptimizer()))
        
        # Track IDs for diagnostics
        self._agent_ids = [aid for aid, _ in agents]
        
        # Bind instances in registry so Orchestrator can call in-process when needed
        for agent_id, instance in agents:
            try:
                registry.bind_instance(agent_id, instance)
                logger.info(f"Bound instance for {agent_id} -> stream {registry.get_stream_name(agent_id)}")
            except Exception as e:
                logger.error(f"Failed binding {agent_id}: {e}")
        
        # Start Redis Stream workers if EventBus is configured
        if not self.event_bus:
            logger.info("Skipping AgentWorker startup (EventBus not configured)")
            return
        
        for agent_id, instance in agents:
            try:
                stream_name = registry.get_stream_name(agent_id) or f"agents:{agent_id}:requests"
                worker = AgentWorker(agent_id=agent_id, agent_instance=instance, bus=self.event_bus, stream=stream_name)
                worker.start(concurrency=1)
                self._workers.append(worker)
                logger.info(f"Started AgentWorker for {agent_id} on {stream_name}")
            except Exception as e:
                logger.error(f"Failed starting worker for {agent_id}: {e}")


async def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="AI Trading Advisory System")
    parser.add_argument("--smoke-test", action="store_true", help="Run a one-shot A2A smoke test and exit")
    parser.add_argument("--agent-id", default="EnhancedTechnicalAgent", help="Agent ID for smoke test")
    parser.add_argument("--action", default="analyze", help="Action/method to invoke in smoke test")
    parser.add_argument("--symbol", default="AAPL", help="Symbol for smoke test")
    parser.add_argument("--timeframe", default="1d", help="Timeframe for smoke test")
    parser.add_argument("--timeout-ms", type=int, default=30000, help="Request timeout in ms for smoke test")
    parser.add_argument("--auto-worker", action="store_true", help="Auto-start a temporary worker for the chosen agent during smoke test")
    parser.add_argument("--bus-diagnostics", action="store_true", help="Print Redis Streams diagnostics and exit")
    args = parser.parse_args()

    if args.smoke_test:
        await run_smoke_test(args.agent_id, args.action, args.symbol, args.timeframe, args.timeout_ms, args.auto_worker)
        return

    if args.bus_diagnostics:
        default_ids = [
            "EnhancedTechnicalAgent",
            "EnhancedSentimentAgent",
            "EnhancedResearchAgent",
            "EnhancedMacroAgent",
            "EnhancedTimingAgent",
            "EnhancedTradeStrategyPlannerAgent",
                "EnhancedPTAAgent",
            "EnhancedPerformanceAgent",
            "EnhancedPortfolioManagerAgent",
            "EnhancedRiskAgent",
            "EnhancedDividendsYieldOptimizerAgent",
        ]
        run_bus_diagnostics(default_ids)
        return

    system = ThreeTierSystem()
    
    # Setup signal handlers
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, shutting down...")
        asyncio.create_task(system.stop())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        await system.start()
    except KeyboardInterrupt:
        logger.info("Received interrupt, shutting down...")
    finally:
        await system.stop()


if __name__ == "__main__":
    # Clear previous session logs
    try:
        log_files = ['logs/integrated_system.log', 'logs/rl_worker.log']
        for log_file in log_files:
            try:
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write('')  # Clear the log file
            except (FileNotFoundError, OSError):
                pass  # File doesn't exist or can't be accessed
    except Exception:
        pass
    
    asyncio.run(main())
