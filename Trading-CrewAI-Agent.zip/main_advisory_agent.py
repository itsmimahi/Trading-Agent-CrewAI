"""
Main Advisory Agent Implementation
The central AI Trading Advisory Agent built with CrewAI framework.
"""

import os
import re
import json
import sys
import logging
import uuid
import math
import hashlib
import traceback
import asyncio
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta, time as dt_time
from dotenv import load_dotenv

try:
    from zoneinfo import ZoneInfo
except Exception:  # pragma: no cover
    ZoneInfo = None  # type: ignore

# Load environment variables
load_dotenv()

# ── Centralised logging setup ───────────────────────────────────────────────
# Import and initialise before any other project module so that all child
# loggers (advisory_flow, market_crew_builder, …) inherit the configuration.
try:
    _config_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config")
    if _config_dir not in sys.path:
        sys.path.insert(0, _config_dir)
    from config.logging_config import setup_logging as _setup_logging  # type: ignore
    _setup_logging()
except Exception as _log_setup_err:
    # Fallback: plain basicConfig so the module never crashes
    print(f"[logging_config] setup_logging() failed — falling back to basicConfig. Reason: {_log_setup_err}")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)-8s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

logger = logging.getLogger(__name__)

# Disable CrewAI telemetry to prevent outbound timeouts and noise
# Must be set BEFORE importing crewai modules
os.environ.setdefault("CREWAI_DISABLE_TELEMETRY", "true")
os.environ.setdefault("CREWAI_DISABLE_TRACKING", "true")
os.environ.setdefault("OTEL_SDK_DISABLED", "true")
# Silence Chroma anonymized telemetry
os.environ.setdefault("ANONYMIZED_TELEMETRY", "false")

# Set HF cache directory to avoid TRANSFORMERS_CACHE deprecation warning
try:
    hf_home_default = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "hf_models", ".hf_home")
    os.environ.setdefault("HF_HOME", hf_home_default)
    # Optional: ignore old var if present
    if os.environ.get("TRANSFORMERS_CACHE"):
        logger.info("TRANSFORMERS_CACHE detected; HF_HOME is set. Consider removing TRANSFORMERS_CACHE from env.")
except Exception:
    pass

# Add project root to path for imports
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from crewai import Agent, Task, Crew, Process
# from crewai.memory import LongTermMemory, ShortTermMemory
from crewai.tools import BaseTool
from crewai.llm import LLM

from agent_registry import agent_registry, SpecializedAgent
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pta_client import PTAClientTool
from routing import GlobalMarketRouter, PortfolioActionGuard
try:
    from agents.ibkr_portfolio_service import get_ibkr_service, IBKRPortfolioService  # type: ignore
except Exception:  # pragma: no cover
    get_ibkr_service = None  # type: ignore
    IBKRPortfolioService = None  # type: ignore
# UniversalPortfolioManager kept for backward-compat (other agents); MainAdvisoryAgent
# now talks to IBKRPortfolioService directly.
try:
    from agents.universal_portfolio_manager import get_portfolio_manager
except Exception:  # pragma: no cover
    get_portfolio_manager = None  # type: ignore
from conversation import (
    ConversationContext, ConversationState, MessageType,
    conversation_manager
)

# Add: local embeddings for Crew memory (short-term/entity) via Chroma EmbeddingFunction
from chromadb import EmbeddingFunction, Documents, Embeddings  # type: ignore
from sentence_transformers import SentenceTransformer  # type: ignore
try:
    import tiktoken  # type: ignore
except Exception:  # pragma: no cover
    tiktoken = None  # type: ignore
try:
    import requests  # type: ignore
except Exception:  # pragma: no cover
    requests = None  # type: ignore

# Optional market data
try:
    import yfinance as yf  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    yf = None  # type: ignore

# Settings for defaults/stock universe
try:
    from config.settings import get_settings
    _SETTINGS = get_settings()
except Exception:
    _SETTINGS = None


_GLOBAL_ST_MODEL = None  # Singleton cache for SentenceTransformer


class LocalHFEmbeddingFunction(EmbeddingFunction):  # Subclass Chroma EmbeddingFunction
    """Local HuggingFace EmbeddingFunction for CrewAI short-term/entity memory."""
    
    def __init__(self, model_path: str):
        # Load once; CPU-only by default on Windows environment
        global _GLOBAL_ST_MODEL
        if _GLOBAL_ST_MODEL is None:
            _GLOBAL_ST_MODEL = SentenceTransformer(model_path, device="cpu")
        self._model = _GLOBAL_ST_MODEL

    def __call__(self, input: Documents) -> Embeddings:  # type: ignore[override]
        # input can be a single string or a list of strings
        if isinstance(input, str):
            texts: List[str] = [input]
        else:
            texts = list(input)
        # Normalize embeddings for cosine similarity; return as list[list[float]]
        vecs = self._model.encode(
            texts,
            normalize_embeddings=True,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        return [v.tolist() for v in vecs]


def _build_local_embedder_config() -> Optional[dict]:
    """Create Crew embedder config using local HF model directory.
    Returns a dict compatible with crewai.Crew(embedder=...).
    """
    # Prefer env override; fallback to bundled hf_models path
    local_model_dir = os.getenv(
        "LOCAL_EMBEDDINGS_MODEL_DIR",
        os.path.join(project_root, "hf_models", "all-mpneet-base-v2"),
    )
    # Provide a callable that returns an EmbeddingFunction instance
    return {
        "provider": "custom",
        "config": {
            "embedder": (lambda: LocalHFEmbeddingFunction(local_model_dir))
        },
    }


# Configure Azure OpenAI LLM (for chat/completions only; embeddings now local)
# is_litellm=True forces LiteLLM routing (standard openai SDK for Azure OpenAI
# Service). Without it, CrewAI 1.14.5 uses the Azure AI Inference SDK which
# targets Azure AI Foundry/serverless endpoints and returns 500 on Azure OpenAI.
# api_base (not base_url) is what LiteLLM's Azure handler reads for the endpoint.
# Also map AZURE_OPENAI_* → AZURE_* so LiteLLM's env-var fallback path works
# even if the parameter doesn't survive Pydantic field validation.
if os.getenv("AZURE_OPENAI_ENDPOINT") and not os.getenv("AZURE_API_BASE"):
    os.environ["AZURE_API_BASE"] = os.environ["AZURE_OPENAI_ENDPOINT"]
if os.getenv("AZURE_OPENAI_API_KEY") and not os.getenv("AZURE_API_KEY"):
    os.environ["AZURE_API_KEY"] = os.environ["AZURE_OPENAI_API_KEY"]
if os.getenv("AZURE_OPENAI_API_VERSION") and not os.getenv("AZURE_API_VERSION"):
    os.environ["AZURE_API_VERSION"] = os.environ["AZURE_OPENAI_API_VERSION"]

azure_llm = LLM(
    model="azure/gpt-4.1",
    is_litellm=True,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_base=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
)


class AgentRegistryTool(BaseTool):
    """Tool for interacting with the Agent Registry."""
    
    name: str = "agent_registry_tool"
    description: str = "Query the agent registry to find specialized agents and their capabilities"
    
    def _run(self, action: str, **kwargs) -> str:
        """Execute agent registry operations."""
        try:
            # Supported actions:
            # - list_all: return all active agents
            # - get_all_agents: alias of list_all
            # - find_by_capability: capability=<name>
            # - find_by_role: role=<role>
            # - get_agent: agent_id=<id>
            # - get_capabilities: agent_id=<id>
            # - find_by_tag: tag=<keyword> (matches role/capability name contains)
            if action in ("list_all", "get_all_agents"):
                agents = agent_registry.get_active_agents()
                return json.dumps([agent.to_dict() for agent in agents])
            
            elif action == "find_by_capability":
                capability = kwargs.get("capability", "")
                agents = agent_registry.find_agents_by_capability(capability)
                return json.dumps([agent.to_dict() for agent in agents])
            
            elif action == "find_by_role":
                role = kwargs.get("role", "")
                agents = agent_registry.find_agents_by_role(role)
                return json.dumps([agent.to_dict() for agent in agents])
            
            elif action == "get_agent":
                agent_id = kwargs.get("agent_id", "")
                agent = agent_registry.get_agent(agent_id)
                return json.dumps(agent.to_dict() if agent else None)
            
            elif action == "get_capabilities":
                agent_id = kwargs.get("agent_id", "")
                agent = agent_registry.get_agent(agent_id)
                if not agent:
                    return json.dumps({"error": f"Agent {agent_id} not found"})
                return json.dumps({
                    "agent_id": agent.agent_id,
                    "capabilities": [c.name for c in agent.capabilities]
                })
            
            elif action == "find_by_tag":
                tag = (kwargs.get("tag", "") or "").strip().lower()
                matches: List[Dict[str, Any]] = []
                for agent in agent_registry.get_active_agents():
                    if tag in agent.role.lower() or any(tag in c.name.lower() for c in agent.capabilities):
                        matches.append(agent.to_dict())
                return json.dumps(matches)
            
            else:
                return f"Unknown action: {action}"
                
        except Exception as e:
            return f"Error in agent registry tool: {str(e)}"


class ConversationTool(BaseTool):
    """Tool for managing conversation context."""
    
    name: str = "conversation_tool"
    description: str = "Manage conversation context, state, and history"
    
    def _run(self, action: str, conversation_id: str, **kwargs) -> str:
        """Execute conversation management operations."""
        try:
            context = conversation_manager.get_conversation(conversation_id)
            if not context:
                # Auto-create missing conversations to avoid tool-error fallbacks
                context = conversation_manager.create_conversation(conversation_id)
            
            if action == "create":
                context = conversation_manager.create_conversation(conversation_id)
                return f"Created conversation {context.conversation_id}"
            
            elif action == "add_message":
                message_type = MessageType(kwargs.get("message_type", "user_input"))
                content = kwargs.get("content", "")
                metadata = kwargs.get("metadata", {})
                message_id = context.add_message(message_type, content, metadata)
                return f"Added message {message_id}"
            
            elif action == "update_state":
                new_state = ConversationState(kwargs.get("state"))
                context.update_state(new_state)
                return f"Updated state to {new_state.value}"
            
            elif action == "set_query":
                query = kwargs.get("query", "")
                context.set_current_query(query)
                return f"Set current query: {query}"
            
            elif action == "set_intent":
                intent = kwargs.get("intent", "")
                context.set_inferred_intent(intent)
                return f"Set inferred intent: {intent}"
            
            elif action == "add_entity":
                entity_type = kwargs.get("entity_type", "")
                value = kwargs.get("value", "")
                confidence = kwargs.get("confidence", 0.0)
                source_message_id = kwargs.get("source_message_id", "")
                context.add_extracted_entity(entity_type, value, confidence, source_message_id)
                return f"Added entity: {entity_type} = {value}"
            
            elif action == "get_summary":
                return json.dumps(context.get_conversation_summary())
            
            elif action == "get_context":
                return json.dumps(context.to_dict())
            
            else:
                return f"Unknown action: {action}"
                
        except Exception as e:
            return json.dumps({
                "error": "conversation_tool_error",
                "message": str(e),
                "action": action,
                "conversation_id": conversation_id
            })


class SpecializedAgentTool(BaseTool):
    """Tool for communicating with specialized agents.
    Prefers in-process A2A dispatch when a bound instance is available; falls back to HTTP API.
    """
    
    name: str = "specialized_agent_tool"
    description: str = "Delegate tasks to specialized agents (A2A preferred, HTTP fallback) and retrieve results"
    
    def _run(self, agent_id: str, task_description: str, input_parameters: Dict[str, Any], 
             conversation_id: str) -> str:
        """Delegate a task to a specialized agent using A2A when possible, otherwise HTTP."""
        try:
            # Get the specialized agent from registry
            agent = agent_registry.get_agent(agent_id)
            if not agent:
                return f"Agent {agent_id} not found in registry"
            
            # Get conversation context
            context = conversation_manager.get_conversation(conversation_id)
            if not context:
                return f"Conversation {conversation_id} not found"
            
            # Add task delegation record
            task_id = context.add_delegated_task(agent_id, task_description, input_parameters)

            # Decide transport: env override or auto
            transport_pref = (os.environ.get("SPECIALIZED_AGENT_TRANSPORT", "auto") or "auto").lower()
            use_a2a = (agent.instance is not None) and (transport_pref in ("auto", "a2a"))

            if use_a2a:
                # A2A in-process dispatch via registry
                message = {
                    "to": agent_id,
                    "action": "analyze",
                    "data": {
                        **(input_parameters or {}),
                        "conversation_id": conversation_id,
                        "task_description": task_description,
                    },
                }
                try:
                    result = asyncio.run(agent_registry.send_message(message))
                except RuntimeError:
                    # Event loop already running (e.g., inside async context) — use alternative scheduling
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        result = loop.run_until_complete(agent_registry.send_message(message))  # type: ignore
                    else:
                        result = loop.run_until_complete(agent_registry.send_message(message))

                context.update_task_status(task_id, "completed", result)
                return json.dumps({
                    "task_id": task_id,
                    "agent_id": agent_id,
                    "status": "completed",
                    "transport": "a2a",
                    "result": result,
                })

            # HTTP fallback
            if requests is None and transport_pref == "http":
                raise RuntimeError("requests library not available for HTTP calls and transport forced to HTTP")
            if requests is None:
                return json.dumps({
                    "error": "specialized_agent_error",
                    "message": "HTTP client unavailable and no bound instance for A2A",
                    "agent_id": agent_id,
                    "conversation_id": conversation_id
                })

            base_url = os.environ.get("SPECIALIZED_AGENTS_BASE_URL", "http://localhost:8000")
            endpoint = (agent.endpoint or "/")
            if endpoint.startswith("http://") or endpoint.startswith("https://"):
                url = endpoint
            else:
                url = base_url.rstrip("/") + endpoint

            payload = {
                "agent_id": agent_id,
                "task": task_description,
                "input": input_parameters,
                "conversation_id": conversation_id,
            }
            headers = {
                "Content-Type": "application/json",
                "X-Request-ID": context.get_context_data("request_id", str(uuid.uuid4())),
            }
            timeout_s = float(os.environ.get("SPECIALIZED_AGENT_TIMEOUT", "20"))
            resp = requests.post(url, json=payload, headers=headers, timeout=timeout_s)
            if not (200 <= resp.status_code < 300):
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
            try:
                result = resp.json()
            except Exception:
                result = {"raw": resp.text}

            context.update_task_status(task_id, "completed", result)
            return json.dumps({
                "task_id": task_id,
                "agent_id": agent_id,
                "status": "completed",
                "transport": "http",
                "result": result
            })
            
        except Exception as e:
            return json.dumps({
                "error": "specialized_agent_error",
                "message": str(e),
                "agent_id": agent_id,
                "conversation_id": conversation_id
            })

class ParallelSpecializedAgentTool(BaseTool):
    """Execute multiple specialized-agent requests in parallel with timeouts and merge results.
    Input: a list of {agent_id, task_description, input_parameters}, optional transport and timeout.
    Output: JSON with per-agent results and summary.
    """

    name: str = "parallel_specialized_agent_tool"
    description: str = "Run multiple specialized agent tasks concurrently (A2A preferred, HTTP fallback) with timeout and merged results"

    def _run(self, requests_list: List[Dict[str, Any]], conversation_id: str, timeout_seconds: float = 20.0, transport: str = "auto") -> str:
        try:
            if not isinstance(requests_list, list) or not requests_list:
                return json.dumps({"error": "requests_list must be a non-empty list"})

            # Helper to run one request (async-friendly)
            async def _run_one(req: Dict[str, Any]) -> Dict[str, Any]:
                agent_id = req.get("agent_id")
                task_description = req.get("task_description", "analyze")
                input_parameters = req.get("input_parameters", {})
                if not agent_id:
                    return {"error": "missing_agent_id", "request": req}
                agent = agent_registry.get_agent(agent_id)
                if not agent:
                    return {"error": f"agent_not_found:{agent_id}", "request": req}
                # Prefer A2A when bound and allowed
                use_a2a = (agent.instance is not None) and (transport in ("auto", "a2a"))
                if use_a2a:
                    message = {
                        "to": agent_id,
                        "action": "analyze",
                        "data": {**(input_parameters or {}), "conversation_id": conversation_id, "task_description": task_description},
                    }
                    try:
                        return await agent_registry.send_message(message)
                    except Exception as e:
                        return {"error": str(e), "agent_id": agent_id, "transport": "a2a"}
                # HTTP fallback
                if requests is None:
                    return {"error": "http_client_unavailable", "agent_id": agent_id}
                base_url = os.environ.get("SPECIALIZED_AGENTS_BASE_URL", "http://localhost:8000")
                endpoint = (agent.endpoint or "/")
                url = endpoint if endpoint.startswith("http") else base_url.rstrip("/") + endpoint
                try:
                    headers = {"Content-Type": "application/json"}
                    resp = requests.post(url, json={
                        "agent_id": agent_id,
                        "task": task_description,
                        "input": input_parameters,
                        "conversation_id": conversation_id,
                    }, timeout=timeout_seconds)
                    return resp.json() if 200 <= resp.status_code < 300 else {"error": f"HTTP {resp.status_code}", "body": resp.text[:500]}
                except Exception as e:
                    return {"error": str(e), "agent_id": agent_id, "transport": "http"}

            async def _run_all() -> List[Dict[str, Any]]:
                tasks = []
                for r in requests_list:
                    tasks.append(asyncio.create_task(_run_one(r)))
                results: List[Dict[str, Any]] = []
                try:
                    results = await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=False), timeout=timeout_seconds)
                except asyncio.TimeoutError:
                    # Some tasks timed out; collect what completed
                    for t in tasks:
                        if not t.done():
                            t.cancel()
                    results = [t.result() if t.done() and not t.cancelled() else {"error": "timeout"} for t in tasks]
                return results

            # Run event loop appropriately
            try:
                results = asyncio.run(_run_all())
            except RuntimeError:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    results = loop.run_until_complete(_run_all())  # type: ignore
                else:
                    results = loop.run_until_complete(_run_all())

            # Merge: simple summary
            successes = sum(1 for r in results if not r.get("error"))
            merged = {
                "total": len(results),
                "successes": successes,
                "failures": len(results) - successes,
                "results": results,
            }
            return json.dumps(merged)
        except Exception as e:
            return json.dumps({"error": f"parallel_tool_error: {e}"})
    
    def _simulate_agent_response(self, agent: SpecializedAgent, task_description: str, 
                                input_parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Simulate a response from a specialized agent."""
        # This is a simulation - in a real implementation, this would make actual API calls
        
        if agent.agent_id == "fundamental_research":
            return {
                "analysis": f"Fundamental analysis for {input_parameters.get('symbol', 'N/A')}",
                "key_metrics": {
                    "pe_ratio": 15.2,
                    "debt_to_equity": 0.45,
                    "roe": 0.18,
                    "revenue_growth": 0.12
                },
                "recommendation": "BUY",
                "confidence": 0.85
            }
        
        elif agent.agent_id == "technical_analysis":
            return {
                "signals": ["Golden Cross", "RSI Oversold"],
                "support_resistance": {
                    "support": 150.0,
                    "resistance": 180.0
                },
                "trend": "Bullish",
                "confidence": 0.78
            }
        
        elif agent.agent_id == "sentiment_analysis":
            return {
                "sentiment_score": 0.65,
                "key_themes": ["Positive earnings", "Market optimism", "Sector rotation"],
                "summary": "Overall positive sentiment with increasing bullish mentions",
                "confidence": 0.72
            }
        
        elif agent.agent_id == "risk_assessment":
            return {
                "risk_score": 0.35,
                "diversification_analysis": {
                    "sector_concentration": "Moderate",
                    "geographic_exposure": "Domestic focused"
                },
                "recommendations": ["Consider international diversification", "Reduce sector concentration"],
                "confidence": 0.80
            }
        
        else:
            return {
                "message": f"Simulated response from {agent.name} (fallback)",
                "task_completed": True,
                "confidence": 0.75
            }


class MarketDataTool(BaseTool):
    """Fetch market overview and top movers using yfinance for Indian market by default."""

    name: str = "market_data_tool"
    description: str = "Get market overview (NIFTY/SENSEX) and top movers for configured stock universe."

    def _run(self, action: str, **kwargs) -> str:
        try:
            if yf is None:
                return json.dumps({"error": "yfinance not installed. Please install yfinance to enable market data."})

            # Defaults
            default_market = getattr(getattr(_SETTINGS, "system", None), "default_market", "IN") if _SETTINGS else "IN"
            market = kwargs.get("market", default_market)

            if action == "market_overview":
                # NIFTY 50 (^NSEI), SENSEX (^BSESN)
                indices = ["^NSEI", "^BSESN"] if market == "IN" else ["^GSPC", "^IXIC", "^DJI"]
                data = {}
                for sym in indices:
                    t = yf.Ticker(sym)
                    hist = t.history(period="2d")
                    if hist is None or hist.empty:
                        continue
                    last = float(hist["Close"].iloc[-1])
                    prev = float(hist["Close"].iloc[-2]) if len(hist) > 1 else last
                    pct = ((last - prev) / prev * 100.0) if prev else 0.0
                    data[sym] = {"last": last, "prev": prev, "pct_change": round(pct, 3)}
                return json.dumps({"market": market, "indices": data})

            elif action == "top_movers":
                universe = []
                if _SETTINGS and getattr(_SETTINGS, "stock_universe", None):
                    universe = list(_SETTINGS.stock_universe)
                # Minimal fallback if no settings
                if not universe:
                    universe = ["RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ITC.NS", "SBIN.NS", "ZOMATO.NS"]
                period = kwargs.get("period", "1d")
                movers: List[Dict[str, Any]] = []
                for sym in universe[:50]:  # cap to 50 for speed
                    try:
                        df = yf.Ticker(sym).history(period="2d")
                        if df is None or df.empty:
                            continue
                        last = float(df["Close"].iloc[-1])
                        prev = float(df["Close"].iloc[-2]) if len(df) > 1 else last
                        pct = ((last - prev) / prev * 100.0) if prev else 0.0
                        movers.append({"symbol": sym, "pct_change": pct, "last": last})
                    except Exception:
                        continue
                movers_sorted = sorted(movers, key=lambda x: x["pct_change"], reverse=True)
                top_n = int(kwargs.get("top", 10))
                return json.dumps({
                    "market": market,
                    "top_gainers": movers_sorted[:top_n],
                    "top_losers": list(reversed(movers_sorted[-top_n:]))
                })

            else:
                return json.dumps({"error": f"Unknown action: {action}"})
        except Exception as e:
            return json.dumps({"error": f"Market data error: {e}"})


class EntityExtractor:
    """Extracts entities from user input."""
    
    @staticmethod
    def extract_entities(text: str) -> List[Dict[str, Any]]:
        """Extract entities from text."""
        entities: List[Dict[str, Any]] = []

        # Build a whitelist from settings (NSE tickers end with .NS)
        settings_universe = []
        if _SETTINGS and getattr(_SETTINGS, "stock_universe", None):
            settings_universe = [s.upper() for s in _SETTINGS.stock_universe]
        # Known company name -> Yahoo symbol mapping (expand as needed)
        known_map = {
            "ZOMATO": "ZOMATO.NS",
            "RELIANCE": "RELIANCE.NS",
            "TCS": "TCS.NS",
            "INFY": "INFY.NS",
            "HDFC": "HDFCBANK.NS",
            "ICICI": "ICICIBANK.NS",
            "SBIN": "SBIN.NS",
            "ITC": "ITC.NS",
        }
        
        tokens = re.findall(r"[A-Za-z][A-Za-z0-9_.-]{1,12}", text)
        stopwords = {"HEY", "HI", "CAN", "YOU", "HELP", "ME", "TO", "WHAT", "IS", "THE", "OF", "TODAY", "IT", "OR"}
        seen_syms = set()
        for tok in tokens:
            up = tok.upper()
            if up in stopwords:
                continue
            # Direct match in universe
            if up.endswith(".NS") and up in settings_universe:
                sym = up
            elif up in known_map:
                sym = known_map[up]
            else:
                continue
            if sym in seen_syms:
                continue
            seen_syms.add(sym)
            entities.append({
                "type": "stock_symbol",
                "value": sym,
                "confidence": 0.9
            })
        
        # Company names (simplified)
        company_keywords = ["Apple", "Microsoft", "Google", "Amazon", "Tesla", "Meta", "Netflix"]
        for keyword in company_keywords:
            if keyword.lower() in text.lower():
                entities.append({
                    "type": "company_name",
                    "value": keyword,
                    "confidence": 0.8
                })
        
        # Time periods
        time_patterns = {
            r'\btoday\b': "1d",
            r'\bthis week\b': "1w",
            r'\bthis month\b': "1m",
            r'\bthis year\b': "1y",
            r'\bshort.?term\b': "short_term",
            r'\blong.?term\b': "long_term"
        }
        
        for pattern, value in time_patterns.items():
            if re.search(pattern, text, re.IGNORECASE):
                entities.append({
                    "type": "time_period",
                    "value": value,
                    "confidence": 0.75
                })
        
        # Investment goals
        goal_keywords = {
            "growth": "growth",
            "income": "income",
            "dividend": "dividend",
            "retirement": "retirement",
            "speculation": "speculation"
        }
        
        for keyword, goal in goal_keywords.items():
            if keyword in text.lower():
                entities.append({
                    "type": "investment_goal",
                    "value": goal,
                    "confidence": 0.7
                })
        
        return entities


class IntentClassifier:
    """Classifies user intent from input."""
    
    INTENT_PATTERNS = {
        "fundamental_analysis": [
            "financial", "earnings", "revenue", "profit", "balance sheet", "income statement",
            "pe ratio", "debt", "fundamentals", "valuation", "company analysis"
        ],
        "technical_analysis": [
            "chart", "technical", "price", "trend", "support", "resistance", "moving average",
            "rsi", "macd", "volume", "pattern", "breakout"
        ],
        "sentiment_analysis": [
            "sentiment", "news", "social", "opinion", "buzz", "mentions", "mood",
            "market sentiment", "investor sentiment"
        ],
        "risk_assessment": [
            "risk", "volatility", "diversification", "portfolio", "allocation", "hedge",
            "downside", "risk management", "var", "beta"
        ],
        "timing": [
            "when", "timing", "entry", "exit", "buy", "sell", "optimal time",
            "market timing", "entry point", "exit point"
        ],
        "strategy": [
            "strategy", "plan", "approach", "method", "trading strategy", "investment strategy",
            "portfolio strategy", "execution"
        ],
        "general_advice": [
            "advice", "recommendation", "suggest", "opinion", "what do you think",
            "should i", "help me", "guidance"
        ],
        "greeting": [
            "hi", "hello", "hey", "good morning", "good afternoon", "good evening",
            "how are you", "who are you", "what are you", "what can you do",
            "how can you help", "can you help", "introduce yourself",
            "tell me about yourself", "what do you do",
        ]
        }
    
    @staticmethod
    def classify_intent(text: str) -> Tuple[str, float]:
        """Classify the intent of user input."""
        text_lower = text.lower()
        intent_scores = {}
        
        for intent, keywords in IntentClassifier.INTENT_PATTERNS.items():
            score = 0
            for keyword in keywords:
                if keyword in text_lower:
                    score += 1
            
            if score > 0:
                intent_scores[intent] = score / len(keywords)
        
        if not intent_scores:
            return "general_advice", 0.5
        
        best_intent = max(intent_scores.items(), key=lambda x: x[1])
        return best_intent[0], min(best_intent[1] * 2, 1.0)  # Scale confidence


class MainAdvisoryAgent:
    """The main AI Trading Advisory Agent."""
    
    def __init__(self):
        self.entity_extractor = EntityExtractor()
        self.intent_classifier = IntentClassifier()
        self.market_router = GlobalMarketRouter()
        self.portfolio_guard = PortfolioActionGuard()
        self._advisory_disclaimer = "Note: This information is for educational purposes only and is not investment advice."
        # Configurable verbosity and behavior flags
        self._verbose = (os.environ.get("ADVISORY_VERBOSE", "0") == "1")
        self._append_disclaimer = (os.environ.get("ADVISORY_APPEND_DISCLAIMER", "1") == "1")
        # Pricing hints for cost estimation (tokens * price_per_1k / 1000)
        self._price_prompt_per_1k = float(os.environ.get("LLM_PRICE_PROMPT_PER_1K", "0.0"))
        self._price_completion_per_1k = float(os.environ.get("LLM_PRICE_COMPLETION_PER_1K", "0.0"))
        self._enforce_market_hours = os.environ.get("ADVISORY_ENFORCE_MARKET_HOURS", "1") == "1"
        self._idempotency_window_minutes = int(os.environ.get("ADVISORY_IDEMPOTENCY_WINDOW_MINUTES", "30"))
        self._approval_timeout_minutes = int(os.environ.get("ADVISORY_APPROVAL_TIMEOUT_MINUTES", "30"))

        # Initialize tools first
        self.tools = [
            AgentRegistryTool(),
            ConversationTool(),
            SpecializedAgentTool(),
            ParallelSpecializedAgentTool(),
            MarketDataTool(),
            PTAClientTool(),
        ]

        # Initialize CrewAI components
        self.agent = self._create_agent()
        # Prepare local embedder config once
        self._embedder_config = _build_local_embedder_config()
        # IBKR portfolio service — sole source of portfolio data (no PTA fallback)
        self._ibkr_service: Optional[Any] = None
        if get_ibkr_service is not None:
            try:
                self._ibkr_service = get_ibkr_service()
                if self._ibkr_service.is_connected():
                    logger.info("MainAdvisoryAgent: IBKRPortfolioService connected")
                else:
                    logger.info(
                        "MainAdvisoryAgent: IBKRPortfolioService not yet connected "
                        "(set IB_ENABLED=1 and start TWS/Gateway to enable live portfolio)"
                    )
            except Exception as _ib_exc:
                logger.warning("MainAdvisoryAgent: IBKRPortfolioService init failed: %s", _ib_exc)
                self._ibkr_service = None
        
    def _create_agent(self) -> Agent:
        """Create the main advisory agent."""
        return Agent(
            role="AI Trading Advisory Agent",
            goal="Provide expert-level stock market analysis and investment recommendations by orchestrating specialized agents and maintaining contextual conversations with users",
            backstory="""You are a sophisticated AI Trading Advisory Agent with deep expertise in financial markets. 
            You serve as the primary interface between users and a suite of specialized financial analysis agents. 
            Your role is to understand user queries, intelligently delegate tasks to appropriate specialized agents, 
            synthesize their insights, and provide comprehensive, actionable investment advice. 
            
            You excel at maintaining conversational context, asking clarifying questions when needed, and 
            delivering recommendations that are tailored to each user's specific situation and goals. 
            You are known for your ability to break down complex financial concepts into understandable insights 
            while maintaining the depth and accuracy expected from a professional financial advisor.""",
            verbose=self._verbose,
            allow_delegation=True,
            max_iter=25,
            memory=False,  # Agent-level memory disabled; Crew-level Memory handles it
            tools=self.tools,
            llm=azure_llm  # Use Azure OpenAI LLM
        )
    
    def process_user_input(self, user_input: str, conversation_id: Optional[str] = None, request_id: Optional[str] = None) -> Dict[str, Any]:
        """Process user input via AdvisoryFlow and return a response dict.

        This method is now a thin adapter: it builds the AdvisoryFlow with all
        necessary dependencies, kicks it off, and maps the typed Flow state back
        to the standard response contract expected by advisory.py.
        """
        from advisory_flow import AdvisoryFlow  # same package; no circular import

        try:
            request_id = request_id or str(uuid.uuid4())

            # Get or create conversation context (also used for idempotency check)
            if conversation_id:
                context = conversation_manager.get_conversation(conversation_id)
                if not context:
                    context = conversation_manager.create_conversation(conversation_id)
            else:
                context = conversation_manager.create_conversation()
            conversation_id = context.conversation_id

            # Idempotency pre-check: return cached response if same input was already answered
            cached = self._check_idempotency(context, user_input)
            if cached:
                return {
                    "conversation_id": conversation_id,
                    "request_id": request_id,
                    "cached": True,
                    **cached,
                }

            # Settings
            default_market = (
                getattr(getattr(_SETTINGS, "system", None), "default_market", "IN")
                if _SETTINGS else "IN"
            )
            max_position_size = float(
                getattr(getattr(_SETTINGS, "trading", None), "max_position_size", 0.20) or 0.20
            )
            max_order_risk_fraction = float(
                getattr(getattr(_SETTINGS, "trading", None), "max_portfolio_risk", 0.05) or 0.05
            )

            flow = AdvisoryFlow(
                llm=azure_llm,
                tools=self.tools,
                embedder_config=self._embedder_config,
                entity_extractor=self.entity_extractor,
                intent_classifier=self.intent_classifier,
                default_market=default_market,
                advisory_disclaimer=self._advisory_disclaimer,
                verbose=self._verbose,
                append_disclaimer=self._append_disclaimer,
                enforce_market_hours=self._enforce_market_hours,
                approval_timeout_minutes=self._approval_timeout_minutes,
                idempotency_window_minutes=self._idempotency_window_minutes,
                max_position_size=max_position_size,
                max_order_risk_fraction=max_order_risk_fraction,
                portfolio_holdings_fn=self._portfolio_holdings,
                portfolio_metrics_fn=self._portfolio_metrics,
                portfolio_preview_fn=self._portfolio_preview,
                portfolio_submit_fn=self._portfolio_submit,
                portfolio_available_fn=(
                    lambda: (
                        self._ibkr_service is not None
                        and self._ibkr_service.is_connected()
                    )
                ),
            )

            flow.kickoff(inputs={
                "user_input": user_input,
                "conversation_id": conversation_id,
                "request_id": request_id,
            })

            fs = flow.state
            refreshed_context = conversation_manager.get_conversation(conversation_id)
            context_summary = (
                refreshed_context.get_conversation_summary()
                if refreshed_context else {}
            )

            return {
                "conversation_id": conversation_id,
                "response": fs.final_response,
                "intent": fs.intent,
                "confidence": fs.confidence,
                "entities": fs.entities,
                "context_summary": context_summary,
                "request_id": request_id,
                "execution_path": fs.execution_path,
                "step_trace": fs.step_trace,
                "active_markets": fs.active_markets,
                "duration_ms": fs.duration_ms,
            }

        except Exception as exc:
            logger.error(
                "process_user_input error | conv=%s | req=%s | %s\n%s",
                conversation_id, request_id, exc, traceback.format_exc(),
            )
            return {
                "error": f"Error processing user input: {exc}",
                "conversation_id": conversation_id,
                "request_id": request_id,
            }

    def _check_idempotency(
        self, context: Any, user_input: str
    ) -> Optional[Dict[str, Any]]:
        """Return previous response payload if identical input was already answered."""
        for idx in range(len(context.messages) - 1, -1, -1):
            msg = context.messages[idx]
            if (
                msg.message_type == MessageType.USER_INPUT
                and msg.content.strip() == user_input.strip()
            ):
                for resp in context.messages[idx + 1:]:
                    if resp.message_type == MessageType.AGENT_RESPONSE:
                        logger.info(
                            "Idempotency cache hit | conv=%s", context.conversation_id
                        )
                        return {
                            "response": resp.content,
                            "intent": context.inferred_intent or "",
                            "confidence": 0.0,
                            "entities": [
                                {
                                    "type": e.entity_type,
                                    "value": e.value,
                                    "confidence": e.confidence,
                                }
                                for e in context.extracted_entities
                            ],
                            "context_summary": context.get_conversation_summary(),
                        }
        return None

    # ── LEGACY process_user_input body (no longer called; kept for reference) ──
    def _process_user_input_legacy(self, user_input: str, conversation_id: Optional[str] = None, request_id: Optional[str] = None) -> Dict[str, Any]:
        """Previous monolithic implementation — superseded by AdvisoryFlow. DO NOT CALL."""
        try:
            # Correlate request id
            request_id = request_id or str(uuid.uuid4())
            # Get or create conversation context
            if conversation_id:
                context = conversation_manager.get_conversation(conversation_id)
                if not context:
                    context = conversation_manager.create_conversation(conversation_id)
            else:
                context = conversation_manager.create_conversation()
            context.set_context_data("request_id", request_id)

            # (legacy idempotency check inline)
            last_same_input_idx = None
            for idx in range(len(context.messages) - 1, -1, -1):
                msg = context.messages[idx]
                if msg.message_type == MessageType.USER_INPUT and msg.content.strip() == user_input.strip():
                    last_same_input_idx = idx
                    break
            if last_same_input_idx is not None:
                # Find an agent response after that message
                for resp in context.messages[last_same_input_idx + 1:]:
                    if resp.message_type == MessageType.AGENT_RESPONSE:
                        logger.info("Idempotency: returning cached response for repeated user input in conversation %s", context.conversation_id)
                        return {
                            "conversation_id": context.conversation_id,
                            "response": resp.content,
                            "intent": (context.inferred_intent or ""),
                            "confidence": 0.0,
                            "entities": [
                                {"type": e.entity_type, "value": e.value, "confidence": e.confidence}
                                for e in context.extracted_entities
                            ],
                            "context_summary": context.get_conversation_summary(),
                            "cached": True,
                        }

            # Add user message to context
            message_id = context.add_message(MessageType.USER_INPUT, user_input)
            
            # Extract entities from user input
            entities = self.entity_extractor.extract_entities(user_input)
            for entity in entities:
                context.add_extracted_entity(
                    entity["type"], 
                    entity["value"], 
                    entity["confidence"], 
                    message_id
                )
            
            # Classify intent
            intent, confidence = self.intent_classifier.classify_intent(user_input)
            context.set_inferred_intent(f"{intent} (confidence: {confidence:.2f})")
            context.set_current_query(user_input)

            default_market = getattr(getattr(_SETTINGS, "system", None), "default_market", "IN") if _SETTINGS else "IN"
            active_markets = self.market_router.detect_markets(user_input, entities, default_market=default_market)
            preferred_agents = self.market_router.preferred_agents_for_intent(intent)
            invocation_mode = self.market_router.invocation_mode(intent, user_input, confidence)
            bypass_fastpath, bypass_reason = self.market_router.should_bypass_fastpath(intent, user_input)
            if bypass_fastpath:
                invocation_mode = "orchestrated"

            context.set_context_data("active_markets", active_markets)
            context.set_context_data("active_market", active_markets[0] if active_markets else default_market)
            context.set_context_data("preferred_agents", preferred_agents)
            context.set_context_data("invocation_mode", invocation_mode)
            context.set_context_data("fastpath_bypass_reason", bypass_reason)

            # Phase 2: explicit approval gate for portfolio actions before trade execution.
            expired_payload = self._expire_pending_approval_if_needed(
                context=context,
                request_id=request_id,
                entities=entities,
                user_input=user_input,
            )
            if expired_payload:
                return expired_payload

            decision_action, decision_approval_id = self.portfolio_guard.extract_decision(user_input)
            pending_action = context.get_context_data("pending_portfolio_action")

            if pending_action and decision_action in ("approve", "reject"):
                gated = self._handle_portfolio_approval_decision(
                    context=context,
                    request_id=request_id,
                    decision_action=decision_action,
                    decision_approval_id=decision_approval_id,
                    pending_action=pending_action,
                    entities=entities,
                )
                if gated:
                    return gated

            parsed_order = self.portfolio_guard.parse_order_request(
                text=user_input,
                entities=entities,
                default_market=active_markets[0] if active_markets else default_market,
            )
            if parsed_order:
                context.set_context_data("invocation_mode", "orchestrated")
                context.set_context_data("fastpath_bypass_reason", "portfolio_action_gate")
                gated = self._start_portfolio_action_approval(
                    context=context,
                    request_id=request_id,
                    parsed_order=parsed_order,
                    entities=entities,
                    active_markets=active_markets,
                )
                if gated:
                    return gated
            
            # Update conversation state
            if context.state == ConversationState.INITIAL_QUERY:
                context.update_state(ConversationState.CONTEXT_GATHERING)

            # Proactive routing: fetch market overview/top movers for relevant intents/keywords
            try:
                needs_market_snapshot = False
                text_lower = user_input.lower()
                if intent in ("risk_assessment",) or any(k in text_lower for k in ["today", "market view", "top stock", "top performer", "gainer", "loser"]):
                    needs_market_snapshot = True
                if needs_market_snapshot:
                    md_tool = None
                    for t in self.tools:
                        if isinstance(t, MarketDataTool):
                            md_tool = t
                            break
                    if md_tool is None:
                        md_tool = MarketDataTool()
                    market_overviews: Dict[str, Any] = {}
                    market_movers: Dict[str, Any] = {}
                    for market in active_markets[:2]:
                        overview_raw = md_tool._run("market_overview", market=market)
                        movers_raw = md_tool._run("top_movers", market=market, top=10)
                        market_overviews[market] = json.loads(overview_raw)
                        market_movers[market] = json.loads(movers_raw)
                    context.set_context_data("market_overview", market_overviews)
                    context.set_context_data("top_movers", market_movers)
                    logger.info(
                        "Routing: prefetch market data | intent=%s | markets=%s | conv=%s | req=%s",
                        intent,
                        active_markets,
                        context.conversation_id,
                        request_id,
                    )
            except Exception as md_err:
                logger.warning("Market data prefetch failed: %s | conv=%s | req=%s", md_err, context.conversation_id, request_id)

            # Log routing decision summary
            try:
                logger.info(
                    "Routing: intent=%s | mode=%s | markets=%s | preferred_agents=%s | entities=%d | conv=%s | req=%s",
                    intent,
                    invocation_mode,
                    active_markets,
                    preferred_agents,
                    len(context.extracted_entities),
                    context.conversation_id,
                    request_id,
                )
            except Exception:
                pass

            # Selective fast path for single-intent queries: call only one specialized agent.
            if invocation_mode == "single_agent" and preferred_agents:
                fastpath = self._try_single_agent_fastpath(
                    user_input=user_input,
                    intent=intent,
                    context=context,
                    entities=entities,
                    active_markets=active_markets,
                    preferred_agents=preferred_agents,
                    request_id=request_id,
                )
                if fastpath:
                    return fastpath
            
            # Create and execute task
            task = self._create_response_task(user_input, context)
            crew = Crew(
                agents=[self.agent],
                tasks=[task],
                process=Process.sequential,
                verbose=self._verbose,
                memory=True,
                # Key addition: use local HuggingFace embeddings for memory
                embedder=self._embedder_config,
            )
            
            # Disable problematic long-term memory saving to avoid LTM save errors
            try:
                setattr(crew, "_long_term_memory", None)
            except Exception:
                pass
            
            start_ts = datetime.now()
            result = crew.kickoff()
            duration_ms = (datetime.now() - start_ts).total_seconds() * 1000.0
            # Rough prompt/response size metrics
            try:
                prompt_chars = len(task.description)
            except Exception:
                prompt_chars = -1
            response_text_tmp = str(result)
            # Token estimation (best-effort)
            prompt_tokens = completion_tokens = total_tokens = None
            est_cost = None
            if tiktoken is not None:
                try:
                    enc = tiktoken.get_encoding("cl100k_base")
                    prompt_tokens = len(enc.encode(task.description))
                    completion_tokens = len(enc.encode(response_text_tmp))
                    total_tokens = prompt_tokens + completion_tokens
                    # Cost estimate if pricing hints provided
                    if self._price_prompt_per_1k > 0 or self._price_completion_per_1k > 0:
                        est_cost = (
                            (prompt_tokens / 1000.0) * self._price_prompt_per_1k +
                            (completion_tokens / 1000.0) * self._price_completion_per_1k
                        )
                except Exception:
                    pass
            logger.info(
                "Crew response | conv=%s | req=%s | dur_ms=%.1f | prompt_chars=%s | response_chars=%d | prompt_tokens=%s | completion_tokens=%s | total_tokens=%s | est_cost=%s",
                context.conversation_id,
                request_id,
                duration_ms,
                prompt_chars,
                len(response_text_tmp),
                prompt_tokens,
                completion_tokens,
                total_tokens,
                (f"{est_cost:.6f}" if isinstance(est_cost, float) else None),
            )
            
            # Add agent response to context (append a brief non-advisory disclaimer)
            response_text = str(result).rstrip()
            if self._append_disclaimer:
                disclaimer = "\n\nNote: This information is for educational purposes only and is not investment advice."
                if disclaimer not in response_text:
                    response_text = response_text + disclaimer
            context.add_message(MessageType.AGENT_RESPONSE, response_text)
            context.update_state(ConversationState.RECOMMENDATION_GENERATION)
            
            return {
                "conversation_id": context.conversation_id,
                "response": response_text,
                "intent": intent,
                "confidence": confidence,
                "entities": entities,
                "context_summary": context.get_conversation_summary(),
                "request_id": request_id,
            }
            
        except Exception as e:
            logger.error("Error processing user input | conv=%s | req=%s | err=%s\n%s", conversation_id, request_id, e, traceback.format_exc())
            return {
                "error": f"Error processing user input: {str(e)}",
                "conversation_id": conversation_id,
                "request_id": request_id,
            }

    def _get_pta_tool(self) -> Optional[PTAClientTool]:
        """Get PTA client tool from registered tools."""
        for t in self.tools:
            if isinstance(t, PTAClientTool):
                return t
        return None

    def _record_approval_state(
        self,
        context: ConversationContext,
        pending_action: Dict[str, Any],
        state: str,
        reason: Optional[str] = None,
    ) -> None:
        """Record approval state transitions for traceability."""
        state_obj = {
            "approval_id": pending_action.get("approval_id"),
            "idempotency_key": pending_action.get("idempotency_key"),
            "state": state,
            "reason": reason,
            "updated_at": datetime.utcnow().isoformat(),
            "created_at": pending_action.get("created_at"),
            "expires_at": pending_action.get("expires_at"),
            "order": pending_action.get("order"),
        }
        history = context.get_context_data("approval_state_history", []) or []
        history.append(state_obj)
        context.set_context_data("approval_state_history", history)
        context.set_context_data("last_approval_state", state_obj)

    def _expire_pending_approval_if_needed(
        self,
        context: ConversationContext,
        request_id: str,
        entities: List[Dict[str, Any]],
        user_input: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Expire stale pending approvals and optionally return user-facing payload."""
        pending_action = context.get_context_data("pending_portfolio_action")
        if not pending_action:
            return None

        expires_at_raw = pending_action.get("expires_at")
        if not expires_at_raw:
            return None

        try:
            expires_at = datetime.fromisoformat(str(expires_at_raw))
        except Exception:
            return None

        if datetime.utcnow() <= expires_at:
            return None

        approval_id = str(pending_action.get("approval_id", ""))
        self._record_approval_state(context, pending_action, state="expired", reason="approval_timeout")
        context.set_context_data("pending_portfolio_action", None)

        if user_input and any(k in user_input.lower() for k in ("approve", "reject", "cancel", "confirm", "deny")):
            response_text = (
                f"Approval request {approval_id} has expired and was not executed. "
                f"Please submit a new trade request if you still want to proceed."
            )
            if self._append_disclaimer and self._advisory_disclaimer not in response_text:
                response_text = f"{response_text}\n\n{self._advisory_disclaimer}"
            context.add_message(MessageType.AGENT_RESPONSE, response_text)
            context.update_state(ConversationState.RECOMMENDATION_GENERATION)
            return {
                "conversation_id": context.conversation_id,
                "response": response_text,
                "intent": "portfolio_action",
                "confidence": 1.0,
                "entities": entities,
                "context_summary": context.get_conversation_summary(),
                "request_id": request_id,
                "approval_required": False,
                "approval_state": "expired",
                "approval_id": approval_id,
                "order_submitted": False,
            }

        return None

    def _portfolio_holdings(self) -> Dict[str, Any]:
        if self._ibkr_service is not None:
            try:
                return self._ibkr_service.get_holdings()
            except Exception as exc:
                logger.warning("MainAdvisoryAgent: IBKR get_holdings failed: %s", exc)
        return {
            "error": "IBKR portfolio unavailable — set IB_ENABLED=1 and start TWS/Gateway",
            "broker": "ib",
            "cash": 0.0,
            "holdings": [],
        }

    def _portfolio_metrics(self) -> Dict[str, Any]:
        if self._ibkr_service is not None:
            try:
                return self._ibkr_service.get_metrics()
            except Exception as exc:
                logger.warning("MainAdvisoryAgent: IBKR get_metrics failed: %s", exc)
        return {
            "error": "IBKR portfolio unavailable",
            "broker": "ib",
            "cash": 0.0,
            "total_value_est": 0.0,
        }

    def _portfolio_preview(self, symbol: str, side: str, quantity: int) -> Dict[str, Any]:
        if self._ibkr_service is not None:
            try:
                return self._ibkr_service.preview_order(symbol, side, quantity)
            except Exception as exc:
                logger.warning("MainAdvisoryAgent: IBKR preview_order failed: %s", exc)
        return {"error": "IBKR portfolio unavailable", "broker": "ib"}

    def _portfolio_submit(self, symbol: str, side: str, quantity: int, idempotency_key: str) -> Dict[str, Any]:
        if self._ibkr_service is not None:
            try:
                return self._ibkr_service.place_order(
                    symbol, side, quantity, idempotency_key=idempotency_key
                )
            except Exception as exc:
                logger.warning("MainAdvisoryAgent: IBKR place_order failed: %s", exc)
        return {
            "error": "IBKR portfolio unavailable — set IB_ENABLED=1 and IB_ALLOW_TRADES=1",
            "broker": "ib",
        }

    def _generate_order_idempotency_key(self, context: ConversationContext, order: Dict[str, Any]) -> str:
        seed = (
            f"{context.conversation_id}|{str(order.get('symbol', '')).upper()}|"
            f"{str(order.get('side', '')).lower()}|{int(order.get('quantity', 0))}"
        )
        return hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]

    def _is_market_open(self, market: str) -> Tuple[bool, str]:
        m = (market or "IN").upper()
        if m == "CRYPTO":
            return True, "24x7"

        windows = {
            "IN": ("Asia/Kolkata", dt_time(9, 15), dt_time(15, 30)),
            "US": ("America/New_York", dt_time(9, 30), dt_time(16, 0)),
            "EU": ("Europe/London", dt_time(8, 0), dt_time(16, 30)),
            "APAC": ("Asia/Tokyo", dt_time(9, 0), dt_time(15, 0)),
        }
        zone_name, open_t, close_t = windows.get(m, windows["IN"])

        if ZoneInfo is None:
            return True, "zoneinfo unavailable"

        now = datetime.now(ZoneInfo(zone_name))
        if now.weekday() >= 5:
            return False, f"{m} market closed (weekend)"
        now_t = now.time().replace(tzinfo=None)
        if open_t <= now_t <= close_t:
            return True, f"{m} market open"
        return False, f"{m} market closed (hours {open_t.strftime('%H:%M')}-{close_t.strftime('%H:%M')} {zone_name})"

    def _validate_pre_trade_order(
        self,
        context: ConversationContext,
        parsed_order: Dict[str, Any],
        preview_obj: Dict[str, Any],
        idempotency_key: str,
    ) -> Dict[str, Any]:
        """Run hard pre-trade validator gates before approval creation."""
        reasons: List[str] = []
        side = str(parsed_order.get("side", "")).lower()
        symbol = str(parsed_order.get("symbol", "")).upper()
        quantity = int(parsed_order.get("quantity", 0) or 0)
        market = str(parsed_order.get("market", "IN")).upper()

        # Idempotency gate
        pending_action = context.get_context_data("pending_portfolio_action") or {}
        if pending_action and pending_action.get("idempotency_key") == idempotency_key:
            reasons.append("Duplicate order request is already pending approval")

        recent_keys = context.get_context_data("trade_idempotency_history", []) or []
        now_ts = datetime.utcnow().timestamp()
        filtered_history = []
        for item in recent_keys:
            ts = float(item.get("ts", 0.0) or 0.0)
            if now_ts - ts <= float(self._idempotency_window_minutes * 60):
                filtered_history.append(item)
        context.set_context_data("trade_idempotency_history", filtered_history)
        if any(item.get("key") == idempotency_key for item in filtered_history):
            reasons.append("Duplicate order blocked by idempotency window")

        # Market hours gate
        if self._enforce_market_hours:
            is_open, market_reason = self._is_market_open(market)
            if not is_open:
                reasons.append(market_reason)

        # Basic shape gate
        if quantity <= 0:
            reasons.append("Quantity must be greater than 0")
        if side not in ("buy", "sell"):
            reasons.append("Order side must be buy or sell")

        holdings = self._portfolio_holdings()
        if isinstance(holdings, dict) and holdings.get("error"):
            reasons.append(f"Unable to verify holdings: {holdings.get('error')}")

        metrics = self._portfolio_metrics()
        if isinstance(metrics, dict) and metrics.get("error"):
            reasons.append(f"Unable to verify portfolio metrics: {metrics.get('error')}")

        estimated_total = float(preview_obj.get("estimated_total", 0.0) or 0.0)
        last_price = float(preview_obj.get("last_price", 0.0) or 0.0)
        notional = last_price * quantity if last_price > 0 else estimated_total

        cash = float((holdings or {}).get("cash", 0.0) or 0.0)
        holdings_list = (holdings or {}).get("holdings", []) if isinstance(holdings, dict) else []
        existing_position = next((h for h in holdings_list if str(h.get("symbol", "")).upper() == symbol), None)
        existing_qty = int((existing_position or {}).get("quantity", 0) or 0)
        existing_avg = float((existing_position or {}).get("avg_price", 0.0) or 0.0)
        existing_value = existing_qty * existing_avg

        if side == "buy" and estimated_total > cash:
            reasons.append(f"Insufficient cash: required {estimated_total:.2f}, available {cash:.2f}")
        if side == "sell" and quantity > existing_qty:
            reasons.append(f"Insufficient position: required {quantity}, available {existing_qty}")

        total_value = float((metrics or {}).get("total_value_est", 0.0) or 0.0)
        if total_value <= 0:
            total_value = max(cash, 0.0)

        max_position_size = float(getattr(getattr(_SETTINGS, "trading", None), "max_position_size", 0.20) or 0.20)
        max_order_risk_fraction = float(
            os.environ.get(
                "ADVISORY_MAX_ORDER_RISK_FRACTION",
                str(getattr(getattr(_SETTINGS, "trading", None), "max_portfolio_risk", 0.05) or 0.05),
            )
        )

        if side == "buy" and total_value > 0:
            projected_position_value = existing_value + notional
            if projected_position_value > total_value * max_position_size:
                reasons.append(
                    f"Position size risk limit exceeded: projected {projected_position_value:.2f} > "
                    f"limit {(total_value * max_position_size):.2f}"
                )

        if total_value > 0 and notional > total_value * max_order_risk_fraction:
            reasons.append(
                f"Order risk limit exceeded: order notional {notional:.2f} > "
                f"limit {(total_value * max_order_risk_fraction):.2f}"
            )

        return {
            "allowed": len(reasons) == 0,
            "reasons": reasons,
            "idempotency_key": idempotency_key,
            "risk_summary": {
                "notional": notional,
                "total_value": total_value,
                "max_position_size": max_position_size,
                "max_order_risk_fraction": max_order_risk_fraction,
            },
        }

    def _start_portfolio_action_approval(
        self,
        context: ConversationContext,
        request_id: str,
        parsed_order: Dict[str, Any],
        entities: List[Dict[str, Any]],
        active_markets: List[str],
    ) -> Optional[Dict[str, Any]]:
        """Create pending approval for a parsed trade request and return preview."""
        try:
            approval_id = str(uuid.uuid4())
            idempotency_key = self._generate_order_idempotency_key(context, parsed_order)

            preview_obj: Dict[str, Any] = self._portfolio_preview(
                symbol=parsed_order["symbol"],
                side=parsed_order["side"],
                quantity=parsed_order["quantity"],
            )
            if isinstance(preview_obj, dict) and preview_obj.get("error"):
                validation = {
                    "allowed": False,
                    "reasons": [f"Unable to preview order: {preview_obj.get('error')}"]
                }
            else:
                validation = self._validate_pre_trade_order(
                    context=context,
                    parsed_order=parsed_order,
                    preview_obj=preview_obj,
                    idempotency_key=idempotency_key,
                )

            if not validation.get("allowed"):
                reasons = validation.get("reasons", [])
                reasons_text = "\n".join([f"- {r}" for r in reasons]) if reasons else "- Validation failed"
                response_text = (
                    "Trade request blocked by hard pre-trade validation gates.\n\n"
                    f"Proposed order: {parsed_order['side'].upper()} {parsed_order['quantity']} {parsed_order['symbol']} "
                    f"(market: {parsed_order.get('market', 'IN')}).\n"
                    f"Reasons:\n{reasons_text}"
                )
                if self._append_disclaimer and self._advisory_disclaimer not in response_text:
                    response_text = f"{response_text}\n\n{self._advisory_disclaimer}"
                context.add_message(MessageType.AGENT_RESPONSE, response_text)
                context.update_state(ConversationState.RECOMMENDATION_GENERATION)
                return {
                    "conversation_id": context.conversation_id,
                    "response": response_text,
                    "intent": "portfolio_action",
                    "confidence": 1.0,
                    "entities": entities,
                    "context_summary": context.get_conversation_summary(),
                    "request_id": request_id,
                    "approval_required": False,
                    "order_blocked": True,
                    "validation": validation,
                }

            pending = {
                "approval_id": approval_id,
                "idempotency_key": idempotency_key,
                "order": parsed_order,
                "preview": preview_obj,
                "validation": validation,
                "created_at": datetime.utcnow().isoformat(),
                "expires_at": (datetime.utcnow() + timedelta(minutes=self._approval_timeout_minutes)).isoformat(),
                "state": "pending_approval",
                "request_id": request_id,
            }
            context.set_context_data("pending_portfolio_action", pending)
            self._record_approval_state(context, pending, state="pending_approval", reason="created")

            estimated_total = preview_obj.get("estimated_total") if isinstance(preview_obj, dict) else None
            fee = None
            if isinstance(preview_obj, dict):
                fee = preview_obj.get("fee")
                if fee is None:
                    fee = preview_obj.get("estimated_fees")
            preview_line = ""
            if estimated_total is not None:
                preview_line = f"Preview estimated total: {estimated_total}."
                if fee is not None:
                    preview_line = f"{preview_line} Estimated fee: {fee}."

            response_text = (
                "Approval required before order submission.\n\n"
                f"Proposed order: {parsed_order['side'].upper()} {parsed_order['quantity']} {parsed_order['symbol']} "
                f"(market: {parsed_order.get('market', 'IN')}).\n"
                f"{preview_line}\n"
                f"Order idempotency key: {idempotency_key}\n"
                f"Approval timeout: {self._approval_timeout_minutes} minutes\n"
                f"To approve: APPROVE {approval_id}\n"
                f"To reject: REJECT {approval_id}"
            ).strip()

            if self._append_disclaimer and self._advisory_disclaimer not in response_text:
                response_text = f"{response_text}\n\n{self._advisory_disclaimer}"

            context.add_message(MessageType.AGENT_RESPONSE, response_text)
            context.update_state(ConversationState.CLARIFICATION_REFINEMENT)

            return {
                "conversation_id": context.conversation_id,
                "response": response_text,
                "intent": "portfolio_action",
                "confidence": 0.95,
                "entities": entities,
                "context_summary": context.get_conversation_summary(),
                "request_id": request_id,
                "approval_required": True,
                "approval_id": approval_id,
                "approval_state": "pending_approval",
                "active_markets": active_markets,
                "order_preview": preview_obj,
                "validation": validation,
            }
        except Exception:
            return None

    def _handle_portfolio_approval_decision(
        self,
        context: ConversationContext,
        request_id: str,
        decision_action: str,
        decision_approval_id: Optional[str],
        pending_action: Dict[str, Any],
        entities: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """Handle approve/reject decision for a pending portfolio action."""
        try:
            pending_id = str(pending_action.get("approval_id", ""))
            if not pending_id or not decision_approval_id:
                return None

            if decision_approval_id != pending_id:
                response_text = (
                    f"Approval ID mismatch. Pending approval is {pending_id}. "
                    f"Reply with APPROVE {pending_id} or REJECT {pending_id}."
                )
                context.add_message(MessageType.AGENT_RESPONSE, response_text)
                return {
                    "conversation_id": context.conversation_id,
                    "response": response_text,
                    "intent": "portfolio_action",
                    "confidence": 1.0,
                    "entities": entities,
                    "context_summary": context.get_conversation_summary(),
                    "request_id": request_id,
                    "approval_required": True,
                    "approval_id": pending_id,
                }

            if decision_action == "reject":
                self._record_approval_state(context, pending_action, state="rejected", reason="user_rejected")
                context.set_context_data("pending_portfolio_action", None)
                response_text = f"Order request {pending_id} rejected. No trade was submitted."
                if self._append_disclaimer and self._advisory_disclaimer not in response_text:
                    response_text = f"{response_text}\n\n{self._advisory_disclaimer}"
                context.add_message(MessageType.AGENT_RESPONSE, response_text)
                context.update_state(ConversationState.RECOMMENDATION_GENERATION)
                return {
                    "conversation_id": context.conversation_id,
                    "response": response_text,
                    "intent": "portfolio_action",
                    "confidence": 1.0,
                    "entities": entities,
                    "context_summary": context.get_conversation_summary(),
                    "request_id": request_id,
                    "approval_required": False,
                    "approval_id": pending_id,
                    "approval_state": "rejected",
                    "order_submitted": False,
                }

            order = pending_action.get("order") or {}
            idem_key = str(pending_action.get("idempotency_key", pending_id))
            submit_obj = self._portfolio_submit(
                symbol=str(order.get("symbol", "")),
                side=str(order.get("side", "")),
                quantity=int(order.get("quantity", 0) or 0),
                idempotency_key=idem_key,
            )

            if isinstance(submit_obj, dict) and submit_obj.get("error"):
                response_text = (
                    f"Approval {pending_id} accepted, but order submission failed: {submit_obj.get('error')}"
                )
                context.add_message(MessageType.AGENT_RESPONSE, response_text)
                return {
                    "conversation_id": context.conversation_id,
                    "response": response_text,
                    "intent": "portfolio_action",
                    "confidence": 0.6,
                    "entities": entities,
                    "context_summary": context.get_conversation_summary(),
                    "request_id": request_id,
                    "approval_required": True,
                    "approval_id": pending_id,
                    "approval_state": "pending_approval",
                    "order_submitted": False,
                }

            self._record_approval_state(context, pending_action, state="approved_executed", reason="submitted")
            context.set_context_data("pending_portfolio_action", None)
            recent_history = context.get_context_data("trade_idempotency_history", []) or []
            recent_history.append({"key": idem_key, "ts": datetime.utcnow().timestamp(), "status": "submitted"})
            context.set_context_data("trade_idempotency_history", recent_history)
            response_text = f"Approval {pending_id} accepted. Order submitted successfully: {json.dumps(submit_obj)}"
            if self._append_disclaimer and self._advisory_disclaimer not in response_text:
                response_text = f"{response_text}\n\n{self._advisory_disclaimer}"
            context.add_message(MessageType.AGENT_RESPONSE, response_text)
            context.update_state(ConversationState.RECOMMENDATION_GENERATION)

            return {
                "conversation_id": context.conversation_id,
                "response": response_text,
                "intent": "portfolio_action",
                "confidence": 1.0,
                "entities": entities,
                "context_summary": context.get_conversation_summary(),
                "request_id": request_id,
                "approval_required": False,
                "approval_id": pending_id,
                "approval_state": "approved_executed",
                "order_submitted": True,
                "order_result": submit_obj,
            }
        except Exception:
            return None

    def _try_single_agent_fastpath(
        self,
        user_input: str,
        intent: str,
        context: ConversationContext,
        entities: List[Dict[str, Any]],
        active_markets: List[str],
        preferred_agents: List[str],
        request_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Attempt a deterministic single-agent path for scoped queries.

        Returns a normal response payload when successful, otherwise None.
        """
        try:
            tool = None
            for t in self.tools:
                if isinstance(t, SpecializedAgentTool):
                    tool = t
                    break
            if tool is None:
                return None

            agent_id = preferred_agents[0]
            symbol = None
            for e in entities:
                if e.get("type") == "stock_symbol":
                    symbol = e.get("value")
                    break

            input_parameters: Dict[str, Any] = {
                "query": user_input,
                "intent": intent,
                "entities": entities,
                "active_markets": active_markets,
                "market": active_markets[0] if active_markets else "IN",
            }
            if symbol:
                input_parameters["symbol"] = symbol

            delegated = tool._run(
                agent_id=agent_id,
                task_description=f"Single-intent {intent} request. Focus only on this analysis scope.",
                input_parameters=input_parameters,
                conversation_id=context.conversation_id,
            )
            try:
                delegated_obj = json.loads(delegated)
            except Exception:
                delegated_obj = {"result": delegated}

            if delegated_obj.get("error"):
                return None

            result_obj = delegated_obj.get("result", delegated_obj)
            if isinstance(result_obj, dict):
                response_text = (
                    result_obj.get("analysis")
                    or result_obj.get("summary")
                    or result_obj.get("message")
                    or json.dumps(result_obj)
                )
                result_confidence = float(result_obj.get("confidence", delegated_obj.get("confidence", 0.75)))
            else:
                response_text = str(result_obj)
                result_confidence = 0.75

            response_text = (
                f"Focused {intent.replace('_', ' ')} response (market: {', '.join(active_markets)}):\n\n"
                f"{response_text}"
            )
            if self._append_disclaimer and self._advisory_disclaimer not in response_text:
                response_text = f"{response_text}\n\n{self._advisory_disclaimer}"

            context.add_message(MessageType.AGENT_RESPONSE, response_text)
            context.update_state(ConversationState.RECOMMENDATION_GENERATION)

            return {
                "conversation_id": context.conversation_id,
                "response": response_text,
                "intent": intent,
                "confidence": result_confidence,
                "entities": entities,
                "context_summary": context.get_conversation_summary(),
                "request_id": request_id,
                "fastpath": True,
                "selected_agents": preferred_agents,
                "active_markets": active_markets,
            }
        except Exception:
            return None
    
    def _create_response_task(self, user_input: str, context: ConversationContext) -> Task:
        """Create a task for generating response to user input."""
        
        # Build context information for the task
        context_info = {
            "user_input": user_input,
            "conversation_id": context.conversation_id,
            "current_state": context.state.value,
            "inferred_intent": context.inferred_intent,
            "extracted_entities": [
                {"type": e.entity_type, "value": e.value, "confidence": e.confidence}
                for e in context.extracted_entities
            ],
            "default_market": getattr(getattr(_SETTINGS, "system", None), "default_market", "IN") if _SETTINGS else "IN",
            "active_markets": context.get_context_data("active_markets", []),
            "preferred_agents": context.get_context_data("preferred_agents", []),
            "invocation_mode": context.get_context_data("invocation_mode", "orchestrated"),
            "fastpath_bypass_reason": context.get_context_data("fastpath_bypass_reason", ""),
        }
        
        task_description = f"""
            Process the user's query and provide a comprehensive response using the following context:
            
            User Input: {user_input}
            Conversation ID: {context.conversation_id}
            Inferred Intent: {context.inferred_intent}
            Extracted Entities: {context_info['extracted_entities']}
            Active Markets: {context_info['active_markets']}
            Preferred Agents (if scoped): {context_info['preferred_agents']}
            Invocation Mode: {context_info['invocation_mode']}
            Fast-Path Bypass Reason: {context_info['fastpath_bypass_reason']}
                
            Instructions:
            1. Analyze the user's query and determine if you need information from specialized agents
            2. If specialized analysis is needed, use the specialized_agent_tool to delegate tasks to a single agent, or parallel_specialized_agent_tool to call multiple agents concurrently (with sensible timeouts)
            3. Use the agent_registry_tool ONLY with these actions: list_all, find_by_capability(capability), find_by_role(role), get_agent(agent_id), get_capabilities(agent_id), find_by_tag(tag)
            4. Synthesize information from multiple sources if needed
            5. Provide a comprehensive, actionable response
            6. Ask at most ONE clarifying question. If the market is not specified, assume the default market = {context_info['default_market']} and proceed with a best-effort answer.
            7. Maintain a professional yet approachable tone
            8. Include specific recommendations when appropriate
            9. If Invocation Mode is single_agent, prioritize only the first Preferred Agent and do not call parallel agents unless explicitly requested by the user.
            10. Do not submit any portfolio order without explicit approval confirmation in the form APPROVE <approval_id>.

            If the query is about "today" market view or "top performing stocks":
            - Call market_data_tool with action="market_overview" to assess NIFTY/SENSEX movement (for India) and summarize bullish/bearish.
            - Call market_data_tool with action="top_movers" (top=10) to list notable gainers/losers from the configured universe.
                
            Available specialized agents and their capabilities can be found using the agent_registry_tool.
            Use the conversation_tool to manage conversation state and context as needed.
            If the user asks to view portfolio, available cash/margins, or simulate a trade (BUY/SELL), use pta_client_tool:
            - "holdings" to retrieve cash and positions
            - "margins" to retrieve available margin
            - "preview_order" with symbol, side in {{buy|sell}}, quantity>0 for an estimate
            - "submit_order" with the same fields (optionally idempotency_key) to execute a paper trade
            - "list_orders" to show prior paper trades
            Assume India market tickers with .NS suffix where relevant.
        """
        
        # If we prefetched market data, inject a compact summary at the end of the task to ground the model
        try:
            market_overview = context.get_context_data("market_overview")
            top_movers = context.get_context_data("top_movers")
            if market_overview or top_movers:
                task_description += "\n\nAdditional Data (pre-fetched):\n"
                if market_overview:
                    task_description += f"- Market Overview: {json.dumps(market_overview)[:1200]}\n"
                if top_movers:
                    task_description += f"- Top Movers: {json.dumps(top_movers)[:1200]}\n"
        except Exception:
            pass

        return Task(
            description=task_description,
            expected_output="A comprehensive response to the user's query, including analysis, insights, and actionable recommendations",
            agent=self.agent
        )
    
    def get_conversation_history(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        """Get conversation history."""
        context = conversation_manager.get_conversation(conversation_id)
        return context.to_dict() if context else None
    
    def list_active_conversations(self) -> List[Dict[str, Any]]:
        """List all active conversations."""
        conversations = conversation_manager.get_active_conversations()
        return [conv.get_conversation_summary() for conv in conversations]


# Global instance
main_advisory_agent = MainAdvisoryAgent()

# --- Startup hook: auto-bind local enhanced_* agents for A2A where available ---
def _auto_bind_enhanced_agents() -> None:
    """Bind local enhanced_* agent instances to the registry for in-process A2A dispatch.
    Safe to run multiple times; binding is idempotent per process.
    Controlled by env: AUTO_BIND_ENHANCED_AGENTS=1 (default 1). Set to 0 to disable.
    """
    if os.environ.get("AUTO_BIND_ENHANCED_AGENTS", "1") != "1":
        return
    try:
        # Lazy imports to avoid importing heavy modules unless needed
        from agents.enhanced_research_agent import EnhancedResearchAgent  # type: ignore
    except Exception:
        EnhancedResearchAgent = None  # type: ignore
    try:
        from agents.enhanced_technical_agent import EnhancedTechnicalAgent  # type: ignore
    except Exception:
        EnhancedTechnicalAgent = None  # type: ignore
    try:
        from agents.enhanced_sentiment_agent import EnhancedSentimentAgent  # type: ignore
    except Exception:
        EnhancedSentimentAgent = None  # type: ignore
    try:
        from agents.enhanced_risk_agent import EnhancedRiskAgent  # type: ignore
    except Exception:
        EnhancedRiskAgent = None  # type: ignore
    try:
        from agents.enhanced_timing_agent import EnhancedTimingAgent  # type: ignore
    except Exception:
        EnhancedTimingAgent = None  # type: ignore
    try:
        from agents.enhanced_trade_strategy_planner import EnhancedTradeStrategyPlanner  # type: ignore
    except Exception:
        EnhancedTradeStrategyPlanner = None  # type: ignore
    try:
        from agents.enhanced_macro_agent import EnhancedMacroAgent  # type: ignore
    except Exception:
        EnhancedMacroAgent = None  # type: ignore

    bindings = [
        ("fundamental_research", EnhancedResearchAgent, {}),
        ("technical_analysis", EnhancedTechnicalAgent, {}),
        ("sentiment_analysis", EnhancedSentimentAgent, {}),
        ("risk_assessment", EnhancedRiskAgent, {}),
        ("timing_agent", EnhancedTimingAgent, {}),
        ("trade_strategy_planner", EnhancedTradeStrategyPlanner, {}),
        ("macroeconomy_specialist", EnhancedMacroAgent, {}),
    ]

    for agent_id, cls, kwargs in bindings:
        try:
            if cls is None:
                continue
            # If already bound, skip
            if agent_registry.get_bound_instance(agent_id):
                continue
            instance = cls(**kwargs)
            agent_registry.bind_instance(agent_id, instance)
            logger.info("A2A binding established | agent_id=%s | class=%s", agent_id, getattr(cls, "__name__", str(cls)))
        except Exception as bind_err:
            logger.warning("A2A binding failed | agent_id=%s | err=%s", agent_id, bind_err)


_auto_bind_enhanced_agents()

