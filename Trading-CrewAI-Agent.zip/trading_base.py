from __future__ import annotations

from typing import Any, Dict, List, Optional


class TradingAdapter:
    """Abstract execution adapter for broker trading.
    Implement place_order, list_orders, get_positions, get_balance, cancel_order.
    """

    name: str = "base"

    def place_order(
        self,
        *,
        symbol: str,
        side: str,
        quantity: int,
        order_type: str = "MARKET",
        product: str = "CNC",
        price: Optional[float] = None,
        tag: Optional[str] = None,
    ) -> Dict[str, Any]:  # pragma: no cover - to be implemented
        raise NotImplementedError

    def cancel_order(self, order_id: str) -> Dict[str, Any]:  # pragma: no cover
        raise NotImplementedError

    def list_orders(self) -> List[Dict[str, Any]]:  # pragma: no cover
        raise NotImplementedError

    def get_positions(self) -> List[Dict[str, Any]]:  # pragma: no cover
        raise NotImplementedError

    def get_balance(self) -> Dict[str, Any]:  # pragma: no cover
        raise NotImplementedError

    def info(self) -> Dict[str, Any]:  # pragma: no cover
        return {"name": self.name}
