# Memory System

> **Sources**: `main_advisory_agent/memory_store.py`, `main_advisory_agent/advisory_memory_hooks.py`  
> **Phase**: 5

---

## Overview

The advisory agent uses a **hierarchical LanceDB-based memory** to:

- Recall prior market analyses for the same market / similar context
- Recall previous synthesis results for the same user intent
- Record all trade executions for audit and learning
- Feed recalled context back into market Crew prompts (improving consistency over time)

```mermaid
flowchart LR
    subgraph Advisory Flow
        MA[market_analysis_step]
        SY[synthesis_step]
        EX[execution_step]
    end

    subgraph Memory System
        MS[(MemoryStore\nLanceDB)]
        subgraph Tables
            T1[market_analyses]
            T2[syntheses]
            T3[trade_executions]
        end
        MS --> T1
        MS --> T2
        MS --> T3
    end

    MA -->|recall| MS
    MA -->|write| MS
    SY -->|write| MS
    EX -->|write| MS

    MS -->|recalled context| MA
```

---

## `MemoryStore`

### Constructor

```python
MemoryStore(
    uri: str,                    # LanceDB directory path (LANCEDB_URI env var)
    embedding_fn: Optional[Any], # embedding function (LocalHFEmbeddingFunction or None)
    top_k: int = 5,              # number of results to return per recall query
)
```

LanceDB is opened in auto-schema mode. Tables are created on first write if they
don't already exist.

### Embedding

Uses `LocalHFEmbeddingFunction` backed by `all-mpnet-base-v2` loaded from
`hf_models/all-mpneet-base-v2/` (local, offline). Falls back to LanceDB's
built-in embeddings if the local model is unavailable.

---

## Tables

### `market_analyses`

| Column | Type | Description |
|--------|------|-------------|
| `id` | str | UUID |
| `market` | str | Market code (`IN`, `US`, …) |
| `conversation_id` | str | Conversation this came from |
| `timestamp` | float | Unix timestamp |
| `text` | str | Raw market Crew output |
| `intent` | str | Intent at time of analysis |
| `vector` | vec[768] | Embedding of `text` |

### `syntheses`

| Column | Type | Description |
|--------|------|-------------|
| `id` | str | UUID |
| `conversation_id` | str | Conversation this came from |
| `timestamp` | float | Unix timestamp |
| `text` | str | Full synthesis (after RL annotation) |
| `intent` | str | Intent |
| `market_codes` | str | Comma-separated markets analysed |
| `vector` | vec[768] | Embedding of `text` |

### `trade_executions`

| Column | Type | Description |
|--------|------|-------------|
| `id` | str | UUID |
| `conversation_id` | str | Conversation this came from |
| `timestamp` | float | Unix timestamp |
| `text` | str | ExecutionCrew trade plan output |
| `vector` | vec[768] | Embedding of `text` |

---

## Memory hooks (`advisory_memory_hooks.py`)

Four helper functions wrap all reads/writes to `MemoryStore`.
They are designed to be called from `AdvisoryFlow` steps and are
**silent on failure** (try/except, returns `{}` or `""` on error).

### `remember_market_analysis`

```python
remember_market_analysis(
    store: MemoryStore,
    market: str,                    # e.g. "IN"
    analysis_text: str,             # raw output from market crew
    conversation_id: str = "",
    intent: str = "",
) -> None
```

Writes a new row to `market_analyses`.

---

### `remember_synthesis`

```python
remember_synthesis(
    store: MemoryStore,
    synthesis_text: str,
    conversation_id: str = "",
    intent: str = "",
    market_codes: List[str] = None,
) -> None
```

Writes a new row to `syntheses`.

---

### `remember_trade_execution`

```python
remember_trade_execution(
    store: MemoryStore,
    execution_text: str,            # ExecutionCrew output
    conversation_id: str = "",
) -> None
```

Writes a new row to `trade_executions`.

---

### `recall_market_history`

```python
results = recall_market_history(
    store: MemoryStore,
    market: str,                    # market to recall for
    user_input: str,                # used as the query vector
    top_k: int = 3,
) -> List[Dict[str, Any]]
```

Performs a vector similarity search against `market_analyses` filtered to the
given market. Returns up to `top_k` rows (most similar first).

**Return schema** (each element):

```python
{
    "text": "Prior analysis text...",
    "market": "IN",
    "timestamp": 1737000000.0,
    "intent": "technical_analysis",
    "_distance": 0.12,         # lower = more similar
}
```

---

## Integration in `AdvisoryFlow`

### Recall (before market crews)

```python
# market_analysis_step
for market in state.active_markets:
    prior = recall_market_history(self._memory_store, market, state.user_input)
    if prior:
        state.memory_recall[market] = prior
        # prior context is embedded into task descriptions for the market Crew
```

### Write (after market crews)

```python
# market_analysis_step (after gather)
for market, result in state.market_results.items():
    remember_market_analysis(
        self._memory_store, market, result["raw"],
        conversation_id=state.conversation_id,
        intent=state.intent,
    )
```

### Write (after synthesis)

```python
# synthesis_step
remember_synthesis(
    self._memory_store, state.synthesis_result,
    conversation_id=state.conversation_id,
    intent=state.intent,
    market_codes=state.active_markets,
)
```

### Write (after execution)

```python
# execution_step
remember_trade_execution(
    self._memory_store, state.execution_result,
    conversation_id=state.conversation_id,
)
```

---

## Configuration

| Env var | Default | Description |
|---------|---------|-------------|
| `LANCEDB_URI` | `data/memory/lancedb` | Directory for LanceDB tables |
| `LOCAL_EMBEDDINGS_MODEL_DIR` | `hf_models/all-mpneet-base-v2` | Local HuggingFace embedding model |
| `MEMORY_TOP_K` | `5` | Default number of recall results |

Memory is **disabled silently** if `MemoryStore` is not injected into `AdvisoryFlow`
(i.e., all hooks become no-ops).
