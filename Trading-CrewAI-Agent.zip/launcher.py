#!/usr/bin/env python3
import argparse
import datetime as dt
import json
import os
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from urllib.request import urlopen, Request
try:
    from dotenv import load_dotenv  # type: ignore
except Exception:
    load_dotenv = None

ROOT = Path(__file__).parent.resolve()
LOGS = ROOT / 'logs'
PIDS_FILE = LOGS / 'pids.json'

# Detect venv python (Windows & POSIX)
def detect_python() -> Path:
    win_candidate = ROOT / 'crewenv' / 'Scripts' / 'python.exe'
    posix_candidate = ROOT / 'crewenv' / 'bin' / 'python'
    if win_candidate.exists():
        return win_candidate
    if posix_candidate.exists():
        return posix_candidate
    # Fallback to current python
    return Path(sys.executable)

PYTHON = detect_python()


def ensure_logs():
    LOGS.mkdir(parents=True, exist_ok=True)


def clear_session_logs():
    """Clear all logs from previous session to keep only current session logs."""
    if not LOGS.exists():
        return
    
    print('Clearing previous session logs...')
    log_files_cleared = 0
    
    # List of log files to clear
    log_patterns = [
        'pta.log',
        'integrated_system.log', 
        'rl_worker.log',
        'rl_api.log',
        'pta_worker.log',
        'pta_websocket.log',
        'main_agent.log',
        'web_ui.log',
        'admin_dashboard.log',
        'system_control.log',
        'system.log',
        'main_agent.log'  # Also clear root level main_agent.log
    ]
    
    # Clear specific log files
    for log_file in log_patterns:
        log_path = LOGS / log_file
        if log_path.exists():
            try:
                log_path.write_text('', encoding='utf-8')  # Clear file content
                log_files_cleared += 1
            except Exception as e:
                print(f'Warning: Could not clear {log_file}: {e}')
    
    # Clear any subdirectory logs
    for subdir in LOGS.iterdir():
        if subdir.is_dir():
            for log_file in subdir.rglob('*.log'):
                try:
                    log_file.write_text('', encoding='utf-8')
                    log_files_cleared += 1
                except Exception as e:
                    print(f'Warning: Could not clear {log_file}: {e}')
    
    # Also clear root level log files
    root_logs = ['main_agent.log', 'system_monitor.log', 'system.log']
    for log_file in root_logs:
        log_path = ROOT / log_file
        if log_path.exists():
            try:
                log_path.write_text('', encoding='utf-8')
                log_files_cleared += 1
            except Exception as e:
                print(f'Warning: Could not clear {log_file}: {e}')
    
    if log_files_cleared > 0:
        print(f'Cleared {log_files_cleared} log files from previous session.')
    else:
        print('No previous session logs found.')


def test_port(host: str, port: int, timeout: float = 1.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def random_hex(n_bytes: int = 32) -> str:
    return secrets.token_hex(n_bytes)


# Dependency helpers

def get_installed_packages(py: Path) -> dict:
    try:
        out = subprocess.check_output([str(py), '-m', 'pip', 'list', '--format=json'], text=True)
        arr = json.loads(out)
        return {p['name'].lower(): p['version'] for p in arr}
    except Exception:
        return {}


def parse_requirements(path: Path) -> set:
    if not path.exists():
        return set()
    names = set()
    for raw in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or line.startswith('-'):
            continue
        if line.startswith('git+') or line.startswith('http'):
            continue
        # Simple name matcher up to first specifier char
        name = ''
        for ch in line:
            if ch in '<=>!~;[':
                break
            name += ch
        name = name.strip().lower()
        if name:
            names.add(name)
    return names


def check_dependencies(py: Path, req: Path) -> list:
    installed = get_installed_packages(py)
    required = parse_requirements(req)
    missing = [r for r in sorted(required) if r not in installed]
    return missing


def pip_install(py: Path, req: Path):
    subprocess.check_call([str(py), '-m', 'pip', 'install', '--upgrade', 'pip'])
    if req.exists():
        subprocess.check_call([str(py), '-m', 'pip', 'install', '-r', str(req)])
    # Optional local wheel for ta_lib
    wheel = next(ROOT.glob('ta_lib-*.whl'), None)
    if wheel:
        subprocess.check_call([str(py), '-m', 'pip', 'install', str(wheel)])


# Redis via Docker

def ensure_redis(env: dict, use_docker: bool = True) -> None:
    if env.get('REDIS_URL'):
        return
    if test_port('127.0.0.1', 6379):
        env['REDIS_URL'] = 'redis://localhost:6379/0'
        print(f"Using existing Redis at {env['REDIS_URL']}")
        return
    if not use_docker:
        print('REDIS_URL not set and --no-docker specified; EventBus disabled.')
        return
    if not shutil.which('docker'):
        print('Docker not found; skipping Redis startup. EventBus disabled.')
        return
    print('Starting Redis via Docker (redis:7) ...')
    try:
        # Check if container exists
        cid = subprocess.check_output(['docker', 'ps', '-a', '--filter', 'name=trading-redis', '--format', '{{.ID}}'], text=True).strip()
        if cid:
            running = subprocess.check_output(['docker', 'inspect', '-f', '{{.State.Running}}', 'trading-redis'], text=True).strip()
            if running != 'true':
                subprocess.check_call(['docker', 'start', 'trading-redis'])
        else:
            subprocess.check_call(['docker', 'run', '-d', '-p', '6379:6379', '--name', 'trading-redis', 'redis:7'])
        # Wait up to 15s
        deadline = time.time() + 15
        while time.time() < deadline:
            if test_port('127.0.0.1', 6379):
                break
            time.sleep(0.3)
        if test_port('127.0.0.1', 6379):
            env['REDIS_URL'] = 'redis://localhost:6379/0'
            print(f"Redis ready at {env['REDIS_URL']}")
        else:
            print('Redis did not become ready; EventBus features will be disabled.')
    except Exception as e:
        print(f'Failed to ensure Redis: {e}')


# Process management

def start_process(cmd: list, log_path: Path, env: dict) -> int:
    ensure_logs()
    log_f = open(log_path, 'a', buffering=1, encoding='utf-8')
    try:
        # On Windows, detach in a new process group; on POSIX, set new session
        creationflags = 0
        preexec_fn = None
        if os.name == 'nt':
            creationflags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
        else:
            preexec_fn = os.setsid
        p = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            stdout=log_f,
            stderr=subprocess.STDOUT,
            env=env,
            creationflags=creationflags,
            preexec_fn=preexec_fn,
        )
        pid = p.pid
        return pid
    finally:
        try:
            log_f.flush()
            log_f.close()
        except Exception:
            pass


def save_pids(pids: dict):
    ensure_logs()
    data = {
        'created_at': dt.datetime.utcnow().isoformat() + 'Z',
        'pids': pids,
    }
    PIDS_FILE.write_text(json.dumps(data, indent=2))


def load_pids() -> dict:
    if not PIDS_FILE.exists():
        return {}
    try:
        data = json.loads(PIDS_FILE.read_text())
        return data.get('pids', {})
    except Exception:
        return {}


def is_running(pid: int) -> bool:
    try:
        if os.name == 'nt':
            # On Windows, os.kill with 0 is not supported, use tasklist
            out = subprocess.check_output(['tasklist', '/FI', f'PID eq {pid}'], text=True, stderr=subprocess.DEVNULL)
            return str(pid) in out
        else:
            os.kill(pid, 0)
            return True
    except Exception:
        return False


def terminate_pid(name: str, pid: int, timeout: float = 5.0):
    try:
        if os.name == 'nt':
            # Try graceful CTRL-BREAK to the group is non-trivial; use taskkill tree
            subprocess.call(['taskkill', '/PID', str(pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            # Try SIGTERM to process group
            try:
                os.killpg(pid, signal.SIGTERM)
            except Exception:
                try:
                    os.kill(pid, signal.SIGTERM)
                except Exception:
                    pass
            deadline = time.time() + timeout
            while time.time() < deadline:
                if not is_running(pid):
                    return
                time.sleep(0.2)
            # Force kill
            try:
                os.killpg(pid, signal.SIGKILL)
            except Exception:
                try:
                    os.kill(pid, signal.SIGKILL)
                except Exception:
                    pass
    except Exception:
        pass


def cmd_start(args):
    ensure_logs()
    
    # Clear logs from previous session
    clear_session_logs()

    # Load environment from .env at project root (so child processes inherit values)
    if load_dotenv is not None:
        try:
            load_dotenv(dotenv_path=ROOT / '.env')
        except Exception:
            pass

    # Dependencies
    req = ROOT / 'requirements.txt'
    missing = check_dependencies(PYTHON, req)
    if args.skip_install:
        if missing:
            print('Warning: missing packages in venv:', ', '.join(missing))
            print('Tip: run without --skip-install to auto-install from requirements.txt')
    else:
        print('Installing dependencies...')
        pip_install(PYTHON, req)

    # Environment
    env = os.environ.copy()
    env['PYTHONUNBUFFERED'] = '1'
    env['UI_PORT'] = str(args.ui_port)
    env['PORT'] = str(args.ui_port)
    env['ALLOWED_ORIGINS'] = f"http://localhost:{args.ui_port},http://localhost:{args.admin_port}"
    env.setdefault('CSRF_SECRET', random_hex(32))
    env['CSRF_ENABLED'] = 'true'
    # PTA configuration
    env['PTA_PORT'] = str(args.pta_port)
    env['PTA_URL'] = env.get('PTA_URL', f"http://localhost:{args.pta_port}")
    env['PTA_BASE_URL'] = env.get('PTA_BASE_URL', env['PTA_URL'])
    # PTA Portfolio Management System
    env.setdefault('PTA_STARTING_CASH', '50000')
    env.setdefault('PTA_BROKERAGE_MIN', '5.0')
    env.setdefault('PTA_BROKERAGE_BPS', '0.0005')
    env.setdefault('PTA_SLIPPAGE_BPS', '0.0002')
    env.setdefault('PTA_WS_PORT', str(args.pta_ws_port))
    env.setdefault('PTA_WS_HOST', 'localhost')
    # Execution & admin defaults for PTA
    env.setdefault('EXECUTION_MODE', 'PAPER')  # Default to PAPER
    env.setdefault('ALLOW_RUNTIME_TOGGLE', '0')  # set to '1' to allow /admin/mode switching
    env.setdefault('ALLOW_LIVE_TRADING', 'NO')   # safety gate for SHOONYA
    if not env.get('PTA_ADMIN_TOKEN'):
        env['PTA_ADMIN_TOKEN'] = random_hex(16)

    # Redis: allow env override for Docker fallback
    use_docker_flag = env.get('LAUNCHER_USE_DOCKER_REDIS')
    if use_docker_flag is not None:
        use_docker = use_docker_flag in ('1', 'true', 'True', 'YES', 'yes')
    else:
        use_docker = not args.no_docker
    ensure_redis(env, use_docker=use_docker)

    # Commands
    processes = {}

    # PTA service (Paper Trading Agent)
    pta_cmd = [str(PYTHON), '-m', 'paper_trading_agent.app']
    pta_log = LOGS / 'pta.log'
    processes['pta'] = start_process(pta_cmd, pta_log, env)

    # Integrated system
    integrated_cmd = [str(PYTHON), str(ROOT / 'start_integrated_system.py')]
    integrated_log = LOGS / 'integrated_system.log'
    processes['integrated'] = start_process(integrated_cmd, integrated_log, env)

    # RL worker if Redis available
    if env.get('REDIS_URL'):
        rl_cmd = [str(PYTHON), str(ROOT / 'RL_Agent' / 'rl_event_worker.py')]
        rl_log = LOGS / 'rl_worker.log'
        processes['rl_worker'] = start_process(rl_cmd, rl_log, env)

    # RL HTTP API server (run on separate port to avoid Web UI collision)
    rl_env = env.copy()
    rl_env['RL_API_PORT'] = rl_env.get('RL_API_PORT', '5500')
    rl_api_cmd = [str(PYTHON), str(ROOT / 'RL_Agent' / 'run_rl_api.py')]
    rl_api_log = LOGS / 'rl_api.log'
    processes['rl_api'] = start_process(rl_api_cmd, rl_api_log, rl_env)

    # PTA EventBus worker (bridges Redis Streams to PTA HTTP)
    if env.get('REDIS_URL'):
        pta_worker_cmd = [str(PYTHON), '-m', 'paper_trading_agent.pta_event_worker']
        pta_worker_log = LOGS / 'pta_worker.log'
        processes['pta_worker'] = start_process(pta_worker_cmd, pta_worker_log, env)

    # PTA WebSocket server for real-time portfolio updates
    if env.get('REDIS_URL'):
        pta_ws_cmd = [str(PYTHON), str(ROOT / 'paper_trading_agent' / 'websocket_server.py')]
        pta_ws_log = LOGS / 'pta_websocket.log'
        processes['pta_websocket'] = start_process(pta_ws_cmd, pta_ws_log, env)

    # Main Advisory Agent HTTP server (port 8000)
    main_agent_cmd = [str(PYTHON), str(ROOT / 'main advisory agent' / 'main.py')]
    main_agent_log = LOGS / 'main_agent.log'
    processes['main_agent'] = start_process(main_agent_cmd, main_agent_log, env)

    # Web UI
    ui_cmd = [str(PYTHON), str(ROOT / 'ui' / 'web_server.py')]
    ui_log = LOGS / 'web_ui.log'
    processes['web_ui'] = start_process(ui_cmd, ui_log, env)

    # Streamlit Admin
    admin_cmd = [str(PYTHON), '-m', 'streamlit', 'run', str(ROOT / 'ui' / 'admin_dashboard.py'), '--server.port', str(args.admin_port), '--server.headless', 'true', '--browser.gatherUsageStats', 'false']
    admin_log = LOGS / 'admin_dashboard.log'
    processes['admin'] = start_process(admin_cmd, admin_log, env)

    save_pids(processes)

    print('\nStarted processes:')
    for name, pid in processes.items():
        print(f"- {name}: PID {pid}")
    print('\nEndpoints:')
    print(f"  Web UI       -> http://localhost:{args.ui_port}")
    print(f"  Admin UI     -> http://localhost:{args.admin_port}")
    print(f"  RL API       -> http://localhost:{rl_env['RL_API_PORT']}")
    print(f"  PTA API      -> http://localhost:{args.pta_port}")
    if env.get('REDIS_URL'):
        print(f"  PTA WebSocket -> ws://localhost:{args.pta_ws_port}")
    print('\nPTA Settings:')
    print(f"  EXECUTION_MODE     : {env.get('EXECUTION_MODE')}")
    print(f"  Starting Cash      : ₹{env.get('PTA_STARTING_CASH', '50000')}")
    print(f"  Brokerage (min/bps): ₹{env.get('PTA_BROKERAGE_MIN', '5')} / {float(env.get('PTA_BROKERAGE_BPS', '0.0005'))*10000:.2f}bps")
    print(f"  Slippage (bps)     : {float(env.get('PTA_SLIPPAGE_BPS', '0.0002'))*10000:.2f}bps")
    print(f"  Runtime toggle     : {'ENABLED' if env.get('ALLOW_RUNTIME_TOGGLE') in ('1','true','True') else 'disabled'}")
    print(f"  Live trading gate  : {env.get('ALLOW_LIVE_TRADING')}")
    print(f"  PTA Admin Token    : {env.get('PTA_ADMIN_TOKEN')}")
    if env.get('REDIS_URL'):
        print(f"  Event Bus          : Redis at {env.get('REDIS_URL')}")
    else:
        print(f"  Event Bus          : Disabled (no REDIS_URL)")

    if args.foreground:
        print('\nForeground mode: press Ctrl+C to exit. Processes will continue running in background.')
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass


def cmd_stop(args):
    pids = load_pids()
    if not pids:
        print('No pid file found or empty. Nothing to stop.')
        return
    for name, pid in pids.items():
        try:
            pid = int(pid)
        except Exception:
            continue
        if is_running(pid):
            print(f'Stopping {name} (PID {pid}) ...')
            terminate_pid(name, pid)
        else:
            print(f'{name} (PID {pid}) is not running.')
    # Optionally stop docker redis
    if shutil.which('docker'):
        try:
            cid = subprocess.check_output(['docker', 'ps', '-a', '--filter', 'name=trading-redis', '--format', '{{.ID}}'], text=True).strip()
            if cid:
                print('Stopping Docker container trading-redis ...')
                subprocess.call(['docker', 'stop', 'trading-redis'])
        except Exception:
            pass
    try:
        PIDS_FILE.unlink(missing_ok=True)
    except Exception:
        pass
    print('Done.')


def http_status(url: str, timeout: float = 5.0):
    try:
        with urlopen(Request(url, headers={'User-Agent': 'launcher-health'}), timeout=timeout) as r:
            return r.status
    except Exception:
        return None


def cmd_health(args):
    ui_open = test_port('127.0.0.1', args.ui_port)
    ad_open = test_port('127.0.0.1', args.admin_port)
    pta_open = test_port('127.0.0.1', args.pta_port)
    pta_ws_open = test_port('127.0.0.1', getattr(args, 'pta_ws_port', 8091))
    print('Ports:')
    print(f"  UI {args.ui_port}: {'open' if ui_open else 'closed'}")
    print(f"  Admin {args.admin_port}: {'open' if ad_open else 'closed'}")
    print(f"  PTA {args.pta_port}: {'open' if pta_open else 'closed'}")
    print(f"  PTA WS {getattr(args, 'pta_ws_port', 8091)}: {'open' if pta_ws_open else 'closed'}")

    ui_root = http_status(f'http://localhost:{args.ui_port}/')
    sse = http_status(f'http://localhost:{args.ui_port}/api/sse/telemetry')
    admin = http_status(f'http://localhost:{args.admin_port}/')
    pta = http_status(f'http://localhost:{args.pta_port}/health')

    print('HTTP:')
    print(f"  Web UI root           : {ui_root if ui_root is not None else 'no response'}")
    print(f"  SSE telemetry endpoint: {sse if sse is not None else 'no response'}")
    print(f"  Admin dashboard       : {admin if admin is not None else 'no response'}")
    print(f"  PTA service           : {pta if pta is not None else 'no response'}")

    pids = load_pids()
    if pids:
        print('Processes:')
        for name, pid in pids.items():
            status = 'running' if is_running(int(pid)) else 'stopped'
            print(f"  {name:<12} PID {pid:<7} {status}")
    else:
        print('No pids recorded.')


def cmd_status(args):
    return cmd_health(args)


def main():
    parser = argparse.ArgumentParser(description='Launcher for Trading-CrewAI-Agent')
    sub = parser.add_subparsers(dest='cmd')

    p_start = sub.add_parser('start', help='Start all services')
    p_start.add_argument('--skip-install', action='store_true', help='Skip pip install; only warn if deps missing')
    p_start.add_argument('--no-docker', action='store_true', help='Do not use Docker to start Redis')
    p_start.add_argument('--ui-port', type=int, default=5000)
    p_start.add_argument('--admin-port', type=int, default=8501)
    p_start.add_argument('--pta-port', type=int, default=8090)
    p_start.add_argument('--pta-ws-port', type=int, default=8091)
    p_start.add_argument('--foreground', action='store_true', help='Keep the launcher process alive')
    p_start.set_defaults(func=cmd_start)

    p_stop = sub.add_parser('stop', help='Stop all services')
    p_stop.set_defaults(func=cmd_stop)

    p_health = sub.add_parser('health', help='Health check & status')
    p_health.add_argument('--ui-port', type=int, default=5000)
    p_health.add_argument('--admin-port', type=int, default=8501)
    p_health.add_argument('--pta-port', type=int, default=8090)
    p_health.add_argument('--pta-ws-port', type=int, default=8091)
    p_health.set_defaults(func=cmd_health)

    p_status = sub.add_parser('status', help='Alias for health')
    p_status.add_argument('--ui-port', type=int, default=5000)
    p_status.add_argument('--admin-port', type=int, default=8501)
    p_status.add_argument('--pta-port', type=int, default=8090)
    p_status.add_argument('--pta-ws-port', type=int, default=8091)
    p_status.set_defaults(func=cmd_status)

    # Default to start if no subcommand
    args = parser.parse_args()
    if not args.cmd:
        args = parser.parse_args(['start'])

    try:
        args.func(args)
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
