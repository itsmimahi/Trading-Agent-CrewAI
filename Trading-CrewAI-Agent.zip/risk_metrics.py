"""
Risk Metrics — RL v2 reward-shaping utilities.

All functions are pure NumPy (no gym / SB3 / yfinance dependency).
Used by PortfolioTradingEnv and RLAgentV2 for step-level reward computation
and post-episode diagnostics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Data class
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RiskSnapshot:
    """Risk metrics at a single evaluation point."""
    sharpe_ratio: float = 0.0       # annualised Sharpe
    max_drawdown: float = 0.0       # positive fraction, e.g. 0.15 = 15 %
    var_95: float = 0.0             # 1-day 95 % historical VaR (positive = loss)
    cvar_95: float = 0.0            # Expected shortfall beyond VaR
    calmar_ratio: float = 0.0       # annualised return / max_drawdown
    turnover: float = 0.0           # Σ|Δweight| at this step
    volatility: float = 0.0         # annualised realised vol


# ─────────────────────────────────────────────────────────────────────────────
# Individual metric functions
# ─────────────────────────────────────────────────────────────────────────────

def compute_sharpe(
    returns: np.ndarray,
    *,
    risk_free: float = 0.0,
    annualize: bool = True,
    periods_per_year: int = 252,
) -> float:
    """Sharpe ratio from a 1-D returns array.

    Args:
        returns:          Per-step returns (fractions).
        risk_free:        Annual risk-free rate.
        annualize:        Scale to annual Sharpe.
        periods_per_year: Trading days per year.

    Returns:
        Sharpe ratio, 0.0 when undefined.
    """
    arr = np.asarray(returns, dtype=float)
    if len(arr) < 2:
        return 0.0
    excess = arr - risk_free / periods_per_year
    std = float(np.std(excess, ddof=1))
    if std < 1e-9:
        return 0.0
    sharpe = float(np.mean(excess)) / std
    if annualize:
        sharpe *= np.sqrt(periods_per_year)
    return sharpe


def compute_max_drawdown(portfolio_values: np.ndarray) -> float:
    """Maximum drawdown as a positive fraction (0 = no drawdown).

    Args:
        portfolio_values: Chronological portfolio value series.

    Returns:
        Maximum drawdown in [0, 1].
    """
    arr = np.asarray(portfolio_values, dtype=float)
    if len(arr) < 2:
        return 0.0
    peak = np.maximum.accumulate(arr)
    safe_peak = np.where(peak > 0, peak, 1.0)
    drawdown = (peak - arr) / safe_peak
    return float(np.max(drawdown))


def compute_var_historical(
    returns: np.ndarray,
    confidence: float = 0.95,
) -> float:
    """Historical Value-at-Risk (positive number = potential loss).

    Args:
        returns:    Per-step returns array.
        confidence: Confidence level, default 0.95.

    Returns:
        VaR ≥ 0.
    """
    arr = np.asarray(returns, dtype=float)
    if len(arr) < 5:
        return 0.0
    return float(-np.percentile(arr, (1.0 - confidence) * 100.0))


def compute_cvar(
    returns: np.ndarray,
    confidence: float = 0.95,
) -> float:
    """Conditional VaR / Expected Shortfall (positive = potential loss).

    Args:
        returns:    Per-step returns array.
        confidence: Confidence level.

    Returns:
        CVaR ≥ 0.
    """
    arr = np.asarray(returns, dtype=float)
    if len(arr) < 5:
        return 0.0
    var = compute_var_historical(arr, confidence)
    tail = arr[arr <= -var]
    if len(tail) == 0:
        return var
    return float(-np.mean(tail))


def compute_turnover(
    weights_old: np.ndarray,
    weights_new: np.ndarray,
) -> float:
    """Sum of absolute weight changes across all assets.

    Args:
        weights_old: Previous allocation weights (N-dim vector).
        weights_new: New allocation weights (N-dim vector).

    Returns:
        Turnover in [0, 2] (0 = no change, 2 = full reversal).
    """
    a = np.asarray(weights_old, dtype=float)
    b = np.asarray(weights_new, dtype=float)
    return float(np.sum(np.abs(b - a)))


def compute_calmar(
    portfolio_values: np.ndarray,
    periods_per_year: int = 252,
) -> float:
    """Calmar ratio = annualised return / maximum drawdown.

    Args:
        portfolio_values: Chronological portfolio value series.
        periods_per_year: Periods per calendar year.

    Returns:
        Calmar ratio; 0.0 when drawdown is negligible.
    """
    arr = np.asarray(portfolio_values, dtype=float)
    if len(arr) < 2:
        return 0.0
    total_return = float(arr[-1] / arr[0]) - 1.0
    n = len(arr)
    ann_return = float((1.0 + total_return) ** (periods_per_year / n) - 1.0)
    mdd = compute_max_drawdown(arr)
    if mdd < 1e-9:
        return 0.0
    return ann_return / mdd


# ─────────────────────────────────────────────────────────────────────────────
# RL v2 Reward formula
# ─────────────────────────────────────────────────────────────────────────────

def risk_aware_reward(
    portfolio_return: float,
    drawdown: float,
    turnover: float,
    var_breach: float,
    rolling_sharpe: float,
    *,
    lambda_dd: float = 2.0,
    lambda_tc: float = 0.001,
    lambda_var: float = 3.0,
    lambda_sharpe: float = 0.5,
    drawdown_free_zone: float = 0.10,
) -> float:
    """Risk-aware step reward for RL v2.

    Formula::

        reward = portfolio_return × 100
                 − λ_dd  × max(0, drawdown − drawdown_free_zone)
                 − λ_tc  × |turnover|
                 − λ_var × max(0, var_breach)
                 + λ_sh  × rolling_sharpe × 0.1

    Args:
        portfolio_return:     Step portfolio return (fraction, e.g. 0.002).
        drawdown:             Current drawdown fraction ∈ [0, 1].
        turnover:             Σ|Δweight| this step.
        var_breach:           Amount by which realised loss exceeded historical
                              VaR.  Pass 0.0 when not breached.
        rolling_sharpe:       Rolling Sharpe computed over the last N steps.
        lambda_dd:            Drawdown penalty weight (default 2.0).
        lambda_tc:            Turnover/cost penalty weight (default 0.001).
        lambda_var:           VaR breach penalty weight (default 3.0).
        lambda_sharpe:        Sharpe bonus weight (default 0.5).
        drawdown_free_zone:   Drawdown below this value incurs no penalty
                              (default 10 %).

    Returns:
        Scalar reward value.
    """
    dd_penalty = lambda_dd * max(0.0, drawdown - drawdown_free_zone)
    tc_penalty = lambda_tc * abs(turnover)
    var_penalty = lambda_var * max(0.0, var_breach)
    sharpe_bonus = lambda_sharpe * rolling_sharpe * 0.1
    return portfolio_return * 100.0 - dd_penalty - tc_penalty - var_penalty + sharpe_bonus


def build_risk_snapshot(
    returns_history: np.ndarray,
    portfolio_values: np.ndarray,
    weights_old: np.ndarray,
    weights_new: np.ndarray,
) -> RiskSnapshot:
    """Convenience factory that computes all metrics at once.

    Args:
        returns_history: Full returns series up to current step.
        portfolio_values: Portfolio value series up to current step.
        weights_old:     Weights before this step.
        weights_new:     Weights after this step.

    Returns:
        Populated RiskSnapshot.
    """
    r = np.asarray(returns_history, dtype=float)
    pv = np.asarray(portfolio_values, dtype=float)
    ann_vol = float(np.std(r[-20:], ddof=1) * np.sqrt(252)) if len(r) >= 2 else 0.0
    return RiskSnapshot(
        sharpe_ratio=compute_sharpe(r),
        max_drawdown=compute_max_drawdown(pv),
        var_95=compute_var_historical(r),
        cvar_95=compute_cvar(r),
        calmar_ratio=compute_calmar(pv),
        turnover=compute_turnover(weights_old, weights_new),
        volatility=ann_vol,
    )
