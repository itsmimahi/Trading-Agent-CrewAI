"""
User routes for the Main Advisory Agent.
"""

from flask import Blueprint, jsonify

user_bp = Blueprint('user', __name__)

@user_bp.route('/user/health')
def user_health():
    """User service health check."""
    return jsonify({
        'status': 'healthy',
        'service': 'user_service',
        'message': 'User service is operational'
    })

@user_bp.route('/user/profile')
def user_profile():
    """Get user profile information."""
    return jsonify({
        'message': 'User profile endpoint - to be implemented',
        'status': 'placeholder'
    })
