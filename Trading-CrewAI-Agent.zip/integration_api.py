"""
Integration API Routes
Provides endpoints for CrewAI system to interact with the RL Trading Agent.
"""

from flask import Blueprint, request, jsonify
import asyncio
from datetime import datetime
from typing import Dict, Any

from .crewai_integration import (
    CrewAIIntegrationService, 
    StrategyRequest, 
    FeedbackData
)

integration_api = Blueprint('integration_api', __name__, url_prefix='/api/integration')

# Initialize the integration service
integration_service = CrewAIIntegrationService()


@integration_api.route('/health', methods=['GET'])
def integration_health():
    """Health check for the integration service."""
    status = integration_service.get_integration_status()
    return jsonify({
        'service': 'CrewAI Integration Service',
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'integration_status': status
    })


@integration_api.route('/status', methods=['GET'])
def get_integration_status():
    """Get detailed integration status."""
    return jsonify(integration_service.get_integration_status())


@integration_api.route('/setup', methods=['POST'])
def setup_integration():
    """Setup the integration by creating and training a default RL agent."""
    try:
        data = request.get_json() or {}
        
        agent_id = data.get('agent_id', 'main_rl_agent')
        algorithm = data.get('algorithm', 'PPO')
        symbol = data.get('symbol', 'AAPL')
        auto_train = data.get('auto_train', False)
        
        # Create the RL agent
        create_result = integration_service.create_rl_agent(
            agent_id=agent_id,
            algorithm=algorithm,
            symbol=symbol,
            **{k: v for k, v in data.items() if k not in ['agent_id', 'algorithm', 'symbol', 'auto_train']}
        )
        
        if 'error' in create_result:
            return jsonify(create_result), 400
        
        response = {
            'message': 'Integration setup completed',
            'agent_created': create_result,
            'agent_id': agent_id
        }
        
        # Optionally start training
        if auto_train:
            train_result = integration_service.train_rl_agent(
                agent_id=agent_id,
                total_timesteps=data.get('total_timesteps', 50000)
            )
            response['training_started'] = train_result
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@integration_api.route('/crewai/simulate_strategy', methods=['POST'])
def simulate_strategy_for_crewai():
    """
    Main endpoint for CrewAI agents to request strategy simulations.
    
    Expected payload:
    {
        "strategy_description": "Bullish on tech stocks, breakout strategy",
        "symbol": "AAPL",
        "start_date": "2023-01-01",
        "end_date": "2023-12-31",
        "initial_balance": 100000,
        "agent_id": "main_rl_agent",
        "requester_agent": "Technical Analysis Agent"
    }
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['strategy_description', 'symbol', 'start_date', 'end_date']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create strategy request
        strategy_request = StrategyRequest(
            strategy_description=data['strategy_description'],
            symbol=data['symbol'],
            start_date=data['start_date'],
            end_date=data['end_date'],
            initial_balance=data.get('initial_balance', 100000.0),
            agent_id=data.get('agent_id', 'main_rl_agent'),
            requester_agent=data.get('requester_agent', 'Unknown Agent')
        )
        
        # Simulate strategy
        result = integration_service.simulate_strategy_for_crewai(strategy_request)
        
        if result.get('success', True):
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@integration_api.route('/crewai/feedback', methods=['POST'])
def receive_feedback_from_crewai():
    """
    Endpoint for CrewAI agents to provide feedback to the RL agent.
    
    Expected payload:
    {
        "agent_id": "main_rl_agent",
        "feedback_type": "performance",
        "feedback_data": {
            "performance_metrics": {
                "sharpe_ratio": 1.5,
                "max_drawdown": 0.08,
                "total_return": 0.15
            }
        },
        "source_agent": "Risk Assessment Agent",
        "confidence": 0.8
    }
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['agent_id', 'feedback_type', 'feedback_data', 'source_agent']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create feedback data
        feedback_data = FeedbackData(
            feedback_type=data['feedback_type'],
            feedback_data=data['feedback_data'],
            source_agent=data['source_agent'],
            timestamp=datetime.now().isoformat(),
            confidence=data.get('confidence', 0.5)
        )
        
        # Send feedback to RL agent
        result = integration_service.send_feedback_to_rl_agent(
            agent_id=data['agent_id'],
            feedback_data=feedback_data
        )
        
        if 'error' not in result:
            return jsonify({
                'success': True,
                'message': 'Feedback sent successfully',
                'result': result,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@integration_api.route('/crewai/learned_rules', methods=['GET'])
def get_learned_rules_for_crewai():
    """
    Endpoint for CrewAI agents to retrieve learned rules from the RL agent.
    
    Query parameters:
    - agent_id: ID of the RL agent (default: main_rl_agent)
    """
    try:
        agent_id = request.args.get('agent_id', 'main_rl_agent')
        
        # Get learned rules from RL agent
        result = integration_service.get_learned_rules_from_rl_agent(agent_id)
        
        if 'error' not in result:
            return jsonify({
                'success': True,
                'learned_rules': result,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@integration_api.route('/crewai/agent_status', methods=['GET'])
def get_agent_status_for_crewai():
    """
    Get the status of RL agents for CrewAI monitoring.
    
    Query parameters:
    - agent_id: ID of the RL agent (optional, returns all if not specified)
    """
    try:
        agent_id = request.args.get('agent_id')
        
        if agent_id:
            # Get specific agent status
            import requests
            response = requests.get(
                f"{integration_service.rl_agent_base_url}/api/rl/agents/{agent_id}",
                timeout=10
            )
            
            if response.status_code == 200:
                agent_info = response.json()
                
                # Add training status
                training_status_response = requests.get(
                    f"{integration_service.rl_agent_base_url}/api/rl/agents/{agent_id}/training/status",
                    timeout=10
                )
                
                if training_status_response.status_code == 200:
                    training_status = training_status_response.json()
                    agent_info['training_status'] = training_status
                
                return jsonify({
                    'success': True,
                    'agent_status': agent_info,
                    'timestamp': datetime.now().isoformat()
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Agent {agent_id} not found'
                }), 404
        
        else:
            # Get all agents status
            import requests
            response = requests.get(
                f"{integration_service.rl_agent_base_url}/api/rl/agents",
                timeout=10
            )
            
            if response.status_code == 200:
                agents_info = response.json()
                return jsonify({
                    'success': True,
                    'agents_status': agents_info,
                    'timestamp': datetime.now().isoformat()
                })
            else:
                return jsonify({
                    'success': False,
                    'error': 'Failed to retrieve agents status'
                }), 500
                
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@integration_api.route('/crewai/backtest', methods=['POST'])
def run_backtest_for_crewai():
    """
    Run a backtest for CrewAI agents.
    
    Expected payload:
    {
        "agent_id": "main_rl_agent",
        "start_date": "2023-01-01",
        "end_date": "2023-12-31",
        "requester_agent": "Performance Analyst Agent"
    }
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['agent_id', 'start_date', 'end_date']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Run backtest via RL agent API
        import requests
        response = requests.post(
            f"{integration_service.rl_agent_base_url}/api/rl/agents/{data['agent_id']}/backtest",
            json={
                'start_date': data['start_date'],
                'end_date': data['end_date']
            },
            timeout=60
        )
        
        if response.status_code == 200:
            backtest_result = response.json()
            
            # Format result for CrewAI
            formatted_result = {
                'success': True,
                'backtest_results': backtest_result['backtest_results'],
                'requester_agent': data.get('requester_agent', 'Unknown Agent'),
                'timestamp': datetime.now().isoformat()
            }
            
            return jsonify(formatted_result)
        else:
            return jsonify({
                'success': False,
                'error': f'Backtest failed: {response.text}'
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@integration_api.route('/crewai/predict', methods=['POST'])
def get_prediction_for_crewai():
    """
    Get action prediction from RL agent for CrewAI.
    
    Expected payload:
    {
        "agent_id": "main_rl_agent",
        "observation": [...],  # Market observation array
        "deterministic": true,
        "requester_agent": "Timing Agent"
    }
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['agent_id', 'observation']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Get prediction via RL agent API
        import requests
        response = requests.post(
            f"{integration_service.rl_agent_base_url}/api/rl/agents/{data['agent_id']}/predict",
            json={
                'observation': data['observation'],
                'deterministic': data.get('deterministic', True)
            },
            timeout=30
        )
        
        if response.status_code == 200:
            prediction_result = response.json()
            
            # Format result for CrewAI
            formatted_result = {
                'success': True,
                'prediction': prediction_result,
                'requester_agent': data.get('requester_agent', 'Unknown Agent'),
                'timestamp': datetime.now().isoformat()
            }
            
            return jsonify(formatted_result)
        else:
            return jsonify({
                'success': False,
                'error': f'Prediction failed: {response.text}'
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@integration_api.route('/crewai/market_regime_signal', methods=['POST'])
def send_market_regime_signal():
    """
    Send market regime change signal to RL agent.
    
    Expected payload:
    {
        "agent_id": "main_rl_agent",
        "regime": "trending",  # trending, sideways, volatile, etc.
        "confidence": 0.8,
        "indicators": {
            "vix": 25.5,
            "trend_strength": 0.7
        },
        "source_agent": "Macroeconomy Specialist Agent"
    }
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['agent_id', 'regime', 'source_agent']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create feedback data for market regime
        feedback_data = FeedbackData(
            feedback_type='market_regime',
            feedback_data={
                'regime': data['regime'],
                'confidence': data.get('confidence', 0.5),
                'indicators': data.get('indicators', {}),
                'timestamp': datetime.now().isoformat()
            },
            source_agent=data['source_agent'],
            timestamp=datetime.now().isoformat(),
            confidence=data.get('confidence', 0.5)
        )
        
        # Send feedback to RL agent
        result = integration_service.send_feedback_to_rl_agent(
            agent_id=data['agent_id'],
            feedback_data=feedback_data
        )
        
        if 'error' not in result:
            return jsonify({
                'success': True,
                'message': 'Market regime signal sent successfully',
                'result': result,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500


@integration_api.route('/crewai/performance_feedback', methods=['POST'])
def send_performance_feedback():
    """
    Send performance feedback to RL agent from CrewAI Risk Assessment Agent.
    
    Expected payload:
    {
        "agent_id": "main_rl_agent",
        "performance_metrics": {
            "sharpe_ratio": 1.5,
            "max_drawdown": 0.08,
            "total_return": 0.15,
            "volatility": 0.12,
            "win_rate": 0.65
        },
        "benchmark_comparison": {
            "outperformance": 0.05,
            "correlation": 0.7
        },
        "source_agent": "Risk Assessment Agent"
    }
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['agent_id', 'performance_metrics', 'source_agent']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create feedback data for performance
        feedback_data = FeedbackData(
            feedback_type='performance',
            feedback_data={
                'performance_metrics': data['performance_metrics'],
                'benchmark_comparison': data.get('benchmark_comparison', {}),
                'timestamp': datetime.now().isoformat()
            },
            source_agent=data['source_agent'],
            timestamp=datetime.now().isoformat(),
            confidence=0.9  # High confidence for performance metrics
        )
        
        # Send feedback to RL agent
        result = integration_service.send_feedback_to_rl_agent(
            agent_id=data['agent_id'],
            feedback_data=feedback_data
        )
        
        if 'error' not in result:
            return jsonify({
                'success': True,
                'message': 'Performance feedback sent successfully',
                'result': result,
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

