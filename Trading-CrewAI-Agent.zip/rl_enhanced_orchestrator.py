"""
Enhanced Orchestrator Agent with RL Integration
Extension of the existing OrchestratorAgent to include RL feedback and weight management
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import json

from agents.orchestrator_agent import OrchestratorAgent
from integration.crewai_rl_bridge import CrewAIRLBridge, StrategyData, PerformanceMetrics, WeightUpdate


class RLEnhancedOrchestratorAgent(OrchestratorAgent):
    """
    Enhanced Orchestrator Agent with RL integration capabilities
    
    Extends the base OrchestratorAgent with:
    - RL feedback processing
    - Dynamic weight management
    - Strategy validation through RL
    - Performance tracking integration
    - Adaptive agent coordination
    """
    
    def __init__(self, registry, debug: bool = False, use_llm: bool = True, 
                 rl_bridge_url: str = "http://localhost:5000"):
        super().__init__(registry, debug, use_llm)
        
        # RL Integration components
        self.rl_bridge = CrewAIRLBridge(rl_agent_url=rl_bridge_url)
        self.agent_weights = {}  # Dynamic weights from RL
        self.performance_history = []
        self.strategy_cache = {}
        self.learning_enabled = True
        
        # Enhanced logging
        self.logger = logging.getLogger("RLEnhancedOrchestratorAgent")
        self.logger.info("RL Enhanced Orchestrator Agent initialized")
        
        # Performance tracking
        self.strategy_performance = {}
        self.agent_contribution_scores = {}
        
    async def initialize_rl_integration(self):
        """Initialize RL integration bridge"""
        try:
            await self.rl_bridge.start()
            self.logger.info("RL integration initialized successfully")
            
            # Load existing agent weights
            await self._load_initial_weights()
            
        except Exception as e:
            self.logger.error(f"Failed to initialize RL integration: {e}")
            self.learning_enabled = False
    
    async def _load_initial_weights(self):
        """Load initial agent weights from RL or defaults"""
        try:
            # Try to get existing weights from RL
            weight_updates = await self.rl_bridge.get_weight_updates()
            if weight_updates:
                self.agent_weights = weight_updates.agent_weights
                self.logger.info(f"Loaded RL weights: {self.agent_weights}")
            else:
                # Use default equal weights
                agents = self.registry.get_active_agents()
                self.agent_weights = {agent.agent_id: 1.0 for agent in agents}
                self.logger.info("Using default equal weights")
                
        except Exception as e:
            self.logger.error(f"Error loading weights: {e}")
            # Fallback to equal weights
            agents = self.registry.get_active_agents()
            self.agent_weights = {agent.agent_id: 1.0 for agent in agents}
    
    async def handle_user_query_with_rl(self, user_query: str) -> str:
        """
        Enhanced query handling with RL integration
        
        Process flow:
        1. Route query to appropriate agents (with weight consideration)
        2. Collect agent responses
        3. Create strategy data
        4. Validate strategy with RL (if applicable)
        5. Synthesize final response
        6. Track performance for RL feedback
        """
        try:
            self.logger.info(f"Processing query with RL integration: {user_query}")
            
            # Step 1: Enhanced routing with weights
            agent_names = await self._route_with_weights(user_query)
            
            if not agent_names or agent_names == ["GeneralAgent"]:
                # Handle general queries directly
                response = await self.get_llm_response(user_query)
                self.update_memory(user_query, response)
                return response
            
            # Step 2: Collect weighted agent responses
            agent_responses = await self._collect_weighted_responses(user_query, agent_names)
            
            # Step 3: Create strategy if applicable
            strategy_data = await self._extract_strategy_from_responses(
                user_query, agent_responses, agent_names
            )
            
            # Step 4: RL strategy validation (if strategy detected)
            if strategy_data and self.learning_enabled:
                validated_strategy = await self._validate_strategy_with_rl(strategy_data)
                if validated_strategy:
                    strategy_data = validated_strategy
            
            # Step 5: Synthesize final response
            final_response = await self._synthesize_response_with_rl(
                user_query, agent_responses, strategy_data
            )
            
            # Step 6: Track for performance feedback
            await self._track_interaction(user_query, agent_names, final_response, strategy_data)
            
            self.update_memory(user_query, final_response)
            return final_response
            
        except Exception as e:
            self.logger.error(f"Error in RL-enhanced query handling: {e}")
            # Fallback to standard processing
            return await super().handle_user_query(user_query)
    
    async def _route_with_weights(self, user_query: str) -> List[str]:
        """Route query considering agent weights from RL"""
        if self.use_llm:
            agent_names = await self.route_to_agents_llm(user_query)
        else:
            agent_names = self.route_to_agents(user_query)
        
        # Apply weight-based filtering/prioritization
        if agent_names and self.agent_weights:
            # Sort agents by weight (highest first)
            weighted_agents = []
            for agent_name in agent_names:
                weight = self.agent_weights.get(agent_name, 1.0)
                weighted_agents.append((agent_name, weight))
            
            # Sort by weight and filter low-weight agents
            weighted_agents.sort(key=lambda x: x[1], reverse=True)
            
            # Keep agents with weight > threshold (0.5)
            filtered_agents = [name for name, weight in weighted_agents if weight > 0.5]
            
            self.logger.info(f"Weighted routing: {dict(weighted_agents)} -> {filtered_agents}")
            return filtered_agents if filtered_agents else agent_names
        
        return agent_names
    
    async def _collect_weighted_responses(self, user_query: str, agent_names: List[str]) -> Dict[str, Any]:
        """Collect responses with weight consideration"""
        responses = {}
        action = "process_query"
        data = {"query": user_query}
        
        for agent_name in agent_names:
            try:
                weight = self.agent_weights.get(agent_name, 1.0)
                
                # Construct message
                a2a_message = self.construct_message(agent_name, action, data)
                
                # Send message and get response
                response = await self.send_message_async(a2a_message)
                
                if response:
                    # Weight the response confidence
                    if isinstance(response, dict) and 'confidence' in response:
                        response['weighted_confidence'] = response['confidence'] * weight
                    
                    responses[agent_name] = response
                    
                    # Track agent contribution
                    self.agent_contribution_scores[agent_name] = \
                        self.agent_contribution_scores.get(agent_name, 0) + weight
                
                self.logger.info(f"Response from {agent_name} (weight: {weight}): {response}")
                
            except Exception as e:
                self.logger.error(f"Error getting response from {agent_name}: {e}")
                continue
        
        return responses
    
    async def _extract_strategy_from_responses(self, user_query: str, 
                                               agent_responses: Dict[str, Any], 
                                               agent_names: List[str]) -> Optional[StrategyData]:
        """Extract strategy data from agent responses for RL validation"""
        try:
            # Check if this is a strategy-related query
            strategy_keywords = ['strategy', 'trade', 'buy', 'sell', 'invest', 'recommendation']
            is_strategy_query = any(keyword in user_query.lower() for keyword in strategy_keywords)
            
            if not is_strategy_query:
                return None
            
            # Extract strategy components from responses
            signals = {}
            risk_parameters = {}
            confidence_scores = []
            symbol = "GENERAL"  # Default, extract from query if possible
            
            # Extract symbol from query
            import re
            symbol_match = re.search(r'\b([A-Z]{1,5})\b', user_query.upper())
            if symbol_match:
                symbol = symbol_match.group(1)
            
            # Process each agent response
            for agent_name, response in agent_responses.items():
                if isinstance(response, dict):
                    # Extract signals
                    if 'signals' in response:
                        signals.update(response['signals'])
                    
                    # Extract risk parameters
                    if 'risk_parameters' in response:
                        risk_parameters.update(response['risk_parameters'])
                    
                    # Extract confidence
                    if 'confidence' in response:
                        confidence_scores.append(response['confidence'])
                    elif 'weighted_confidence' in response:
                        confidence_scores.append(response['weighted_confidence'])
            
            # Calculate overall confidence
            overall_confidence = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0.5
            
            # Create strategy data
            strategy = StrategyData(
                symbol=symbol,
                timeframe="1D",  # Default, could be extracted from query
                strategy_type="multi_agent",
                signals=signals,
                risk_parameters=risk_parameters or {"stop_loss": 0.02, "take_profit": 0.05},
                confidence=overall_confidence,
                generated_by=agent_names
            )
            
            self.logger.info(f"Extracted strategy: {strategy}")
            return strategy
            
        except Exception as e:
            self.logger.error(f"Error extracting strategy: {e}")
            return None
    
    async def _validate_strategy_with_rl(self, strategy: StrategyData) -> Optional[StrategyData]:
        """Validate and potentially optimize strategy with RL agent"""
        try:
            self.logger.info(f"Validating strategy with RL: {strategy.symbol}")
            
            # Send strategy to RL for validation
            validation_result = await self.rl_bridge.send_strategy_for_validation(strategy)
            
            if validation_result and validation_result.get('status') == 'success':
                # Update strategy with RL recommendations
                if 'optimized_parameters' in validation_result:
                    strategy.risk_parameters.update(validation_result['optimized_parameters'])
                
                if 'confidence_adjustment' in validation_result:
                    strategy.confidence *= validation_result['confidence_adjustment']
                
                self.logger.info(f"Strategy validated and optimized by RL")
                return strategy
            else:
                self.logger.warning(f"RL validation failed or not recommended: {validation_result}")
                return strategy  # Return original strategy
                
        except Exception as e:
            self.logger.error(f"Error in RL strategy validation: {e}")
            return strategy  # Return original strategy on error
    
    async def _synthesize_response_with_rl(self, user_query: str, 
                                           agent_responses: Dict[str, Any], 
                                           strategy_data: Optional[StrategyData]) -> str:
        """Synthesize final response incorporating RL insights"""
        try:
            # Start with standard synthesis
            base_response = await self.synthesize_responses(agent_responses)
            
            # Add RL insights if available
            if strategy_data and self.learning_enabled:
                rl_insights = await self.rl_bridge.get_learning_insights()
                
                if rl_insights:
                    # Incorporate RL insights into response
                    rl_section = "\n\n🧠 **AI Learning Insights:**\n"
                    
                    if 'market_regime' in rl_insights:
                        rl_section += f"- Current market regime: {rl_insights['market_regime']}\n"
                    
                    if 'strategy_recommendation' in rl_insights:
                        rl_section += f"- Strategy recommendation: {rl_insights['strategy_recommendation']}\n"
                    
                    if 'risk_assessment' in rl_insights:
                        rl_section += f"- Risk assessment: {rl_insights['risk_assessment']}\n"
                    
                    if 'confidence_level' in rl_insights:
                        rl_section += f"- Confidence level: {rl_insights['confidence_level']:.2f}\n"
                    
                    base_response += rl_section
            
            return base_response
            
        except Exception as e:
            self.logger.error(f"Error in RL response synthesis: {e}")
            return await self.synthesize_responses(agent_responses)
    
    async def _track_interaction(self, user_query: str, agent_names: List[str], 
                                 response: str, strategy_data: Optional[StrategyData]):
        """Track interaction for performance feedback"""
        try:
            interaction_data = {
                "timestamp": datetime.now(),
                "user_query": user_query,
                "agent_names": agent_names,
                "response_length": len(response),
                "strategy_generated": strategy_data is not None,
                "agent_weights": {name: self.agent_weights.get(name, 1.0) for name in agent_names}
            }
            
            # Store for future performance analysis
            self.performance_history.append(interaction_data)
            
            # Keep only last 100 interactions
            if len(self.performance_history) > 100:
                self.performance_history = self.performance_history[-100:]
            
            self.logger.info(f"Interaction tracked: {len(self.performance_history)} total interactions")
            
        except Exception as e:
            self.logger.error(f"Error tracking interaction: {e}")
    
    async def send_performance_feedback_to_rl(self, strategy_id: str, metrics: Dict[str, float]):
        """Send performance feedback to RL agent"""
        try:
            if not self.learning_enabled:
                return False
            
            # Create performance metrics object
            performance_metrics = PerformanceMetrics(
                strategy_id=strategy_id,
                total_return=metrics.get('total_return', 0.0),
                sharpe_ratio=metrics.get('sharpe_ratio', 0.0),
                max_drawdown=metrics.get('max_drawdown', 0.0),
                win_rate=metrics.get('win_rate', 0.0),
                avg_trade_duration=metrics.get('avg_trade_duration', 0.0),
                total_trades=metrics.get('total_trades', 0),
                agent_contributions=self.agent_contribution_scores.copy()
            )
            
            # Send to RL agent
            success = await self.rl_bridge.send_performance_feedback(performance_metrics)
            
            if success:
                self.logger.info(f"Performance feedback sent for strategy {strategy_id}")
                # Clear contribution scores
                self.agent_contribution_scores.clear()
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error sending performance feedback: {e}")
            return False
    
    async def update_weights_from_rl(self):
        """Check for and apply weight updates from RL agent"""
        try:
            if not self.learning_enabled:
                return False
            
            weight_updates = await self.rl_bridge.get_weight_updates()
            
            if weight_updates:
                # Apply weight updates
                self.agent_weights.update(weight_updates.agent_weights)
                
                self.logger.info(f"Applied RL weight updates: {weight_updates.agent_weights}")
                self.logger.info(f"RL reasoning: {weight_updates.reasoning}")
                
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error updating weights from RL: {e}")
            return False
    
    async def notify_rl_regime_change(self, regime_data: Dict[str, Any]):
        """Notify RL agent of market regime changes"""
        try:
            if not self.learning_enabled:
                return False
            
            success = await self.rl_bridge.notify_regime_change(regime_data)
            
            if success:
                self.logger.info(f"Notified RL of regime change: {regime_data}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error notifying regime change: {e}")
            return False
    
    async def get_system_health(self) -> Dict[str, Any]:
        """Get comprehensive system health including RL integration"""
        try:
            # Base health check
            base_health = {
                "orchestrator": True,
                "agent_count": len(self.registry.get_active_agents()),
                "memory_size": len(self.memory),
                "performance_history": len(self.performance_history)
            }
            
            # RL health check
            if self.learning_enabled:
                rl_health = await self.rl_bridge.health_check()
                base_health.update(rl_health)
            else:
                base_health["rl_agent"] = False
                base_health["advisory_agent"] = True
                base_health["bridge"] = False
            
            # Agent weights status
            base_health["agent_weights"] = self.agent_weights
            base_health["learning_enabled"] = self.learning_enabled
            
            return base_health
            
        except Exception as e:
            self.logger.error(f"Error getting system health: {e}")
            return {"status": "error", "message": str(e)}
    
    async def shutdown(self):
        """Clean shutdown of enhanced orchestrator"""
        try:
            if self.rl_bridge:
                await self.rl_bridge.stop()
            self.logger.info("RL Enhanced Orchestrator Agent shutdown complete")
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")


# Example usage
async def main():
    """Example usage of RLEnhancedOrchestratorAgent"""
    from agent_registry import agent_registry
    
    # Create enhanced orchestrator
    orchestrator = RLEnhancedOrchestratorAgent(
        registry=agent_registry,
        debug=True,
        use_llm=True
    )
    
    try:
        # Initialize RL integration
        await orchestrator.initialize_rl_integration()
        
        # Test query processing
        test_query = "What's your analysis on AAPL for a swing trading strategy?"
        response = await orchestrator.handle_user_query_with_rl(test_query)
        print(f"Response: {response}")
        
        # Check system health
        health = await orchestrator.get_system_health()
        print(f"System health: {health}")
        
    finally:
        await orchestrator.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
