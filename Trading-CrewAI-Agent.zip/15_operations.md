# Operations

---

## Architecture deployment modes

| Mode | When to use | Key differences |
|------|------------|-----------------|
| **Local / development** | Single developer, paper trading | All services in one process; no Redis required |
| **Docker Compose** | Testing full stack locally | Each service in a container; Redis included |
| **Distributed** | Production-like deployment | Advisory API, RL worker, and Redis on separate hosts |

---

## Local startup (no Docker)

```powershell
# 1. Activate environment
.\crewenv\Scripts\Activate.ps1

# 2. Start the advisory API
python main_advisory_agent/main.py
# → Listening on http://localhost:8000

# 3. (Optional) Start the agent worker
python integration/agent_worker.py
# → Consuming advisory.* Redis streams
```

Check logs in `logs/` — each component writes to `logs/<component>.log`.

---

## Docker Compose

### Services

`docker-compose.yml` defines:

| Service | Port | Description |
|---------|------|-------------|
| `advisory_agent` | 8000 | Main advisory API (`main_advisory_agent/Dockerfile`) |
| `redis` | 6379 | Redis 7 (Alpine) for EventBus |
| `agent_worker` | — | Background consumer (`integration/agent_worker.py`) |

### Commands

```bash
# Start all services
docker-compose up -d

# Start only advisory API + Redis
docker-compose up -d advisory_agent redis

# View logs
docker-compose logs -f advisory_agent

# Stop all
docker-compose down

# Rebuild after code change
docker-compose build advisory_agent
docker-compose up -d advisory_agent
```

### Environment

Docker Compose reads `.env` automatically. Copy `.env.example` and fill in values
before running.

---

## Health and readiness

### Advisory API health check

```bash
curl http://localhost:8000/health
# {"status": "ok", "ibkr_connected": false, "memory_available": true}
```

Response fields:

| Field | Description |
|-------|-------------|
| `status` | `"ok"` or `"degraded"` |
| `ibkr_connected` | `true` when IBKR paper account is reachable |
| `memory_available` | `true` when LanceDB is accessible |
| `checkpoint_db` | `true` when SQLite persistence file exists |

### System monitor

`system_monitor.py` — standalone script that polls all services and prints status:

```bash
python system_monitor.py
```

---

## Startup sequence (full stack)

```
1. Redis starts (Docker or local redis-server)
2. advisory_agent starts:
     a. Loads .env
     b. Initialises MemoryStore (LanceDB)
     c. Opens SQLite checkpoint DB
     d. Attempts IBKR connect (if IB_ENABLED=1)
     e. Loads RLAgentV2 checkpoint (if ENABLE_RL_VALIDATION_V2=1)
     f. Starts FastAPI / uvicorn
3. agent_worker starts:
     a. Connects to Redis
     b. Creates consumer groups if absent
     c. Starts consuming advisory streams
```

If any optional service (Redis, IBKR, LanceDB) fails to start, the advisory API
continues in **degraded mode** — it logs a warning but remains available.

---

## Persistent data directories

| Path | Content | Managed by |
|------|---------|-----------|
| `data/advisory_checkpoints.db` | SQLite: flow checkpoints + approvals | `SQLiteFlowPersistence` |
| `data/memory/lancedb/` | LanceDB vector tables | `MemoryStore` |
| `data/pta_paper_state.json` | Legacy paper trading state | `PaperTradingAgent` (unused in main path) |
| `logs/` | Application logs | Python `logging` |
| `hf_models/` | Local HuggingFace model weights | Git LFS / manual download |
| `checkpoints/` | Trained RL v2 `.zip` files | `RLAgentV2.save()` |

---

## Troubleshooting

### IBKR not connecting

```
ERROR agents.ibkr_portfolio_service:connect failed: Connection refused
```

Checklist:
- TWS is running and logged in
- Socket port matches `IB_PORT` (default 7497)
- "Enable ActiveX and Socket Clients" checked in TWS API settings
- `IB_ENABLED=1` in `.env`
- Only one client connecting with the same `IB_CLIENT_ID`

### `ib_insync not installed`

```
ERROR agents.ibkr_portfolio_service: ib_insync not installed
```

Install with: `pip install ib_insync`

### LanceDB errors on first run

LanceDB tables are created automatically on the first write. If you see:

```
FileNotFoundError: [WinError 3] Cannot find path 'data/memory/lancedb'
```

Create the directory manually: `mkdir -p data/memory/lancedb`

### RL checkpoint not loading

```
WARNING analysis_crew_builder: RL v2 checkpoint not found at <path>
```

Either train a new model (see [RL Agent v2 — Training](09_rl_agent_v2.md#training-pipeline))
or set `ENABLE_RL_VALIDATION_V2=0`.

### Redis connection refused

```
redis.exceptions.ConnectionError: Error 10061 connecting to localhost:6379
```

Redis is optional. Set `REDIS_URL=` empty or don't start `agent_worker`.
The advisory API functions without Redis.

### CrewAI verbose output filling logs

Set `ADVISORY_VERBOSE=0` (default). Only set to `1` for debugging.

### PowerShell NativeCommandError after tests

Not a real failure. Python `unittest` writes to stderr. Check the output for
`"Ran N tests in ... OK"` to confirm success.

---

## Log locations

| Component | Log file |
|-----------|---------|
| Advisory agent | `logs/advisory_agent.log` |
| Agent worker | `logs/agent_worker.log` |
| E2E agent | `logs/e2e_agent/` |
| Trade strategy planner | `logs/trade_strategy_planner/` |
| PID tracking | `logs/pids.json` |

Log format (JSON):

```json
{
    "timestamp": "2025-01-15T10:30:00.123Z",
    "level": "INFO",
    "logger": "main_advisory_agent.advisory_flow",
    "message": "Flow:synthesis_step | conv=conv_abc | synthesis_len=1240",
    "conversation_id": "conv_abc",
    "step": "synthesis_step",
    "duration_ms": 4521.3
}
```

---

## Upgrading dependencies

```powershell
# View current package versions
pip list | Select-String "crewai|langchain|openai|ib_insync|stable"

# Upgrade CrewAI
pip install --upgrade "crewai==1.14.5"

# Never modify pyproject.toml by hand — use pip or uv
```

Note: CrewAI Flow API is pinned to **1.14.5**. Do not upgrade without reviewing
breaking changes in `CHANGELOG.md` — the `@start`, `@listen`, `@router` decorators
and `SQLiteFlowPersistence` API may change between minor versions.
