# Testing

---

## Test suite overview

| Phase | Script | Tests | Coverage |
|-------|--------|-------|---------|
| Phase 0 | `scripts/test_advisory_flow_topology.py` | 17 | `AdvisoryFlow` topology, state transitions, router, fallback |
| Phase 1 | `scripts/test_market_crews.py` | 26 | `MarketCrewBuilder`, `GlobalMarketRouter`, intent detection |
| Phase 2 | `scripts/test_mcp_data_layer.py` | 18 | MCP data tools, `build_data_tools`, Alpha Vantage stubs |
| Phase 3 | `scripts/test_analysis_crew.py` | 20 | `AnalysisCrewBuilder`, `rl_a2a_validate` v1/v2, annotation format |
| Phase 4 | `scripts/test_execution_crew.py` | 55 | `ExecutionCrewBuilder`, `PortfolioActionGuard`, `AdvisoryApprovalProvider` |
| Phase 5 | `scripts/test_memory_system.py` | 51 | `MemoryStore`, all four memory hooks, LanceDB round-trips |
| Phase 6 | `scripts/test_flow_persistence.py` | 41 | `SQLiteFlowPersistence`, checkpoint/resume, expiry |
| RL v2 | `scripts/test_rl_v2.py` | 68 | `risk_metrics`, `RegimeClassifier`, `PortfolioTradingEnv`, `RLAgentV2` |
| **Total** | | **296** | |

---

## Running tests

### Individual phase

```powershell
# Activate environment first
.\crewenv\Scripts\Activate.ps1

# Run a single phase
python scripts/test_advisory_flow_topology.py   # Phase 0
python scripts/test_market_crews.py             # Phase 1
python scripts/test_mcp_data_layer.py           # Phase 2
python scripts/test_analysis_crew.py            # Phase 3
python scripts/test_execution_crew.py           # Phase 4
python scripts/test_memory_system.py            # Phase 5
python scripts/test_flow_persistence.py         # Phase 6
python scripts/test_rl_v2.py                    # RL v2
```

### All phases sequentially

```powershell
foreach ($s in @(
    "test_advisory_flow_topology",
    "test_market_crews",
    "test_mcp_data_layer",
    "test_analysis_crew",
    "test_execution_crew",
    "test_memory_system",
    "test_flow_persistence",
    "test_rl_v2"
)) {
    python "scripts/$s.py"
}
```

### Expected output format

```
test_something (TestClassName) ... ok
test_another (TestClassName) ... ok
----------------------------------------------------------------------
Ran 41 tests in 2.34s

OK
```

PowerShell may print a `NativeCommandError` on exit code 1 even when all tests pass.
This is because Python's `unittest` writes summaries to stderr. Check for "OK" in the
output — not for the PowerShell exit code.

---

## Phase 0 — Advisory flow topology (17 tests)

**File**: `scripts/test_advisory_flow_topology.py`

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_flow_initialises` | `AdvisoryFlow` instantiates without error |
| `test_state_defaults` | `AdvisoryFlowState` has correct default values |
| `test_market_router_general` | Router returns `"market_analysis"` for general queries |
| `test_market_router_portfolio` | Router returns `"portfolio_gate"` for orders |
| `test_market_router_resume` | Router returns `"advisory_execution_resume"` when pending |
| `test_fallback_crew_runs` | Phase 0 fallback Crew executes and returns string |
| `test_disclaimer_appended` | Disclaimer is appended when `ADVISORY_APPEND_DISCLAIMER=1` |

---

## Phase 1 — Market Crews (26 tests)

**File**: `scripts/test_market_crews.py`

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_detect_markets_in` | `"Reliance"` → `["IN"]` |
| `test_detect_markets_us` | `"Apple stock"` → `["US"]` |
| `test_detect_markets_crypto` | `"Bitcoin"` → `["CRYPTO"]` |
| `test_market_crew_builds` | `build_market_crew` returns a `Crew` with agents and tasks |
| `test_parallel_markets` | `asyncio.gather` executes multiple markets without error |
| `test_result_schema` | Each market result has `raw`, `market` keys |

---

## Phase 2 — MCP data layer (18 tests)

**File**: `scripts/test_mcp_data_layer.py`

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_build_data_tools_returns_list` | `build_data_tools()` returns non-empty list |
| `test_stock_quote_tool` | `StockQuoteTool.run(...)` returns dict with price |
| `test_technical_tool_rsi` | `TechnicalIndicatorTool.rsi(...)` returns float in [0, 100] |
| `test_tools_injected_into_crew` | Market crew agents have data tools in their `.tools` list |

---

## Phase 3 — Analysis Crew (20 tests)

**File**: `scripts/test_analysis_crew.py`

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_analysis_crew_builds` | `AnalysisCrewBuilder.build(...)` returns `Crew` |
| `test_rl_validate_passthrough` | `rl_a2a_validate` returns synthesis unchanged on timeout |
| `test_rl_v2_annotation_format` | Annotation block contains regime, positions table, risk table |
| `test_no_trade_override_warning` | Warning block added when `no_trade_override=True` |

---

## Phase 4 — Execution Crew & Approval (55 tests)

**File**: `scripts/test_execution_crew.py`

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_guard_blocks_oversized_order` | Order exceeding `max_order_risk_fraction` is rejected |
| `test_guard_allows_valid_order` | Valid small order passes guard |
| `test_approval_create_and_approve` | Full create → approve cycle succeeds |
| `test_approval_expiry` | Expired entry rejected by `expire_old_entries` |
| `test_approval_reject` | Rejected entry has status `REJECTED` |
| `test_execution_crew_builds` | `ExecutionCrewBuilder.build(...)` returns `Crew` |
| `test_two_pass_advisory_approval` | First pass returns draft; second pass runs `ExecutionCrew` |

---

## Phase 5 — Memory system (51 tests)

**File**: `scripts/test_memory_system.py`

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_remember_and_recall_market` | Write + vector search returns the same record |
| `test_recall_filters_by_market` | Query for `"US"` does not return `"IN"` records |
| `test_remember_synthesis` | Synthesis round-trips through LanceDB |
| `test_remember_trade_execution` | Execution text is stored and searchable |
| `test_hooks_silent_on_error` | All hooks return gracefully when `MemoryStore` is `None` |

---

## Phase 6 — Flow persistence (41 tests)

**File**: `scripts/test_flow_persistence.py`

Key test cases:

| Test | What it verifies |
|------|-----------------|
| `test_persist_and_load_full_cycle` | Save + load round-trips state intact |
| `test_resume_skips_market_analysis` | Flow skips Phase 1 when checkpoint at Phase 1 exists |
| `test_resume_skips_synthesis` | Flow skips Phases 1+3 when checkpoint at Phase 3 exists |
| `test_persist_silent_on_failure` | DB write failure is caught; flow continues |
| `test_wal_mode_enabled` | `PRAGMA journal_mode` returns `wal` |
| `test_concurrent_writes` | Two threads with different UUIDs don't conflict |

---

## RL v2 (68 tests)

**File**: `scripts/test_rl_v2.py`

| Group | Tests | Key scenarios |
|-------|-------|---------------|
| `risk_metrics` | 13 | Sharpe (normal/zero-std), max_drawdown, VaR, CVaR, turnover, Calmar, reward formula |
| `regime_classifier` | 10 | BULL/BEAR/SIDEWAYS/HIGH_VOL detection, min-persistence filter, multi-asset majority vote |
| `portfolio_env` | 8 | Observation shape, action clipping, drawdown kill-switch, mock-data mode |
| `rl_agent_v2` | 8 | Construct, save/load, validate_strategy (mock policy), no-trade override trigger |
| Integration | 29 | End-to-end train → checkpoint → validate cycle; annotation injection |

---

## Test isolation

- All tests use **in-memory SQLite** for approval store and checkpoints
- LanceDB uses a **temp directory** (`tmp_path` fixture)
- `ib_insync` and `stable_baselines3` are **gracefully skipped** if not installed
- External API calls are **mocked** using `unittest.mock.patch`

---

## Adding new tests

1. Create `scripts/test_<component>.py`
2. Use `unittest.TestCase` (consistent with existing suite)
3. Add a brief comment block at the top describing which source files are covered
4. Run the full suite before committing to ensure no regressions
