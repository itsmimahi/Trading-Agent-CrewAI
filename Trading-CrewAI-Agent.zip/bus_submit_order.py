"""
Tiny helper to submit a PTA order over Redis Streams and print the reply.

Usage (PowerShell):
  $env:REDIS_URL="redis://localhost:6379/0"
  python scripts/bus_submit_order.py --symbol RELIANCE.NS --side buy --quantity 1

Optionally include approval:
  python scripts/bus_submit_order.py --symbol RELIANCE.NS --side buy --quantity 1 --approval-id <UUID>
  # or pass --approved to set the approved flag directly on the message

Environment:
  REDIS_URL redis connection string (default redis://localhost:6379/0)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys

# Ensure project root on path
ROOT = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(ROOT)
if ROOT not in sys.path:
    sys.path.append(ROOT)

try:
    from integration.event_bus import RedisStreamsEventBus
except Exception as e:
    print(json.dumps({"success": False, "error": f"Import error: {e}"}))
    raise


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", required=True)
    p.add_argument("--side", required=True, choices=["buy", "sell"])
    p.add_argument("--quantity", type=int, required=True)
    p.add_argument("--approval-id")
    p.add_argument("--approved", action="store_true")
    p.add_argument("--timeout-ms", type=int, default=10000)
    args = p.parse_args()

    bus = RedisStreamsEventBus()
    payload = {"symbol": args.symbol, "side": args.side, "quantity": args.quantity}
    if args.approved:
        payload["approved"] = True
    if args.approval_id:
        payload["approval_id"] = args.approval_id

    try:
        resp = await bus.request("pta:orders_submit", payload, timeout_ms=args.timeout_ms)
        print(json.dumps(resp))
    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
    finally:
        try:
            await bus.stop()
        except Exception:
            pass


if __name__ == "__main__":
    asyncio.run(main())
