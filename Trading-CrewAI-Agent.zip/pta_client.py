import os
import json
from typing import Any, Dict

try:
    import requests  # type: ignore
except Exception:  # pragma: no cover
    requests = None  # type: ignore

from crewai.tools import BaseTool


class PTAClientTool(BaseTool):
    """Client tool for the Paper Trading Agent (PTA) service.
    Actions:
      - holdings: GET /portfolio/holdings
      - margins: GET /portfolio/margins
      - last_price: GET /market/last_price/<symbol>
      - update_price: POST /market/update_price {symbol, price}
      - preview_order: POST /orders/preview {symbol, side, quantity}
      - submit_order: POST /orders/submit {symbol, side, quantity, idempotency_key?}
      - list_orders: GET /orders/orders
    """

    name: str = "pta_client_tool"
    description: str = "Interact with the Paper Trading Agent for read-only portfolio and paper order operations"

    def _run(self, action: str, **kwargs) -> str:
        if requests is None:
            return json.dumps({"error": "requests library not available"})

        base_url = os.getenv("PTA_BASE_URL", "http://localhost:8090").rstrip('/')
        timeout_s = float(os.getenv("PTA_TIMEOUT", "10"))

        try:
            if action == "holdings":
                r = requests.get(f"{base_url}/portfolio/holdings", timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            if action == "margins":
                r = requests.get(f"{base_url}/portfolio/margins", timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            if action == "last_price":
                symbol = str(kwargs.get("symbol", "")).upper()
                if not symbol:
                    return json.dumps({"error": "symbol required"})
                r = requests.get(f"{base_url}/market/last_price/{symbol}", timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            if action == "metrics":
                r = requests.get(f"{base_url}/portfolio/metrics", timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            if action == "update_price":
                symbol = str(kwargs.get("symbol", "")).upper()
                price = kwargs.get("price")
                if not symbol or price is None:
                    return json.dumps({"error": "symbol and price required"})
                r = requests.post(f"{base_url}/market/update_price", json={"symbol": symbol, "price": price}, timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            if action == "preview_order":
                payload = {
                    "symbol": str(kwargs.get("symbol", "")).upper(),
                    "side": str(kwargs.get("side", "")).lower(),
                    "quantity": int(kwargs.get("quantity", 0)),
                }
                r = requests.post(f"{base_url}/orders/preview", json=payload, timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            if action == "submit_order":
                payload = {
                    "symbol": str(kwargs.get("symbol", "")).upper(),
                    "side": str(kwargs.get("side", "")).lower(),
                    "quantity": int(kwargs.get("quantity", 0)),
                }
                idem = kwargs.get("idempotency_key")
                if idem:
                    payload["idempotency_key"] = str(idem)
                r = requests.post(f"{base_url}/orders/submit", json=payload, timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            if action == "list_orders":
                r = requests.get(f"{base_url}/orders/orders", timeout=timeout_s)
                return r.text if r.ok else json.dumps({"error": r.text, "status": r.status_code})

            return json.dumps({"error": f"unknown action: {action}"})
        except Exception as e:  # pragma: no cover
            return json.dumps({"error": str(e), "action": action})
