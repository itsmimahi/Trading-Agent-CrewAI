from flask import Blueprint, jsonify, request, current_app

adapter_bp = Blueprint('adapter', __name__)


@adapter_bp.route('/status', methods=['GET'])
def status():
    adapter = current_app.config.get('MARKET_ADAPTER')
    info = None
    try:
        info = adapter.info() if adapter else None
    except Exception:
        info = None
    return jsonify({
        'broker': current_app.config.get('BROKER'),
        'adapter': info
    })


@adapter_bp.route('/connect', methods=['POST'])
def connect():
    adapter = current_app.config.get('MARKET_ADAPTER')
    if not adapter:
        return jsonify({'error': 'adapter not configured'}), 400
    try:
        ok = adapter.ws_connect()
        return jsonify({'connected': bool(ok), 'adapter': adapter.info()})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@adapter_bp.route('/subscribe', methods=['POST'])
def subscribe():
    adapter = current_app.config.get('MARKET_ADAPTER')
    if not adapter:
        return jsonify({'error': 'adapter not configured'}), 400
    data = request.get_json(force=True) or {}
    symbols = data.get('symbols') or []
    if not isinstance(symbols, list) or not symbols:
        return jsonify({'error': 'symbols must be a non-empty list'}), 400
    try:
        added = []
        # Prefer adapter-provided mapping/subscription if available
        if hasattr(adapter, 'add_subscription_symbols'):
            try:
                added = adapter.add_subscription_symbols([str(s).upper() for s in symbols])  # type: ignore[attr-defined]
            except Exception:
                added = []
        # Always warm cache with a one-off poll
        for s in symbols:
            try:
                adapter.poll_price(str(s).upper())
            except Exception:
                pass
        # Try connecting WS if not already connected
        try:
            info_before = adapter.info() or {}
            if not info_before.get('ws'):
                adapter.ws_connect()
        except Exception:
            pass
        return jsonify({'subscribed': added, 'adapter': adapter.info()})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
