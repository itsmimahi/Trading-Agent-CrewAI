"""
PTA EventBus Worker
Bridges Redis Streams (A2A) to the Paper Trading Agent (PTA) HTTP API.
This lets agents communicate over the bus for low-latency, resilient A2A,
while the Web UI and external callers keep using HTTP.

Streams (request -> reply_to):
- pta:get_holdings          -> returns {cash, holdings[]}
- pta:get_margins           -> returns {available, used, net}
- pta:last_price            -> expects {symbol} -> {symbol, last_price}
- pta:subscribe             -> expects {symbols: [..]} -> {subscribed: [...]} (best-effort)
- pta:orders_preview        -> expects {symbol, side, quantity} -> preview payload
- pta:orders_submit         -> expects {symbol, side, quantity, idempotency_key?} -> order result
- pta:orders_list           -> returns [orders]

Usage:
  REDIS_URL=redis://localhost:6379/0 PTA_URL=http://localhost:8090 python -m paper_trading_agent.pta_event_worker

Notes:
- This worker proxies to PTA HTTP to reuse the same in-memory state and idempotency.
- If PTA_URL is unreachable, handlers reply with success=False and an error message.
"""
from __future__ import annotations

import asyncio
import logging
import os
import json
from datetime import datetime, time
from typing import Any, Dict, Optional

import requests

# Ensure project root on path for integration.event_bus
import sys
import pathlib
ROOT_DIR = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

try:
    from integration.event_bus import RedisStreamsEventBus
except Exception as e:  # pragma: no cover
    raise RuntimeError(f"Cannot import EventBus. Ensure project root is on PYTHONPATH. Details: {e}")

# Use central logging config if available; fall back to basicConfig
try:
    _root = pathlib.Path(__file__).resolve().parents[1]
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location("logging_config", str(_root / "config" / "logging_config.py"))
    _lmod = _ilu.module_from_spec(_spec)  # type: ignore[arg-type]
    _spec.loader.exec_module(_lmod)  # type: ignore[union-attr]
    _lmod.setup_logging()
except Exception:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)-8s] %(name)s — %(message)s")

log = logging.getLogger("PTABusWorker")


class PTABusWorker:
    def __init__(self, *, bus: RedisStreamsEventBus, pta_url: Optional[str] = None):
        self.bus = bus
        self.pta_url = (pta_url or os.environ.get("PTA_URL") or os.environ.get("PTA_BASE_URL") or "http://localhost:8090").rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': 'PTA-Bus-Worker/1.0'})
        self.timeout = int(os.environ.get("PTA_HTTP_TIMEOUT", "15"))
        # Approval gating
        self.enforce_maa_approval = str(os.environ.get("ENFORCE_MAA_APPROVAL", "true")).lower() in {"1", "true", "yes", "on"}
        self.maa_base_url = (os.environ.get("MAA_BASE_URL") or os.environ.get("ADVISORY_BASE_URL") or "http://localhost:8000").rstrip("/")

    # Safety helpers
    def _log_event(self, level: int, event: str, **fields: object) -> None:
        try:
            rec = {"event": event, **fields}
            log.log(level, json.dumps(rec))
        except Exception:
            # Fall back to plain text
            log.log(level, f"{event} {fields}")

    def _within_trading_window(self) -> bool:
    # DEV MODE: Always allow trading window
        return True

    def _symbol_allowed(self, symbol: str) -> bool:
    # DEV MODE: Always allow all symbols
        return True

    def _max_qty_ok(self, qty: int) -> bool:
        v = os.environ.get('PTA_MAX_ORDER_QTY')
        if not v:
            return True
        try:
            limit = int(v)
            return int(qty) <= limit
        except Exception:
            return True

    # Helpers
    def _reply(self, msg: Dict[str, Any], payload: Dict[str, Any]):
        reply_to = msg.get("reply_to")
        corr = msg.get("correlation_id")
        out = {**payload, "correlation_id": corr}
        if reply_to:
            self.bus.publish(reply_to, out)

    def start(self) -> None:
        # Portfolio
        try:
            self.bus.start_consumer(stream="pta:get_holdings", group="pta-worker-group", consumer_name=None, handler=self._h_get_holdings, concurrency=1)
            log.info("Subscribed: pta:get_holdings")
        except Exception as e:
            log.exception(f"Subscribe failed: pta:get_holdings - {e}")
        try:
            self.bus.start_consumer(stream="pta:get_margins", group="pta-worker-group", consumer_name=None, handler=self._h_get_margins, concurrency=1)
            log.info("Subscribed: pta:get_margins")
        except Exception as e:
            log.exception(f"Subscribe failed: pta:get_margins - {e}")
        # Market
        try:
            self.bus.start_consumer(stream="pta:last_price", group="pta-worker-group", consumer_name=None, handler=self._h_last_price, concurrency=1)
            log.info("Subscribed: pta:last_price")
        except Exception as e:
            log.exception(f"Subscribe failed: pta:last_price - {e}")
        try:
            self.bus.start_consumer(stream="pta:subscribe", group="pta-worker-group", consumer_name=None, handler=self._h_subscribe, concurrency=1)
            log.info("Subscribed: pta:subscribe")
        except Exception as e:
            log.exception(f"Subscribe failed: pta:subscribe - {e}")
        # Orders
        try:
            self.bus.start_consumer(stream="pta:orders_preview", group="pta-worker-group", consumer_name=None, handler=self._h_orders_preview, concurrency=1)
            log.info("Subscribed: pta:orders_preview")
        except Exception as e:
            log.exception(f"Subscribe failed: pta:orders_preview - {e}")
        try:
            self.bus.start_consumer(stream="pta:orders_submit", group="pta-worker-group", consumer_name=None, handler=self._h_orders_submit, concurrency=1)
            log.info("Subscribed: pta:orders_submit")
        except Exception as e:
            log.exception(f"Subscribe failed: pta:orders_submit - {e}")
        try:
            self.bus.start_consumer(stream="pta:orders_list", group="pta-worker-group", consumer_name=None, handler=self._h_orders_list, concurrency=1)
            log.info("Subscribed: pta:orders_list")
        except Exception as e:
            log.exception(f"Subscribe failed: pta:orders_list - {e}")
        log.info("PTABusWorker started. Listening on a2a:pta:* streams")

    # Handlers
    def _h_get_holdings(self, msg: Dict[str, Any]):
        try:
            log.info("Handling pta:get_holdings request")
            r = self.session.get(f"{self.pta_url}/portfolio/holdings", timeout=self.timeout)
            ok = r.ok
            data = r.json() if ok else {"error": f"HTTP {r.status_code}"}
            self._reply(msg, {"success": ok, **({"data": data} if ok else data)})
        except Exception as e:
            self._reply(msg, {"success": False, "error": str(e)})

    def _h_get_margins(self, msg: Dict[str, Any]):
        try:
            r = self.session.get(f"{self.pta_url}/portfolio/margins", timeout=self.timeout)
            ok = r.ok
            data = r.json() if ok else {"error": f"HTTP {r.status_code}"}
            self._reply(msg, {"success": ok, **({"data": data} if ok else data)})
        except Exception as e:
            self._reply(msg, {"success": False, "error": str(e)})

    def _h_last_price(self, msg: Dict[str, Any]):
        symbol = (msg.get("symbol") or msg.get("data", {}).get("symbol") or "").upper()
        if not symbol:
            self._reply(msg, {"success": False, "error": "symbol required"})
            return
        try:
            r = self.session.get(f"{self.pta_url}/market/last_price/{symbol}", timeout=self.timeout)
            ok = r.ok
            data = r.json() if ok else {"error": f"HTTP {r.status_code}"}
            self._reply(msg, {"success": ok, **({"data": data} if ok else data)})
        except Exception as e:
            self._reply(msg, {"success": False, "error": str(e)})

    def _h_subscribe(self, msg: Dict[str, Any]):
        symbols = msg.get("symbols") or msg.get("data", {}).get("symbols") or []
        if not isinstance(symbols, list) or not symbols:
            self._reply(msg, {"success": False, "error": "symbols must be a non-empty list"})
            return
        try:
            r = self.session.post(f"{self.pta_url}/adapter/subscribe", json={"symbols": symbols}, timeout=self.timeout)
            ok = r.ok
            data = r.json() if ok else {"error": f"HTTP {r.status_code}"}
            self._reply(msg, {"success": ok, **({"data": data} if ok else data)})
        except Exception as e:
            self._reply(msg, {"success": False, "error": str(e)})

    def _h_orders_preview(self, msg: Dict[str, Any]):
        payload = msg.get("data") or msg
        try:
            body = {
                "symbol": str(payload.get("symbol", "")).upper(),
                "side": str(payload.get("side", "")).lower(),
                "quantity": int(payload.get("quantity", 0)),
            }
            r = self.session.post(f"{self.pta_url}/orders/preview", json=body, timeout=self.timeout)
            ok = r.ok
            data = r.json() if ok else {"error": f"HTTP {r.status_code}"}
            self._reply(msg, {"success": ok, **({"data": data} if ok else data)})
        except Exception as e:
            self._reply(msg, {"success": False, "error": str(e)})

    def _h_orders_submit(self, msg: Dict[str, Any]):
        payload = msg.get("data") or msg
        try:
            log.info(f"Handling pta:orders_submit corr={msg.get('correlation_id')}")
            # Basic validation and safety limiters at bus boundary
            symbol = str(payload.get("symbol", "")).upper()
            side = str(payload.get("side", "")).lower()
            try:
                quantity = int(payload.get("quantity", 0))
            except Exception:
                quantity = 0
            if not symbol or side not in {"buy", "sell"} or quantity <= 0:
                self._log_event(logging.WARNING, "order_violation", reason="invalid_params", symbol=symbol, side=side, quantity=quantity, corr=msg.get("correlation_id"))
                self._reply(msg, {"success": False, "error": "invalid_params", "details": "symbol, side in {buy|sell}, quantity>0 required", "symbol": symbol, "side": side, "quantity": quantity})
                return
            if not self._symbol_allowed(symbol):
                self._log_event(logging.WARNING, "order_violation", reason="symbol_not_allowed", symbol=symbol, side=side, quantity=quantity, corr=msg.get("correlation_id"), whitelist=os.environ.get("PTA_SYMBOL_WHITELIST"))
                self._reply(msg, {"success": False, "error": "symbol_not_allowed", "details": "symbol not in whitelist", "symbol": symbol})
                return
            if not self._max_qty_ok(quantity):
                self._log_event(logging.WARNING, "order_violation", reason="qty_exceeds_limit", symbol=symbol, side=side, quantity=quantity, corr=msg.get("correlation_id"), max_qty=os.environ.get("PTA_MAX_ORDER_QTY"))
                self._reply(msg, {"success": False, "error": "qty_exceeds_limit", "details": "quantity exceeds max limit", "quantity": quantity, "max_qty": os.environ.get("PTA_MAX_ORDER_QTY")})
                return
            if not self._within_trading_window():
                self._log_event(logging.WARNING, "order_violation", reason="outside_trading_window", symbol=symbol, side=side, quantity=quantity, corr=msg.get("correlation_id"), window=os.environ.get("PTA_TRADING_WINDOW"))
                self._reply(msg, {"success": False, "error": "outside_trading_window", "details": "outside trading window", "window": os.environ.get("PTA_TRADING_WINDOW")})
                return
            # Enforce MAA approval (if enabled)
            if self.enforce_maa_approval:
                approved_flag = bool(payload.get("approved")) or bool(payload.get("approval", {}).get("approved"))
                approval_id = payload.get("approval_id") or payload.get("approval", {}).get("id")
                # Correlation id may be on root message
                corr_id = msg.get("correlation_id") or payload.get("correlation_id")

                if not approved_flag:
                    ok = False
                    reason = "Approval flag missing"
                    # Try verifying approval_id with MAA REST
                    if approval_id:
                        try:
                            r = self.session.get(f"{self.maa_base_url}/api/approvals/{approval_id}", timeout=self.timeout)
                            if r.ok:
                                st = (r.json() or {}).get("status")
                                ok = (st == "approved")
                                reason = None if ok else f"Approval status={st}"
                            else:
                                reason = f"MAA HTTP {r.status_code}"
                        except Exception as e:
                            reason = f"MAA verify error: {e}"
                    # Optionally try correlation id lookup when provided (best-effort)
                    if not ok and corr_id and approval_id:
                        # already tried above; skip
                        pass

                    if not (approved_flag or ok):
                        self._log_event(logging.WARNING, "order_violation", reason="approval_required", symbol=symbol, side=side, quantity=quantity, corr=corr_id, approval_id=approval_id)
                        self._reply(msg, {"success": False, "error": "approval_required", "details": reason or "Approval missing/invalid", "correlation_id": corr_id, "approval_id": approval_id})
                        return

            body = {
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
            }
            if payload.get("idempotency_key"):
                body["idempotency_key"] = payload["idempotency_key"]
            r = self.session.post(f"{self.pta_url}/orders/submit", json=body, timeout=self.timeout)
            ok = r.ok
            data = r.json() if ok else {"error": f"HTTP {r.status_code}"}
            self._reply(msg, {"success": ok, **({"data": data} if ok else data)})
        except Exception as e:
            self._reply(msg, {"success": False, "error": str(e)})

    def _h_orders_list(self, msg: Dict[str, Any]):
        try:
            r = self.session.get(f"{self.pta_url}/orders/orders", timeout=self.timeout)
            ok = r.ok
            data = r.json() if ok else {"error": f"HTTP {r.status_code}"}
            self._reply(msg, {"success": ok, **({"data": data} if ok else data)})
        except Exception as e:
            self._reply(msg, {"success": False, "error": str(e)})


async def main():
    bus = RedisStreamsEventBus()
    worker = PTABusWorker(bus=bus)
    worker.start()
    try:
        while True:
            await asyncio.sleep(60)
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        await bus.stop()


if __name__ == "__main__":
    asyncio.run(main())
