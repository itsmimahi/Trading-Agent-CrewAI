"""
Enhanced Macro-Economic Agent using CrewAI Framework - Hybrid Plus Approach
Combines quantitative macro analysis with LLM reasoning for comprehensive economic insights.
"""

import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import requests
import json
from dataclasses import dataclass

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from config.settings import get_settings
from crewai import Task, Crew, Process

@dataclass
class MacroIndicator:
    """Macro-economic indicator structure"""
    name: str
    value: float
    previous_value: float
    change: float
    change_percent: float
    importance: str
    trend: str
    impact: str

class EnhancedMacroAgent(EnhancedBaseAgent):
    """Enhanced Macro Economic Agent using CrewAI Framework with comprehensive economic analysis capabilities."""
    
    memory = None
    async def analyze(self, timeframe: str = "1month") -> Dict[str, Any]:
        """
        Main analysis method for macro agent, delegates to analyze_macro_environment.
        """
        return await self.analyze_macro_environment(timeframe)

    async def mathematical_analysis(self, timeframe: str = "1month", data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Perform mathematical/quantitative macro analysis for a given timeframe.
        """
        return await self._analyze_key_indicators(timeframe)
    """
    Enhanced Macro-Economic Agent with Hybrid Plus approach.
    Combines quantitative macro analysis with LLM reasoning for comprehensive economic insights.
    """
    
    def __init__(self, name: str = "EnhancedMacroAgent", description: str = "Macro-Economic Agent for comprehensive macroeconomic analysis and insights", role: str = "Macro-Economic Analysis Specialist", goal: str = "Provide comprehensive macroeconomic analysis combining quantitative models with economic intelligence", backstory: str = "Expert economist with deep knowledge of macroeconomic indicators and their market implications", capabilities: Optional[List[Any]] = None, **kwargs):
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.TREND_ANALYSIS,
                AgentCapability.PATTERN_RECOGNITION,
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.CONTEXTUAL_REASONING
            ]
        
        super().__init__(name=name, description=description, capabilities=capabilities, role=role, goal=goal, backstory=backstory, **kwargs)
        
        self.settings = get_settings()
        self.rbi_base_url = "https://www.rbi.org.in"
        self.economic_indicators = {
            'usd_inr': 'USDINR=X',
            'india_vix': '^NSEBANK',
            'crude_oil': 'CL=F',
            'gold': 'GC=F',
            'us_10y': '^TNX',
            'india_bonds': '000001.BO'
        }
        
        # Initialize specialized tools
        self._initialize_macro_tools()
        
        # Macro analysis prompt template
        self.macro_analysis_prompt = """
        You are an expert macroeconomic analyst with access to comprehensive economic data and indicators.
        
        Current Economic Indicators:
        {economic_indicators}
        
        Currency and Commodity Analysis:
        {currency_commodity_data}
        
        Interest Rate Environment:
        {interest_rate_data}
        
        Inflation and Growth Metrics:
        {inflation_growth_data}
        
        Global Economic Context:
        {global_context}
        
        Based on this quantitative analysis, provide:
        1. Economic Environment Assessment - Overall economic condition and phase
        2. Key Risk Factors - Major economic risks and opportunities
        3. Sector Impact Analysis - How macro trends affect different sectors
        4. Investment Implications - Specific guidance for investment decisions
        5. Timing Considerations - Best and worst times for different strategies
        6. Policy Impact Analysis - How government/RBI policies affect markets
        
        Consider:
        - Current economic cycle phase
        - Inflation trends and central bank policy
        - Global economic interconnections
        - Sector rotation implications
        - Currency impact on investments
        - Geopolitical considerations
        
        Provide actionable insights that combine economic theory with practical market implications.
        """

    def _initialize_macro_tools(self):
        """Initialize macro-economic specific tools"""
        tools = [
            AgentTool(
                name="analyze_economic_indicators",
                description="Analyze key economic indicators and their trends",
                function=self._analyze_economic_indicators,
                parameters={"indicators": ["gdp", "inflation", "interest_rates", "employment"]}
            ),
            AgentTool(
                name="currency_analysis",
                description="Analyze currency trends and their market impact",
                function=self._analyze_currency_trends,
                parameters={"currencies": ["USD/INR", "EUR/INR", "GBP/INR"]}
            ),
            AgentTool(
                name="commodity_analysis",
                description="Analyze commodity trends and their economic impact",
                function=self._analyze_commodity_trends,
                parameters={"commodities": ["crude_oil", "gold", "silver", "copper"]}
            ),
            AgentTool(
                name="interest_rate_analysis",
                description="Analyze interest rate environment and policy implications",
                function=self._analyze_interest_rates,
                parameters={"include_yield_curve": True, "global_comparison": True}
            ),
            AgentTool(
                name="inflation_analysis",
                description="Analyze inflation trends and their market implications",
                function=self._analyze_inflation_trends,
                parameters={"components": ["core", "food", "fuel"], "historical_comparison": True}
            )
        ]
        
        for tool in tools:
            self.tools.append(tool)


    async def analyze_macro_environment(self, timeframe: str = "1month") -> Dict[str, Any]:
        """
        Perform comprehensive macro-economic analysis using CrewAI Hybrid Plus approach.
        
        Args:
            timeframe: Analysis timeframe ('1week', '1month', '3month', '6month')
            
        Returns:
            Dict containing comprehensive macro-economic analysis
        """
        try:
            self.logger.info(f"Starting CrewAI enhanced macro analysis for {timeframe}")
            
            # Step 1: Quantitative Economic Analysis
            economic_indicators = await self._analyze_key_indicators(timeframe)
            
            # Step 2: Currency and Commodity Analysis
            currency_commodity_data = await self._analyze_currency_commodities(timeframe)
            
            # Step 3: Interest Rate Environment
            interest_rate_data = await self._analyze_interest_rate_environment(timeframe)
            
            # Step 4: Inflation and Growth Analysis
            inflation_growth_data = await self._analyze_inflation_growth(timeframe)
            
            # Step 5: Global Economic Context
            global_context = await self._analyze_global_context(timeframe)
            
            # Step 6: CrewAI-based Macro Interpretation
            crewai_analysis = await self._get_llm_macro_analysis(
                economic_indicators=economic_indicators,
                currency_commodity_data=currency_commodity_data,
                interest_rate_data=interest_rate_data,
                inflation_growth_data=inflation_growth_data,
                global_context=global_context
            )
            
            # Step 7: Combine quantitative and qualitative analysis
            comprehensive_analysis = {
                "timeframe": timeframe,
                "timestamp": datetime.now().isoformat(),
                "economic_indicators": economic_indicators,
                "currency_commodity_analysis": currency_commodity_data,
                "interest_rate_environment": interest_rate_data,
                "inflation_growth_analysis": inflation_growth_data,
                "global_context": global_context,
                "crewai_analysis": crewai_analysis,
                "macro_score": self._calculate_macro_score(economic_indicators, crewai_analysis),
                "investment_implications": self._generate_investment_implications(crewai_analysis)
            }
            
            # Store in memory for learning
            await self._store_analysis_in_memory(comprehensive_analysis)
            
            return comprehensive_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI macro analysis: {str(e)}")
            return self._get_default_macro_result(timeframe)

    async def _analyze_key_indicators(self, timeframe: str) -> Dict[str, Any]:
        """Analyze key economic indicators quantitatively"""
        try:
            indicators = {}
            
            # Simulate economic indicator data (in real implementation, fetch from APIs)
            # GDP Growth Rate
            indicators["gdp_growth"] = {
                "current": 6.5,  # Simulated current GDP growth
                "previous": 6.2,
                "trend": "improving",
                "impact": "positive"
            }
            
            # CPI Inflation
            indicators["cpi_inflation"] = {
                "current": 5.8,  # Simulated current CPI
                "previous": 6.1,
                "trend": "declining",
                "impact": "positive"
            }
            
            # Industrial Production
            indicators["industrial_production"] = {
                "current": 4.2,  # Simulated IP growth
                "previous": 3.8,
                "trend": "improving",
                "impact": "positive"
            }
            
            # Calculate composite economic health score
            health_score = self._calculate_economic_health_score(indicators)
            indicators["economic_health_score"] = health_score
            
            return indicators
            
        except Exception as e:
            self.logger.error(f"Error analyzing key indicators: {str(e)}")
            return {}

    async def _analyze_currency_commodities(self, timeframe: str) -> Dict[str, Any]:
        """Analyze currency and commodity trends"""
        try:
            analysis = {}
            
            # Currency Analysis (USD/INR)
            # In real implementation, fetch from forex API
            analysis["usd_inr"] = {
                "current_rate": 83.25,  # Simulated
                "monthly_change": -0.8,
                "volatility": 2.1,
                "trend": "strengthening_inr",
                "impact_on_stocks": "positive"
            }
            
            # Crude Oil Analysis
            analysis["crude_oil"] = {
                "current_price": 85.50,  # Simulated
                "monthly_change": -3.2,
                "volatility": 15.8,
                "trend": "declining",
                "impact_on_inflation": "positive"
            }
            
            # Gold Analysis
            analysis["gold"] = {
                "current_price": 62500,  # Simulated INR per 10g
                "monthly_change": 2.1,
                "volatility": 8.5,
                "trend": "rising",
                "safe_haven_demand": "moderate"
            }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error analyzing currency/commodities: {str(e)}")
            return {}

    async def _analyze_interest_rate_environment(self, timeframe: str) -> Dict[str, Any]:
        """Analyze interest rate environment and policy implications"""
        try:
            analysis = {}
            
            # RBI Policy Rate
            analysis["repo_rate"] = {
                "current": 6.50,  # Simulated
                "previous": 6.25,
                "last_change": 0.25,
                "policy_stance": "neutral",
                "next_meeting": "2024-02-08"
            }
            
            # Government Bond Yields
            analysis["10y_bond_yield"] = {
                "current": 7.15,  # Simulated
                "monthly_change": 0.05,
                "spread_to_policy": 0.65,
                "trend": "stable"
            }
            
            # Yield Curve Analysis
            analysis["yield_curve"] = {
                "shape": "normal",
                "steepness": 1.2,
                "inversion_risk": "low",
                "implication": "healthy_growth_expectations"
            }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error analyzing interest rates: {str(e)}")
            return {}

    async def _analyze_inflation_growth(self, timeframe: str) -> Dict[str, Any]:
        """Analyze inflation and growth dynamics"""
        try:
            analysis = {}
            
            # Inflation Components
            analysis["inflation_breakdown"] = {
                "core_cpi": 4.2,  # Simulated
                "food_inflation": 7.8,
                "fuel_inflation": 3.5,
                "services_inflation": 5.1,
                "trend": "moderating"
            }
            
            # Growth Momentum
            analysis["growth_momentum"] = {
                "consumption_growth": 5.8,  # Simulated
                "investment_growth": 4.2,
                "export_growth": 3.1,
                "government_spending": 6.5,
                "overall_trend": "steady"
            }
            
            # Real vs Nominal Growth
            analysis["real_vs_nominal"] = {
                "nominal_gdp_growth": 11.2,  # Simulated
                "real_gdp_growth": 6.5,
                "gdp_deflator": 4.7,
                "quality": "good"
            }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error analyzing inflation/growth: {str(e)}")
            return {}

    async def _analyze_global_context(self, timeframe: str) -> Dict[str, Any]:
        """Analyze global economic context affecting Indian markets"""
        try:
            analysis = {}
            
            # US Economic Indicators
            analysis["us_economy"] = {
                "gdp_growth": 2.4,  # Simulated
                "inflation": 3.2,
                "fed_rate": 5.25,
                "employment": 3.7,
                "impact_on_india": "moderate"
            }
            
            # China Economic Indicators
            analysis["china_economy"] = {
                "gdp_growth": 5.2,  # Simulated
                "pmi": 49.8,
                "trade_impact": "moderate",
                "commodity_demand": "steady"
            }
            
            # Global Risk Factors
            analysis["global_risks"] = {
                "geopolitical_tension": "moderate",
                "trade_wars": "low",
                "climate_risks": "moderate",
                "cyber_security": "moderate",
                "overall_risk_level": "moderate"
            }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error analyzing global context: {str(e)}")
            return {}

    async def _get_llm_macro_analysis(self, **kwargs) -> Dict[str, Any]:
        """Get CrewAI-based macro-economic analysis and interpretation"""
        try:
            # Format the prompt with all the quantitative data
            macro_analysis_prompt = f"""
            You are an expert macroeconomic analyst with access to comprehensive economic data and indicators.
            
            Current Economic Indicators:
            {kwargs.get('economic_indicators', {})}
            
            Currency and Commodity Analysis:
            {kwargs.get('currency_commodity_data', {})}
            
            Interest Rate Environment:
            {kwargs.get('interest_rate_data', {})}
            
            Inflation and Growth Metrics:
            {kwargs.get('inflation_growth_data', {})}
            
            Global Economic Context:
            {kwargs.get('global_context', {})}
            
            Based on this quantitative analysis, provide:
            1. Economic Environment Assessment - Overall economic condition and phase
            2. Key Risk Factors - Major economic risks and opportunities
            3. Sector Impact Analysis - How macro trends affect different sectors
            4. Investment Implications - Specific guidance for investment decisions
            5. Timing Considerations - Best and worst times for different strategies
            6. Policy Impact Analysis - How government/RBI policies affect markets
            
            Consider:
            - Current economic cycle phase
            - Inflation trends and central bank policy
            - Global economic interconnections
            - Sector rotation implications
            - Currency impact on investments
            - Geopolitical considerations
            
            Provide actionable insights that combine economic theory with practical market implications.
            """
            
            # Use CrewAI agent for analysis
            task = Task(
                description=macro_analysis_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive macroeconomic analysis with actionable insights"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            analysis = self._parse_crewai_macro_response(str(result))
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI macro analysis: {str(e)}")
            return {"error": str(e)}

    def _parse_llm_macro_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response into structured macro analysis"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            # Split response into sections
            sections = response.split('\n\n')
            parsed_analysis = {
                "economic_environment": "",
                "key_risks_opportunities": "",
                "sector_impact": "",
                "investment_implications": "",
                "timing_considerations": "",
                "policy_impact": ""
            }
            current_section = None
            for section in sections:
                if "Economic Environment Assessment" in section:
                    current_section = "economic_environment"
                elif "Key Risk Factors" in section:
                    current_section = "key_risks_opportunities"
                elif "Sector Impact Analysis" in section:
                    current_section = "sector_impact"
                elif "Investment Implications" in section:
                    current_section = "investment_implications"
                elif "Timing Considerations" in section:
                    current_section = "timing_considerations"
                elif "Policy Impact Analysis" in section:
                    current_section = "policy_impact"
                elif current_section and section.strip():
                    parsed_analysis[current_section] = section.strip()
            
            return parsed_analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing LLM response: {str(e)}")
            return {"raw_response": response}

    def _parse_crewai_macro_response(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI response into structured macro analysis"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Simple parsing for now, assuming a clear structure
            # This can be enhanced with more sophisticated NLP/LLM parsing
            sections = response.split('\n\n')
            parsed_analysis = {
                "economic_environment": "",
                "key_risks_opportunities": "",
                "sector_impact": "",
                "investment_implications": "",
                "timing_considerations": "",
                "policy_impact": ""
            }
            
            for section in sections:
                if "Economic Environment Assessment" in section:
                    parsed_analysis["economic_environment"] = section.strip()
                elif "Key Risk Factors" in section:
                    parsed_analysis["key_risks_opportunities"] = section.strip()
                elif "Sector Impact Analysis" in section:
                    parsed_analysis["sector_impact"] = section.strip()
                elif "Investment Implications" in section:
                    parsed_analysis["investment_implications"] = section.strip()
                elif "Timing Considerations" in section:
                    parsed_analysis["timing_considerations"] = section.strip()
                elif "Policy Impact Analysis" in section:
                    parsed_analysis["policy_impact"] = section.strip()
            
            return parsed_analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI response: {str(e)}")
            return {"raw_response": response}

    def _calculate_economic_health_score(self, indicators: Dict) -> float:
        """Calculate composite economic health score"""
        try:
            score = 50  # Base score
            
            # GDP Growth contribution
            gdp_growth = indicators.get("gdp_growth", {}).get("current", 0)
            if gdp_growth > 6:
                score += 15
            elif gdp_growth > 4:
                score += 10
            else:
                score += 5
            
            # Inflation contribution (target around 4-6%)
            inflation = indicators.get("cpi_inflation", {}).get("current", 0)
            if 4 <= inflation <= 6:
                score += 15
            elif 3 <= inflation <= 7:
                score += 10
            else:
                score += 5
            
            # Industrial Production contribution
            ip_growth = indicators.get("industrial_production", {}).get("current", 0)
            if ip_growth > 4:
                score += 10
            elif ip_growth > 2:
                score += 5
            
            return min(100, max(0, score))
            
        except Exception as e:
            self.logger.error(f"Error calculating economic health score: {str(e)}")
            return 50.0

    def _calculate_macro_score(self, indicators: Dict, crewai_analysis: Dict) -> float:
        """Calculate composite macro score combining quantitative and qualitative factors"""
        try:
            base_score = indicators.get("economic_health_score", 50)
            
            # Adjust based on CrewAI analysis
            qualitative_adjustment = 0
            
            # Parse CrewAI analysis for economic sentiment
            environment = crewai_analysis.get("economic_environment", "").lower()
            if "positive" in environment or "favorable" in environment:
                qualitative_adjustment += 10
            elif "negative" in environment or "challenging" in environment:
                qualitative_adjustment -= 10
            
            # Final score (0-100)
            final_score = max(0, min(100, base_score + qualitative_adjustment))
            
            return final_score
            
        except Exception as e:
            self.logger.error(f"Error calculating macro score: {str(e)}")
            return 50.0

    def _generate_investment_implications(self, crewai_analysis: Dict) -> List[str]:
        """Generate actionable investment implications"""
        implications = []
        
        try:
            # Extract implications from CrewAI analysis
            investment_section = crewai_analysis.get("investment_implications", "")
            
            if investment_section:
                # Split into bullet points or sentences
                points = investment_section.split('.')
                implications.extend([point.strip() for point in points[:3] if point.strip()])
            
            # Add default implications if none found
            if not implications:
                implications = [
                    "Monitor economic indicators for investment timing",
                    "Consider sector rotation based on macro trends",
                    "Maintain diversification across asset classes"
                ]
            
            return implications[:5]  # Return top 5 implications
            
        except Exception as e:
            self.logger.error(f"Error generating investment implications: {str(e)}")
            return ["Monitor macroeconomic developments for investment opportunities"]

    def _get_default_macro_result(self, timeframe: str) -> Dict[str, Any]:
        """Return default macro analysis result when data is unavailable"""
        return {
            "timeframe": timeframe,
            "timestamp": datetime.now().isoformat(),
            "error": "Unable to perform macro analysis due to data limitations",
            "macro_score": 50,
            "investment_implications": ["Manual macro assessment recommended due to data limitations"]
        }

    # Additional tool methods
    async def _analyze_economic_indicators(self, indicators: List[str]) -> Dict[str, Any]:
        """Analyze specific economic indicators"""
        results = {}
        
        for indicator in indicators:
            if indicator == "gdp":
                results[indicator] = {"value": 6.5, "trend": "stable", "impact": "positive"}
            elif indicator == "inflation":
                results[indicator] = {"value": 5.8, "trend": "moderating", "impact": "positive"}
            elif indicator == "interest_rates":
                results[indicator] = {"value": 6.5, "trend": "stable", "impact": "neutral"}
            elif indicator == "employment":
                results[indicator] = {"value": 3.2, "trend": "improving", "impact": "positive"}
        
        return results

    async def _analyze_currency_trends(self, currencies: List[str]) -> Dict[str, Any]:
        """Analyze currency trends and implications"""
        results = {}
        
        for currency in currencies:
            if "USD/INR" in currency:
                results[currency] = {
                    "current_rate": 83.25,
                    "trend": "strengthening_inr",
                    "volatility": "moderate",
                    "impact": "positive_for_stocks"
                }
        
        return results

    async def _analyze_commodity_trends(self, commodities: List[str]) -> Dict[str, Any]:
        """Analyze commodity trends and their economic impact"""
        results = {}
        
        for commodity in commodities:
            if commodity == "crude_oil":
                results[commodity] = {
                    "price": 85.50,
                    "trend": "declining",
                    "impact_on_inflation": "positive"
                }
            elif commodity == "gold":
                results[commodity] = {
                    "price": 62500,
                    "trend": "rising",
                    "safe_haven_demand": "moderate"
                }
        
        return results

    async def _analyze_interest_rates(self, include_yield_curve: bool = True) -> Dict[str, Any]:
        """Analyze interest rate environment"""
        analysis = {
            "policy_rate": 6.50,
            "bond_yield_10y": 7.15,
            "policy_stance": "neutral",
            "rate_cycle": "peak"
        }
        
        if include_yield_curve:
            analysis["yield_curve"] = {
                "shape": "normal",
                "steepness": 1.2,
                "inversion_risk": "low"
            }
        
        return analysis

    async def _analyze_inflation_trends(self, components: List[str]) -> Dict[str, Any]:
        """Analyze inflation trends and components"""
        analysis = {
            "headline_cpi": 5.8,
            "trend": "moderating",
            "target_deviation": 1.8
        }
        
        for component in components:
            if component == "core":
                analysis["core_inflation"] = 4.2
            elif component == "food":
                analysis["food_inflation"] = 7.8
            elif component == "fuel":
                analysis["fuel_inflation"] = 3.5
        
        return analysis
