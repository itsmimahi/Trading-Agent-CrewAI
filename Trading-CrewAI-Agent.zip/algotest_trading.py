import os
import requests
from .trading_base import TradingAdapter
from .shoonya import ShoonyaAdapter # For symbol mapping

class AlgoTestTradingAdapter(TradingAdapter):
    """
    Trading adapter for AlgoTest.in platform.
    Handles order placement and portfolio fetching via AlgoTest API.
    """
    def __init__(self, user_id: str = "user"):
        self.api_key = os.getenv("ALGOTEST_API_KEY")
        self.api_secret = os.getenv("ALGOTEST_API_SECRET")
        self.base_url = "https://api.algotest.in/api/v1" # Assuming v1, adjust if needed
        self.headers = {
            "Content-Type": "application/json",
            "X-API-KEY": self.api_key,
            "X-API-SECRET": self.api_secret
        }
        self._shoonya_mapper = ShoonyaAdapter() # For symbol mapping
        self.is_initialized = self.api_key and self.api_secret

    def info(self) -> dict:
        return {
            "adapter": "AlgoTest",
            "is_initialized": self.is_initialized,
            "mode": "live_paper"
        }

    def place_order(self, symbol: str, side: str, quantity: int, order_type: str = 'MARKET', product: str = 'MIS', price: float = 0, tag: str = 'crewai') -> dict:
        if not self.is_initialized:
            return {"success": False, "error": "AlgoTest adapter not initialized. Check API keys."}

        # AlgoTest might use a different symbol format, map it if needed
        # For now, assuming it takes standard format like 'RELIANCE-EQ'
        broker_symbol = self._shoonya_mapper.get_broker_symbol(symbol) # e.g., RELIANCE.NS -> NSE|RELIANCE-EQ

        payload = {
            "instrument": broker_symbol,
            "transaction_type": side.upper(), # BUY or SELL
            "quantity": quantity,
            "order_type": order_type.upper(),
            "product_type": product.upper(),
            "price": price,
            "tag": tag
        }
        
        try:
            response = requests.post(f"{self.base_url}/orders", headers=self.headers, json=payload)
            response.raise_for_status()
            return {"success": True, "data": response.json()}
        except requests.exceptions.RequestException as e:
            return {"success": False, "error": str(e), "details": e.response.text if e.response else "No response"}

    def list_orders(self) -> dict:
        if not self.is_initialized:
            return {"success": False, "error": "AlgoTest adapter not initialized."}
        
        try:
            response = requests.get(f"{self.base_url}/orders", headers=self.headers)
            response.raise_for_status()
            # Normalize the response to your standard format here if needed
            return {"success": True, "data": response.json()}
        except requests.exceptions.RequestException as e:
            return {"success": False, "error": str(e)}

    def get_positions(self) -> dict:
        if not self.is_initialized:
            return {"success": False, "error": "AlgoTest adapter not initialized."}
            
        try:
            response = requests.get(f"{self.base_url}/positions", headers=self.headers)
            response.raise_for_status()
            # Normalize the response here
            return {"success": True, "data": response.json()}
        except requests.exceptions.RequestException as e:
            return {"success": False, "error": str(e)}

    def get_balance(self) -> dict:
        if not self.is_initialized:
            return {"success": False, "error": "AlgoTest adapter not initialized."}
        
        try:
            # Assuming a /profile or /balance endpoint exists
            response = requests.get(f"{self.base_url}/balance", headers=self.headers)
            response.raise_for_status()
            return {"success": True, "data": response.json()}
        except requests.exceptions.RequestException as e:
            return {"success": False, "error": str(e)}

    def cancel_order(self, order_id: str) -> dict:
        # Implementation for cancelling an order via AlgoTest API
        pass
