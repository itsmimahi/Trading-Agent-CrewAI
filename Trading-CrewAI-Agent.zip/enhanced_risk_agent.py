"""
Enhanced Risk Management Agent using CrewAI Framework - Hybrid Plus Approach
Combines mathematical risk models with LLM reasoning for comprehensive risk analysis.
"""
import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from scipy import stats
import yfinance as yf
from dataclasses import dataclass


from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from config.settings import get_settings
from crewai import Task, Crew, Process

@dataclass
class RiskMetrics:
    """Risk metrics structure"""
    volatility: float
    var_95: float
    var_99: float
    cvar_95: float
    cvar_99: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    beta: float
    alpha: float
    tracking_error: float
    information_ratio: float
    calmar_ratio: float
    risk_score: float

class EnhancedRiskAgent(EnhancedBaseAgent):
    memory = None

    # For compatibility with coordinator and tool registration
    risk_analysis_prompt: str = "Provide a comprehensive risk analysis for the given symbol."

    async def analyze_risk(self, symbol: str) -> dict:
        """Stub for compatibility with coordinator. Calls analyze method."""
        try:
            return await self.analyze(symbol)
        except Exception as e:
            self.logger.error(f"Error in analyze_risk: {e}")
            return {"error": str(e)}

    """
    Enhanced Risk Management Agent using CrewAI Framework with Hybrid Plus approach.
    Combines mathematical risk models with LLM reasoning for comprehensive analysis.
    """
    
    def __init__(self, name: str = "EnhancedRiskAgent", description: str = "Risk Management Agent for comprehensive risk analysis and mitigation strategies", role: str = "Risk Management Specialist", goal: str = "Provide comprehensive risk analysis combining mathematical precision with contextual intelligence", backstory: str = "Expert risk analyst with deep knowledge of financial risk models and market dynamics", capabilities: Optional[List[Any]] = None, weight: float = 0.15, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.RISK_ASSESSMENT,
                AgentCapability.PATTERN_RECOGNITION,
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.CONTEXTUAL_REASONING
            ]
        super().__init__(
            name=name,
            description=description,
            capabilities=capabilities,
            role=role,
            goal=goal,
            backstory=backstory,
            weight=weight,
            use_llm=use_llm,
            use_memory=use_memory,
            use_knowledge_base=use_knowledge_base,
            **kwargs
        )

        self.risk_free_rate = 0.065  # 6.5% - Indian govt bond yield
        self.market_benchmark = '^NSEI'  # Nifty 50 as benchmark

        # Initialize specialized tools
        self._initialize_risk_tools()

    def _initialize_risk_tools(self):
        """Initialize risk-specific tools"""
        tools = [
            AgentTool(
                name="calculate_var",
                description="Calculate Value at Risk using multiple methods",
                function=self._calculate_var,
                parameters={"confidence_levels": [0.95, 0.99], "methods": ["parametric", "historical", "monte_carlo"]}
            ),
            AgentTool(
                name="calculate_risk_metrics",
                description="Calculate comprehensive risk metrics",
                function=self._calculate_comprehensive_risk_metrics,
                parameters={"include_ratios": True, "benchmark_comparison": True}
            ),
            AgentTool(
                name="stress_test",
                description="Perform stress testing under various scenarios",
                function=self._perform_stress_test,
                parameters={"scenarios": ["market_crash", "interest_rate_shock", "sector_rotation"]}
            ),
            AgentTool(
                name="correlation_analysis",
                description="Analyze correlation and concentration risks",
                function=self._analyze_correlations,
                parameters={"include_rolling": True, "time_windows": [30, 60, 252]}
            ),
            AgentTool(
                name="liquidity_analysis",
                description="Assess liquidity risk and market impact",
                function=self._analyze_liquidity,
                parameters={"include_bid_ask": True, "volume_analysis": True}
            )
        ]
        
        for tool in tools:
            self.tools.append(tool)

    async def analyze(self, symbol: str, timeframe: str = "1d") -> Dict[str, Any]:
        """
        Main analysis method combining math and LLM for risk agent.
        """
        # For compatibility, just call analyze_risk with symbol
        return await self.analyze_risk(symbol)

    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform mathematical/quantitative risk analysis for a symbol.
        """
        # For demonstration, call the comprehensive risk metrics calculator
        return await self._calculate_comprehensive_risk_metrics(symbol)

    async def analyze_risk(self, symbol: str, portfolio_data: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Perform comprehensive risk analysis using CrewAI Hybrid Plus approach.
        
        Args:
            symbol: Stock symbol or portfolio identifier
            portfolio_data: Optional portfolio data for portfolio-level analysis
            
        Returns:
            Dict containing comprehensive risk analysis
        """
        try:
            self.logger.info(f"Starting CrewAI enhanced risk analysis for {symbol}")
            
            # Step 1: Mathematical Risk Analysis
            risk_metrics = await self._calculate_comprehensive_risk_metrics(symbol)
            
            # Step 2: Market Context Analysis
            market_context = await self._analyze_market_context()
            
            # Step 3: Portfolio Context (if provided)
            portfolio_context = await self._analyze_portfolio_context(portfolio_data) if portfolio_data else {}
            
            # Step 4: Historical Performance Analysis
            historical_performance = await self._analyze_historical_performance(symbol)
            
            # Step 5: CrewAI-based Risk Interpretation
            crewai_analysis = await self._get_llm_risk_analysis(
                risk_metrics=risk_metrics,
                market_context=market_context,
                portfolio_data=portfolio_context,
                historical_performance=historical_performance
            )
            
            # Step 6: Combine quantitative and qualitative analysis
            comprehensive_analysis = {
                "symbol": symbol,
                "timestamp": datetime.now().isoformat(),
                "quantitative_metrics": risk_metrics,
                "market_context": market_context,
                "portfolio_context": portfolio_context,
                "historical_performance": historical_performance,
                "crewai_analysis": crewai_analysis,
                "risk_score": risk_metrics.get("risk_score"),
                "recommendations": self._generate_risk_recommendations(risk_metrics, crewai_analysis)
            }
            
            # Store in memory for learning
            await self._store_analysis_in_memory(comprehensive_analysis)
            
            return comprehensive_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI risk analysis: {str(e)}")
            return self._get_default_risk_result(symbol)

    async def _calculate_comprehensive_risk_metrics(self, symbol: str) -> Dict[str, Any]:
        """Calculate comprehensive risk metrics using mathematical models"""
        try:
            # Get historical data
            stock_data = await self._get_historical_data(symbol, period="2y")
            market_data = await self._get_historical_data(self.market_benchmark, period="2y")
            
            if stock_data is None or stock_data.empty:
                return {}
            
            # Calculate returns
            stock_returns = stock_data['Close'].pct_change().dropna()
            market_returns = market_data['Close'].pct_change().dropna() if market_data is not None else None
            
            # Basic risk metrics
            volatility = stock_returns.std() * np.sqrt(252)  # Annualized volatility
            
            # Value at Risk (VaR) calculations
            var_95 = np.percentile(stock_returns, 5)
            var_99 = np.percentile(stock_returns, 1)
            
            # Conditional VaR (Expected Shortfall)
            cvar_95 = stock_returns[stock_returns <= var_95].mean()
            cvar_99 = stock_returns[stock_returns <= var_99].mean()
            
            # Maximum Drawdown
            cumulative_returns = (1 + stock_returns).cumprod()
            running_max = cumulative_returns.expanding().max()
            drawdown = (cumulative_returns - running_max) / running_max
            max_drawdown = drawdown.min()
            
            # Risk-adjusted returns
            excess_returns = stock_returns.mean() - (self.risk_free_rate / 252)
            sharpe_ratio = excess_returns / stock_returns.std() * np.sqrt(252)
            
            # Sortino Ratio (downside deviation)
            negative_returns = stock_returns[stock_returns < 0]
            downside_deviation = negative_returns.std() * np.sqrt(252)
            sortino_ratio = (stock_returns.mean() * 252 - self.risk_free_rate) / downside_deviation
            
            # Market-relative metrics
            beta = alpha = tracking_error = information_ratio = 0
            if market_returns is not None and len(market_returns) > 0:
                # Align data
                aligned_data = pd.concat([stock_returns, market_returns], axis=1, join='inner')
                aligned_data.columns = ['stock', 'market']
                
                if len(aligned_data) > 20:  # Minimum data points
                    beta = np.cov(aligned_data['stock'], aligned_data['market'])[0,1] / np.var(aligned_data['market'])
                    alpha = aligned_data['stock'].mean() - beta * aligned_data['market'].mean()
                    tracking_error = (aligned_data['stock'] - aligned_data['market']).std() * np.sqrt(252)
                    information_ratio = alpha / tracking_error if tracking_error > 0 else 0
            
            # Calmar Ratio
            calmar_ratio = (stock_returns.mean() * 252) / abs(max_drawdown) if max_drawdown < 0 else 0
            
            # Calculate overall risk score (0-100, higher = riskier)
            risk_score = min(100, max(0, 
                50 + (volatility - 0.25) * 100 + abs(max_drawdown) * 100 - sharpe_ratio * 10
            ))
            
            return {
                "volatility": float(volatility),
                "var_95": float(var_95),
                "var_99": float(var_99),
                "cvar_95": float(cvar_95),
                "cvar_99": float(cvar_99),
                "sharpe_ratio": float(sharpe_ratio),
                "sortino_ratio": float(sortino_ratio),
                "max_drawdown": float(max_drawdown),
                "beta": float(beta),
                "alpha": float(alpha),
                "tracking_error": float(tracking_error),
                "information_ratio": float(information_ratio),
                "calmar_ratio": float(calmar_ratio),
                "risk_score": float(risk_score),
                "data_quality": {
                    "data_points": len(stock_returns),
                    "time_period": "2 years",
                    "completeness": len(stock_returns) / (2 * 252)
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating risk metrics: {str(e)}")
            return {}

    async def _analyze_market_context(self) -> Dict[str, Any]:
        """Analyze current market context for risk assessment"""
        try:
            # Get market data
            market_data = await self._get_historical_data(self.market_benchmark, period="6mo")
            
            if market_data is None or market_data.empty:
                return {}
            
            # Calculate market volatility
            market_returns = market_data['Close'].pct_change().dropna()
            current_volatility = market_returns.rolling(30).std().iloc[-1] * np.sqrt(252)
            long_term_volatility = market_returns.std() * np.sqrt(252)
            
            # Market trend analysis
            recent_performance = (market_data['Close'].iloc[-1] / market_data['Close'].iloc[-63] - 1) * 100  # 3-month
            
            # VIX proxy (market volatility indicator)
            volatility_regime = "HIGH" if current_volatility > long_term_volatility * 1.5 else \
                              "MODERATE" if current_volatility > long_term_volatility * 1.2 else "LOW"
            
            return {
                "market_volatility": float(current_volatility),
                "volatility_regime": volatility_regime,
                "recent_market_performance": float(recent_performance),
                "market_trend": "BULLISH" if recent_performance > 5 else "BEARISH" if recent_performance < -5 else "NEUTRAL",
                "risk_environment": "HIGH" if volatility_regime == "HIGH" and recent_performance < -10 else "MODERATE"
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing market context: {str(e)}")
            return {}

    async def _analyze_portfolio_context(self, portfolio_data: Dict) -> Dict[str, Any]:
        """Analyze portfolio-level risk context"""
        try:
            if not portfolio_data:
                return {}
            
            # Extract portfolio information
            holdings = portfolio_data.get('holdings', {})
            total_value = portfolio_data.get('total_value', 0)
            
            # Calculate concentration risk
            concentration_risk = 0
            if holdings:
                weights = [holding.get('weight', 0) for holding in holdings.values()]
                concentration_risk = max(weights) if weights else 0
            
            # Calculate diversification metrics
            num_holdings = len(holdings)
            diversification_score = min(100, num_holdings * 10)  # Simple diversification score
            
            return {
                "num_holdings": num_holdings,
                "concentration_risk": float(concentration_risk),
                "diversification_score": float(diversification_score),
                "total_value": float(total_value),
                "risk_level": "HIGH" if concentration_risk > 0.3 else "MODERATE" if concentration_risk > 0.15 else "LOW"
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing portfolio context: {str(e)}")
            return {}

    async def _analyze_historical_performance(self, symbol: str) -> Dict[str, Any]:
        """Analyze historical performance patterns"""
        try:
            # Get longer-term data
            stock_data = await self._get_historical_data(symbol, period="5y")
            
            if stock_data is None or stock_data.empty:
                return {}
            
            # Calculate various performance metrics
            stock_returns = stock_data['Close'].pct_change().dropna()
            
            # Performance across different periods
            periods = {
                "1_month": 21,
                "3_months": 63,
                "6_months": 126,
                "1_year": 252,
                "3_years": 756
            }
            
            performance_metrics = {}
            for period_name, days in periods.items():
                if len(stock_returns) >= days:
                    period_return = (stock_data['Close'].iloc[-1] / stock_data['Close'].iloc[-days] - 1) * 100
                    period_volatility = stock_returns.tail(days).std() * np.sqrt(252)
                    performance_metrics[period_name] = {
                        "return": float(period_return),
                        "volatility": float(period_volatility)
                    }
            
            # Best and worst periods
            rolling_returns = stock_returns.rolling(21).apply(lambda x: (1 + x).prod() - 1)
            best_month = rolling_returns.max()
            worst_month = rolling_returns.min()
            
            return {
                "performance_periods": performance_metrics,
                "best_month_return": float(best_month),
                "worst_month_return": float(worst_month),
                "consistency_score": float(1 - stock_returns.std() / abs(stock_returns.mean())) if stock_returns.mean() != 0 else 0
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing historical performance: {str(e)}")
            return {}

    async def _get_llm_risk_analysis(self, **kwargs) -> Dict[str, Any]:
        """Get CrewAI-based risk analysis and interpretation"""
        try:
            # Format the prompt with all the quantitative data
            risk_analysis_prompt = f"""
            You are an expert Risk Management Specialist with deep knowledge of financial risk models and market dynamics.
            
            Analyze the following risk data and provide comprehensive insights:
            
            Risk Metrics: {kwargs.get('risk_metrics', {})}
            Market Context: {kwargs.get('market_context', {})}
            Portfolio Data: {kwargs.get('portfolio_data', {})}
            Historical Performance: {kwargs.get('historical_performance', {})}
            
            Please provide:
            1. Risk assessment summary
            2. Risk factor analysis
            3. Comparative analysis
            4. Risk mitigation recommendations
            5. Scenario analysis
            6. Risk-return optimization suggestions
            
            Be precise, data-driven, and provide actionable insights for risk management.
            """
            
            # Use CrewAI agent for analysis
            task = Task(
                description=risk_analysis_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive risk analysis with actionable insights"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            analysis = self._parse_crewai_risk_response(str(result))
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI risk analysis: {str(e)}")
            return {"error": str(e)}

    def _parse_llm_risk_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response into structured risk analysis"""
        try:
            # Split response into sections
            sections = response.split('\n\n')
            
            parsed_analysis = {
                "risk_assessment_summary": "",
                "risk_factor_analysis": "",
                "comparative_analysis": "",
                "mitigation_recommendations": [],
                "scenario_analysis": {},
                "optimization_suggestions": []
            }
            
            current_section = None
            for section in sections:
                if "Risk Assessment Summary" in section:
                    current_section = "risk_assessment_summary"
                elif "Risk Factor Analysis" in section:
                    current_section = "risk_factor_analysis"
                elif "Comparative Risk Analysis" in section:
                    current_section = "comparative_analysis"
                elif "Risk Mitigation Recommendations" in section:
                    current_section = "mitigation_recommendations"
                elif "Scenario Analysis" in section:
                    current_section = "scenario_analysis"
                elif "Risk-Return Optimization" in section:
                    current_section = "optimization_suggestions"
                elif current_section and section.strip():
                    if current_section in ["risk_assessment_summary", "risk_factor_analysis", "comparative_analysis"]:
                        parsed_analysis[current_section] = section.strip()
                    elif current_section in ["mitigation_recommendations", "optimization_suggestions"]:
                        parsed_analysis[current_section].append(section.strip())
            
            return parsed_analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing LLM response: {str(e)}")
            return {"raw_response": response}

    def _parse_crewai_risk_response(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI response into structured risk analysis"""
        try:
            # CrewAI response is typically a JSON string or a simple string.
            # For simplicity, we'll assume a basic structure if it's not JSON.
            # In a real scenario, you might need a more robust JSON parsing.
            
            # Attempt to parse as JSON
            import json
            try:
                analysis_data = json.loads(response)
                return analysis_data
            except json.JSONDecodeError:
                # If not JSON, treat it as a single string response
                return {"raw_response": response}
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI response: {str(e)}")
            return {"raw_response": response}

    def _calculate_composite_risk_score(self, risk_metrics: Dict, llm_analysis: Dict) -> float:
        """Calculate composite risk score combining quantitative and qualitative factors"""
        try:
            base_score = risk_metrics.get("risk_score", 50)
            
            # Adjust based on LLM analysis
            qualitative_adjustment = 0
            
            # Parse LLM analysis for risk indicators
            summary = llm_analysis.get("risk_assessment_summary", "").lower()
            if "high risk" in summary or "significant risk" in summary:
                qualitative_adjustment += 10
            elif "low risk" in summary or "minimal risk" in summary:
                qualitative_adjustment -= 10
            
            # Final score (0-100)
            final_score = max(0, min(100, base_score + qualitative_adjustment))
            
            return final_score
            
        except Exception as e:
            self.logger.error(f"Error calculating composite risk score: {str(e)}")
            return 50.0

    def _generate_risk_recommendations(self, risk_metrics: Dict, llm_analysis: Dict) -> List[str]:
        """Generate actionable risk recommendations"""
        recommendations = []
        
        try:
            # Risk score based recommendations
            risk_score = risk_metrics.get("risk_score", 50)
            
            if risk_score > 70:
                recommendations.append("Consider position sizing reduction due to high risk levels")
                recommendations.append("Implement stop-loss orders to limit downside")
            elif risk_score > 50:
                recommendations.append("Monitor position closely and consider hedging strategies")
            
            # Volatility based recommendations
            volatility = risk_metrics.get("volatility", 0)
            if volatility > 0.4:
                recommendations.append("High volatility detected - consider dollar-cost averaging")
            
            # Sharpe ratio recommendations
            sharpe_ratio = risk_metrics.get("sharpe_ratio", 0)
            if sharpe_ratio < 0.5:
                recommendations.append("Poor risk-adjusted returns - consider alternative investments")
            
            # Add LLM recommendations
            llm_recommendations = llm_analysis.get("mitigation_recommendations", [])
            recommendations.extend(llm_recommendations[:3])  # Top 3 LLM recommendations
            
            return recommendations[:5]  # Return top 5 recommendations
            
        except Exception as e:
            self.logger.error(f"Error generating recommendations: {str(e)}")
            return ["Monitor risk levels closely and adjust position sizing accordingly"]

    async def _get_historical_data(self, symbol: str, period: str = "1y") -> Optional[pd.DataFrame]:
        """Get historical data for analysis"""
        try:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period=period)
            
            if data.empty:
                return None
                
            return data
            
        except Exception as e:
            self.logger.error(f"Error getting historical data for {symbol}: {str(e)}")
            return None

    def _get_default_risk_result(self, symbol: str) -> Dict[str, Any]:
        """Return default risk analysis result when data is unavailable"""
        return {
            "symbol": symbol,
            "timestamp": datetime.now().isoformat(),
            "error": "Unable to perform risk analysis due to data limitations",
            "risk_score": 50,
            "recommendations": ["Manual risk assessment recommended due to data limitations"]
        }

    # Additional tool methods
    async def _calculate_var(self, data: pd.Series, confidence_levels: List[float] = [0.95, 0.99]) -> Dict[str, float]:
        """Calculate Value at Risk using multiple methods"""
        results = {}
        
        for confidence in confidence_levels:
            # Parametric VaR
            results[f"var_{int(confidence*100)}_parametric"] = float(np.percentile(data, (1-confidence)*100))
            
            # Historical VaR
            results[f"var_{int(confidence*100)}_historical"] = float(data.quantile(1-confidence))
        
        return results

    async def _perform_stress_test(self, returns: pd.Series, scenarios: List[str]) -> Dict[str, Any]:
        """Perform stress testing under various scenarios"""
        stress_results = {}
        
        for scenario in scenarios:
            if scenario == "market_crash":
                # Simulate 20% market crash
                stressed_returns = returns - 0.20
                stress_results[scenario] = {
                    "expected_loss": float(stressed_returns.mean()),
                    "worst_case": float(stressed_returns.min())
                }
            elif scenario == "interest_rate_shock":
                # Simulate interest rate impact
                stressed_returns = returns * 0.8  # 20% reduction
                stress_results[scenario] = {
                    "expected_impact": float(stressed_returns.mean()),
                    "volatility_increase": float(stressed_returns.std() - returns.std())
                }
        
        return stress_results

    async def _analyze_correlations(self, returns: pd.Series, market_returns: pd.Series) -> Dict[str, float]:
        """Analyze correlation and concentration risks"""
        correlation = returns.corr(market_returns)
        rolling_correlation = returns.rolling(30).corr(market_returns).std()
        
        return {
            "correlation_with_market": float(correlation),
            "correlation_stability": float(1 - rolling_correlation),  # Higher = more stable
            "concentration_risk": float(abs(correlation))  # Higher correlation = higher concentration risk
        }

    async def _analyze_liquidity(self, symbol: str) -> Dict[str, Any]:
        """Analyze liquidity risk and market impact"""
        try:
            # Get recent trading data
            ticker = yf.Ticker(symbol)
            data = ticker.history(period="1mo")
            
            if data.empty:
                return {}
            
            # Calculate liquidity metrics
            avg_volume = data['Volume'].mean()
            volume_volatility = data['Volume'].std() / avg_volume if avg_volume > 0 else 0
            
            # Price impact estimate (simplified)
            price_volatility = data['Close'].pct_change().std()
            
            return {
                "average_volume": float(avg_volume),
                "volume_volatility": float(volume_volatility),
                "liquidity_score": float(min(100, avg_volume / 100000)),  # Simplified liquidity score
                "price_impact_estimate": float(price_volatility * 100)
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing liquidity: {str(e)}")
            return {}
