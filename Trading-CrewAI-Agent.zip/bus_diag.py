"""
Diagnostics for Redis Streams event bus.
Prints info about the PTA order submit stream and consumer group.

Usage (PowerShell):
  $env:REDIS_URL="redis://localhost:6379/0"
  python scripts/bus_diag.py
"""
from __future__ import annotations

import json
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(ROOT)
if ROOT not in sys.path:
    sys.path.append(ROOT)

from integration.event_bus import RedisStreamsEventBus


def main():
    bus = RedisStreamsEventBus()
    target = "pta:orders_submit"
    stream_key = bus.stream(target)
    info = bus.xinfo_stream(target)
    groups = bus.xinfo_groups(target)
    pending = bus.xpending(target, "pta-worker-group") or {}
    out = {
        "redis_url": os.environ.get("REDIS_URL"),
        "stream": stream_key,
        "xlen": bus.xlen(target),
        "xinfo": info,
        "groups": groups,
        "pending": pending,
    }
    print(json.dumps(out, default=str, indent=2))


if __name__ == "__main__":
    main()
