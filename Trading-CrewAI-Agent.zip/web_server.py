#!/usr/bin/env python3
"""
Enhanced Web UI Server for AI Trading Advisory System
Serves the modern web interface and provides integration with backend APIs
"""

# Safe imports with graceful fallbacks for optional packages
import os
import sys
import logging
import requests
import json
from datetime import datetime, timedelta
import hashlib
import time
from functools import wraps
import bleach
from werkzeug.security import generate_password_hash
from urllib.parse import urlparse

# Ensure UTF-8 stdout/stderr to avoid UnicodeEncodeError on Windows
try:
    sys.stdout.reconfigure(encoding='utf-8')  # type: ignore[attr-defined]
    sys.stderr.reconfigure(encoding='utf-8')  # type: ignore[attr-defined]
except Exception:
    pass

from flask import Flask, render_template, send_from_directory, jsonify, request, session, g, Response, url_for

try:
    from flask_cors import CORS  # type: ignore
except ImportError:  # pragma: no cover
    def CORS(*args, **kwargs):  # type: ignore
        return None

try:
    from flask_compress import Compress  # type: ignore
except ImportError:  # pragma: no cover
    Compress = None  # type: ignore

try:
    from flask_limiter import Limiter  # type: ignore
    from flask_limiter.util import get_remote_address  # type: ignore
except ImportError:  # pragma: no cover
    Limiter = None  # type: ignore
    def get_remote_address():  # type: ignore
        return request.remote_addr

try:
    from flask_caching import Cache  # type: ignore
except ImportError:  # pragma: no cover
    Cache = None  # type: ignore

try:
    import redis  # type: ignore
except ImportError:  # pragma: no cover
    redis = None  # type: ignore

# Add retries/backoff support
try:
    from requests.adapters import HTTPAdapter
    try:
        from urllib3.util.retry import Retry  # type: ignore
    except Exception:  # pragma: no cover
        Retry = None  # Fallback if urllib3 Retry not available
except Exception:  # pragma: no cover
    HTTPAdapter = None
    Retry = None

# Add project path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(project_root)

# Initialize Flask app
app = Flask(__name__, 
            static_folder='web',
            template_folder='web')

# --- Logging Configuration ---
# Quieten Werkzeug's default logger to only show warnings and errors
log = logging.getLogger('werkzeug')
log.setLevel(logging.WARNING)

# Custom 404 handler to log the requested path
@app.errorhandler(404)
def not_found_error(error):
    app.logger.error(f"404 Not Found: The requested URL '{request.path}' with method '{request.method}' was not found on the server.")
    return jsonify(success=False, error="Not Found", message="The requested resource was not found."), 404
# --- End Logging Configuration ---

# Security Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-key-change-in-production')
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)

# Enable CORS for all routes (secured to allowed origins)
# Replace permissive wildcard with explicit allowed origins
# These can be overridden via env var UI_ALLOWED_ORIGINS (comma-separated)
_allowed_origins_env = os.environ.get('UI_ALLOWED_ORIGINS') or os.environ.get('ALLOWED_ORIGINS')
_default_allowed = ['http://localhost:3000']
ALLOWED_ORIGINS = [o.strip() for o in (_allowed_origins_env.split(',') if _allowed_origins_env else _default_allowed) if o.strip()]
CORS(app, origins=ALLOWED_ORIGINS, supports_credentials=True, methods=['GET', 'POST', 'OPTIONS'], allow_headers=['Content-Type', 'X-CSRF-Token', 'X-Request-ID', 'Idempotency-Key'])

# Performance optimizations
try:
    # Compression for responses
    compress = Compress(app) if Compress else None
    
    # Rate limiting
    limiter = Limiter(
        key_func=get_remote_address,
        app=app,
        default_limits=["200 per day", "50 per hour"]
    ) if Limiter else None
    
    # Caching setup
    cache = Cache(app, config={'CACHE_TYPE': 'simple'}) if Cache else None
    
except Exception:
    # Fallback if performance packages not installed or misconfigured
    compress = None
    limiter = None
    cache = None

# Connection pooling session
session_pool = requests.Session()
session_pool.headers.update({
    'User-Agent': 'AI-Trading-Advisory-UI/1.0'
})
# Configure HTTP retries/backoff if available
if HTTPAdapter is not None and Retry is not None:
    # Disable automatic retries to avoid noisy urllib3 warnings during startup
    retry_cfg = Retry(
        total=0,
        connect=0,
        read=0,
        redirect=0,
        status=0,
        allowed_methods=False,
        raise_on_status=False,
        respect_retry_after_header=True,
    )
    adapter = HTTPAdapter(max_retries=retry_cfg, pool_connections=20, pool_maxsize=50)
    session_pool.mount('http://', adapter)
    session_pool.mount('https://', adapter)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/web_ui.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configuration
CONFIG = {
    'MAIN_AGENT_URL': 'http://localhost:8000',
    'RL_AGENT_URL': 'http://localhost:5500',
    'PTA_URL': os.environ.get('PTA_URL') or os.environ.get('PTA_BASE_URL') or 'http://localhost:8090',
    'WEB_UI_PORT': 5000,
    'DEBUG': True,
    'CACHE_TIMEOUT': 300,  # 5 minutes
    'API_TIMEOUT': 30,
    'MAX_CONTENT_LENGTH': 16 * 1024 * 1024,  # 16MB
    'ALLOWED_ORIGINS': ALLOWED_ORIGINS,
    'ENABLE_CSRF': True,
    # Health check behavior
    'HEALTH_STARTUP_GRACE': int(os.environ.get('HEALTH_STARTUP_GRACE', '15')),
    'HEALTH_BACKOFF_MAX': int(os.environ.get('HEALTH_BACKOFF_MAX', '20')),
}

# Load Azure config from project settings
try:
    from config.settings import get_settings  # import Azure/OpenAI config
    _settings = get_settings()
    AZURE_CFG = _settings.ai
    AZURE_ENABLED = bool(
        getattr(AZURE_CFG, 'azure_openai_endpoint', '') and getattr(AZURE_CFG, 'azure_openai_api_key', '')
    )
    CONFIG['AZURE_ENABLED'] = AZURE_ENABLED
    # Extra hint for UI/system status when embeddings deployment looks misconfigured
    try:
        emb = getattr(AZURE_CFG, 'azure_openai_embedding_model', '')
        if AZURE_ENABLED and (not emb or emb.strip() == 'text-embedding-ada-002'):
            CONFIG['AZURE_EMBEDDINGS_WARNING'] = 'Embeddings deployment not configured properly. Set AZURE_OPENAI_EMBEDDING_MODEL to your Azure deployment name (e.g. for text-embedding-3-small).'
    except Exception:
        pass
except Exception:
    AZURE_CFG = None
    AZURE_ENABLED = False
    CONFIG['AZURE_ENABLED'] = False

# Override port from environment if provided
try:
    _ui_port_env = os.environ.get('UI_PORT') or os.environ.get('PORT')
    if _ui_port_env:
        CONFIG['WEB_UI_PORT'] = int(_ui_port_env)
    # Also allow RL agent URL override via env
    _rl_env = os.environ.get('RL_AGENT_URL') or os.environ.get('RL_API_URL')
    if _rl_env:
        CONFIG['RL_AGENT_URL'] = _rl_env
    _pta_env = os.environ.get('PTA_URL') or os.environ.get('PTA_BASE_URL')
    if _pta_env:
        CONFIG['PTA_URL'] = _pta_env
except Exception:
    pass

app.config['MAX_CONTENT_LENGTH'] = CONFIG['MAX_CONTENT_LENGTH']

# Security utilities
def sanitize_input(text):
    """Sanitize user input to prevent XSS"""
    try:
        return bleach.clean(text, tags=[], attributes={}, strip=True)
    except:
        # Fallback manual sanitization
        dangerous_chars = ['<', '>', '"', "'", '&', 'javascript:', 'data:', 'vbscript:']
        for char in dangerous_chars:
            text = text.replace(char, '')
        return text

def generate_csrf_token():
    """Generate CSRF token"""
    return hashlib.sha256(f"{session.get('user_id', 'anonymous')}{time.time()}".encode()).hexdigest()

def rate_limit_key():
    """Generate rate limit key"""
    return f"rate_limit:{request.remote_addr}"

def _get_or_create_request_id() -> str:
    rid = request.headers.get('X-Request-ID')
    if not rid:
        # use time+remote addr hash
        rid = hashlib.sha256(f"{request.remote_addr}-{time.time()}".encode()).hexdigest()[:16]
    return rid

def _upstream_headers() -> dict:
    # Build headers to propagate to upstream services
    hdrs = {
        'X-Request-ID': getattr(g, 'request_id', ''),
        'X-Forwarded-For': request.headers.get('X-Forwarded-For', request.remote_addr or ''),
        'X-Forwarded-Host': request.host,
    }
    # pass through Idempotency-Key if provided by client
    idem_key = request.headers.get('Idempotency-Key')
    if idem_key:
        hdrs['Idempotency-Key'] = idem_key
    # Include session id if present for traceability (no PII)
    if 'user_id' in session:
        hdrs['X-User-Session'] = session['user_id']
    return hdrs

# Decorators
def require_valid_session(f):
    """Decorator to require valid session"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            session['user_id'] = f"user_{int(time.time())}"
        return f(*args, **kwargs)
    return decorated_function

def cache_response(timeout=CONFIG['CACHE_TIMEOUT']):
    """Decorator to cache responses"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if cache:
                cache_key = f"route:{request.endpoint}:{request.args.to_dict()}"
                cached_response = cache.get(cache_key)
                if cached_response:
                    return cached_response
                
                response = f(*args, **kwargs)
                cache.set(cache_key, response, timeout=timeout)
                return response
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Placeholders (will be overridden by real implementations defined later)
if '_validate_csrf' not in globals():
    def _validate_csrf() -> bool:  # type: ignore
        return True
if '_get_allowed_origin' not in globals():
    def _get_allowed_origin():  # type: ignore
        return None

# Helper decorator to enforce CSRF on state-changing methods
def require_csrf(f):
    @wraps(f)
    def _wrapped(*args, **kwargs):
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            if not _validate_csrf():
                resp = jsonify({
                    'success': False,
                    'error': 'CSRF validation failed',
                    'timestamp': datetime.now().isoformat(),
                    'request_id': getattr(g, 'request_id', '')
                })
                resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
                allowed = _get_allowed_origin()
                if allowed:
                    resp.headers['Access-Control-Allow-Origin'] = allowed
                    resp.headers['Vary'] = 'Origin'
                return resp, 403
        return f(*args, **kwargs)
    return _wrapped

# --- Admin endpoints: logs and cache control ---
LOGS_DIR = os.path.join(os.path.dirname(__file__), 'logs')

@app.route('/api/admin/logs/list', methods=['GET'])
@require_valid_session
def list_logs():
    try:
        files = []
        if os.path.isdir(LOGS_DIR):
            for name in os.listdir(LOGS_DIR):
                if not name.endswith('.log'):
                    continue
                path = os.path.join(LOGS_DIR, name)
                try:
                    stat = os.stat(path)
                    files.append({'name': name, 'size': stat.st_size, 'modified': datetime.fromtimestamp(stat.st_mtime).isoformat()})
                except Exception:
                    continue
        resp = jsonify({'success': True, 'files': files, 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        allowed = _get_allowed_origin()
        if allowed:
            resp.headers['Access-Control-Allow-Origin'] = allowed
            resp.headers['Vary'] = 'Origin'
        return resp
    except Exception as e:
        logger.error(f"List logs error: {e}")
        resp = jsonify({'success': False, 'error': 'Failed to list logs', 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 500

@app.route('/api/admin/logs/tail', methods=['GET'])
@require_valid_session
def tail_log():
    try:
        name = request.args.get('file', '')
        lines = int(request.args.get('lines', '100'))
        if not name or '/' in name or '\\' in name or not name.endswith('.log'):
            resp = jsonify({'success': False, 'error': 'Invalid file name', 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, 400
        path = os.path.join(LOGS_DIR, name)
        if not os.path.isfile(path):
            resp = jsonify({'success': False, 'error': 'File not found', 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, 404
        # Read last N lines efficiently
        content = []
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            try:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                block = 1024
                data = ''
                while lines > 0 and size > 0:
                    read_size = block if size - block > 0 else size
                    f.seek(size - read_size)
                    chunk = f.read(read_size)
                    data = chunk + data
                    size -= read_size
                    found = data.splitlines()
                    if len(found) > lines:
                        content = found[-lines:]
                        break
                if not content:
                    content = data.splitlines()[-lines:]
            except Exception:
                f.seek(0)
                content = f.readlines()[-lines:]
        resp = jsonify({'success': True, 'file': name, 'lines': lines, 'content': content, 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        allowed = _get_allowed_origin()
        if allowed:
            resp.headers['Access-Control-Allow-Origin'] = allowed
            resp.headers['Vary'] = 'Origin'
        return resp
    except Exception as e:
        logger.error(f"Tail log error: {e}")
        resp = jsonify({'success': False, 'error': 'Failed to read log', 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 500

@app.route('/api/admin/cache/clear', methods=['POST'])
@require_valid_session
@require_csrf
def clear_cache():
    try:
        cleared = False
        if cache:
            try:
                cache.clear()
                cleared = True
            except Exception:
                cleared = False
        resp = jsonify({'success': True, 'cleared': cleared, 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        allowed = _get_allowed_origin()
        if allowed:
            resp.headers['Access-Control-Allow-Origin'] = allowed
            resp.headers['Vary'] = 'Origin'
        return resp
    except Exception as e:
        logger.error(f"Clear cache error: {e}")
        resp = jsonify({'success': False, 'error': 'Failed to clear cache', 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 500

@app.route('/')
@require_valid_session
def index():
    """Serve the main application page"""
    # Add CSP headers for security
    response = send_from_directory('web', 'index.html')
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; "
        "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com data:; "
        "img-src 'self' data:; "
        "connect-src 'self' http://localhost:8000 http://localhost:5000 http://localhost:5500;"
    )
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

# Lightweight root health to avoid 404 noise from external pingers
@app.route('/health')
def root_health():
    resp = jsonify({
        'status': 'healthy',
        'service': 'Enhanced Web UI',
        'path': '/health',
        'timestamp': datetime.now().isoformat()
    })
    resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
    return resp

# Provide a favicon to avoid noisy 404s from browsers
@app.route('/favicon.ico')
def favicon():
    try:
        web_dir = os.path.join(os.path.dirname(__file__), 'web')
        ico_path = os.path.join(web_dir, 'favicon.ico')
        png_path = os.path.join(web_dir, 'favicon.png')
        if os.path.exists(ico_path):
            resp = send_from_directory('web', 'favicon.ico')
        elif os.path.exists(png_path):
            resp = send_from_directory('web', 'favicon.png')
        else:
            # 1x1 transparent PNG fallback
            import base64
            data = base64.b64decode(
                'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9YqNQh8AAAAASUVORK5CYII='
            )
            resp = Response(data, mimetype='image/png')
        resp.headers['Cache-Control'] = 'public, max-age=31536000'
        return resp
    except Exception:
        return ('', 204)

@app.route('/<path:filename>')
def static_files(filename):
    """Serve static files (CSS, JS, images) with caching headers"""
    response = send_from_directory('web', filename)
    
    # Add caching headers for static assets
    if filename.endswith(('.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.ico')):
        response.headers['Cache-Control'] = 'public, max-age=31536000'  # 1 year
    
    return response

@app.route('/static/<path:filename>')
def static_busted_files(filename):
    """Serve static files with cache-busting query param support."""
    # Ignore query string, just serve the file
    response = send_from_directory(app.static_folder, filename)
    # Add caching headers for static assets
    if filename.endswith(('.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.ico')):
        response.headers['Cache-Control'] = 'public, max-age=31536000'  # 1 year
    return response

@app.route('/api/health')
def health_check():
    """Health check endpoint for the web UI server"""
    resp = jsonify({
        'status': 'healthy',
        'service': 'Enhanced Web UI',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })
    # attach request id for traceability
    resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
    # reflect allowed origin if present
    allowed = _get_allowed_origin()
    if allowed:
        resp.headers['Access-Control-Allow-Origin'] = allowed
        resp.headers['Vary'] = 'Origin'
    return resp

@app.route('/api/system/status')
def system_status():
    """Get comprehensive system status"""
    try:
        status = {
            'webUI': {
                'status': 'online',
                'url': f'http://localhost:{CONFIG["WEB_UI_PORT"]}',
                'timestamp': datetime.now().isoformat()
            },
            'mainAgent': check_service_health(CONFIG['MAIN_AGENT_URL']),
            'rlAgent': check_service_health(CONFIG['RL_AGENT_URL']),
            'integration': check_integration_health()
        }
        # Include Azure health if configured
        status['azure'] = check_azure_health() if AZURE_ENABLED else {
            'status': 'offline',
            'error': 'disabled',
            'last_check': datetime.now().isoformat()
        }
        
        return jsonify({
            'success': True,
            'data': status,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"System status check failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/proxy/chat', methods=['POST'])
@require_valid_session
def proxy_chat():
    """Proxy chat requests to the main agent with security and performance optimizations"""
    try:
        # CSRF validation
        if not _validate_csrf():
            resp = jsonify({
                'success': False,
                'error': 'CSRF validation failed',
                'timestamp': datetime.now().isoformat(),
                'request_id': getattr(g, 'request_id', '')
            })
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, 403
        # Rate limiting check (with error handling)
        try:
            if limiter and hasattr(limiter, 'test'):
                limiter.test()
        except Exception as rate_limit_error:
            logger.warning(f"Rate limiter error: {rate_limit_error}")
        
        data = request.get_json()
        if not data:
            resp = jsonify({
                'success': False,
                'error': 'No data provided',
                'timestamp': datetime.now().isoformat()
            })
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, 400
        
        # Input sanitization
        if 'message' in data:
            data['message'] = sanitize_input(data['message'])
        
        # Add session info
        data['session_id'] = session.get('user_id')
        data['timestamp'] = datetime.now().isoformat()
        # If client sent Idempotency-Key header, also mirror into body for servers lacking header access (optional)
        idem_header = request.headers.get('Idempotency-Key')
        if idem_header:
            data.setdefault('idempotency_key', idem_header)
        
        # Forward request to main agent with connection pooling and request id
        upstream_headers = _upstream_headers()
        response = session_pool.post(
            f"{CONFIG['MAIN_AGENT_URL']}/api/advisory/chat",
            json=data,
            headers=upstream_headers,
            timeout=CONFIG['API_TIMEOUT']
        )
        
        if response.ok:
            # Pass through 202 in-progress so the frontend auto-retry logic engages
            status_code = response.status_code
            try:
                result = response.json()
            except Exception:
                result = {}

            # If upstream is still processing, return 202 with minimal transformation
            if status_code == 202 or (isinstance(result, dict) and result.get('status') == 'in_progress'):
                resp = jsonify(result if isinstance(result, dict) else {'status': 'in_progress'})
                resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
                # Hint clients to poll shortly
                resp.headers['Retry-After'] = '1'
                return resp, 202

            # For successful completions, flatten payload so client doesn't need to unwrap
            combined = {}
            if isinstance(result, dict):
                combined.update(result)
            else:
                combined['response'] = result
            combined['success'] = True
            combined['timestamp'] = datetime.now().isoformat()
            combined['request_id'] = getattr(g, 'request_id', '')
            resp = jsonify(combined)
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, status_code
        else:
            logger.warning(f"Main agent returned {response.status_code}: {response.text}")
            resp = jsonify({
                'success': False,
                'error': f'Main agent returned {response.status_code}',
                'timestamp': datetime.now().isoformat(),
                'request_id': getattr(g, 'request_id', '')
            })
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, response.status_code
            
    except requests.exceptions.Timeout:
        logger.error("Request timeout to main agent")
        resp = jsonify({
            'success': False,
            'error': 'Request timeout - main agent did not respond',
            'timestamp': datetime.now().isoformat(),
            'request_id': getattr(g, 'request_id', '')
        })
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 504
        
    except requests.exceptions.ConnectionError:
        logger.error("Connection error to main agent")
        resp = jsonify({
            'success': False,
            'error': 'Cannot connect to main agent - service may be down',
            'timestamp': datetime.now().isoformat(),
            'request_id': getattr(g, 'request_id', '')
        })
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 503
        
    except Exception as e:
        logger.error(f"Chat proxy error: {e}")
        resp = jsonify({
            'success': False,
            'error': 'Internal server error',
            'timestamp': datetime.now().isoformat(),
            'request_id': getattr(g, 'request_id', '')
        })
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 500

@app.route('/api/proxy/rl/insights')
@cache_response(timeout=60)  # Cache for 1 minute
@require_valid_session
def proxy_rl_insights():
    """Proxy RL insights requests with caching and endpoint alignment"""
    try:
        upstream_headers = _upstream_headers()
        # Prefer the bridge-aligned endpoint
        url_primary = f"{CONFIG['RL_AGENT_URL']}/api/learning_insights"
        url_fallback = f"{CONFIG['RL_AGENT_URL']}/api/insights"
        response = session_pool.get(url_primary, headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not response.ok:
            logger.info(f"/api/learning_insights returned {response.status_code}, trying /api/insights")
            response = session_pool.get(url_fallback, headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if response.ok:
            result = response.json()
            resp = jsonify({
                'success': True,
                'data': result,
                'timestamp': datetime.now().isoformat(),
                'cached': False,
                'request_id': getattr(g, 'request_id', '')
            })
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp
        else:
            logger.warning(f"RL agent returned {response.status_code}: {response.text}")
            resp = jsonify({
                'success': False,
                'error': f'RL agent returned {response.status_code}',
                'timestamp': datetime.now().isoformat(),
                'request_id': getattr(g, 'request_id', '')
            })
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, response.status_code
    except requests.exceptions.Timeout:
        logger.error("Request timeout to RL agent")
        resp = jsonify({
            'success': False,
            'error': 'Request timeout - RL agent did not respond',
            'timestamp': datetime.now().isoformat(),
            'request_id': getattr(g, 'request_id', '')
        })
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 504
    except requests.exceptions.ConnectionError:
        logger.error("Connection error to RL agent")
        resp = jsonify({
            'success': False,
            'error': 'Cannot connect to RL agent - service may be down',
            'timestamp': datetime.now().isoformat(),
            'request_id': getattr(g, 'request_id', '')
        })
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 503
    except Exception as e:
        logger.error(f"RL insights proxy error: {e}")
        resp = jsonify({
            'success': False,
            'error': 'Internal server error',
            'timestamp': datetime.now().isoformat(),
            'request_id': getattr(g, 'request_id', '')
        })
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 500

# --- PTA proxy endpoints: portfolio, market, adapter ---
@app.route('/api/proxy/pta/portfolio/holdings', methods=['GET'])
@require_valid_session
def proxy_pta_holdings():
    try:
        upstream_headers = _upstream_headers()
        r = session_pool.get(f"{CONFIG['PTA_URL']}/portfolio/holdings", headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA holdings proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/proxy/pta/portfolio/margins', methods=['GET'])
@require_valid_session
def proxy_pta_margins():
    try:
        upstream_headers = _upstream_headers()
        r = session_pool.get(f"{CONFIG['PTA_URL']}/portfolio/margins", headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA margins proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/proxy/pta/portfolio/metrics', methods=['GET'])
@require_valid_session
def proxy_pta_metrics():
    try:
        upstream_headers = _upstream_headers()
        r = session_pool.get(f"{CONFIG['PTA_URL']}/portfolio/metrics", headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA metrics proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/proxy/pta/market/last_price/<symbol>', methods=['GET'])
@require_valid_session
def proxy_pta_last_price(symbol: str):
    try:
        upstream_headers = _upstream_headers()
        r = session_pool.get(f"{CONFIG['PTA_URL']}/market/last_price/{symbol}", headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA last_price proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/proxy/pta/adapter/status', methods=['GET'])
@require_valid_session
def proxy_pta_adapter_status():
    try:
        upstream_headers = _upstream_headers()
        r = session_pool.get(f"{CONFIG['PTA_URL']}/adapter/status", headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA adapter status proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/proxy/pta/orders/orders', methods=['GET'])
@require_valid_session
def proxy_pta_orders():
    try:
        upstream_headers = _upstream_headers()
        r = session_pool.get(f"{CONFIG['PTA_URL']}/orders/orders", headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA orders proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/proxy/pta/orders/submit', methods=['POST'])
@require_valid_session
@require_csrf
def proxy_pta_orders_submit():
    try:
        payload = request.get_json(force=True) or {}
        upstream_headers = _upstream_headers()
        r = session_pool.post(f"{CONFIG['PTA_URL']}/orders/submit", json=payload, headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA orders submit proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/proxy/pta/adapter/subscribe', methods=['POST'])
@require_valid_session
@require_csrf
def proxy_pta_adapter_subscribe():
    try:
        payload = request.get_json(force=True) or {}
        if not isinstance(payload.get('symbols'), list) or not payload['symbols']:
            return jsonify({'success': False, 'error': 'symbols must be a non-empty list'}), 400
        upstream_headers = _upstream_headers()
        r = session_pool.post(f"{CONFIG['PTA_URL']}/adapter/subscribe", json=payload, headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if not r.ok:
            return jsonify({'success': False, 'error': f'PTA returned {r.status_code}'}), r.status_code
        data = r.json()
        resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat()})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp
    except requests.exceptions.Timeout:
        return jsonify({'success': False, 'error': 'PTA timeout'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'success': False, 'error': 'PTA unavailable'}), 503
    except Exception as e:
        logger.error(f"PTA subscribe proxy error: {e}")
        return jsonify({'success': False, 'error': 'Internal error'}), 500

@app.route('/api/metrics')
@cache_response(timeout=30)
def get_metrics():
    """Get system metrics"""
    try:
        uptime_seconds = time.time() - app.config.get('START_TIME', time.time())
        metrics = {
            'webUI': {
                'uptime': uptime_seconds,
                'requests': getattr(app, 'total_requests', 0),
                'successful_requests': getattr(app, 'successful_requests', 0),
                'failed_requests': getattr(app, 'failed_requests', 0),
                'average_response_time': getattr(app, 'avg_response_time', 0),
                'cache_hits': getattr(app, 'cache_hits', 0)
            },
            'timestamp': datetime.now().isoformat()
        }
        # Try to get metrics from other services (use /health endpoints)
        try:
            main_agent_response = requests.get(
                f"{CONFIG['MAIN_AGENT_URL']}/health",
                timeout=5
            )
            if main_agent_response.ok:
                metrics['mainAgent'] = main_agent_response.json()
        except:
            pass
        try:
            rl_agent_response = requests.get(
                f"{CONFIG['RL_AGENT_URL']}/health",
                timeout=5
            )
            if rl_agent_response.ok:
                metrics['rlAgent'] = rl_agent_response.json()
        except:
            pass
        return jsonify({
            'success': True,
            'data': metrics,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        logger.error(f"Metrics error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

# Compatibility: proxy legacy route to RL API to avoid 404s on UI server
@app.route('/api/get_weight_updates')
@require_valid_session
def proxy_get_weight_updates():
    try:
        upstream_headers = _upstream_headers()
        url = f"{CONFIG['RL_AGENT_URL']}/api/get_weight_updates"
        resp_up = session_pool.get(url, headers=upstream_headers, timeout=CONFIG['API_TIMEOUT'])
        if resp_up.ok:
            data = resp_up.json()
            resp = jsonify({'success': True, 'data': data, 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp
        else:
            resp = jsonify({'success': False, 'error': f'Upstream {resp_up.status_code}', 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
            resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
            return resp, resp_up.status_code
    except requests.exceptions.Timeout:
        resp = jsonify({'success': False, 'error': 'Timeout', 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 504
    except Exception as e:
        resp = jsonify({'success': False, 'error': str(e), 'timestamp': datetime.now().isoformat(), 'request_id': getattr(g, 'request_id', '')})
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 500

# Security Routes
@app.route('/api/csrf-token')
@require_valid_session
def get_csrf_token():
    """Generate and return CSRF token"""
    token = generate_csrf_token()
    session['csrf_token'] = token
    
    return jsonify({
        'success': True,
        'token': token,
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/session/validate')
@require_valid_session
def validate_session():
    """Validate current session"""
    return jsonify({
        'success': True,
        'valid': True,
        'user_id': session.get('user_id'),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/session/logout', methods=['POST'])
@require_valid_session
def logout_session():
    """Logout and clear session"""
    # Enforce CSRF for logout as well
    if not _validate_csrf():
        resp = jsonify({
            'success': False,
            'error': 'CSRF validation failed',
            'timestamp': datetime.now().isoformat(),
            'request_id': getattr(g, 'request_id', '')
        })
        resp.headers['X-Request-ID'] = getattr(g, 'request_id', '')
        return resp, 403
    session.clear()
    response = jsonify({
        'success': True,
        'message': 'Logged out successfully',
        'timestamp': datetime.now().isoformat()
    })
    # Clear session cookie
    response.set_cookie('session', '', expires=0, secure=True, httponly=True)
    # reflect allowed origin if present
    allowed = _get_allowed_origin()
    if allowed:
        response.headers['Access-Control-Allow-Origin'] = allowed
        response.headers['Vary'] = 'Origin'
    return response

# Performance Monitoring Routes
@app.route('/api/performance/metrics')
@cache_response(timeout=60)
@require_valid_session
def get_performance_metrics():
    """Get system performance metrics"""
    try:
        metrics = {
            'server': {
                'uptime': time.time() - app.config.get('START_TIME', time.time()),
                'active_requests': len(session_pool.adapters),
                'cache_size': len(cache.cache._data) if cache else 0,
                'memory_usage': 'N/A'  # Could add psutil for actual memory monitoring
            },
            'api': {
                'total_requests': getattr(app, 'total_requests', 0),
                'successful_requests': getattr(app, 'successful_requests', 0),
                'failed_requests': getattr(app, 'failed_requests', 0),
                'average_response_time': getattr(app, 'avg_response_time', 0)
            },
            'security': {
                'csrf_tokens_issued': getattr(app, 'csrf_tokens_issued', 0),
                'rate_limit_hits': getattr(app, 'rate_limit_hits', 0),
                'blocked_requests': getattr(app, 'blocked_requests', 0)
            }
        }
        
        return jsonify({
            'success': True,
            'data': metrics,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Performance metrics error: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve performance metrics',
            'timestamp': datetime.now().isoformat()
        }), 500

# Rate limiting decorator for specific routes
def apply_rate_limit(max_requests=10, window=60):
    """Apply rate limiting to specific routes"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if limiter:
                try:
                    limiter.test()
                except Exception:
                    app.rate_limit_hits = getattr(app, 'rate_limit_hits', 0) + 1
                    return jsonify({
                        'success': False,
                        'error': 'Rate limit exceeded',
                        'timestamp': datetime.now().isoformat()
                    }), 429
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Error handlers
@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        'success': False,
        'error': 'Resource not found',
        'timestamp': datetime.now().isoformat()
    }), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    logger.error(f"Internal server error: {error}")
    return jsonify({
        'success': False,
        'error': 'Internal server error',
        'timestamp': datetime.now().isoformat()
    }), 500

@app.errorhandler(429)
def rate_limit_error(error):
    """Handle rate limit errors"""
    return jsonify({
        'success': False,
        'error': 'Rate limit exceeded. Please slow down your requests.',
        'timestamp': datetime.now().isoformat()
    }), 429

# Request/response middleware
@app.before_request
def before_request():
    """Before request middleware"""
    # Initialize request tracking
    g.start_time = time.time()
    app.total_requests = getattr(app, 'total_requests', 0) + 1
    # Attach/propagate request id
    g.request_id = _get_or_create_request_id()
    # Security headers logging
    if request.endpoint and not request.endpoint.startswith('static'):
        logger.info(f"Request[{g.request_id}]: {request.method} {request.path} from {request.remote_addr}")

@app.after_request
def after_request(response):
    """After request middleware"""
    # Add security headers
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    
    # Add CORS headers
    response.headers['Access-Control-Allow-Credentials'] = 'true'
    
    # Performance tracking
    if hasattr(g, 'start_time'):
        response_time = (time.time() - g.start_time) * 1000
        response.headers['X-Response-Time'] = f"{response_time:.2f}ms"
        
        # Update average response time
        current_avg = getattr(app, 'avg_response_time', 0)
        total_requests = getattr(app, 'total_requests', 1)
        app.avg_response_time = ((current_avg * (total_requests - 1)) + response_time) / total_requests
    
    # Track successful vs failed requests
    if response.status_code < 400:
        app.successful_requests = getattr(app, 'successful_requests', 0) + 1
    else:
        app.failed_requests = getattr(app, 'failed_requests', 0) + 1
    # Add request id header for all responses
    response.headers['X-Request-ID'] = getattr(g, 'request_id', '')
    # Reflect allowed origin for CORS when applicable
    allowed = _get_allowed_origin()
    if allowed:
        response.headers['Access-Control-Allow-Origin'] = allowed
        response.headers['Vary'] = 'Origin'
    return response

# --- Optional SSE telemetry endpoint ---
@app.route('/api/sse/telemetry')
@require_valid_session
def sse_telemetry():
    """Server-Sent Events endpoint streaming basic telemetry and health every few seconds.
    This does not require EventBus. If REDIS_URL is configured later, we can extend to push live topic events.
    """
    request_id = getattr(g, 'request_id', '')
    def generate():
        last_emit = 0
        while True:
            now = time.time()
            if now - last_emit >= 60:  # every 60 seconds
                status = {
                    'ts': datetime.now().isoformat(),
                    'request_id': request_id,
                    'services': {
                        'mainAgent': check_service_health(CONFIG['MAIN_AGENT_URL']),
                        'rlAgent': check_service_health(CONFIG['RL_AGENT_URL']),
                    }
                }
                payload = json.dumps(status)
                yield f"event: telemetry\ndata: {payload}\n\n"
                last_emit = now
            time.sleep(1)
    headers = {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no',  # for some proxies
        'X-Request-ID': request_id,
    }
    return Response(generate(), headers=headers)

# Initialize app configuration
app.config['START_TIME'] = time.time()
# Per-service failure backoff state: { url: {backoff: seconds, cooldown_until: ts} }
HEALTH_BACKOFF_STATE = {}

# Health utility helpers

def check_service_health(url: str) -> dict:
    """Check a service /health endpoint and return a normalized status dict with startup grace and failure backoff."""
    # Startup grace period: avoid hammering during initial bring-up
    try:
        uptime = time.time() - app.config.get('START_TIME', time.time())
    except Exception:
        uptime = 0
    if uptime < CONFIG.get('HEALTH_STARTUP_GRACE', 15):
        return {
            'status': 'checking',
            'url': url,
            'grace': True,
            'last_check': datetime.now().isoformat()
        }

    # Failure backoff: skip checks while cooling down
    state = HEALTH_BACKOFF_STATE.get(url)
    now = time.time()
    if state and now < state.get('cooldown_until', 0):
        return {
            'status': 'checking',
            'url': url,
            'backoff': state.get('backoff', 0),
            'next_check_in': max(0, state.get('cooldown_until', 0) - now),
            'last_check': datetime.now().isoformat()
        }

    try:
        resp = session_pool.get(f"{url}/health", timeout=5)
        if resp.ok:
            # Reset backoff on success
            if url in HEALTH_BACKOFF_STATE:
                HEALTH_BACKOFF_STATE.pop(url, None)
            return {
                'status': 'online',
                'url': url,
                'response_time': resp.elapsed.total_seconds() * 1000,
                'last_check': datetime.now().isoformat()
            }
        # Non-2xx -> set backoff
        cur = (state or {}).get('backoff', 1)
        new_backoff = min(max(cur * 2, 1), CONFIG.get('HEALTH_BACKOFF_MAX', 20))
        HEALTH_BACKOFF_STATE[url] = {
            'backoff': new_backoff,
            'cooldown_until': now + new_backoff,
        }
        return {
            'status': 'error',
            'url': url,
            'error': f'HTTP {resp.status_code}',
            'last_check': datetime.now().isoformat()
        }
    except requests.exceptions.ConnectionError:
        cur = (state or {}).get('backoff', 1)
        new_backoff = min(max(cur * 2, 1), CONFIG.get('HEALTH_BACKOFF_MAX', 20))
        HEALTH_BACKOFF_STATE[url] = {
            'backoff': new_backoff,
            'cooldown_until': now + new_backoff,
        }
        return {
            'status': 'offline',
            'url': url,
            'error': 'Connection refused',
            'last_check': datetime.now().isoformat()
        }
    except requests.exceptions.Timeout:
        cur = (state or {}).get('backoff', 1)
        new_backoff = min(max(cur * 2, 1), CONFIG.get('HEALTH_BACKOFF_MAX', 20))
        HEALTH_BACKOFF_STATE[url] = {
            'backoff': new_backoff,
            'cooldown_until': now + new_backoff,
        }
        return {
            'status': 'timeout',
            'url': url,
            'error': 'Request timeout',
            'last_check': datetime.now().isoformat()
        }
    except Exception as e:
        cur = (state or {}).get('backoff', 1)
        new_backoff = min(max(cur * 2, 1), CONFIG.get('HEALTH_BACKOFF_MAX', 20))
        HEALTH_BACKOFF_STATE[url] = {
            'backoff': new_backoff,
            'cooldown_until': now + new_backoff,
        }
        return {
            'status': 'error',
            'url': url,
            'error': str(e),
            'last_check': datetime.now().isoformat()
        }


def check_integration_health() -> dict:
    """Basic integration health derived from Main Agent health (placeholder)."""
    try:
        resp = session_pool.get(f"{CONFIG['MAIN_AGENT_URL']}/health", timeout=5)
        if resp.ok:
            return {
                'status': 'online',
                'data': resp.json(),
                'last_check': datetime.now().isoformat()
            }
        return {
            'status': 'error',
            'error': f'HTTP {resp.status_code}',
            'last_check': datetime.now().isoformat()
        }
    except Exception as e:
        return {
            'status': 'offline',
            'error': str(e),
            'last_check': datetime.now().isoformat()
        }


def check_azure_health() -> dict:
    """Check Azure OpenAI by listing deployments with the configured API version.
    Returns normalized status dict.
    """
    try:
        if not AZURE_ENABLED or AZURE_CFG is None:
            return {
                'status': 'offline',
                'error': 'disabled',
                'last_check': datetime.now().isoformat()
            }
        base = getattr(AZURE_CFG, 'azure_openai_endpoint', '').rstrip('/')
        api_version = getattr(AZURE_CFG, 'azure_openai_api_version', '') or '2024-02-15-preview'
        url = f"{base}/openai/deployments?api-version={api_version}"
        headers = {
            'api-key': getattr(AZURE_CFG, 'azure_openai_api_key', ''),
            'Accept': 'application/json'
        }
        t0 = time.time()
        resp = session_pool.get(url, headers=headers, timeout=8)
        rt_ms = (time.time() - t0) * 1000
        if resp.ok:
            try:
                data = resp.json()
                deployments = 0
                # Azure returns {"data": [...]} for deployments
                if isinstance(data, dict) and 'data' in data and isinstance(data['data'], list):
                    deployments = len(data['data'])
            except Exception:
                deployments = None
            return {
                'status': 'online',
                'response_time': rt_ms,
                'deployments': deployments,
                'last_check': datetime.now().isoformat()
            }
        else:
            return {
                'status': 'error',
                'error': f'HTTP {resp.status_code}',
                'last_check': datetime.now().isoformat()
            }
    except requests.exceptions.Timeout:
        return {
            'status': 'timeout',
            'error': 'Request timeout',
            'last_check': datetime.now().isoformat()
        }
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e),
            'last_check': datetime.now().isoformat()
        }

# Main application startup
if __name__ == '__main__':
    # Clear previous session logs
    try:
        log_files = ['logs/web_ui.log', '../logs/web_ui.log']
        for log_file in log_files:
            try:
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write('')  # Clear the log file
            except (FileNotFoundError, OSError):
                pass  # File doesn't exist or can't be accessed
    except Exception:
        pass
    
    logger.info("🚀 Starting Enhanced Web UI Server...")
    logger.info(f"📍 Server will be available at: http://localhost:{CONFIG['WEB_UI_PORT']}")
    logger.info("🔒 Security features enabled")
    logger.info("⚡ Performance optimizations active")
    
    # Run the Flask application
    app.run(
        host='0.0.0.0',
        port=CONFIG['WEB_UI_PORT'],
        debug=CONFIG['DEBUG'],
        threaded=True
    )
