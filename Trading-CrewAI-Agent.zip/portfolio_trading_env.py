"""
Multi-Asset Portfolio Trading Environment — RL v2.

Replaces the single-symbol ``TradingEnvironment`` (v1) with a portfolio-aware,
regime-conditioned gymnasium environment suited for PPO / SAC continuous-action
policies.

Key differences from v1
------------------------
* **Multi-asset**: trade N symbols simultaneously with shared capital.
* **Continuous action space**: per-asset weight-delta ∈ [−max_delta, +max_delta].
  The environment clips and renormalises weights after each step.
* **Regime one-hot** (4 floats) appended to every observation vector.
* **Risk-aware reward**: alpha − dd_penalty − turnover_cost − VaR_breach + Sharpe_bonus.
* **Kill-switch**: episode terminates when portfolio drawdown exceeds ``max_drawdown``.
* **Mock-data mode**: pass ``data_dict`` directly to skip yfinance / TA-Lib.

Observation vector layout (all float32)
----------------------------------------
For each asset i (in symbols order):
    lookback × n_features price/indicator features  (flattened)

Then appended:
    n_assets  current allocation weights
    4         regime one-hot
    5         portfolio scalars:
                  cash_ratio, value_ratio, total_pnl_pct, drawdown, rolling_vol

Total size = n_assets × lookback × n_features + n_assets + 4 + 5

Action vector layout
---------------------
    n_assets floats ∈ [−max_delta, +max_delta]

Each value is added to the corresponding asset weight; the resulting weight
vector is clipped to [0, max_weight_per_asset] and re-normalised so weights
sum ≤ 1 (remainder is held as cash).
"""

from __future__ import annotations

import warnings
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

try:
    import gymnasium as gym
    from gymnasium import spaces
except ImportError:
    import gym                          # type: ignore[no-redef]
    from gym import spaces              # type: ignore[assignment]

from .regime_classifier import MarketRegime, RegimeClassifier
from .risk_metrics import (
    compute_max_drawdown,
    compute_var_historical,
    compute_turnover,
    compute_sharpe,
    risk_aware_reward,
)

# ---------------------------------------------------------------------------
# Feature constants
# ---------------------------------------------------------------------------
_N_FEATURES = 11   # per asset per timestep (see _compute_features)
# Features:  Close_norm, High_norm, Low_norm, Volume_norm,
#            SMA5_norm, SMA20_norm, RSI_norm, MACD_norm,
#            ATR_norm, BB_width_norm, Price_chg5_norm


class PortfolioTradingEnv(gym.Env):
    """Multi-asset portfolio trading environment for RL v2.

    Parameters
    ----------
    symbols : list[str]
        Asset tickers.  Default: ["^NSEI", "^NSEBANK", "^GSPC", "GLD", "NVDA"].
    initial_balance : float
        Starting cash balance in USD.
    lookback : int
        Number of past timesteps included in each asset's feature block.
    max_weight_per_asset : float
        Upper bound on any single asset's portfolio weight (default 0.40).
    max_delta : float
        Maximum weight-delta the agent can apply per step (default 0.20).
    transaction_cost : float
        Proportional cost per unit of turnover (default 0.001 = 0.1 %).
    max_drawdown : float
        Episode kill-switch: terminates when drawdown exceeds this (default 0.25).
    start_date : str
        Start of training window for yfinance download.
    end_date : str
        End of training window.
    data_dict : dict[str, pd.DataFrame] | None
        Pre-loaded OHLCV DataFrames keyed by symbol.  When provided,
        ``start_date`` / ``end_date`` / yfinance are ignored.  Enables
        unit-testing without network access.
    regime_classifier : RegimeClassifier | None
        Shared regime classifier instance.  A new one is created if None.
    reward_kwargs : dict | None
        Extra kwargs forwarded to ``risk_aware_reward()`` (e.g. ``lambda_dd``).
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        symbols: Optional[List[str]] = None,
        initial_balance: float = 100_000.0,
        lookback: int = 20,
        max_weight_per_asset: float = 0.40,
        max_delta: float = 0.20,
        transaction_cost: float = 0.001,
        max_drawdown: float = 0.25,
        start_date: str = "2020-01-01",
        end_date: str = "2024-12-31",
        data_dict: Optional[Dict[str, pd.DataFrame]] = None,
        regime_classifier: Optional[RegimeClassifier] = None,
        reward_kwargs: Optional[Dict[str, float]] = None,
    ) -> None:
        super().__init__()

        self.symbols: List[str] = symbols or [
            "^NSEI", "^NSEBANK", "^GSPC", "GLD", "NVDA"
        ]
        self.n_assets = len(self.symbols)
        self.initial_balance = initial_balance
        self.lookback = lookback
        self.max_weight_per_asset = max_weight_per_asset
        self.max_delta = max_delta
        self.transaction_cost = transaction_cost
        self.max_drawdown_threshold = max_drawdown
        self.start_date = start_date
        self.end_date = end_date
        self._reward_kwargs: Dict[str, float] = reward_kwargs or {}

        # Regime classifier (shared across env instances when passed in)
        self._regime_clf = regime_classifier or RegimeClassifier()

        # Load or store price data
        self._data_dict: Optional[Dict[str, pd.DataFrame]] = data_dict
        self._features: Optional[Dict[str, np.ndarray]] = None  # computed on reset
        self._closes: Optional[Dict[str, np.ndarray]] = None
        self._n_steps: int = 0  # usable time steps after computing features

        # ── Spaces ─────────────────────────────────────────────────────────
        obs_size = self.n_assets * self.lookback * _N_FEATURES + self.n_assets + 4 + 5
        self.observation_space = spaces.Box(
            low=-10.0, high=10.0, shape=(obs_size,), dtype=np.float32
        )
        self.action_space = spaces.Box(
            low=-self.max_delta,
            high=self.max_delta,
            shape=(self.n_assets,),
            dtype=np.float32,
        )

        # Portfolio state (initialised in reset)
        self._weights: np.ndarray = np.zeros(self.n_assets, dtype=np.float32)
        self._portfolio_value: float = initial_balance
        self._cash: float = initial_balance
        self._step_idx: int = 0
        self._portfolio_history: List[float] = []
        self._returns_history: List[float] = []
        self._prev_prices: Optional[np.ndarray] = None

    # ── Gym API ────────────────────────────────────────────────────────────

    def reset(
        self,
        *,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset environment to the beginning of the data window.

        Returns:
            Tuple of (observation, info_dict).
        """
        super().reset(seed=seed)

        # Load data on first call or if not cached
        if self._features is None:
            self._load_and_compute_features()

        # Reset portfolio
        self._weights = np.zeros(self.n_assets, dtype=np.float32)
        self._portfolio_value = self.initial_balance
        self._cash = self.initial_balance
        self._step_idx = self.lookback  # first usable index
        self._portfolio_history = [self.initial_balance]
        self._returns_history = []
        self._prev_prices = self._get_current_prices()
        self._regime_clf.reset()

        obs = self._get_obs()
        return obs, {"step": self._step_idx}

    def step(
        self, action: np.ndarray
    ) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """Execute one trading step.

        Args:
            action: Per-asset weight deltas of shape (n_assets,).

        Returns:
            (observation, reward, terminated, truncated, info)
        """
        # ── 1. Update weights ────────────────────────────────────────────
        old_weights = self._weights.copy()
        self._apply_action(action)
        turnover = compute_turnover(old_weights, self._weights)

        # ── 2. Price step ────────────────────────────────────────────────
        self._step_idx += 1
        current_prices = self._get_current_prices()

        # ── 3. Portfolio update ──────────────────────────────────────────
        old_value = self._portfolio_value
        price_returns = self._price_returns(current_prices)

        # P&L from each position
        pnl = float(np.dot(old_weights * old_value, price_returns))
        # Transaction cost on turnover
        cost = self.transaction_cost * turnover * old_value
        self._portfolio_value = old_value + pnl - cost
        self._cash = self._portfolio_value * (1.0 - float(np.sum(self._weights)))

        step_return = (self._portfolio_value - old_value) / max(old_value, 1.0)
        self._portfolio_history.append(self._portfolio_value)
        self._returns_history.append(step_return)
        self._prev_prices = current_prices

        # ── 4. Reward ────────────────────────────────────────────────────
        drawdown = compute_max_drawdown(np.array(self._portfolio_history))
        rolling_r = np.array(self._returns_history[-20:])
        sharpe = compute_sharpe(rolling_r) if len(rolling_r) >= 2 else 0.0
        var95 = compute_var_historical(rolling_r) if len(rolling_r) >= 5 else 0.0
        var_breach = max(0.0, -step_return - var95)

        reward = risk_aware_reward(
            portfolio_return=step_return,
            drawdown=drawdown,
            turnover=turnover,
            var_breach=var_breach,
            rolling_sharpe=sharpe,
            **self._reward_kwargs,
        )

        # ── 5. Termination ───────────────────────────────────────────────
        terminated = (
            drawdown >= self.max_drawdown_threshold
            or self._step_idx >= self._n_steps - 1
        )
        truncated = False

        obs = self._get_obs()
        info = {
            "portfolio_value": self._portfolio_value,
            "drawdown": drawdown,
            "turnover": turnover,
            "sharpe": sharpe,
            "regime": self._current_regime().name,
            "step": self._step_idx,
        }
        return obs, float(reward), terminated, truncated, info

    def render(self) -> None:
        """Print a brief portfolio summary."""
        dd = compute_max_drawdown(np.array(self._portfolio_history))
        print(
            f"Step {self._step_idx:4d} | "
            f"Portfolio: ${self._portfolio_value:,.0f} | "
            f"Drawdown: {dd:.1%} | "
            f"Regime: {self._current_regime().name} | "
            f"Weights: {np.round(self._weights, 2)}"
        )

    # ── Observation builder ────────────────────────────────────────────────

    def _get_obs(self) -> np.ndarray:
        """Build the flat observation vector."""
        parts: List[np.ndarray] = []

        # Per-asset lookback feature blocks
        for i, sym in enumerate(self.symbols):
            feat = self._features[sym]  # shape (T, _N_FEATURES)
            block = feat[self._step_idx - self.lookback: self._step_idx]
            parts.append(block.flatten().astype(np.float32))

        # Current allocation weights
        parts.append(self._weights.astype(np.float32))

        # Regime one-hot
        parts.append(RegimeClassifier.to_one_hot(self._current_regime()))

        # Portfolio scalars
        total_val = self._portfolio_value
        pnl_pct = (total_val - self.initial_balance) / self.initial_balance
        drawdown = compute_max_drawdown(np.array(self._portfolio_history))
        rolling_r = np.array(self._returns_history[-20:])
        roll_vol = float(np.std(rolling_r, ddof=1) * np.sqrt(252)) if len(rolling_r) >= 2 else 0.0
        portfolio_scalars = np.array(
            [
                self._cash / self.initial_balance,  # cash_ratio
                total_val / self.initial_balance,   # value_ratio
                pnl_pct,                            # total_pnl_pct
                drawdown,                           # drawdown
                roll_vol,                           # rolling_vol
            ],
            dtype=np.float32,
        )
        parts.append(portfolio_scalars)

        obs = np.concatenate(parts)
        return np.clip(obs, -10.0, 10.0).astype(np.float32)

    # ── Portfolio helpers ──────────────────────────────────────────────────

    def _apply_action(self, action: np.ndarray) -> None:
        """Apply weight deltas, clip and renormalise."""
        new_weights = self._weights + np.asarray(action, dtype=np.float32)
        # Clip each weight to valid range
        new_weights = np.clip(new_weights, 0.0, self.max_weight_per_asset)
        # Renormalise so sum ≤ 1 (excess is cash)
        total = float(np.sum(new_weights))
        if total > 1.0:
            new_weights /= total
        self._weights = new_weights

    def _get_current_prices(self) -> np.ndarray:
        """Extract current closing prices for all assets."""
        prices = np.array(
            [
                float(self._closes[sym][self._step_idx])
                for sym in self.symbols
            ],
            dtype=np.float32,
        )
        return prices

    def _price_returns(self, current_prices: np.ndarray) -> np.ndarray:
        """Per-asset step return based on price change since last step."""
        if self._prev_prices is None:
            return np.zeros(self.n_assets, dtype=np.float32)
        safe_prev = np.where(self._prev_prices > 0, self._prev_prices, 1.0)
        return (current_prices - self._prev_prices) / safe_prev

    def _current_regime(self) -> MarketRegime:
        """Compute portfolio-level regime from available price history."""
        closes_dict: Dict[str, np.ndarray] = {
            sym: self._closes[sym][: self._step_idx + 1]
            for sym in self.symbols
        }
        return self._regime_clf.classify_multi_asset(closes_dict)

    # ── Data loading / feature engineering ────────────────────────────────

    def _load_and_compute_features(self) -> None:
        """Load price data (yfinance or injected dict) and compute indicators."""
        if self._data_dict is not None:
            raw = self._data_dict
        else:
            raw = self._download_data()

        features: Dict[str, np.ndarray] = {}
        closes: Dict[str, np.ndarray] = {}
        lengths: List[int] = []

        for sym in self.symbols:
            df = raw.get(sym)
            if df is None or len(df) < self.lookback + 5:
                raise ValueError(
                    f"Insufficient data for symbol '{sym}': "
                    f"need ≥ {self.lookback + 5} rows."
                )
            f, c = self._compute_features(df)
            features[sym] = f
            closes[sym] = c
            lengths.append(len(f))

        # Align all series to shortest length
        min_len = min(lengths)
        for sym in self.symbols:
            features[sym] = features[sym][-min_len:]
            closes[sym] = closes[sym][-min_len:]

        self._features = features
        self._closes = closes
        self._n_steps = min_len

    def _download_data(self) -> Dict[str, pd.DataFrame]:
        """Download OHLCV data from yfinance."""
        try:
            import yfinance as yf
        except ImportError as exc:
            raise ImportError("yfinance is required for data download") from exc

        data: Dict[str, pd.DataFrame] = {}
        for sym in self.symbols:
            df = yf.download(sym, start=self.start_date, end=self.end_date,
                             progress=False, auto_adjust=True)
            if df.empty:
                raise ValueError(f"No data returned for symbol '{sym}'")
            data[sym] = df
        return data

    @staticmethod
    def _compute_features(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Compute a normalised _N_FEATURES-dim feature matrix from an OHLCV DataFrame.

        Features (11 per timestep):
            0  Close / Close (=1, anchor)  → normalised by rolling mean
            1  High / Close
            2  Low  / Close
            3  log(Volume / Volume_SMA20)
            4  SMA5 / Close
            5  SMA20 / Close
            6  RSI / 100
            7  MACD_norm  (MACD / Close)
            8  ATR / Close
            9  BB_width / Close
            10 5-day price change (fraction)

        Returns:
            features: float32 array of shape (T, _N_FEATURES)
            closes:   float32 array of shape (T,)
        """
        close = df["Close"].values.astype(float).flatten()
        high  = df["High"].values.astype(float).flatten()
        low   = df["Low"].values.astype(float).flatten()
        vol   = df["Volume"].values.astype(float).flatten()
        T = len(close)

        safe_close = np.where(close > 0, close, 1.0)

        # SMA
        def _sma(x: np.ndarray, n: int) -> np.ndarray:
            out = np.full(T, np.nan)
            for i in range(n - 1, T):
                out[i] = np.mean(x[i - n + 1: i + 1])
            return out

        sma5  = _sma(close, 5)
        sma20 = _sma(close, 20)
        vol_sma20 = _sma(vol, 20)

        # RSI (14-period)
        delta = np.diff(close, prepend=close[0])
        gain = np.where(delta > 0, delta, 0.0)
        loss = np.where(delta < 0, -delta, 0.0)
        avg_gain = _sma(gain, 14)
        avg_loss = _sma(loss, 14)
        rs = np.where(avg_loss > 1e-9, avg_gain / avg_loss, 100.0)
        rsi = 100.0 - 100.0 / (1.0 + rs)

        # MACD (12/26 EMA diff)
        def _ema(x: np.ndarray, n: int) -> np.ndarray:
            out = np.full(T, np.nan)
            alpha = 2.0 / (n + 1)
            for i in range(T):
                if np.isnan(x[i]):
                    continue
                if np.isnan(out[max(0, i - 1)]):
                    out[i] = x[i]
                else:
                    out[i] = alpha * x[i] + (1.0 - alpha) * out[i - 1]
            return out

        ema12 = _ema(close, 12)
        ema26 = _ema(close, 26)
        macd = ema12 - ema26

        # ATR (14-period)
        prev_close = np.roll(close, 1)
        prev_close[0] = close[0]
        tr = np.maximum(high - low, np.maximum(np.abs(high - prev_close), np.abs(low - prev_close)))
        atr = _sma(tr, 14)

        # Bollinger Bands width (20-period)
        rolling_std = np.full(T, np.nan)
        for i in range(19, T):
            rolling_std[i] = np.std(close[i - 19: i + 1], ddof=0)
        bb_width = 4.0 * rolling_std  # upper - lower

        # 5-day price change
        price_chg5 = np.zeros(T)
        for i in range(5, T):
            if close[i - 5] > 0:
                price_chg5[i] = (close[i] - close[i - 5]) / close[i - 5]

        # Volume normalisation
        safe_vol_sma = np.where(vol_sma20 > 0, vol_sma20, 1.0)
        vol_norm = np.log1p(vol / safe_vol_sma)

        # Build feature matrix and normalise
        features = np.stack(
            [
                close / safe_close,             # 0: = 1 (anchor)
                high / safe_close,              # 1
                low / safe_close,               # 2
                vol_norm,                       # 3
                np.where(~np.isnan(sma5),  sma5  / safe_close, 1.0),   # 4
                np.where(~np.isnan(sma20), sma20 / safe_close, 1.0),   # 5
                np.where(~np.isnan(rsi),   rsi   / 100.0, 0.5),        # 6
                np.where(~np.isnan(macd),  macd  / safe_close, 0.0),   # 7
                np.where(~np.isnan(atr),   atr   / safe_close, 0.0),   # 8
                np.where(~np.isnan(bb_width), bb_width / safe_close, 0.0),  # 9
                np.clip(price_chg5, -0.5, 0.5),  # 10
            ],
            axis=1,
        ).astype(np.float32)

        # Fill NaN with 0 (early timesteps)
        features = np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0)
        return features, close.astype(np.float32)
