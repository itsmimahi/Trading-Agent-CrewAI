"""
Enhanced Dividends Yield Optimizer Agent using CrewAI Framework - Hybrid Plus Approach
Identify dividend-paying stocks that are consistent, safe, and high-yielding
"""

import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from config.settings import config
from crewai import Task, Crew, Process

logger = logging.getLogger(__name__)

@dataclass
class DividendMetrics:
    """Dividend metrics structure"""
    dividend_yield: float
    payout_ratio: float
    dividend_growth_rate: float
    dividend_consistency: float
    free_cash_flow_coverage: float
    sustainability_score: float

@dataclass
class DividendStock:
    """Dividend stock structure"""
    symbol: str
    company_name: str
    dividend_yield: float
    payout_ratio: float
    dividend_growth_rate: float
    sustainability_score: float
    sector: str
    market_cap: float
    recommendation: str

class EnhancedDividendsYieldOptimizer(EnhancedBaseAgent):
    """
    Enhanced Dividends Yield Optimizer Agent using CrewAI Framework with Hybrid Plus Approach
    
    Mathematical Core: Dividend yield calculations, payout ratio analysis, sustainability scoring
    LLM Reasoning: Dividend sustainability analysis, sector comparison, income strategy planning
    Tools: Dividend screener, payout sustainability calculator, sector-dividend benchmarks
    Memory: Dividend payment history, sustainability tracking, sector performance
    Knowledge Base: Dividend investing principles, sector dividend patterns, sustainability metrics
    """
    
    def __init__(self, name: str = "EnhancedDividendsYieldOptimizer", description: str = "Dividends Yield Optimizer Agent for identifying high-yielding dividend stocks", role: str = "Dividend Investment Specialist", goal: str = "Identify dividend-paying stocks that are consistent, safe, and high-yielding", backstory: str = "Expert in dividend investing with deep knowledge of income strategies and dividend sustainability", capabilities: Optional[List[Any]] = None, weight: float = 0.15, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.RISK_ASSESSMENT,
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.PATTERN_RECOGNITION
            ]
        super().__init__(
            name=name,
            description=description,
            capabilities=capabilities,
            weight=weight,
            use_llm=use_llm,
            use_memory=use_memory,
            use_knowledge_base=use_knowledge_base,
            role=role,
            goal=goal,
            backstory=backstory,
            **kwargs
        )
        
        # Dividend screening parameters
        self.dividend_thresholds = {
            'min_dividend_yield': 0.03,  # 3% minimum yield
            'max_payout_ratio': 0.75,  # 75% maximum payout ratio
            'min_sustainability_score': 0.6,  # 60% minimum sustainability
            'min_market_cap': 1000000000,  # $1B minimum market cap
            'min_dividend_growth': 0.02  # 2% minimum dividend growth
        }
        
        # Sector dividend benchmarks
        self.sector_benchmarks = {
            'utilities': {'avg_yield': 0.04, 'avg_payout': 0.65},
            'financials': {'avg_yield': 0.035, 'avg_payout': 0.45},
            'consumer_staples': {'avg_yield': 0.03, 'avg_payout': 0.55},
            'energy': {'avg_yield': 0.045, 'avg_payout': 0.60},
            'real_estate': {'avg_yield': 0.04, 'avg_payout': 0.70},
            'technology': {'avg_yield': 0.02, 'avg_payout': 0.30}
        }
        
        # Load dividend knowledge
        self._load_dividend_knowledge()
    
    def _load_dividend_knowledge(self):
        """Load dividend investing knowledge into knowledge base"""
        try:
            dividend_knowledge = [
                # Dividend Investing Principles
                "High Dividend Yield: Stocks with yields above 4% may indicate value or risk",
                "Sustainable Payout Ratio: Payout ratios below 60% are generally sustainable",
                "Dividend Growth: Companies with consistent dividend growth are preferred",
                "Free Cash Flow Coverage: FCF should cover dividend payments comfortably",
                "Sector Diversification: Spread dividend investments across sectors",
                
                # Dividend Sustainability
                "Earnings Stability: Companies with stable earnings can maintain dividends",
                "Debt Levels: Low debt-to-equity ratios support dividend sustainability",
                "Cash Flow Generation: Strong operating cash flow supports dividends",
                "Industry Position: Market leaders tend to have more stable dividends",
                "Economic Sensitivity: Defensive sectors maintain dividends in downturns",
                
                # Dividend Strategy
                "Dividend Aristocrats: Companies with 25+ years of dividend increases",
                "Dividend Growth Strategy: Focus on companies growing dividends over time",
                "High Yield Strategy: Focus on current yield for immediate income",
                "Dividend Reinvestment: DRIP programs can compound returns over time",
                "Tax Efficiency: Qualified dividends receive favorable tax treatment",
                
                # Risk Management
                "Yield Trap: Very high yields may indicate dividend cuts ahead",
                "Sector Concentration: Avoid over-concentration in single sector",
                "Interest Rate Sensitivity: Dividend stocks sensitive to rate changes",
                "Economic Cycle: Some sectors perform better in different cycles",
                "Dividend Cuts: Monitor signs of potential dividend reductions"
            ]
            
            if self.use_knowledge_base:
                self.knowledge_base.add_knowledge(dividend_knowledge)
                
        except Exception as e:
            self.logger.error(f"Error loading dividend knowledge: {e}")
    
    async def analyze(self, symbol: str, dividend_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Main analysis method combining mathematical analysis with CrewAI reasoning"""
        try:
            self.logger.info(f"Starting CrewAI comprehensive dividend analysis for {symbol}")
            
            # Use provided dividend data or create mock data
            if dividend_data is None:
                dividend_data = self._create_mock_dividend_data(symbol)
            
            # 1. Mathematical Analysis (Dividend metrics and sustainability)
            math_results = await self.mathematical_analysis(symbol, {'dividend_data': dividend_data})
            if "error" in math_results:
                return math_results
            
            # 2. Get market context for CrewAI reasoning
            market_context = await self._get_market_context(symbol)
            
            # 3. CrewAI Reasoning (Dividend sustainability and strategy)
            if self.use_llm:
                crewai_reasoning = await self._get_crewai_dividend_reasoning(math_results, market_context)
            else:
                crewai_reasoning = {"reasoning": "CrewAI analysis not available"}
            
            # 4. Final Synthesis
            final_analysis = {
                "agent_name": self.name,
                "symbol": symbol,
                "analysis_timestamp": datetime.now().isoformat(),
                "mathematical_analysis": math_results,
                "crewai_reasoning": crewai_reasoning,
                "market_context": market_context,
                "confidence_score": math_results.get('sustainability_score', 0.5),
                "recommendation": math_results.get('recommendation', 'HOLD'),
                "agent_weight": self.weight
            }
            
            return final_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI comprehensive analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Perform mathematical/quantitative dividend analysis"""
        try:
            dividend_data = data.get('dividend_data', {})
            
            # Calculate dividend metrics
            dividend_metrics = self._calculate_dividend_metrics(dividend_data)
            
            # Assess dividend sustainability
            sustainability_analysis = self._assess_dividend_sustainability(dividend_metrics)
            
            # Compare with sector benchmarks
            sector_comparison = self._compare_with_sector_benchmarks(dividend_metrics, dividend_data.get('sector', 'unknown'))
            
            # Generate dividend recommendation
            recommendation = self._generate_dividend_recommendation(dividend_metrics, sustainability_analysis)
            
            return {
                "symbol": symbol,
                "dividend_metrics": dividend_metrics,
                "sustainability_analysis": sustainability_analysis,
                "sector_comparison": sector_comparison,
                "recommendation": recommendation,
                "calculation_timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in mathematical analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    def _calculate_dividend_metrics(self, dividend_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate comprehensive dividend metrics"""
        try:
            # Extract basic dividend data
            annual_dividend = dividend_data.get('annual_dividend', 0)
            stock_price = dividend_data.get('stock_price', 100)
            earnings_per_share = dividend_data.get('earnings_per_share', 0)
            free_cash_flow = dividend_data.get('free_cash_flow', 0)
            dividend_growth_rate = dividend_data.get('dividend_growth_rate', 0)
            
            # Calculate key metrics
            dividend_yield = annual_dividend / stock_price if stock_price > 0 else 0
            payout_ratio = annual_dividend / earnings_per_share if earnings_per_share > 0 else 0
            fcf_coverage = free_cash_flow / annual_dividend if annual_dividend > 0 else 0
            
            # Calculate dividend consistency (mock calculation)
            dividend_consistency = 0.8  # Mock value, would be calculated from historical data
            
            # Calculate sustainability score
            sustainability_score = self._calculate_sustainability_score(
                dividend_yield, payout_ratio, fcf_coverage, dividend_consistency
            )
            
            return {
                "dividend_yield": dividend_yield,
                "payout_ratio": payout_ratio,
                "dividend_growth_rate": dividend_growth_rate,
                "dividend_consistency": dividend_consistency,
                "free_cash_flow_coverage": fcf_coverage,
                "sustainability_score": sustainability_score
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating dividend metrics: {e}")
            return {
                "dividend_yield": 0,
                "payout_ratio": 0,
                "dividend_growth_rate": 0,
                "dividend_consistency": 0,
                "free_cash_flow_coverage": 0,
                "sustainability_score": 0
            }
    
    def _calculate_sustainability_score(self, dividend_yield: float, payout_ratio: float, 
                                     fcf_coverage: float, dividend_consistency: float) -> float:
        """Calculate dividend sustainability score"""
        try:
            score = 0.0
            
            # Payout ratio contribution (lower is better, max 40%)
            if payout_ratio <= 0.4:
                score += 0.3
            elif payout_ratio <= 0.6:
                score += 0.2
            elif payout_ratio <= 0.8:
                score += 0.1
            
            # FCF coverage contribution (higher is better)
            if fcf_coverage >= 2.0:
                score += 0.3
            elif fcf_coverage >= 1.5:
                score += 0.2
            elif fcf_coverage >= 1.0:
                score += 0.1
            
            # Dividend consistency contribution
            score += dividend_consistency * 0.2
            
            # Dividend yield contribution (moderate is better)
            if 0.03 <= dividend_yield <= 0.06:
                score += 0.2
            elif 0.02 <= dividend_yield <= 0.08:
                score += 0.1
            
            return min(score, 1.0)
            
        except Exception as e:
            self.logger.error(f"Error calculating sustainability score: {e}")
            return 0.5
    
    def _assess_dividend_sustainability(self, dividend_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Assess dividend sustainability"""
        try:
            sustainability_score = dividend_metrics.get('sustainability_score', 0)
            payout_ratio = dividend_metrics.get('payout_ratio', 0)
            fcf_coverage = dividend_metrics.get('free_cash_flow_coverage', 0)
            
            # Determine sustainability level
            if sustainability_score >= 0.8:
                sustainability_level = "HIGH"
                risk_level = "LOW"
            elif sustainability_score >= 0.6:
                sustainability_level = "MEDIUM"
                risk_level = "MODERATE"
            else:
                sustainability_level = "LOW"
                risk_level = "HIGH"
            
            # Identify risk factors
            risk_factors = []
            if payout_ratio > 0.75:
                risk_factors.append("High payout ratio")
            if fcf_coverage < 1.0:
                risk_factors.append("Insufficient FCF coverage")
            if sustainability_score < 0.5:
                risk_factors.append("Low sustainability score")
            
            return {
                "sustainability_level": sustainability_level,
                "risk_level": risk_level,
                "risk_factors": risk_factors,
                "sustainability_score": sustainability_score,
                "recommendation": "BUY" if sustainability_score >= 0.7 else "HOLD" if sustainability_score >= 0.5 else "SELL"
            }
            
        except Exception as e:
            self.logger.error(f"Error assessing dividend sustainability: {e}")
            return {
                "sustainability_level": "UNKNOWN",
                "risk_level": "UNKNOWN",
                "risk_factors": ["Unable to assess"],
                "sustainability_score": 0.5,
                "recommendation": "HOLD"
            }
    
    def _compare_with_sector_benchmarks(self, dividend_metrics: Dict[str, Any], sector: str) -> Dict[str, Any]:
        """Compare dividend metrics with sector benchmarks"""
        try:
            dividend_yield = dividend_metrics.get('dividend_yield', 0)
            payout_ratio = dividend_metrics.get('payout_ratio', 0)
            
            # Get sector benchmarks
            sector_benchmark = self.sector_benchmarks.get(sector.lower(), 
                                                        {'avg_yield': 0.03, 'avg_payout': 0.5})
            
            avg_yield = sector_benchmark['avg_yield']
            avg_payout = sector_benchmark['avg_payout']
            
            # Calculate relative performance
            yield_vs_sector = dividend_yield / avg_yield if avg_yield > 0 else 1.0
            payout_vs_sector = payout_ratio / avg_payout if avg_payout > 0 else 1.0
            
            # Determine sector ranking
            if yield_vs_sector > 1.2 and payout_vs_sector < 1.1:
                sector_ranking = "ABOVE_AVERAGE"
            elif yield_vs_sector > 1.0 and payout_vs_sector < 1.2:
                sector_ranking = "AVERAGE"
            else:
                sector_ranking = "BELOW_AVERAGE"
            
            return {
                "sector": sector,
                "sector_avg_yield": avg_yield,
                "sector_avg_payout": avg_payout,
                "yield_vs_sector": yield_vs_sector,
                "payout_vs_sector": payout_vs_sector,
                "sector_ranking": sector_ranking
            }
            
        except Exception as e:
            self.logger.error(f"Error comparing with sector benchmarks: {e}")
            return {
                "sector": sector,
                "sector_avg_yield": 0.03,
                "sector_avg_payout": 0.5,
                "yield_vs_sector": 1.0,
                "payout_vs_sector": 1.0,
                "sector_ranking": "UNKNOWN"
            }
    
    def _generate_dividend_recommendation(self, dividend_metrics: Dict[str, Any], 
                                        sustainability_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Generate dividend investment recommendation"""
        try:
            dividend_yield = dividend_metrics.get('dividend_yield', 0)
            sustainability_score = dividend_metrics.get('sustainability_score', 0)
            risk_level = sustainability_analysis.get('risk_level', 'UNKNOWN')
            
            # Determine recommendation based on yield and sustainability
            if dividend_yield >= self.dividend_thresholds['min_dividend_yield'] and sustainability_score >= 0.7:
                recommendation = "STRONG_BUY"
                reasoning = "High yield with strong sustainability"
            elif dividend_yield >= self.dividend_thresholds['min_dividend_yield'] and sustainability_score >= 0.6:
                recommendation = "BUY"
                reasoning = "Good yield with acceptable sustainability"
            elif dividend_yield >= self.dividend_thresholds['min_dividend_yield'] and sustainability_score >= 0.5:
                recommendation = "HOLD"
                reasoning = "High yield but sustainability concerns"
            elif sustainability_score >= 0.8:
                recommendation = "BUY"
                reasoning = "Strong sustainability despite lower yield"
            else:
                recommendation = "SELL"
                reasoning = "Poor yield or sustainability"
            
            return {
                "recommendation": recommendation,
                "reasoning": reasoning,
                "dividend_yield": dividend_yield,
                "sustainability_score": sustainability_score,
                "risk_level": risk_level
            }
            
        except Exception as e:
            self.logger.error(f"Error generating dividend recommendation: {e}")
            return {
                "recommendation": "HOLD",
                "reasoning": "Unable to generate recommendation",
                "dividend_yield": 0,
                "sustainability_score": 0.5,
                "risk_level": "UNKNOWN"
            }
    
    def _create_mock_dividend_data(self, symbol: str) -> Dict[str, Any]:
        """Create mock dividend data for testing"""
        return {
            "annual_dividend": 2.50,
            "stock_price": 50.00,
            "earnings_per_share": 4.00,
            "free_cash_flow": 300000000,
            "dividend_growth_rate": 0.05,
            "sector": "utilities",
            "market_cap": 5000000000,
            "company_name": f"Mock Company {symbol}"
        }
    
    async def _get_market_context(self, symbol: str) -> str:
        """Get current market context for CrewAI reasoning"""
        try:
            return f"""
            Dividend analysis context for {symbol}:
            - Interest rate environment: Impact on dividend stock attractiveness
            - Economic cycle: Current phase and its effect on dividend sustainability
            - Sector rotation: Which sectors are favored for dividend investing
            - Market volatility: Impact on dividend stock performance
            - Inflation expectations: Effect on real dividend yields
            - Regulatory environment: Changes affecting dividend policies
            - Tax policy: Impact on dividend taxation and investor preferences
            - Sector-specific factors: Industry trends affecting dividend sustainability
            """
        except Exception as e:
            self.logger.error(f"Error getting market context: {e}")
            return "Market context not available"

    async def _get_crewai_dividend_reasoning(self, math_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Get CrewAI-based dividend reasoning for sustainability analysis"""
        try:
            reasoning_prompt = f"""
            You are an expert dividend investment specialist with deep knowledge of income strategies and dividend sustainability.
            
            Dividend Analysis Results:
            {math_results}
            
            Market Context:
            {market_context}
            
            Based on this comprehensive dividend analysis, provide:
            1. Dividend Sustainability Assessment - Long-term viability of dividend payments
            2. Income Strategy Analysis - How this stock fits into income portfolios
            3. Risk Assessment - Potential risks to dividend payments
            4. Sector Analysis - How sector factors affect dividend sustainability
            5. Investment Timing - Optimal timing for dividend stock investment
            6. Portfolio Integration - How this dividend stock fits into broader portfolio
            
            Consider:
            - Dividend yield vs. sustainability trade-offs
            - Sector-specific dividend patterns and risks
            - Economic cycle impact on dividend sustainability
            - Interest rate sensitivity of dividend stocks
            - Tax implications of dividend income
            - Diversification benefits of dividend stocks
            
            Provide comprehensive dividend analysis that combines quantitative metrics with market wisdom.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive dividend reasoning and sustainability analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            return {"reasoning": str(result)}
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI dividend reasoning: {str(e)}")
            return {"error": str(e)}

    async def optimize_dividends(self, symbol: str, dividend_data: Dict[str, Any] = None) -> dict:
        """Main method for dividend optimization. Calls analyze method."""
        try:
            return await self.analyze(symbol, dividend_data)
        except Exception as e:
            self.logger.error(f"Error in optimize_dividends: {e}")
            return {"error": str(e)} 
        
        
        