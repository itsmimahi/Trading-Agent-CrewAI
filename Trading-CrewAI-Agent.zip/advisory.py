"""
Advisory Agent API Routes
Flask routes for interacting with the main advisory agent.
"""

from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import json
import asyncio
from typing import Dict, Any
from datetime import datetime
import os

# Lazy-load the heavy MainAdvisoryAgent to improve startup time and health readiness
_MAIN_AGENT = None
def _get_main_agent():
    global _MAIN_AGENT
    if _MAIN_AGENT is None:
        try:
            from main_advisory_agent import MainAdvisoryAgent  # type: ignore
            _MAIN_AGENT = MainAdvisoryAgent()
        except Exception as e:
            # Defer errors to request time for clearer responses
            raise RuntimeError(f"Failed to initialize MainAdvisoryAgent: {e}")
    return _MAIN_AGENT
from idempotency_store import IdempotencyStore
from agent_registry import agent_registry
from conversation import conversation_manager, MessageType
# Integration is optional; degrade gracefully if unavailable
try:
    from integration_connector import integration_connector  # type: ignore
except Exception:
    class _StubIntegration:
        is_connected = False
        async def initialize(self):
            return False
    integration_connector = _StubIntegration()  # type: ignore

advisory_bp = Blueprint('advisory', __name__)
_IDEMP_STORE = IdempotencyStore(db_path=os.environ.get('IDEMPOTENCY_DB', 'idempotency_cache.db'))


@advisory_bp.route('/chat', methods=['POST'])
@cross_origin()
def chat():
    """Main chat endpoint for user interactions."""
    try:
        # Opportunistic TTL cleanup (no-op if errors)
        try:
            ttl = int(os.environ.get('IDEMPOTENCY_TTL_SECONDS', '86400'))
            max_rows = int(os.environ.get('IDEMPOTENCY_PURGE_BATCH', '100'))
            _IDEMP_STORE.purge_expired(ttl_seconds=ttl, max_rows=max_rows)
        except Exception:
            pass

        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required', 'status': 'error'}), 400

        user_message = data['message']
        conversation_id = data.get('conversation_id')
        idem_key = request.headers.get('Idempotency-Key') or data.get('idempotency_key')
        request_id = request.headers.get('X-Request-ID')

        # Fast path for testing
        test_mode = bool(data.get('test_mode')) or os.environ.get('ADVISORY_TEST_MODE') == '1'
        if test_mode:
            context = conversation_manager.get_conversation(conversation_id) if conversation_id else None
            if not context:
                context = conversation_manager.create_conversation(conversation_id) if conversation_id else conversation_manager.create_conversation()
            try:
                context.add_message(MessageType.USER_INPUT, user_message)
                quick_response = f"[TEST MODE] Quick advisory response to: {user_message[:120]}"
                context.add_message(MessageType.AGENT_RESPONSE, quick_response)
            except Exception:
                quick_response = f"[TEST MODE] Quick advisory response to: {user_message[:120]}"
            return jsonify({'response': quick_response, 'conversation_id': context.conversation_id, 'intent': 'general_advice', 'confidence': 0.5, 'entities': [], 'context_summary': None, 'status': 'success'})

        # Idempotency cache
        if idem_key:
            rec, inserted = _IDEMP_STORE.start(idem_key, conversation_id=conversation_id)
            if rec:
                if rec.status == 'completed' and rec.response_json:
                    cached = json.loads(rec.response_json)
                    cached['cached'] = True
                    resp = jsonify(cached)
                    if request_id:
                        resp.headers['X-Request-ID'] = request_id
                    return resp
                if rec.status == 'failed' and rec.response_json:
                    cached = json.loads(rec.response_json)
                    cached['cached'] = True
                    resp = jsonify(cached)
                    if request_id:
                        resp.headers['X-Request-ID'] = request_id
                    return resp, 409
                if not inserted and rec.status == 'in_progress':
                    body = {'status': 'in_progress', 'conversation_id': rec.conversation_id}
                    resp = jsonify(body)
                    resp.headers['Retry-After'] = '1'
                    if request_id:
                        resp.headers['X-Request-ID'] = request_id
                    return resp, 202

        # Process request
        result = _get_main_agent().process_user_input(user_message, conversation_id, request_id=request_id)
        if isinstance(result, dict) and 'error' in result:
            if idem_key:
                try:
                    _IDEMP_STORE.set_failed(idem_key, result, conversation_id=result.get('conversation_id'))
                except Exception:
                    pass
            return jsonify({'error': result.get('error', 'Unknown error'), 'status': 'error'}), 500

        payload = {
            'response': result.get('response'),
            'conversation_id': result.get('conversation_id'),
            'intent': result.get('intent'),
            'confidence': result.get('confidence'),
            'entities': result.get('entities', []),
            'context_summary': result.get('context_summary'),
            'request_id': result.get('request_id'),
            'status': 'success'
        }
        if idem_key:
            try:
                _IDEMP_STORE.set_result(idem_key, payload, conversation_id=payload.get('conversation_id'))
            except Exception:
                pass
        resp = jsonify(payload)
        if request_id:
            resp.headers['X-Request-ID'] = request_id
        return resp
    except Exception as e:
        return jsonify({'error': f'Internal server error: {str(e)}', 'status': 'error'}), 500


@advisory_bp.route('/conversation/<conversation_id>', methods=['GET'])
@cross_origin()
def get_conversation(conversation_id: str):
    """Get conversation history."""
    try:
        history = _get_main_agent().get_conversation_history(conversation_id)
        
        if not history:
            return jsonify({
                'error': 'Conversation not found',
                'status': 'error'
            }), 404
        
        return jsonify({
            'conversation': history,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'error': f'Error retrieving conversation: {str(e)}',
            'status': 'error'
        }), 500


@advisory_bp.route('/conversations', methods=['GET'])
@cross_origin()
def list_conversations():
    """List all active conversations."""
    try:
        conversations = _get_main_agent().list_active_conversations()
        
        return jsonify({
            'conversations': conversations,
            'count': len(conversations),
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'error': f'Error listing conversations: {str(e)}',
            'status': 'error'
        }), 500


@advisory_bp.route('/conversation/<conversation_id>', methods=['DELETE'])
@cross_origin()
def delete_conversation(conversation_id: str):
    """Delete a conversation."""
    try:
        success = conversation_manager.delete_conversation(conversation_id)
        
        if not success:
            return jsonify({
                'error': 'Conversation not found',
                'status': 'error'
            }), 404
        
        return jsonify({
            'message': 'Conversation deleted successfully',
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'error': f'Error deleting conversation: {str(e)}',
            'status': 'error'
        }), 500


@advisory_bp.route('/agents', methods=['GET'])
@cross_origin()
def get_agents():
    """Get all available specialized agents."""
    try:
        agents = agent_registry.get_active_agents()
        
        return jsonify({
            'agents': [agent.to_dict() for agent in agents],
            'count': len(agents),
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'error': f'Error retrieving agents: {str(e)}',
            'status': 'error'
        }), 500


@advisory_bp.route('/agents/<agent_id>', methods=['GET'])
@cross_origin()
def get_agent(agent_id: str):
    """Get details of a specific agent."""
    try:
        agent = agent_registry.get_agent(agent_id)
        
        if not agent:
            return jsonify({
                'error': 'Agent not found',
                'status': 'error'
            }), 404
        
        return jsonify({
            'agent': agent.to_dict(),
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'error': f'Error retrieving agent: {str(e)}',
            'status': 'error'
        }), 500


@advisory_bp.route('/agents/capabilities', methods=['GET'])
@cross_origin()
def get_agent_capabilities():
    """Get all agent capabilities."""
    try:
        agents = agent_registry.get_active_agents()
        capabilities = {}
        
        for agent in agents:
            capabilities[agent.agent_id] = {
                'name': agent.name,
                'role': agent.role,
                'capabilities': [
                    {
                        'name': cap.name,
                        'description': cap.description
                    }
                    for cap in agent.capabilities
                ]
            }
        
        return jsonify({
            'capabilities': capabilities,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'error': f'Error retrieving capabilities: {str(e)}',
            'status': 'error'
        }), 500


@advisory_bp.route('/health', methods=['GET'])
@cross_origin()
def health_check():
    """Health check endpoint."""
    try:
        # Check if main components are working
        agent_count = len(agent_registry.get_active_agents())
        conversation_count = len(conversation_manager.get_all_conversations())
        # DB health (optional)
        db_ok = True
        try:
            from user import db  # type: ignore
            db_ok = hasattr(db, 'engine') or True
        except Exception:
            db_ok = False
        # RL API health quick ping
        rl_api_ok = False
        try:
            import requests  # type: ignore
            resp = requests.get(os.environ.get('RL_API_HEALTH_URL', 'http://localhost:5000/api/rl/health'), timeout=2)
            rl_api_ok = (resp.status_code == 200)
        except Exception:
            pass
        
        return jsonify({
            'status': 'healthy',
            'timestamp': str(datetime.now()),
            'components': {
                'agent_registry': {
                    'status': 'active',
                    'agent_count': agent_count
                },
                'conversation_manager': {
                    'status': 'active',
                    'conversation_count': conversation_count
                },
                'database': {
                    'status': 'active' if db_ok else 'disabled'
                },
                'rl_api': {
                    'status': 'reachable' if rl_api_ok else 'unreachable',
                    'url': os.environ.get('RL_API_HEALTH_URL', 'http://localhost:5000/api/rl/health')
                },
                'main_advisory_agent': {
                    'status': 'active'
                }
            }
        })
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': str(datetime.now())
        }), 500


@advisory_bp.route('/demo', methods=['POST'])
@cross_origin()
def demo_query():
    """Demo endpoint with predefined queries for testing."""
    try:
        data = request.get_json()
        demo_type = (data or {}).get('demo_type', 'general')
        demo_queries = {
            'general': "What's your opinion on the current market conditions?",
            'fundamental': "Can you analyze Apple's financial performance and fundamentals?",
            'technical': "What does the technical analysis say about Tesla's stock chart?",
            'sentiment': "What's the market sentiment around tech stocks right now?",
            'risk': "How should I assess the risk in my current portfolio?",
            'timing': "When would be a good time to buy Microsoft stock?",
            'strategy': "Can you help me develop a long-term investment strategy?",
        }
        query = demo_queries.get(demo_type, demo_queries['general'])
        result = _get_main_agent().process_user_input(query)
        if isinstance(result, dict) and 'error' in result:
            return jsonify({'error': result.get('error', 'Unknown error'), 'status': 'error'}), 500
        return jsonify({
            'demo_type': demo_type,
            'query': query,
            'response': result.get('response'),
            'conversation_id': result.get('conversation_id'),
            'intent': result.get('intent'),
            'confidence': result.get('confidence'),
            'entities': result.get('entities', []),
            'status': 'success'
        })
    except Exception as e:
        return jsonify({'error': f'Demo error: {str(e)}', 'status': 'error'}), 500


# Error handlers
@advisory_bp.errorhandler(400)
def bad_request(error):
    return jsonify({
        'error': 'Bad request',
        'message': str(error),
        'status': 'error'
    }), 400


@advisory_bp.errorhandler(404)
def not_found(error):
    return jsonify({
        'error': 'Not found',
        'message': str(error),
        'status': 'error'
    }), 404


@advisory_bp.route('/integration/health', methods=['GET'])
@cross_origin()
def integration_health():
    """Get integration system health status."""
    try:
        # Quick non-blocking health check
        health_result = {
            'connector_status': hasattr(integration_connector, 'is_connected'),
            'bridge_status': False,  # Quick check without async
            'orchestrator_status': False,
            'rl_agent_status': False,
            'overall_health': False
        }
        
        return jsonify({
            'integration_health': health_result,
            'timestamp': datetime.now().isoformat(),
            'status': 'success',
            'note': 'Quick health check - use initialize endpoint for full status'
        })
        
    except Exception as e:
        return jsonify({
            'error': str(e),
            'integration_health': {'overall_health': False},
            'status': 'error'
        }), 500

@advisory_bp.route('/integration/initialize', methods=['POST'])
@cross_origin()
def initialize_integration():
    """Initialize the integration system."""
    try:
        # Run async initialization
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            init_result = loop.run_until_complete(
                integration_connector.initialize()
            )
        finally:
            loop.close()
            
        if init_result:
            return jsonify({
                'message': 'Integration system initialized successfully',
                'status': 'success',
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'error': 'Failed to initialize integration system',
                'status': 'error'
            }), 500
            
    except Exception as e:
        return jsonify({
            'error': str(e),
            'status': 'error'
        }), 500

@advisory_bp.errorhandler(500)
def internal_error(error):
    return jsonify({
        'error': 'Internal server error',
        'message': str(error),
        'status': 'error'
    }), 500

