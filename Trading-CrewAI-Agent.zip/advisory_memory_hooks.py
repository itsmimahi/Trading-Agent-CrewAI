"""
Phase 5 — AdvisoryMemoryHooks
==============================
High-level helpers that connect ``AdvisoryMemoryStore`` to the advisory
flow.  Each function wraps a single domain operation (remember/recall)
with the correct scope/sub_scope values so call sites in
``advisory_flow.py`` stay clean.

Usage in advisory_flow.py
──────────────────────────
    # At synthesis_step (store the result):
    if self._memory_store:
        from advisory_memory_hooks import remember_synthesis
        remember_synthesis(self._memory_store, s.conversation_id, s.synthesis_result)

    # At market_analysis_step (recall prior context):
    if self._memory_store:
        from advisory_memory_hooks import recall_market_history
        for market in s.active_markets:
            prior = recall_market_history(self._memory_store, market, s.user_input)
            if prior:
                s.memory_recall[market] = prior
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from memory_store import AdvisoryMemoryStore

from memory_store import MemoryScope, MemorySubScope

logger = logging.getLogger(__name__)

_RECALL_K = 5              # default recall results per query
_RECALL_MIN_SCORE = 0.2    # minimum composite score to include


# ─────────────────────────────────────────────────────────────────────────────
# Market analysis memory
# ─────────────────────────────────────────────────────────────────────────────

def remember_market_analysis(
    store: "AdvisoryMemoryStore",
    market: str,
    analysis_text: str,
    importance: float = 0.6,
) -> Optional[str]:
    """
    Persist a per-market analysis result to the MARKET/analysis-history scope.

    Args:
        store:         AdvisoryMemoryStore instance.
        market:        Market code (IN, US, EU, APAC, CRYPTO).
        analysis_text: Raw text output from the market crew.
        importance:    Recall importance weight (default 0.6 — analyses are
                       usually more important than raw data cache entries).

    Returns:
        entry_id string, or None on failure.
    """
    try:
        entry_id = store.remember(
            scope=MemoryScope.MARKET,
            sub_scope=MemorySubScope.market_analysis(market),
            text=f"[{market} analysis @ {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}]\n{analysis_text}",
            importance=importance,
            metadata={"market": market, "type": "analysis"},
        )
        logger.debug("remember_market_analysis | market=%s | id=%s", market, entry_id)
        return entry_id
    except Exception as exc:
        logger.warning("remember_market_analysis | market=%s | err=%s", market, exc)
        return None


def recall_market_history(
    store: "AdvisoryMemoryStore",
    market: str,
    query: str,
    k: int = _RECALL_K,
    min_score: float = _RECALL_MIN_SCORE,
) -> str:
    """
    Retrieve the most relevant past analyses for *market* given *query*.

    Returns:
        A formatted string of recalled context, or empty string if none.
    """
    try:
        hits = store.recall(
            scope=MemoryScope.MARKET,
            sub_scope=MemorySubScope.market_analysis(market),
            query=query,
            k=k,
            min_score=min_score,
        )
        if not hits:
            return ""
        header = f"### Prior {market} Market Context ({len(hits)} entry/entries)\n\n"
        body = "\n\n---\n\n".join(h[:500] for h in hits)  # cap each hit
        return header + body
    except Exception as exc:
        logger.warning("recall_market_history | market=%s | err=%s", market, exc)
        return ""


# ─────────────────────────────────────────────────────────────────────────────
# Synthesis / shared memory
# ─────────────────────────────────────────────────────────────────────────────

def remember_synthesis(
    store: "AdvisoryMemoryStore",
    conv_id: str,
    synthesis_text: str,
    importance: float = 0.7,
) -> Optional[str]:
    """
    Persist the approved advisory synthesis to two scopes:
    1. CONVERSATION scope (linked to this conversation)
    2. SHARED/strategies scope (cross-session pattern learning)

    Args:
        store:          AdvisoryMemoryStore instance.
        conv_id:        Conversation identifier.
        synthesis_text: Full synthesis text from AnalysisCrewBuilder.
        importance:     Recall importance weight.

    Returns:
        entry_id from the CONVERSATION scope write.
    """
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    text = f"[Synthesis @ {ts}]\n{synthesis_text}"
    try:
        # 1. Conversation scope (per-conv recall)
        conv_id_str = store.remember(
            scope=MemoryScope.CONVERSATION,
            sub_scope=MemorySubScope.conversation(conv_id),
            text=text,
            importance=importance,
            metadata={"type": "synthesis", "conv_id": conv_id},
        )
        # 2. Shared scope (cross-session patterns)
        store.remember(
            scope=MemoryScope.SHARED,
            sub_scope=MemorySubScope.SHARED_STRATEGIES,
            text=text,
            importance=importance * 0.8,  # slight downweight for shared pool
            metadata={"type": "synthesis", "conv_id": conv_id},
        )
        logger.debug("remember_synthesis | conv=%s | id=%s", conv_id, conv_id_str)
        return conv_id_str
    except Exception as exc:
        logger.warning("remember_synthesis | conv=%s | err=%s", conv_id, exc)
        return None


def recall_shared_patterns(
    store: "AdvisoryMemoryStore",
    query: str,
    k: int = _RECALL_K,
    min_score: float = _RECALL_MIN_SCORE,
) -> str:
    """
    Retrieve cross-session strategy patterns relevant to *query*.

    Returns:
        Formatted context string, or empty string if none found.
    """
    try:
        hits = store.recall(
            scope=MemoryScope.SHARED,
            sub_scope=MemorySubScope.SHARED_STRATEGIES,
            query=query,
            k=k,
            min_score=min_score,
        )
        if not hits:
            return ""
        header = f"### Relevant Past Strategies ({len(hits)} match/es)\n\n"
        body = "\n\n---\n\n".join(h[:500] for h in hits)
        return header + body
    except Exception as exc:
        logger.warning("recall_shared_patterns | err=%s", exc)
        return ""


# ─────────────────────────────────────────────────────────────────────────────
# Conversation context memory
# ─────────────────────────────────────────────────────────────────────────────

def remember_conversation(
    store: "AdvisoryMemoryStore",
    conv_id: str,
    text: str,
    importance: float = 0.5,
) -> Optional[str]:
    """
    Persist a single turn / observation to the CONVERSATION scope.

    Args:
        store:      AdvisoryMemoryStore instance.
        conv_id:    Conversation identifier.
        text:       Content to remember.
        importance: Recall importance weight.

    Returns:
        entry_id string, or None on failure.
    """
    try:
        return store.remember(
            scope=MemoryScope.CONVERSATION,
            sub_scope=MemorySubScope.conversation(conv_id),
            text=text,
            importance=importance,
            metadata={"conv_id": conv_id},
        )
    except Exception as exc:
        logger.warning("remember_conversation | conv=%s | err=%s", conv_id, exc)
        return None


def recall_conversation_context(
    store: "AdvisoryMemoryStore",
    conv_id: str,
    query: str,
    k: int = _RECALL_K,
    min_score: float = _RECALL_MIN_SCORE,
) -> str:
    """
    Retrieve prior conversation context relevant to *query*.

    Returns:
        Formatted context string, or empty string if none found.
    """
    try:
        hits = store.recall(
            scope=MemoryScope.CONVERSATION,
            sub_scope=MemorySubScope.conversation(conv_id),
            query=query,
            k=k,
            min_score=min_score,
        )
        if not hits:
            return ""
        return "\n\n".join(h[:400] for h in hits)
    except Exception as exc:
        logger.warning("recall_conversation_context | conv=%s | err=%s", conv_id, exc)
        return ""


# ─────────────────────────────────────────────────────────────────────────────
# Portfolio memory
# ─────────────────────────────────────────────────────────────────────────────

def remember_trade_execution(
    store: "AdvisoryMemoryStore",
    execution_result: str,
    conv_id: str = "",
    importance: float = 0.8,
) -> Optional[str]:
    """
    Persist an execution result to PORTFOLIO/trade-history + SHARED/strategies.

    Args:
        store:            AdvisoryMemoryStore instance.
        execution_result: Raw text output from ExecutionCrew.
        conv_id:          Optional conversation reference.
        importance:       Recall importance weight (default 0.8 — trade
                          history has high recall priority for RL feedback).

    Returns:
        entry_id string, or None on failure.
    """
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    text = f"[Execution @ {ts}]\n{execution_result}"
    try:
        eid = store.remember(
            scope=MemoryScope.PORTFOLIO,
            sub_scope=MemorySubScope.PORTFOLIO_TRADE_HIST,
            text=text,
            importance=importance,
            metadata={"type": "trade_execution", "conv_id": conv_id},
        )
        # Also store as RL learning signal in shared scope
        store.remember(
            scope=MemoryScope.SHARED,
            sub_scope=MemorySubScope.SHARED_RL_LEARNINGS,
            text=text,
            importance=importance * 0.9,
            metadata={"type": "rl_feedback", "conv_id": conv_id},
        )
        logger.debug("remember_trade_execution | conv=%s | id=%s", conv_id, eid)
        return eid
    except Exception as exc:
        logger.warning("remember_trade_execution | conv=%s | err=%s", conv_id, exc)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

def build_memory_store(
    db_path: Optional[str] = None,
    use_sentence_transformer: bool = False,
    model_name: str = "sentence-transformers/all-MiniLM-L2-v2",
) -> "AdvisoryMemoryStore":
    """
    Factory that creates an ``AdvisoryMemoryStore`` with sensible defaults.

    Args:
        db_path: LanceDB directory.  Defaults to ``ADVISORY_MEMORY_PATH``
                 env var, falling back to ``.advisory_memory`` in the CWD.
        use_sentence_transformer: If True, use a real sentence_transformers
                 model for embeddings (slower, semantically meaningful).
        model_name: SentenceTransformer model name/path (only used when
                 ``use_sentence_transformer=True``).

    Returns:
        A ready-to-use ``AdvisoryMemoryStore`` instance.
    """
    from memory_store import AdvisoryMemoryStore  # noqa: F811

    resolved_path = db_path or os.getenv(
        "ADVISORY_MEMORY_PATH", ".advisory_memory"
    )
    embedder = None
    if use_sentence_transformer:
        try:
            from memory_store import make_sentence_transformer_embedder
            embedder = make_sentence_transformer_embedder(model_name)
            logger.info("build_memory_store | embedder=sentence_transformer | model=%s", model_name)
        except ImportError:
            logger.warning("build_memory_store | sentence_transformers unavailable; using hash embedder")

    return AdvisoryMemoryStore(db_path=resolved_path, embedder_fn=embedder)
