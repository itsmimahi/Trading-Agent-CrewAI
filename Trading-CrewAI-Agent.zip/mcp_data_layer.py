"""
Phase 2 — MCP Data Layer
========================
Provides a set of CrewAI BaseTool-compatible market data tools that the
MarketCrewBuilder injects into all 7 specialist agents.

Data source priority:
    1. yfinance (free, no key required — primary for quotes, OHLCV, news)
    2. Alpha Vantage (when ALPHA_VANTAGE_API_KEY is set — richer fundamentals
       and tech indicators; free tier = 25 req/day, 5 req/min → cache is critical)

All _run() methods are synchronous and return JSON strings.
Errors are returned as {"error": "...", "source": "..."} — never raised.

Usage:
    from mcp_data_layer import build_data_tools
    tools = build_data_tools()          # or build_data_tools(av_key="YOUR_KEY")
    builder = MarketCrewBuilder(llm=llm, tools=tools)
"""

from __future__ import annotations

import concurrent.futures
import json
import logging
import os
import time
from typing import Any, Callable, Dict, List, Optional, TypeVar

_T = TypeVar("_T")

import yfinance as yf
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# In-process TTL cache (shared across all tool instances)
# ─────────────────────────────────────────────────────────────────────────────

class _TTLCache:
    """Thread-naive in-process cache with per-entry TTL."""

    def __init__(self, ttl_seconds: int = 300) -> None:
        self._store: Dict[str, tuple] = {}  # key → (value, expiry_ts)
        self._ttl = ttl_seconds

    def get(self, key: str) -> Optional[str]:
        entry = self._store.get(key)
        if entry and time.time() < entry[1]:
            return entry[0]
        return None

    def set(self, key: str, value: str) -> None:
        self._store[key] = (value, time.time() + self._ttl)

    def clear(self) -> None:
        self._store.clear()


_CACHE = _TTLCache(ttl_seconds=300)

# How long (seconds) to wait for any single yfinance network call before
# giving up and returning an error.  Set MCP_TOOL_TIMEOUT=N to override.
_TOOL_TIMEOUT: int = int(os.getenv("MCP_TOOL_TIMEOUT", "8"))


def _call_with_timeout(fn: Callable[[], _T], timeout: int = _TOOL_TIMEOUT) -> _T:
    """Run *fn* in a thread and raise TimeoutError if it doesn't finish in time."""
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(fn)
        try:
            return future.result(timeout=timeout)
        except concurrent.futures.TimeoutError:
            raise TimeoutError(
                f"Network call timed out after {timeout}s — "
                "check internet connectivity or set MCP_TOOL_TIMEOUT env var"
            )


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic input schemas
# ─────────────────────────────────────────────────────────────────────────────

class _SymbolInput(BaseModel):
    symbol: str = Field(..., description="Ticker symbol, e.g. RELIANCE.NS, AAPL, BTC-USD")


class _OHLCVInput(BaseModel):
    symbol: str = Field(..., description="Ticker symbol")
    period: str = Field(
        default="3mo",
        description="Historical period: 1d | 5d | 1mo | 3mo | 6mo | 1y | 2y | 5y",
    )
    interval: str = Field(
        default="1d",
        description="Bar interval: 1m | 5m | 15m | 30m | 1h | 1d | 1wk | 1mo",
    )


class _NewsInput(BaseModel):
    symbol: str = Field(..., description="Ticker symbol or company name")
    limit: int = Field(default=5, description="Number of news items to return (1–15)")


class _MarketInput(BaseModel):
    market: str = Field(
        default="IN",
        description="Market code: IN | US | EU | APAC | CRYPTO",
    )


class _TechInput(BaseModel):
    symbol: str = Field(..., description="Ticker symbol")
    indicators: str = Field(
        default="RSI,MACD,BB",
        description="Comma-separated list of indicators: RSI | MACD | BB | SMA20 | SMA50 | EMA9",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers — yfinance
# ─────────────────────────────────────────────────────────────────────────────

_MARKET_INDICES: Dict[str, List[str]] = {
    "IN":     ["^NSEI", "^BSESN", "^NSEBANK"],
    "US":     ["^GSPC", "^NDX", "^DJI", "^VIX"],
    "EU":     ["^STOXX50E", "^GDAXI", "^FTSE", "^FCHI"],
    "APAC":   ["^N225", "^HSI", "^AXJO", "^KS11"],
    "CRYPTO": ["BTC-USD", "ETH-USD", "SOL-USD", "BNB-USD"],
}

_MARKET_FX: Dict[str, List[str]] = {
    "IN":     ["USDINR=X", "EURINR=X", "INR=X"],
    "US":     ["EURUSD=X", "GBPUSD=X", "DX-Y.NYB"],
    "EU":     ["EURUSD=X", "GBPUSD=X", "EURGBP=X"],
    "APAC":   ["USDJPY=X", "USDAUD=X", "USDSGD=X"],
    "CRYPTO": ["USDT-USD", "BTC-USD"],
}

_COMMODITIES = ["CL=F", "GC=F", "SI=F"]   # crude oil, gold, silver


def _safe_round(val: Any, digits: int = 4) -> Any:
    """Round float-like values; return val unchanged for non-numeric."""
    try:
        return round(float(val), digits)
    except (TypeError, ValueError):
        return val


def _yf_info(symbol: str) -> Dict[str, Any]:
    """Fetch yfinance .info dict with a hard timeout guard."""
    try:
        return _call_with_timeout(lambda: yf.Ticker(symbol).info or {})
    except Exception as exc:
        logger.debug("yf_info(%s) failed: %s", symbol, exc)
        return {}


def _compute_rsi(closes, period: int = 14):
    """Compute RSI from a pandas Series of closes."""
    try:
        delta = closes.diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.ewm(com=period - 1, min_periods=period).mean()
        avg_loss = loss.ewm(com=period - 1, min_periods=period).mean()
        last_gain = float(avg_gain.iloc[-1])
        last_loss = float(avg_loss.iloc[-1])
        # Edge cases: pure uptrend → 100; pure downtrend → 0
        if last_loss == 0:
            return 100.0 if last_gain > 0 else 50.0
        if last_gain == 0:
            return 0.0
        rs = last_gain / last_loss
        return _safe_round(100 - (100 / (1 + rs)))
    except Exception:
        return None


def _compute_macd(closes):
    """Return (macd_line, signal_line, histogram) for the most recent bar."""
    try:
        ema12 = closes.ewm(span=12, adjust=False).mean()
        ema26 = closes.ewm(span=26, adjust=False).mean()
        macd = ema12 - ema26
        signal = macd.ewm(span=9, adjust=False).mean()
        hist = macd - signal
        return _safe_round(macd.iloc[-1]), _safe_round(signal.iloc[-1]), _safe_round(hist.iloc[-1])
    except Exception:
        return None, None, None


def _compute_bb(closes, window: int = 20):
    """Return (upper, middle, lower) Bollinger Bands for the most recent bar."""
    try:
        sma = closes.rolling(window).mean()
        std = closes.rolling(window).std()
        upper = sma + 2 * std
        lower = sma - 2 * std
        return _safe_round(upper.iloc[-1]), _safe_round(sma.iloc[-1]), _safe_round(lower.iloc[-1])
    except Exception:
        return None, None, None


# ─────────────────────────────────────────────────────────────────────────────
# Tool 1: Get Stock Quote
# ─────────────────────────────────────────────────────────────────────────────

class GetStockQuoteTool(BaseTool):
    """Current price, change%, volume, 52-week range for a ticker."""

    name: str = "get_stock_quote"
    description: str = (
        "Fetch the current market quote for a ticker symbol. Returns price, "
        "day change %, volume, 52-week high/low, market cap, and currency. "
        "Examples: RELIANCE.NS (NSE), AAPL (NASDAQ), BTC-USD (crypto)."
    )
    args_schema: type = _SymbolInput

    def _run(self, symbol: str) -> str:
        cache_key = f"quote:{symbol}"
        cached = _CACHE.get(cache_key)
        if cached:
            return cached

        try:
            ticker = yf.Ticker(symbol)
            info = _call_with_timeout(lambda: ticker.info or {})

            price = (
                info.get("currentPrice")
                or info.get("regularMarketPrice")
                or info.get("previousClose")
            )

            if price is None:
                hist = _call_with_timeout(lambda: ticker.history(period="1d"))
                if not hist.empty:
                    price = float(hist["Close"].iloc[-1])

            result = {
                "symbol": symbol,
                "price": _safe_round(price, 2) if price else None,
                "currency": info.get("currency", "N/A"),
                "day_change_pct": _safe_round(info.get("regularMarketChangePercent", 0), 2),
                "volume": info.get("regularMarketVolume") or info.get("volume"),
                "avg_volume_10d": info.get("averageVolume10days") or info.get("averageVolume"),
                "market_cap": info.get("marketCap"),
                "fifty_two_week_high": _safe_round(info.get("fiftyTwoWeekHigh", 0), 2),
                "fifty_two_week_low":  _safe_round(info.get("fiftyTwoWeekLow", 0), 2),
                "name": info.get("longName") or info.get("shortName", symbol),
                "exchange": info.get("exchange", "N/A"),
                "source": "yfinance",
            }

            payload = json.dumps(result, default=str)
            _CACHE.set(cache_key, payload)
            return payload

        except Exception as exc:
            logger.warning("GetStockQuoteTool(%s) error: %s", symbol, exc)
            return json.dumps({"error": str(exc), "symbol": symbol, "source": "yfinance"})


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2: Get OHLCV Historical Data
# ─────────────────────────────────────────────────────────────────────────────

class GetOHLCVTool(BaseTool):
    """OHLCV historical price data for charting or technical analysis."""

    name: str = "get_ohlcv"
    description: str = (
        "Fetch historical OHLCV (Open/High/Low/Close/Volume) price data for a ticker. "
        "Use period='3mo' and interval='1d' for daily data over 3 months. "
        "Returns a list of bars with date, open, high, low, close, volume."
    )
    args_schema: type = _OHLCVInput

    def _run(self, symbol: str, period: str = "3mo", interval: str = "1d") -> str:
        cache_key = f"ohlcv:{symbol}:{period}:{interval}"
        cached = _CACHE.get(cache_key)
        if cached:
            return cached

        try:
            ticker = yf.Ticker(symbol)
            hist = _call_with_timeout(lambda: ticker.history(period=period, interval=interval))

            if hist.empty:
                result = {"error": "No data returned", "symbol": symbol, "source": "yfinance"}
                return json.dumps(result)

            bars = []
            for date, row in hist.iterrows():
                bars.append({
                    "date":   str(date)[:10],
                    "open":   _safe_round(row["Open"], 2),
                    "high":   _safe_round(row["High"], 2),
                    "low":    _safe_round(row["Low"], 2),
                    "close":  _safe_round(row["Close"], 2),
                    "volume": int(row["Volume"]) if row["Volume"] == row["Volume"] else 0,
                })

            result = {
                "symbol": symbol,
                "period": period,
                "interval": interval,
                "bars": bars[-90:],  # cap at 90 bars to keep LLM context manageable
                "bar_count": len(bars),
                "source": "yfinance",
            }
            payload = json.dumps(result, default=str)
            _CACHE.set(cache_key, payload)
            return payload

        except Exception as exc:
            logger.warning("GetOHLCVTool(%s) error: %s", symbol, exc)
            return json.dumps({"error": str(exc), "symbol": symbol, "source": "yfinance"})


# ─────────────────────────────────────────────────────────────────────────────
# Tool 3: Get Fundamentals
# ─────────────────────────────────────────────────────────────────────────────

class GetFundamentalsTool(BaseTool):
    """Financial ratios, valuation, and sector data for a ticker."""

    name: str = "get_fundamentals"
    description: str = (
        "Fetch fundamental financial data for a ticker: PE ratio, PB ratio, "
        "EPS, revenue/earnings growth, debt-to-equity, ROE, ROA, dividend yield, "
        "sector, industry, and market cap. Use for valuation and stock screening."
    )
    args_schema: type = _SymbolInput

    def _run(self, symbol: str) -> str:
        cache_key = f"fundamentals:{symbol}"
        cached = _CACHE.get(cache_key)
        if cached:
            return cached

        try:
            info = _yf_info(symbol)

            result = {
                "symbol": symbol,
                "name": info.get("longName") or info.get("shortName", symbol),
                "sector": info.get("sector", "N/A"),
                "industry": info.get("industry", "N/A"),
                "market_cap": info.get("marketCap"),
                "currency": info.get("currency", "N/A"),
                # Valuation
                "pe_trailing": _safe_round(info.get("trailingPE"), 2),
                "pe_forward": _safe_round(info.get("forwardPE"), 2),
                "pb_ratio": _safe_round(info.get("priceToBook"), 2),
                "ps_ratio": _safe_round(info.get("priceToSalesTrailing12Months"), 2),
                "ev_ebitda": _safe_round(info.get("enterpriseToEbitda"), 2),
                # EPS / Growth
                "eps_trailing": _safe_round(info.get("trailingEps"), 2),
                "eps_forward": _safe_round(info.get("forwardEps"), 2),
                "revenue_growth_yoy": _safe_round(info.get("revenueGrowth"), 4),
                "earnings_growth_yoy": _safe_round(info.get("earningsGrowth"), 4),
                # Balance sheet / profitability
                "debt_to_equity": _safe_round(info.get("debtToEquity"), 2),
                "roe": _safe_round(info.get("returnOnEquity"), 4),
                "roa": _safe_round(info.get("returnOnAssets"), 4),
                "current_ratio": _safe_round(info.get("currentRatio"), 2),
                "quick_ratio": _safe_round(info.get("quickRatio"), 2),
                "gross_margins": _safe_round(info.get("grossMargins"), 4),
                "operating_margins": _safe_round(info.get("operatingMargins"), 4),
                "profit_margins": _safe_round(info.get("profitMargins"), 4),
                # Dividends & yield
                "dividend_yield": _safe_round(info.get("dividendYield"), 4),
                "payout_ratio": _safe_round(info.get("payoutRatio"), 4),
                # Risk
                "beta": _safe_round(info.get("beta"), 2),
                "short_ratio": _safe_round(info.get("shortRatio"), 2),
                "source": "yfinance",
            }

            payload = json.dumps(result, default=str)
            _CACHE.set(cache_key, payload)
            return payload

        except Exception as exc:
            logger.warning("GetFundamentalsTool(%s) error: %s", symbol, exc)
            return json.dumps({"error": str(exc), "symbol": symbol, "source": "yfinance"})


# ─────────────────────────────────────────────────────────────────────────────
# Tool 4: Get News Headlines
# ─────────────────────────────────────────────────────────────────────────────

class GetNewsTool(BaseTool):
    """Recent news headlines for a ticker or company."""

    name: str = "get_news"
    description: str = (
        "Fetch recent news headlines for a ticker symbol or company name. "
        "Returns titles, sources, publish dates, and article URLs. "
        "Use for sentiment analysis and event-driven trading signals."
    )
    args_schema: type = _NewsInput

    def _run(self, symbol: str, limit: int = 5) -> str:
        limit = max(1, min(limit, 15))
        cache_key = f"news:{symbol}:{limit}"
        cached = _CACHE.get(cache_key)
        if cached:
            return cached

        try:
            def _fetch():
                ticker = yf.Ticker(symbol)
                return ticker.news or []

            raw_news = _call_with_timeout(_fetch)
            items = []

            for item in raw_news[:limit]:
                content = item.get("content", {})
                # yfinance 0.2.x returns nested content dict
                title = (
                    content.get("title")
                    or item.get("title", "")
                )
                provider = (
                    content.get("provider", {}).get("displayName")
                    or item.get("publisher", "Unknown")
                )
                pub_time = content.get("pubDate") or item.get("providerPublishTime")
                if isinstance(pub_time, (int, float)):
                    import datetime
                    pub_time = datetime.datetime.utcfromtimestamp(pub_time).strftime("%Y-%m-%d %H:%M UTC")
                url = content.get("canonicalUrl", {}).get("url") or item.get("link", "")
                summary = content.get("summary") or content.get("description") or ""

                items.append({
                    "title": title,
                    "source": provider,
                    "published": pub_time,
                    "url": url,
                    "summary": summary[:200] if summary else "",
                })

            result = {
                "symbol": symbol,
                "count": len(items),
                "news": items,
                "source": "yfinance",
            }
            payload = json.dumps(result, default=str)
            _CACHE.set(cache_key, payload)
            return payload

        except Exception as exc:
            logger.warning("GetNewsTool(%s) error: %s", symbol, exc)
            return json.dumps({"error": str(exc), "symbol": symbol, "source": "yfinance"})


# ─────────────────────────────────────────────────────────────────────────────
# Tool 5: Get Market Overview (Indices)
# ─────────────────────────────────────────────────────────────────────────────

class GetMarketOverviewTool(BaseTool):
    """Current values of major indices for a market (IN/US/EU/APAC/CRYPTO)."""

    name: str = "get_market_overview"
    description: str = (
        "Fetch current values and day-change % for major indices of a market. "
        "market='IN' returns NIFTY50, SENSEX, NIFTY Bank. "
        "market='US' returns S&P500, NASDAQ100, DJIA, VIX. "
        "market='EU' returns EuroStoxx50, DAX, FTSE100, CAC40. "
        "market='APAC' returns Nikkei225, HangSeng, ASX200, KOSPI. "
        "market='CRYPTO' returns BTC, ETH, SOL, BNB prices."
    )
    args_schema: type = _MarketInput

    def _run(self, market: str = "IN") -> str:
        mkt = market.upper()
        cache_key = f"market_overview:{mkt}"
        cached = _CACHE.get(cache_key)
        if cached:
            return cached

        symbols = _MARKET_INDICES.get(mkt, _MARKET_INDICES["IN"])
        results = []

        for sym in symbols:
            try:
                info = _yf_info(sym)
                price = (
                    info.get("regularMarketPrice")
                    or info.get("currentPrice")
                    or info.get("previousClose")
                )
                results.append({
                    "symbol": sym,
                    "name": info.get("longName") or info.get("shortName", sym),
                    "price": _safe_round(price, 2),
                    "change_pct": _safe_round(info.get("regularMarketChangePercent", 0), 2),
                    "currency": info.get("currency", "N/A"),
                })
            except Exception as exc:
                results.append({"symbol": sym, "error": str(exc)})

        payload = json.dumps({"market": mkt, "indices": results, "source": "yfinance"}, default=str)
        _CACHE.set(cache_key, payload)
        return payload


# ─────────────────────────────────────────────────────────────────────────────
# Tool 6: Get Technical Indicators
# ─────────────────────────────────────────────────────────────────────────────

class GetTechnicalIndicatorsTool(BaseTool):
    """Compute RSI, MACD, Bollinger Bands, SMAs for a ticker."""

    name: str = "get_technical_indicators"
    description: str = (
        "Compute technical analysis indicators for a ticker from daily OHLCV data. "
        "indicators='RSI,MACD,BB,SMA20,SMA50,EMA9' — use any combination. "
        "RSI: momentum oscillator (0–100). MACD: trend/momentum (line, signal, hist). "
        "BB: Bollinger Bands (upper, middle, lower). SMA20/SMA50: moving averages."
    )
    args_schema: type = _TechInput

    def _run(self, symbol: str, indicators: str = "RSI,MACD,BB") -> str:
        cache_key = f"tech:{symbol}:{indicators}"
        cached = _CACHE.get(cache_key)
        if cached:
            return cached

        try:
            ticker = yf.Ticker(symbol)
            hist = _call_with_timeout(lambda: ticker.history(period="6mo", interval="1d"))

            if hist.empty:
                return json.dumps({"error": "No price data", "symbol": symbol})

            closes = hist["Close"]
            requested = {i.strip().upper() for i in indicators.split(",")}
            result: Dict[str, Any] = {"symbol": symbol, "source": "computed_from_yfinance"}

            if "RSI" in requested:
                result["rsi_14"] = _compute_rsi(closes, period=14)

            if "MACD" in requested:
                m, s, h = _compute_macd(closes)
                result["macd"] = {"line": m, "signal": s, "histogram": h}

            if "BB" in requested:
                upper, mid, lower = _compute_bb(closes, window=20)
                result["bollinger_bands"] = {
                    "upper": upper,
                    "middle": mid,
                    "lower": lower,
                    "current_close": _safe_round(closes.iloc[-1], 2),
                    "position": (
                        "above_upper" if closes.iloc[-1] > (upper or 0)
                        else "below_lower" if closes.iloc[-1] < (lower or float("inf"))
                        else "within_bands"
                    ),
                }

            if "SMA20" in requested:
                sma20 = closes.rolling(20).mean()
                result["sma_20"] = _safe_round(sma20.iloc[-1], 2)

            if "SMA50" in requested:
                sma50 = closes.rolling(50).mean()
                result["sma_50"] = _safe_round(sma50.iloc[-1], 2)

            if "EMA9" in requested:
                ema9 = closes.ewm(span=9, adjust=False).mean()
                result["ema_9"] = _safe_round(ema9.iloc[-1], 2)

            payload = json.dumps(result, default=str)
            _CACHE.set(cache_key, payload)
            return payload

        except Exception as exc:
            logger.warning("GetTechnicalIndicatorsTool(%s) error: %s", symbol, exc)
            return json.dumps({"error": str(exc), "symbol": symbol, "source": "yfinance"})


# ─────────────────────────────────────────────────────────────────────────────
# Tool 7: Get Economic Indicators
# ─────────────────────────────────────────────────────────────────────────────

class GetEconomicIndicatorsTool(BaseTool):
    """Macro / economic data: FX rates, commodities, bond yields, VIX."""

    name: str = "get_economic_indicators"
    description: str = (
        "Fetch macro-economic indicators for a market: FX rates (e.g. USD/INR), "
        "crude oil, gold, silver spot prices, and VIX. "
        "market='IN': USD/INR, EUR/INR, crude, gold. "
        "market='US': EUR/USD, GBP/USD, DXY, VIX, crude, gold. "
        "Use for macro context in investment decisions."
    )
    args_schema: type = _MarketInput

    def _run(self, market: str = "IN") -> str:
        mkt = market.upper()
        cache_key = f"economic:{mkt}"
        cached = _CACHE.get(cache_key)
        if cached:
            return cached

        fx_symbols = _MARKET_FX.get(mkt, _MARKET_FX["IN"])
        all_symbols = fx_symbols + _COMMODITIES + ["^VIX", "^TNX"]
        results: Dict[str, Any] = {"market": mkt, "indicators": {}, "source": "yfinance"}

        for sym in all_symbols:
            try:
                info = _yf_info(sym)
                price = (
                    info.get("regularMarketPrice")
                    or info.get("currentPrice")
                    or info.get("previousClose")
                )
                label = (
                    info.get("shortName")
                    or info.get("longName")
                    or sym
                )
                results["indicators"][sym] = {
                    "label": label,
                    "price": _safe_round(price, 4) if price else None,
                    "change_pct": _safe_round(info.get("regularMarketChangePercent", 0), 2),
                    "currency": info.get("currency", "N/A"),
                }
            except Exception as exc:
                results["indicators"][sym] = {"error": str(exc)}

        payload = json.dumps(results, default=str)
        _CACHE.set(cache_key, payload)
        return payload


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

def build_data_tools(av_key: Optional[str] = None) -> List[BaseTool]:
    """
    Build and return the full set of market data tools.

    Args:
        av_key: Optional Alpha Vantage API key. When provided it is stored in
                the environment variable ``ALPHA_VANTAGE_API_KEY`` so existing
                ``MarketDataCollector`` code can also pick it up.

    Returns:
        List of 7 BaseTool instances ready to be injected into agents.
    """
    if av_key:
        os.environ.setdefault("ALPHA_VANTAGE_API_KEY", av_key)

    tools: List[BaseTool] = [
        GetStockQuoteTool(),
        GetOHLCVTool(),
        GetFundamentalsTool(),
        GetNewsTool(),
        GetMarketOverviewTool(),
        GetTechnicalIndicatorsTool(),
        GetEconomicIndicatorsTool(),
    ]
    logger.info("mcp_data_layer: built %d data tools", len(tools))
    return tools
