"""
AI Trading Advisory System Package
"""
__version__ = "1.0.0"
