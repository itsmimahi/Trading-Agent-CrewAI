"""
RL_Agent Package
Reinforcement Learning Trading Agent for AI Trading Advisory System
"""

from .rl_agent import RLTradingAgent
from .trading_environment import TradingEnvironment

# ── v2 exports ────────────────────────────────────────────────────────────
from .risk_metrics import (
    RiskSnapshot,
    compute_sharpe,
    compute_max_drawdown,
    compute_var_historical,
    compute_cvar,
    compute_turnover,
    compute_calmar,
    risk_aware_reward,
    build_risk_snapshot,
)
from .regime_classifier import MarketRegime, RegimeClassifier
from .portfolio_trading_env import PortfolioTradingEnv
from .rl_agent_v2 import RLAgentV2, ValidationResult, PositionRecommendation

__version__ = "2.0.0"
__author__ = "AI Trading Advisory System"

__all__ = [
    # v1
    "RLTradingAgent",
    "TradingEnvironment",
    # v2 — risk utilities
    "RiskSnapshot",
    "compute_sharpe",
    "compute_max_drawdown",
    "compute_var_historical",
    "compute_cvar",
    "compute_turnover",
    "compute_calmar",
    "risk_aware_reward",
    "build_risk_snapshot",
    # v2 — regime
    "MarketRegime",
    "RegimeClassifier",
    # v2 — environment + agent
    "PortfolioTradingEnv",
    "RLAgentV2",
    "ValidationResult",
    "PositionRecommendation",
]
