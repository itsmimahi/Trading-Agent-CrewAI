from .base import MarketDataAdapter
from .zerodha import ZerodhaAdapter
from .shoonya import ShoonyaAdapter
from .angel import AngelAdapter


def create_adapter(broker: str) -> MarketDataAdapter | None:
    b = (broker or "").upper()
    if b == "ZERODHA":
        return ZerodhaAdapter()
    if b == "SHOONYA":
        return ShoonyaAdapter()
    if b == "ANGEL":
        return AngelAdapter()
    return None
