"""
Configuration package for AI Trading Advisory System
"""

from .settings import config, setup_environment

__all__ = ['config', 'setup_environment']
