"""
AI Trading Advisory System Agents

This package contains all the AI agents for the trading advisory system.
"""

from .base_agent import BaseAgent, AgentRecommendation, RecommendationType

__all__ = [
    'BaseAgent',
    'AgentRecommendation', 
    'RecommendationType'
]
