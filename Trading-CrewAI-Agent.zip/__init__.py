"""
Main Advisory Agent Package
The central AI Trading Advisory Agent built with CrewAI framework.
"""

__version__ = "1.0.0"
__author__ = "AI Trading Advisory System"

# Make key components available at package level
try:
    from .main_advisory_agent import main_advisory_agent
    from .agent_registry import agent_registry
    from .conversation import conversation_manager
    from .user import db
except ImportError:
    # Handle import errors gracefully during development
    pass
