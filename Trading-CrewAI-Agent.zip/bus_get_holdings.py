from __future__ import annotations
import asyncio, json, os, sys
ROOT = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(ROOT)
if ROOT not in sys.path:
    sys.path.append(ROOT)
from integration.event_bus import RedisStreamsEventBus

async def main():
    bus = RedisStreamsEventBus()
    try:
        resp = await bus.request("pta:get_holdings", {}, timeout_ms=8000)
        print(json.dumps(resp))
    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
    finally:
        await bus.stop()

if __name__ == "__main__":
    asyncio.run(main())
