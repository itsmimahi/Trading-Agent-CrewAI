"""
Phase 1 — MarketCrewBuilder
============================
Builds one CrewAI Crew per market segment (IN / US / EU / APAC / CRYPTO).
Each Crew contains 7 slim specialist agents that mirror the Enhanced* agents
from agents/ but are lightweight crewai.Agent objects — no heavy initialization,
no model downloads — so they can be spun up in parallel via asyncio.gather.

The 7-agent pipeline per market:
    1. Macro Economist       — macro indicators, central bank, currency
    2. Research Analyst      — fundamentals, valuation, sector health
    3. Technical Analyst     — chart patterns, indicators, signals
    4. Sentiment Analyst     — news/social sentiment, fear & greed
    5. Risk Manager          — VaR, position sizing, stop-loss, drawdown
    6. Market Timer          — entry/exit timing, regime detection
    7. Strategy Planner      — synthesise all above → actionable strategy

Usage (inside advisory_flow.market_analysis_step):
    from market_crew_builder import MarketCrewBuilder
    builder = MarketCrewBuilder(llm=self._llm, tools=self._tools, verbose=False)
    crew = builder.build_market_crew(
        market="IN",
        user_input="...",
        intent="technical_analysis",
        entities=[...],
        portfolio_snapshot={...},
    )
    result = crew.kickoff()   # or await asyncio.to_thread(crew.kickoff)

Phase 2+: Inject MCP tools (data layer) alongside the generic tools list.
Phase 3+: Return CrewOutput; AnalysisCrew consumes all 5 market outputs.
"""

from __future__ import annotations

import logging
import textwrap
from datetime import datetime
from typing import Any, Dict, List, Optional

from crewai import Agent, Crew, Process, Task
from crewai.llm import LLM

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Market configuration registry
# ─────────────────────────────────────────────────────────────────────────────

MARKET_CONFIGS: Dict[str, Dict[str, str]] = {
    "IN": {
        "name": "Indian Markets",
        "currency": "INR",
        "timezone": "Asia/Kolkata",
        "hours_utc": "03:45–10:00 UTC",
        "benchmark": "NIFTY 50 (^NSEI)",
        "secondary_indices": "SENSEX (^BSESN), NIFTY BANK, NIFTY IT, NIFTY PHARMA",
        "regulator": "SEBI",
        "data_suffix": ".NS (NSE) / .BO (BSE)",
        "typical_symbols": "RELIANCE.NS, TCS.NS, INFY.NS, HDFCBANK.NS, WIPRO.NS",
        "macro_focus": (
            "RBI repo rate, CPI/WPI inflation, IIP, FII/DII flows, "
            "INR/USD rate, Brent crude, India 10Y G-Sec yield"
        ),
        "sentiment_sources": (
            "NSE market breadth, BSE advance/decline, India VIX, FII derivatives data, "
            "Economic Times, Moneycontrol, Bloomberg India"
        ),
        "risk_notes": (
            "Circuit-breaker limits (5/10/20%), T+1 settlement, SEBI lot sizes, "
            "STT/SEBI fees, F&O expiry Thursdays"
        ),
    },
    "US": {
        "name": "US Markets",
        "currency": "USD",
        "timezone": "America/New_York",
        "hours_utc": "13:30–20:00 UTC",
        "benchmark": "S&P 500 (^GSPC)",
        "secondary_indices": "NASDAQ 100 (^NDX), DJIA (^DJI), Russell 2000 (^RUT)",
        "regulator": "SEC / FINRA / CFTC",
        "data_suffix": "No suffix (NYSE/NASDAQ) — e.g. AAPL, MSFT",
        "typical_symbols": "AAPL, MSFT, GOOGL, NVDA, AMZN, META, TSLA",
        "macro_focus": (
            "Fed funds rate, FOMC minutes, CPI/PCE, NFP payrolls, "
            "US 10Y Treasury yield, DXY (USD index), ISM PMI"
        ),
        "sentiment_sources": (
            "S&P 500 advance/decline, VIX (^VIX), put/call ratio, AAII sentiment survey, "
            "CNN Fear & Greed, Bloomberg, Reuters, WSJ"
        ),
        "risk_notes": (
            "T+2 settlement (moving to T+1), PDT rule ($25K min), "
            "options expiry 3rd Fridays, pre/after-market sessions 04:00–20:00 ET"
        ),
    },
    "EU": {
        "name": "European Markets",
        "currency": "EUR / GBP / CHF",
        "timezone": "Europe/London",
        "hours_utc": "07:00–15:30 UTC",
        "benchmark": "Euro Stoxx 50 (^STOXX50E)",
        "secondary_indices": "DAX (^GDAXI), FTSE 100 (^FTSE), CAC 40 (^FCHI), SMI (^SSMI)",
        "regulator": "ESMA / FCA (post-Brexit)",
        "data_suffix": ".PA (Paris), .L (London), .DE (Frankfurt), .MI (Milan), .AS (Amsterdam)",
        "typical_symbols": "ASML.AS, SAP.DE, LVMH.PA, NESN.SW, VOD.L, SHEL.L, SIE.DE",
        "macro_focus": (
            "ECB deposit rate/QE, Eurozone CPI, PMI flash, EUR/USD, "
            "Brent crude, German Bunds 10Y, UK Gilts, Brexit trade impact"
        ),
        "sentiment_sources": (
            "STOXX breadth, VSTOXX (volatility), ZEW Economic Sentiment, "
            "IFO Business Climate, European newspapers (FT, Handelsblatt, Le Monde)"
        ),
        "risk_notes": (
            "T+2 settlement under CSDR, MiFID II transparency, ESMA short-selling bans, "
            "currency risk (EUR/GBP/CHF), fragmented liquidity across exchanges"
        ),
    },
    "APAC": {
        "name": "Asia-Pacific Markets",
        "currency": "JPY / AUD / SGD / HKD / KRW",
        "timezone": "Asia/Tokyo",
        "hours_utc": "00:00–06:00 UTC (JP/AU/HK staggered)",
        "benchmark": "Nikkei 225 (^N225)",
        "secondary_indices": (
            "TOPIX (^TOPX), Hang Seng (^HSI), ASX 200 (^AXJO), "
            "KOSPI (^KS11), STI (^STI), FTSE China A50"
        ),
        "regulator": "FSA (JP) / SFC (HK) / ASIC (AU) / MAS (SG) / FSC (KR)",
        "data_suffix": ".T (Tokyo), .HK (HK), .AX (ASX), .KS (Korea), .SI (Singapore), .TW (Taiwan)",
        "typical_symbols": (
            "7203.T (Toyota), 9984.T (SoftBank), 700.HK (Tencent), "
            "BHP.AX, 005930.KS (Samsung), 2330.TW (TSMC)"
        ),
        "macro_focus": (
            "BOJ YCC/rate policy, PBOC liquidity, China PMI/NBS, "
            "AUD/USD, iron ore/LME metals, semiconductor export controls, "
            "JPY carry trade flows"
        ),
        "sentiment_sources": (
            "Nikkei/Asian breadth, China CSI 300 flows, Reuters Asia, "
            "Caixin PMI, Nikkei Asia, South China Morning Post"
        ),
        "risk_notes": (
            "Fragmented sessions across 4 time zones, currency risk across 5+ FX pairs, "
            "circuit breakers (JP: ±5% on futures), limited short-selling (CN A-shares), "
            "geopolitical risk (Taiwan Strait, DPRK)"
        ),
    },
    "CRYPTO": {
        "name": "Cryptocurrency Markets",
        "currency": "USD / USDT / USDC",
        "timezone": "UTC (24/7/365)",
        "hours_utc": "Always open",
        "benchmark": "BTC/USD",
        "secondary_indices": (
            "ETH/USD, SOL/USD, BNB/USD, TOTAL market cap, "
            "BTC dominance %, DeFi TVL, crypto fear & greed index"
        ),
        "regulator": "SEC (US, spot/ETFs), CFTC (futures), MiCA (EU), FCA (UK)",
        "data_suffix": "-USD (Yahoo Finance: BTC-USD, ETH-USD, SOL-USD)",
        "typical_symbols": "BTC-USD, ETH-USD, SOL-USD, BNB-USD, XRP-USD, AVAX-USD",
        "macro_focus": (
            "BTC halving cycles (next ~2028), Fed rate environment, "
            "stablecoin mint/burn flows, on-chain active addresses, "
            "spot BTC/ETH ETF inflows (US), regulatory enforcement actions"
        ),
        "sentiment_sources": (
            "Crypto Fear & Greed Index, CoinGlass funding rates, "
            "open interest, exchange netflows, Glassnode on-chain, "
            "Twitter/X crypto community, CoinDesk, The Block"
        ),
        "risk_notes": (
            "No circuit breakers — 24/7 volatility possible (±20% days), "
            "liquidity varies sharply across venues, smart contract risk, "
            "exchange counterparty risk (custody), regulatory surprise risk"
        ),
    },
}

# Agent roles/weights (same as Enhanced agents from agents/)
_AGENT_WEIGHTS = {
    "research":   0.25,
    "technical":  0.20,
    "sentiment":  0.15,
    "risk":       0.15,
    "macro":      0.10,
    "timing":     0.10,
    "strategy":   0.25,  # synthesiser — gets all context
}


# ─────────────────────────────────────────────────────────────────────────────
# Builder
# ─────────────────────────────────────────────────────────────────────────────

class MarketCrewBuilder:
    """
    Builds a per-market Crew with 7 specialist agents.

    Design notes:
    - Agents are slim crewai.Agent objects (no heavy Enhanced* init overhead).
    - Roles/goals/backstory mirror the Enhanced* agent classes in agents/.
    - Market config is injected into each agent's backstory and every task.
    - Sequential process with planning_llm so agents benefit from a plan step.
    - Phase 2+: inject MCP tools into `tools` for live market data.
    """

    def __init__(
        self,
        llm: LLM,
        tools: List[Any],
        verbose: bool = False,
        max_iter: int = 10,
    ) -> None:
        self._llm = llm
        self._tools = tools or []
        self._verbose = verbose
        self._max_iter = max_iter

    # ── Public API ────────────────────────────────────────────────────────────

    def build_market_crew(
        self,
        market: str,
        user_input: str,
        intent: str,
        entities: List[Dict[str, Any]],
        portfolio_snapshot: Optional[Dict[str, Any]] = None,
    ) -> Crew:
        """
        Build and return a Crew for `market` (IN/US/EU/APAC/CRYPTO).

        Args:
            market: Market code.  Falls back to "IN" if unrecognised.
            user_input: The original user query.
            intent: Classified intent (e.g. "technical_analysis").
            entities: Extracted entities from the user query.
            portfolio_snapshot: Pre-fetched portfolio holdings (optional).

        Returns:
            A crewai.Crew ready to kickoff().
        """
        cfg = MARKET_CONFIGS.get(market.upper(), MARKET_CONFIGS["IN"])
        market_ctx = self._build_market_context(cfg, user_input, intent, entities, portfolio_snapshot)

        agents = self._build_agents(cfg, market_ctx)
        tasks = self._build_tasks(agents, cfg, market_ctx, user_input, intent, entities)

        crew = Crew(
            agents=list(agents.values()),
            tasks=tasks,
            process=Process.sequential,
            verbose=self._verbose,
            memory=False,  # Disabled: CrewAI 1.14.5 memory bugs cause noise; no cross-session recall loss
            planning=True,
            planning_llm=self._llm,
        )
        logger.info(
            "MarketCrewBuilder | market=%s | agents=%d | tasks=%d | intent=%s",
            market, len(agents), len(tasks), intent,
        )
        return crew

    # ── Context builder ───────────────────────────────────────────────────────

    @staticmethod
    def _build_market_context(
        cfg: Dict[str, str],
        user_input: str,
        intent: str,
        entities: List[Dict[str, Any]],
        portfolio_snapshot: Optional[Dict[str, Any]],
    ) -> str:
        """Build a compact market context string shared across all task prompts."""
        symbol_entities = [
            e["value"] for e in entities if e.get("type") in ("symbol", "ticker", "stock")
        ]
        portfolio_note = ""
        if portfolio_snapshot:
            cash = portfolio_snapshot.get("cash", "unknown")
            holdings = portfolio_snapshot.get("holdings", [])
            n_pos = len(holdings) if isinstance(holdings, list) else "?"
            portfolio_note = f"\nPortfolio: cash={cash}, open_positions={n_pos}"

        return textwrap.dedent(f"""\
            Market: {cfg['name']} | Currency: {cfg['currency']}
            Benchmark: {cfg['benchmark']}
            Secondary Indices: {cfg['secondary_indices']}
            Trading Hours (UTC): {cfg['hours_utc']}
            Macro Focus: {cfg['macro_focus']}
            Sentiment Sources: {cfg['sentiment_sources']}
            Risk Notes: {cfg['risk_notes']}
            Data Ticker Suffix: {cfg['data_suffix']}
            Typical Symbols: {cfg['typical_symbols']}
            ──
            User Query: {user_input}
            Intent: {intent}
            Symbols of Interest: {', '.join(symbol_entities) if symbol_entities else 'none specified — use market benchmark'}
            Timestamp (UTC): {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}{portfolio_note}
        """).strip()

    # ── Agent factory ─────────────────────────────────────────────────────────

    def _build_agents(
        self, cfg: Dict[str, str], market_ctx: str
    ) -> Dict[str, Agent]:
        """
        Return an ordered dict of 7 slim crewai.Agent objects for this market.
        Roles/goals mirror the Enhanced* agent classes; backstory is market-enriched.
        """
        mkt = cfg["name"]

        def _agent(role: str, goal: str, backstory: str) -> Agent:
            return Agent(
                role=role,
                goal=goal,
                backstory=backstory,
                verbose=self._verbose,
                allow_delegation=False,  # sequential — no sub-delegation needed
                memory=False,  # Crew-level Memory(llm=...) handles shared memory
                reasoning=True,
                max_reasoning_attempts=2,
                max_iter=self._max_iter,
                tools=self._tools,
                llm=self._llm,
            )

        return {
            "macro": _agent(
                role=f"Macro-Economic Analyst ({mkt})",
                goal=(
                    "Analyse macroeconomic indicators, central bank policy, currency dynamics, "
                    "and commodity flows specific to " + mkt + " to provide a directional macro view."
                ),
                backstory=(
                    f"You are a senior economist specialising in {mkt}. "
                    f"You track {cfg['macro_focus']}. "
                    "You translate complex macro data into clear market implications — "
                    "identifying tailwinds, headwinds, and policy-driven inflection points."
                ),
            ),
            "research": _agent(
                role=f"Fundamental Research Analyst ({mkt})",
                goal=(
                    "Evaluate company fundamentals, sector health, and valuation for securities "
                    "in " + mkt + " using financial ratios, DCF models, and peer comparison."
                ),
                backstory=(
                    f"You are a CFA-level analyst covering {mkt}. "
                    "You assess PE/PB ratios, ROE, debt/equity, EPS growth, and sector multiples. "
                    f"You are fluent in {cfg['regulator']} disclosures and accounting standards."
                ),
            ),
            "technical": _agent(
                role=f"Technical Analysis Specialist ({mkt})",
                goal=(
                    "Identify chart patterns, support/resistance levels, momentum signals, "
                    "and trend direction for securities in " + mkt + "."
                ),
                backstory=(
                    f"You are a CMT-certified technical analyst for {mkt}. "
                    "You use SMA/EMA (20/50/200), RSI, MACD, Bollinger Bands, ATR, ADX, "
                    "volume profile, and candlestick patterns to generate precise entry/exit signals. "
                    f"You benchmark against {cfg['benchmark']}."
                ),
            ),
            "sentiment": _agent(
                role=f"Market Sentiment Analyst ({mkt})",
                goal=(
                    "Measure and interpret market sentiment for " + mkt
                    + " using news, social media, fear/greed indicators, and options flow."
                ),
                backstory=(
                    f"You are a sentiment specialist for {mkt}. "
                    f"You monitor {cfg['sentiment_sources']}. "
                    "You use FinBERT/VADER sentiment scoring, news impact analysis, "
                    "and contrarian signals to assess crowd psychology."
                ),
            ),
            "risk": _agent(
                role=f"Risk Management Specialist ({mkt})",
                goal=(
                    "Quantify portfolio and position risk for " + mkt
                    + " using VaR, max drawdown, position sizing, and stress tests."
                ),
                backstory=(
                    f"You are a FRM-certified risk manager for {mkt}. "
                    f"You apply {cfg['risk_notes']}. "
                    "You calculate parametric/historical VaR, Sharpe/Sortino ratios, "
                    "Kelly criterion position sizing, and scenario stress tests. "
                    "Your job is to protect capital first, then seek returns."
                ),
            ),
            "timing": _agent(
                role=f"Market Timing Specialist ({mkt})",
                goal=(
                    "Identify optimal entry and exit timing windows for positions in "
                    + mkt + " based on regime detection, momentum cycles, and seasonality."
                ),
                backstory=(
                    f"You are a quantitative timing specialist for {mkt}. "
                    f"Your benchmark is {cfg['benchmark']}. "
                    "You use Hurst exponent, market regime models (trending/mean-reverting), "
                    "time-of-day/day-of-week patterns, options expiry calendars, "
                    "and earnings blackout windows to optimise timing."
                ),
            ),
            "strategy": _agent(
                role=f"Trade Strategy Planner ({mkt})",
                goal=(
                    "Synthesise macro, fundamental, technical, sentiment, risk, and timing "
                    "inputs into a coherent, actionable trade strategy for " + mkt + "."
                ),
                backstory=(
                    f"You are a senior portfolio strategist for {mkt}. "
                    "You synthesise all specialist analyses into a unified strategy note that "
                    "includes: directional view (bullish/bearish/neutral), specific entry levels, "
                    "stop-loss, target prices, position sizing (% of portfolio), "
                    "and a confidence score (0–100). "
                    "You explicitly flag key risks and catalysts to watch."
                ),
            ),
        }

    # ── Task factory ──────────────────────────────────────────────────────────

    def _build_tasks(
        self,
        agents: Dict[str, Agent],
        cfg: Dict[str, str],
        market_ctx: str,
        user_input: str,
        intent: str,
        entities: List[Dict[str, Any]],
    ) -> List[Task]:
        """
        Build 7 sequential tasks.  Each task's output is passed as context
        to the next via CrewAI's built-in sequential context chaining.
        """
        symbol_hint = self._symbol_hint(entities, cfg)
        intent_focus = self._intent_focus(intent)

        # ── 1. Macro ─────────────────────────────────────────────────────────
        t_macro = Task(
            description=textwrap.dedent(f"""\
                {market_ctx}

                Task: Macro-Economic Assessment
                ================================
                {intent_focus}

                1. Identify the current macro regime for {cfg['name']}:
                   - Central bank policy stance (rate direction, QE/QT)
                   - Key macro indicators: {cfg['macro_focus']}
                   - Currency outlook ({cfg['currency']})
                   - Commodity/trade flow implications (if relevant)

                2. Rate the macro environment: Strongly Bullish / Bullish /
                   Neutral / Bearish / Strongly Bearish — with a 1-sentence rationale.

                3. Flag any macro catalyst in the next 30 days that could move markets.

                Focus on: {symbol_hint}
            """).strip(),
            expected_output=(
                "A concise macro assessment note: regime rating, top-3 macro drivers, "
                "currency outlook, and upcoming catalysts. Max 300 words."
            ),
            agent=agents["macro"],
        )

        # ── 2. Fundamental Research ───────────────────────────────────────────
        t_research = Task(
            description=textwrap.dedent(f"""\
                {market_ctx}

                Task: Fundamental Research
                ==========================
                {intent_focus}

                Using the macro context from the previous step:

                1. For the symbol(s) of interest ({symbol_hint}):
                   - Key financial ratios: P/E, P/B, ROE, EV/EBITDA, Debt/Equity
                   - Recent earnings trend (EPS beat/miss, guidance)
                   - Sector positioning and competitive moat
                   - Relative valuation vs sector peers and {cfg['benchmark']}

                2. Fundamental verdict: Undervalued / Fairly Valued / Overvalued
                   — cite the primary metric driving the verdict.

                3. Key fundamental risk: one sentence.
            """).strip(),
            expected_output=(
                "A fundamental summary: key ratios, earnings trend, valuation verdict, "
                "and primary risk. Max 250 words."
            ),
            agent=agents["research"],
            context=[t_macro],
        )

        # ── 3. Technical Analysis ─────────────────────────────────────────────
        t_technical = Task(
            description=textwrap.dedent(f"""\
                {market_ctx}

                Task: Technical Analysis
                ========================
                {intent_focus}

                Using macro and fundamental context:

                1. Trend analysis for {symbol_hint}:
                   - Price vs SMA20/50/200: above/below/crossing
                   - MACD: signal crossover, histogram momentum
                   - RSI (14): overbought (>70) / neutral / oversold (<30)
                   - ADX (14): trending (>25) / range-bound (<20)

                2. Key levels:
                   - Immediate support (S1) and resistance (R1)
                   - Major support (S2) and resistance (R2) — 52-week range context
                   - Volume profile: is volume confirming the trend?

                3. Chart patterns (if present): name the pattern, completion %, target

                4. Technical signal: Strong Buy / Buy / Neutral / Sell / Strong Sell
            """).strip(),
            expected_output=(
                "Technical note: trend status, key levels (S1/R1/S2/R2), "
                "indicator readings, pattern (if any), and signal verdict. Max 250 words."
            ),
            agent=agents["technical"],
            context=[t_macro, t_research],
        )

        # ── 4. Sentiment ──────────────────────────────────────────────────────
        t_sentiment = Task(
            description=textwrap.dedent(f"""\
                {market_ctx}

                Task: Sentiment Analysis
                ========================
                {intent_focus}

                1. News sentiment for {symbol_hint} over the last 5 days:
                   - Headline tone: Positive / Neutral / Negative
                   - Key news drivers (earnings, product launch, regulatory, macro)

                2. Market breadth sentiment for {cfg['name']}:
                   - Advance/decline ratio, new highs vs new lows
                   - Volatility index ({cfg.get('secondary_indices', '')[:40]}) reading vs 30-day avg

                3. Sentiment score: Very Bullish / Bullish / Neutral / Bearish / Very Bearish
                   — contrarian flag if extreme (i.e. sentiment may be overdone)

                Sources to reference: {cfg['sentiment_sources']}
            """).strip(),
            expected_output=(
                "Sentiment summary: news tone, market breadth, volatility reading, "
                "sentiment verdict, and contrarian flag if applicable. Max 200 words."
            ),
            agent=agents["sentiment"],
            context=[t_macro, t_technical],
        )

        # ── 5. Risk Assessment ────────────────────────────────────────────────
        t_risk = Task(
            description=textwrap.dedent(f"""\
                {market_ctx}

                Task: Risk Assessment
                =====================
                {intent_focus}

                Using all prior analysis:

                1. Position risk for {symbol_hint}:
                   - Estimate 1-day 95% VaR (use ATR or implied vol as proxy)
                   - Maximum adverse excursion: plausible downside scenario (%)
                   - Suggested stop-loss level (price or % from current)

                2. Portfolio-level risk (if portfolio data available):
                   - Concentration risk check
                   - Correlation to {cfg['benchmark']}
                   - Recommended max position size (% of portfolio, Kelly or fixed-fraction)

                3. Risk flags: {cfg['risk_notes']}

                4. Overall risk rating: Low / Medium / High / Very High
            """).strip(),
            expected_output=(
                "Risk note: VaR estimate, stop-loss level, max position size, "
                "portfolio risk flags, and risk rating. Max 200 words."
            ),
            agent=agents["risk"],
            context=[t_macro, t_technical, t_sentiment],
        )

        # ── 6. Timing ─────────────────────────────────────────────────────────
        t_timing = Task(
            description=textwrap.dedent(f"""\
                {market_ctx}

                Task: Entry/Exit Timing
                =======================
                {intent_focus}

                Using technical and risk context:

                1. Market regime for {cfg['name']}: Trending / Mean-Reverting / Transition
                   - Hurst exponent proxy: if ADX > 25 → trending; if ADX < 20 → range

                2. Timing recommendation for {symbol_hint}:
                   - Immediate: Enter now / Wait for pullback / Wait for breakout / Avoid
                   - Ideal entry window: price level or trigger condition
                   - Time horizon: Intraday / 1–5 days / 1–4 weeks / 1–3 months

                3. Key timing catalysts in {cfg['name']} (next 14 days):
                   - Earnings dates, central bank meetings, macro data releases,
                     options expiry, index rebalancing

                4. Timing confidence: High / Medium / Low
            """).strip(),
            expected_output=(
                "Timing note: regime, entry recommendation, trigger condition, "
                "time horizon, upcoming catalysts, and timing confidence. Max 200 words."
            ),
            agent=agents["timing"],
            context=[t_technical, t_risk],
        )

        # ── 7. Strategy Synthesis ─────────────────────────────────────────────
        t_strategy = Task(
            description=textwrap.dedent(f"""\
                {market_ctx}

                Task: Trade Strategy Synthesis
                ================================
                You have received analysis from 6 specialist agents.
                Synthesise everything into a unified strategy note.

                Original user query: "{user_input}"
                Intent: {intent_focus}

                Required output structure:
                ─────────────────────────────────────────────────
                MARKET: {cfg['name']}
                SYMBOL(S): {symbol_hint}

                DIRECTIONAL VIEW: [Strongly Bullish / Bullish / Neutral / Bearish / Strongly Bearish]
                CONFIDENCE SCORE: [0–100]

                STRATEGY SUMMARY:
                (2–3 sentences integrating macro + fundamental + technical + sentiment)

                TRADE RECOMMENDATION:
                • Action:       [Buy / Sell / Hold / Avoid]
                • Entry:        [price level or trigger]
                • Stop-Loss:    [price level]
                • Target 1:     [price level]
                • Target 2:     [price level, optional]
                • Position Size:[% of portfolio]
                • Time Horizon: [Intraday / Days / Weeks / Months]

                KEY RISKS:
                1. [Risk 1]
                2. [Risk 2]
                3. [Risk 3]

                CATALYSTS TO WATCH:
                • [Catalyst 1]
                • [Catalyst 2]

                DISCLAIMER: This is an AI-generated advisory for informational purposes.
                All investments carry risk. Past performance does not guarantee future results.
                ─────────────────────────────────────────────────
            """).strip(),
            expected_output=(
                "A complete structured strategy note in the exact format specified above, "
                "incorporating all specialist inputs. Include explicit entry, stop-loss, "
                "and target levels wherever possible."
            ),
            agent=agents["strategy"],
            context=[t_macro, t_research, t_technical, t_sentiment, t_risk, t_timing],
        )

        return [t_macro, t_research, t_technical, t_sentiment, t_risk, t_timing, t_strategy]

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _symbol_hint(
        entities: List[Dict[str, Any]], cfg: Dict[str, str]
    ) -> str:
        """Extract symbol entities or fall back to market benchmark."""
        symbols = [
            e["value"] for e in entities
            if e.get("type") in ("symbol", "ticker", "stock", "crypto", "company")
        ]
        if symbols:
            return ", ".join(symbols[:5])
        return f"the {cfg['benchmark']} index or leading stocks in {cfg['name']}"

    @staticmethod
    def _intent_focus(intent: str) -> str:
        """Map intent to a short focus instruction for each task prompt."""
        _MAP = {
            "technical_analysis":   "Focus: technical signals and chart patterns.",
            "fundamental_analysis": "Focus: fundamentals, valuation, and earnings.",
            "sentiment_analysis":   "Focus: news sentiment and market mood.",
            "risk_assessment":      "Focus: risk quantification and position sizing.",
            "macro_analysis":       "Focus: macro drivers and central bank policy.",
            "trade_strategy":       "Focus: actionable entry/exit strategy.",
            "portfolio_review":     "Focus: portfolio-level risk and rebalancing.",
            "market_overview":      "Focus: broad market assessment across all factors.",
            "general_advice":       "Focus: balanced view across all factors.",
        }
        return _MAP.get(intent, "Focus: balanced analysis across all factors.")
