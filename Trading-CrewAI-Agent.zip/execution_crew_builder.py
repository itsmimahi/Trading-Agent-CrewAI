"""
Phase 4 — ExecutionCrewBuilder
================================
Builds the execution planning Crew that translates an approved advisory
synthesis (from AnalysisCrew) into a validated, broker-ready trade list.

3-agent sequential pipeline
────────────────────────────
    1. ExecutionPlannerAgent    — selects which recommendations to act on now;
                                  cross-checks portfolio constraints and cash
    2. TradeListBuilderAgent    — converts selected recommendations into a
                                  structured JSON trade list
    3. RiskFinalCheckAgent      — validates every order against position-size
                                  limits, order-risk fraction, and stop-loss rules;
                                  marks each order APPROVED / REJECTED / WATCH

Output format (from RiskFinalCheckAgent)
─────────────────────────────────────────
    ## EXECUTION_PLAN
    ```json
    [
      {
        "symbol": "RELIANCE.NS",
        "side":   "BUY",
        "qty":    10,
        "market": "IN",
        "limit_price": 2520.0,
        "stop_loss":   2395.0,
        "rationale":   "Breakout above 200-DMA...",
        "priority":    1,
        "horizon":     "MEDIUM",
        "status":      "APPROVED",
        "reject_reason": ""
      },
      ...
    ]
    ```
    ## SUMMARY
    Approved: 3 trades | Rejected: 1 | On watch: 1

Integration in advisory_flow.execution_step
────────────────────────────────────────────
    try:
        from execution_crew_builder import ExecutionCrewBuilder
        exec_builder = ExecutionCrewBuilder(
            llm=self._llm, verbose=self._verbose,
            max_position_size=self._max_position_size,
            max_order_risk_fraction=self._max_order_risk_fraction,
        )
        crew = exec_builder.build(
            synthesis=s.synthesis_result,
            portfolio_snapshot=s.portfolio_snapshot,
        )
        s.execution_result = str(crew.kickoff())
    except ImportError:
        pass
"""

from __future__ import annotations

import json
import logging
import textwrap
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

from crewai import Agent, Crew, Process, Task
from crewai.llm import LLM

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Builder
# ─────────────────────────────────────────────────────────────────────────────

class ExecutionCrewBuilder:
    """
    Builds the ExecutionCrew (Phase 4).

    Accepts the approved advisory synthesis and portfolio context, then runs
    three specialist agents to produce a validated, broker-ready trade list.
    """

    def __init__(
        self,
        llm: LLM,
        verbose: bool = False,
        max_iter: int = 6,
        max_position_size: float = 0.20,       # max 20% of portfolio per trade
        max_order_risk_fraction: float = 0.05,  # max 5% of portfolio at risk per order
    ) -> None:
        self._llm = llm
        self._verbose = verbose
        self._max_iter = max_iter
        self._max_position_size = max_position_size
        self._max_order_risk_fraction = max_order_risk_fraction

    # ── Public API ────────────────────────────────────────────────────────────

    def build(
        self,
        synthesis: str,
        portfolio_snapshot: Optional[Dict[str, Any]] = None,
    ) -> Crew:
        """
        Build and return the ExecutionCrew.

        Args:
            synthesis: The approved advisory synthesis text from AnalysisCrewBuilder.
            portfolio_snapshot: Current holdings and cash from portfolio broker.

        Returns:
            A crewai.Crew ready to kickoff().
        """
        portfolio_ctx = self._format_portfolio(portfolio_snapshot)
        constraints = self._format_constraints()
        agents = self._build_agents()
        tasks = self._build_tasks(agents, synthesis, portfolio_ctx, constraints)

        crew = Crew(
            agents=list(agents.values()),
            tasks=tasks,
            process=Process.sequential,
            verbose=self._verbose,
            memory=False,  # Disabled: CrewAI 1.14.5 memory bugs cause noise; no cross-session recall loss
            planning=True,
            planning_llm=self._llm,
        )
        logger.info(
            "ExecutionCrewBuilder | agents=%d | tasks=%d", len(agents), len(tasks)
        )
        return crew

    # ── Formatters ────────────────────────────────────────────────────────────

    @staticmethod
    def _format_portfolio(snapshot: Optional[Dict[str, Any]]) -> str:
        if not snapshot:
            return "Portfolio data unavailable — assume standard cash allocation."
        cash = snapshot.get("cash", "N/A")
        holdings = snapshot.get("holdings", []) or []
        total_value = snapshot.get("total_value") or snapshot.get("net_value", "N/A")

        lines = [
            f"Available Cash: {cash}",
            f"Total Portfolio Value: {total_value}",
            f"Open Positions ({len(holdings)}):",
        ]
        for h in holdings[:15]:  # cap to avoid LLM context overflow
            sym = h.get("symbol", "?")
            qty = h.get("quantity", "?")
            pnl = h.get("unrealized_pnl", "?")
            lines.append(f"  - {sym}: qty={qty}, unrealized_pnl={pnl}")

        return "\n".join(lines)

    def _format_constraints(self) -> str:
        return (
            f"Risk Constraints:\n"
            f"  - Max position size: {self._max_position_size * 100:.0f}% of portfolio value per trade\n"
            f"  - Max order risk fraction: {self._max_order_risk_fraction * 100:.0f}% of portfolio at risk per order\n"
            f"  - Every APPROVED trade must have a stop-loss level defined\n"
            f"  - No duplicate symbols in approved trades (if already held, prefer ADD/REDUCE, not new BUY)\n"
            f"  - Maximum 5 concurrent open recommendations to execute at once"
        )

    # ── Agent factory ─────────────────────────────────────────────────────────

    def _build_agents(self) -> Dict[str, Agent]:

        def _agent(role: str, goal: str, backstory: str) -> Agent:
            return Agent(
                role=role,
                goal=goal,
                backstory=backstory,
                verbose=self._verbose,
                allow_delegation=False,
                memory=False,  # Crew-level Memory(llm=...) handles shared memory
                reasoning=True,
                max_reasoning_attempts=2,
                max_iter=self._max_iter,
                llm=self._llm,
            )

        return {
            "planner": _agent(
                role="Execution Planner",
                goal=(
                    "Select which advisory recommendations to execute immediately versus "
                    "add to a watch list, based on available cash and portfolio constraints."
                ),
                backstory=(
                    "You are a senior portfolio implementation specialist. You receive an "
                    "approved investment advisory and decide what can realistically be "
                    "executed given current portfolio state, cash availability, and "
                    "position concentration rules. You are disciplined and risk-conscious — "
                    "you never overextend a portfolio just because the analysis looks good."
                ),
            ),
            "trade_builder": _agent(
                role="Trade List Builder",
                goal=(
                    "Convert approved recommendations into a precise, structured JSON trade "
                    "list with symbol, side, quantity, limit price, stop-loss, and rationale."
                ),
                backstory=(
                    "You are an order management specialist with deep knowledge of "
                    "equity and crypto order construction. You translate investment "
                    "recommendations into broker-ready order specifications. You always "
                    "specify both a limit price (to avoid slippage) and a stop-loss level "
                    "(to enforce the risk framework). You produce clean, machine-parseable JSON."
                ),
            ),
            "risk_checker": _agent(
                role="Final Risk Gate",
                goal=(
                    "Validate every proposed trade against position-size limits, order-risk "
                    "fraction, stop-loss rules, and duplicate-symbol checks. Mark each trade "
                    "APPROVED, REJECTED, or WATCH with a clear reason."
                ),
                backstory=(
                    "You are the last line of defense before any order reaches the broker. "
                    "You apply the firm's risk rules mechanically and without emotion. "
                    "A trade that violates any risk constraint is REJECTED — no exceptions. "
                    "You output a final, clean execution plan in structured JSON format "
                    "followed by a plain-English summary."
                ),
            ),
        }

    # ── Task factory ──────────────────────────────────────────────────────────

    def _build_tasks(
        self,
        agents: Dict[str, Agent],
        synthesis: str,
        portfolio_ctx: str,
        constraints: str,
    ) -> List[Task]:
        ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

        # Task 1: Execution Planning
        planning_task = Task(
            description=textwrap.dedent(f"""
                Timestamp: {ts}

                You have received an APPROVED advisory synthesis:

                {synthesis[:4000]}

                Current Portfolio State:
                {portfolio_ctx}

                {constraints}

                Your tasks:
                1. Identify the top recommendations from the synthesis (look for BUY/SELL/HOLD signals).
                2. For each recommendation, decide:
                   - EXECUTE NOW: cash is available, no position-size violation, conviction is HIGH/MEDIUM
                   - WATCH: conviction is LOW or cash is insufficient or position is already at limit
                   - SKIP: recommendation is HOLD or already heavily weighted in portfolio
                3. Provide a brief rationale for each decision.
                4. State the total estimated capital required for EXECUTE NOW recommendations.

                Be concise. Output a numbered list of decisions.
            """).strip(),
            expected_output=(
                "Numbered list of execution decisions (EXECUTE NOW / WATCH / SKIP) with "
                "1-line rationale per recommendation and total capital required estimate."
            ),
            agent=agents["planner"],
        )

        # Task 2: Trade List Construction
        trade_build_task = Task(
            description=textwrap.dedent(f"""
                Using the execution plan from the Execution Planner, build a structured
                JSON trade list for all EXECUTE NOW recommendations.

                {portfolio_ctx}

                For each EXECUTE NOW trade, produce a JSON object with these exact keys:
                - "symbol":      ticker symbol (with market suffix, e.g. RELIANCE.NS, AAPL, BTC-USD)
                - "side":        "BUY" or "SELL"
                - "qty":         integer quantity (calculate from available cash and position size limits)
                - "market":      "IN" | "US" | "EU" | "APAC" | "CRYPTO"
                - "limit_price": float (entry limit price — use current price ± 0.5% slippage allowance)
                - "stop_loss":   float (stop-loss level as absolute price, not %)
                - "rationale":   string (1-2 sentence rationale from the synthesis)
                - "priority":    integer (1 = highest, descending)
                - "horizon":     "SHORT" | "MEDIUM" | "LONG"
                - "status":      "PENDING"
                - "reject_reason": ""

                Output the list wrapped in a ```json code block.
                Also include a WATCH_LIST section with tickers the planner flagged as WATCH.
            """).strip(),
            expected_output=(
                "A valid JSON array of trade order objects (all EXECUTE NOW trades) in a "
                "```json code block, plus a WATCH_LIST section."
            ),
            agent=agents["trade_builder"],
            context=[planning_task],
        )

        # Task 3: Risk Final Check
        risk_check_task = Task(
            description=textwrap.dedent(f"""
                Timestamp: {ts}

                Apply the following risk rules to EVERY trade in the trade list:

                {constraints}

                For each trade:
                1. Check: qty × limit_price ≤ max_position_size × portfolio_value
                   → If violated: set status="REJECTED", reject_reason="Position size exceeds limit"
                2. Check: qty × (limit_price - stop_loss) ≤ max_order_risk_fraction × portfolio_value
                   → If violated: set status="REJECTED", reject_reason="Order risk fraction exceeded"
                3. Check: stop_loss is set (not null, not 0, not equal to limit_price)
                   → If missing: set status="REJECTED", reject_reason="No stop-loss defined"
                4. Check: no duplicate symbols in APPROVED list
                   → If duplicate: keep the higher-priority one, REJECT the other
                5. If all checks pass: set status="APPROVED"

                Output the final validated trade list as:

                ## EXECUTION_PLAN
                ```json
                [... validated trade objects with status APPROVED/REJECTED ...]
                ```

                ## SUMMARY
                Approved: N trades | Rejected: N | On watch: N
                Total capital to deploy: $ / ₹ / crypto value

                Use ONLY the portfolio value from the context. If unknown, state "portfolio value unavailable"
                and mark all trades that require size calculations as status="WATCH".
            """).strip(),
            expected_output=(
                "Final validated execution plan with ## EXECUTION_PLAN JSON block "
                "and ## SUMMARY section. Every trade has status APPROVED/REJECTED/WATCH."
            ),
            agent=agents["risk_checker"],
            context=[planning_task, trade_build_task],
        )

        return [planning_task, trade_build_task, risk_check_task]


# ─────────────────────────────────────────────────────────────────────────────
# Trade-list parser (used by execution_step to extract APPROVED orders)
# ─────────────────────────────────────────────────────────────────────────────

def extract_approved_trades(execution_result: str) -> List[Dict[str, Any]]:
    """
    Extract APPROVED trades from the ExecutionCrew's output text.

    Looks for the ``## EXECUTION_PLAN`` JSON block and returns only trades
    with ``"status": "APPROVED"``.  Returns an empty list on any parse error.

    Args:
        execution_result: Raw string output from ExecutionCrew.kickoff().

    Returns:
        List of approved trade dicts, or [] if none found.
    """
    try:
        import re
        # Find the ```json ... ``` block after ## EXECUTION_PLAN
        pattern = r"##\s*EXECUTION_PLAN.*?```json\s*(.*?)```"
        match = re.search(pattern, execution_result, re.DOTALL | re.IGNORECASE)
        if not match:
            logger.debug("extract_approved_trades: no EXECUTION_PLAN block found")
            return []

        raw_json = match.group(1).strip()
        trades: List[Dict[str, Any]] = json.loads(raw_json)
        approved = [t for t in trades if str(t.get("status", "")).upper() == "APPROVED"]
        logger.info("extract_approved_trades | total=%d | approved=%d", len(trades), len(approved))
        return approved

    except Exception as exc:
        logger.debug("extract_approved_trades | parse error: %s", exc)
        return []
