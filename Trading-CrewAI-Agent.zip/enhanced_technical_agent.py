"""
Enhanced Technical Agent using CrewAI Framework - Hybrid Plus Approach
Mathematical Core + LLM Reasoning + Tools + Memory + Knowledge Base
"""

import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass
import talib as ta

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from data.collectors.market_data import market_data_collector
from config.settings import config
from crewai import Task, Crew, Process

logger = logging.getLogger(__name__)

@dataclass
class TechnicalIndicators:
    """Technical indicators calculation results"""
    sma_20: float
    sma_50: float
    sma_200: float
    ema_12: float
    ema_26: float
    rsi: float
    macd: float
    macd_signal: float
    macd_histogram: float
    bollinger_upper: float
    bollinger_lower: float
    bollinger_width: float
    stochastic_k: float
    stochastic_d: float
    williams_r: float
    atr: float
    adx: float
    cci: float
    momentum: float
    volume_sma: float

@dataclass
class PatternAnalysis:
    """Chart pattern analysis results"""
    pattern_type: str
    pattern_strength: float
    breakout_probability: float
    target_price: float
    stop_loss: float
    support_levels: List[float]
    resistance_levels: List[float]
    trend_direction: str
    trend_strength: float

@dataclass
class SignalAnalysis:
    """Trading signal analysis results"""
    signal_type: str  # buy, sell, hold
    signal_strength: float
    entry_price: float
    exit_price: float
    risk_reward_ratio: float
    probability: float
    timeframe: str

class EnhancedTechnicalAgent(EnhancedBaseAgent):
    memory = None
    """
    Enhanced Technical Agent using CrewAI Framework with Hybrid Plus Approach
    
    Mathematical Core: Technical indicator calculations, pattern recognition algorithms
    LLM Reasoning: Chart pattern interpretation, market regime analysis, signal validation
    Tools: Pattern scanner, indicator calculator, signal generator
    Memory: Pattern success rates, market cycle phases, indicator performance
    Knowledge Base: Technical analysis principles, pattern success probabilities
    """
    
    def __init__(self, name: str = "Technical Agent", description: str = "Technical analysis and chart pattern recognition", role: str = "Technical Analysis Specialist", goal: str = "Provide advanced technical analysis and chart pattern recognition", backstory: str = "Expert in technical analysis and quantitative trading", capabilities: Optional[List[Any]] = None, weight: float = 0.20, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.PATTERN_RECOGNITION,
                AgentCapability.TREND_ANALYSIS,
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.CONTEXTUAL_REASONING
            ]
        super().__init__(
            name=name,
            description=description,
            role=role,
            goal=goal,
            backstory=backstory,
            capabilities=capabilities,
            weight=weight,
            use_llm=use_llm,
            use_memory=use_memory,
            use_knowledge_base=use_knowledge_base,
            **kwargs
        )
        
        # Mathematical thresholds and models
        self.indicator_periods = {
            'sma_short': 20,
            'sma_medium': 50,
            'sma_long': 200,
            'ema_fast': 12,
            'ema_slow': 26,
            'rsi_period': 14,
            'stoch_period': 14,
            'atr_period': 14,
            'adx_period': 14
        }
        
        # Pattern recognition parameters
        self.pattern_thresholds = {
            'support_resistance_tolerance': 0.02,  # 2%
            'trend_strength_threshold': 0.6,
            'breakout_volume_multiplier': 1.5,
            'pattern_confirmation_periods': 3
        }
        
        # Signal scoring weights
        self.signal_weights = {
            'trend_following': 0.30,
            'momentum': 0.25,
            'mean_reversion': 0.20,
            'volume_confirmation': 0.15,
            'pattern_recognition': 0.10
        }
        
        # Load technical analysis knowledge
        self._load_technical_knowledge()
    
    def _initialize_tools(self):
        """Initialize Technical Agent specific tools"""
        self.logger.info(f"Initializing tools for {self.name}")
        super()._initialize_tools()
        
        # Add specialized technical tools
        self.tools.extend([
            AgentTool(
                name="calculate_indicators",
                description="Calculate comprehensive technical indicators",
                function=self._calculate_technical_indicators
            ),
            AgentTool(
                name="scan_patterns",
                description="Scan for chart patterns",
                function=self._scan_chart_patterns
            ),
            AgentTool(
                name="identify_support_resistance",
                description="Identify support and resistance levels",
                function=self._identify_support_resistance
            ),
            AgentTool(
                name="generate_signals",
                description="Generate trading signals",
                function=self._generate_trading_signals
            ),
            AgentTool(
                name="analyze_volume",
                description="Analyze volume patterns",
                function=self._analyze_volume_patterns
            ),
            AgentTool(
                name="momentum_analysis",
                description="Analyze momentum indicators",
                function=self._momentum_analysis
            ),
            AgentTool(
                name="trend_analysis",
                description="Analyze trend strength and direction",
                function=self._trend_analysis
            )
        ])
    
    def _load_technical_knowledge(self):
        """Load technical analysis knowledge into knowledge base"""
        try:
            technical_knowledge = [
                # Moving Averages
                "Golden Cross: When 50-day MA crosses above 200-day MA, bullish signal",
                "Death Cross: When 50-day MA crosses below 200-day MA, bearish signal",
                "Moving Average Support: Price bouncing off MA indicates support",
                "Moving Average Resistance: Price rejection at MA indicates resistance",
                
                # RSI Patterns
                "RSI Divergence: Price makes new highs while RSI makes lower highs = bearish divergence",
                "RSI Overbought: RSI above 70 suggests potential selling pressure",
                "RSI Oversold: RSI below 30 suggests potential buying opportunity",
                "RSI Trend Confirmation: RSI above 50 confirms uptrend, below 50 confirms downtrend",
                
                # MACD Signals
                "MACD Signal Line Cross: MACD crossing above signal line = bullish",
                "MACD Histogram: Increasing histogram shows strengthening momentum",
                "MACD Divergence: Price vs MACD divergence suggests trend reversal",
                "MACD Zero Line: MACD above zero indicates bullish momentum",
                
                # Chart Patterns
                "Head and Shoulders: Reversal pattern with 85% success rate",
                "Double Bottom: Reversal pattern with 78% success rate",
                "Triangle Patterns: Continuation patterns with 70% success rate",
                "Flag Patterns: Continuation patterns with 68% success rate",
                "Cup and Handle: Bullish continuation with 65% success rate",
                
                # Volume Analysis
                "Volume Confirmation: Rising prices with increasing volume = strong trend",
                "Volume Divergence: Price up but volume down = weak trend",
                "Breakout Volume: Volume 50% above average confirms breakout",
                "Distribution Days: High volume selling indicates institutional distribution",
                
                # Support and Resistance
                "Support: Price level where buying interest emerges",
                "Resistance: Price level where selling pressure emerges",
                "Role Reversal: Broken support becomes resistance and vice versa",
                "Multiple Touches: More touches increase level significance",
                
                # Market Regime Analysis
                "Trending Market: ADX above 25 indicates strong trend",
                "Ranging Market: ADX below 20 indicates choppy/sideways market",
                "Volatility Expansion: Bollinger Bands widening indicates volatility increase",
                "Volatility Contraction: Bollinger Bands narrowing indicates volatility decrease"
            ]
            
            if self.use_knowledge_base:
                self.knowledge_base.add_knowledge(technical_knowledge)
                
        except Exception as e:
            self.logger.error(f"Error loading technical knowledge: {e}")
    
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform mathematical/quantitative technical analysis
        Pure mathematical calculations without LLM
        """
        try:
            # Get price data as list of MarketData
            price_data = await market_data_collector.get_stock_data(symbol, period="6mo")
            if not price_data:
                return {"error": "No price data available"}

            # Convert list of MarketData to pandas DataFrame
            import pandas as pd
            df = pd.DataFrame([vars(row) for row in price_data])
            if df.empty:
                return {"error": "No price data available (empty DataFrame)"}

            # Fix column names to match expected format (MarketData uses lowercase, technical analysis expects uppercase)
            df = df.rename(columns={
                'open': 'Open',
                'high': 'High', 
                'low': 'Low',
                'close': 'Close',
                'volume': 'Volume',
                'adj_close': 'Adj Close'
            })
            
            # Set timestamp as index
            if 'timestamp' in df.columns:
                df['Date'] = pd.to_datetime(df['timestamp'])
                df.set_index('Date', inplace=True)
            
            # Ensure numeric columns are float type
            numeric_columns = ['Open', 'High', 'Low', 'Close', 'Volume', 'Adj Close']
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')

            # Calculate technical indicators
            indicators = self._calculate_technical_indicators(df)

            # Pattern analysis
            pattern_analysis = self._scan_chart_patterns(df)

            # Support/Resistance analysis
            support_resistance = self._identify_support_resistance(df)

            # Signal generation
            signals = self._generate_trading_signals(df, indicators)

            # Volume analysis
            volume_analysis = self._analyze_volume_patterns(df)

            # Momentum analysis
            momentum_analysis = self._momentum_analysis(df, indicators)

            # Trend analysis
            trend_analysis = self._trend_analysis(df, indicators)

            # Calculate overall technical score
            technical_score = self._calculate_technical_score(indicators, pattern_analysis, signals, trend_analysis)

            return {
                "symbol": symbol,
                "technical_indicators": indicators.__dict__ if indicators else {},
                "pattern_analysis": pattern_analysis.__dict__ if pattern_analysis else {},
                "support_resistance": support_resistance,
                "trading_signals": [signal.__dict__ for signal in signals] if signals else [],
                "volume_analysis": volume_analysis,
                "momentum_analysis": momentum_analysis,
                "trend_analysis": trend_analysis,
                "technical_score": technical_score,
                "calculation_timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in mathematical analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    def _calculate_technical_indicators(self, df: pd.DataFrame) -> Optional[TechnicalIndicators]:
        """Calculate comprehensive technical indicators"""
        try:
            if df.empty:
                return None
            
            # Ensure we have the required columns
            required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
            if not all(col in df.columns for col in required_cols):
                self.logger.error(f"Missing required columns. Available: {list(df.columns)}, Required: {required_cols}")
                return None

            # Drop rows with NaN values in required columns
            df_clean = df[required_cols].dropna()
            if df_clean.empty:
                self.logger.error("No valid data after removing NaN values")
                return None

            # Calculate moving averages
            df['SMA_20'] = ta.SMA(df['Close'], timeperiod=20)
            df['SMA_50'] = ta.SMA(df['Close'], timeperiod=50)
            df['SMA_200'] = ta.SMA(df['Close'], timeperiod=200)
            df['EMA_12'] = ta.EMA(df['Close'], timeperiod=12)
            df['EMA_26'] = ta.EMA(df['Close'], timeperiod=26)
            
            # Calculate oscillators
            df['RSI'] = ta.RSI(df['Close'], timeperiod=14)
            
            # Calculate stochastic
            df['STOCH_K'], df['STOCH_D'] = ta.STOCH(df['High'], df['Low'], df['Close'], 
                                                  fastk_period=14, slowk_period=3, slowd_period=3)
                
            df['WILLIAMS_R'] = ta.WILLR(df['High'], df['Low'], df['Close'], timeperiod=14)
            df['CCI'] = ta.CCI(df['High'], df['Low'], df['Close'], timeperiod=20)
            
            # Calculate MACD
            df['MACD'], df['MACD_SIGNAL'], df['MACD_HISTOGRAM'] = ta.MACD(df['Close'], 
                                                                        fastperiod=12, 
                                                                        slowperiod=26, 
                                                                        signalperiod=9)
            
            # Calculate Bollinger Bands
            df['BB_UPPER'], df['BB_MIDDLE'], df['BB_LOWER'] = ta.BBANDS(df['Close'], 
                                                                     timeperiod=20, 
                                                                     nbdevup=2, 
                                                                     nbdevdn=2)
            df['BB_WIDTH'] = (df['BB_UPPER'] - df['BB_LOWER']) / df['BB_MIDDLE']
            
            # Calculate volatility and trend indicators
            df['ATR'] = ta.ATR(df['High'], df['Low'], df['Close'], timeperiod=14)
            df['ADX'] = ta.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
            df['MOMENTUM'] = ta.MOM(df['Close'], timeperiod=10)
            df['VOLUME_SMA'] = ta.SMA(df['Volume'], timeperiod=20)
            
            # Get latest values (handle NaN with fillna)
            latest = df.iloc[-1]
            
            # Helper function to safely get float values
            def safe_float(value, default=0.0):
                try:
                    if pd.isna(value):
                        return default
                    return float(value)
                except (ValueError, TypeError):
                    return default
            
            return TechnicalIndicators(
                sma_20=safe_float(latest.get('SMA_20')),
                sma_50=safe_float(latest.get('SMA_50')),
                sma_200=safe_float(latest.get('SMA_200')),
                ema_12=safe_float(latest.get('EMA_12')),
                ema_26=safe_float(latest.get('EMA_26')),
                rsi=safe_float(latest.get('RSI')),
                macd=safe_float(latest.get('MACD')),
                macd_signal=safe_float(latest.get('MACD_SIGNAL')),
                macd_histogram=safe_float(latest.get('MACD_HISTOGRAM')),
                bollinger_upper=safe_float(latest.get('BB_UPPER')),
                bollinger_lower=safe_float(latest.get('BB_LOWER')),
                bollinger_width=safe_float(latest.get('BB_WIDTH')),
                stochastic_k=safe_float(latest.get('STOCH_K')),
                stochastic_d=safe_float(latest.get('STOCH_D')),
                williams_r=safe_float(latest.get('WILLIAMS_R')),
                atr=safe_float(latest.get('ATR')),
                adx=safe_float(latest.get('ADX')),
                cci=safe_float(latest.get('CCI')),
                momentum=safe_float(latest.get('MOMENTUM')),
                volume_sma=safe_float(latest.get('VOLUME_SMA'))
            )
            
        except Exception as e:
            self.logger.error(f"Error calculating technical indicators: {e}")
            return None
    
    def _scan_chart_patterns(self, df: pd.DataFrame) -> Optional[PatternAnalysis]:
        """Scan for chart patterns"""
        try:
            if df.empty or len(df) < 50:
                return None
            
            # Ensure required columns exist - DEFENSIVE CHECK
            required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
            missing_cols = [col for col in required_cols if col not in df.columns]
            if missing_cols:
                self.logger.error(f"Missing required columns for pattern analysis. Missing: {missing_cols}, Available: {list(df.columns)}")
                return None
            
            # Verify column data types and convert if needed
            for col in ['High', 'Low', 'Close']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Simple pattern recognition with safe column access
            recent_highs = df['High'].rolling(window=20).max()
            recent_lows = df['Low'].rolling(window=20).min()
            current_price = df['Close'].iloc[-1]
            
            # Identify trend with null checks
            sma_50 = df['Close'].rolling(window=50).mean().iloc[-1] if len(df) >= 50 else None
            sma_20 = df['Close'].rolling(window=20).mean().iloc[-1] if len(df) >= 20 else None
            
            if pd.notna(current_price) and pd.notna(sma_50) and pd.notna(sma_20):
                if current_price > sma_50 and sma_20 > sma_50:
                    trend_direction = "uptrend"
                    trend_strength = 0.8
                elif current_price < sma_50 and sma_20 < sma_50:
                    trend_direction = "downtrend"
                    trend_strength = 0.8
                else:
                    trend_direction = "sideways"
                    trend_strength = 0.4
            else:
                trend_direction = "sideways"
                trend_strength = 0.4
            
            # Identify support and resistance
            support_levels = self._find_support_levels(df)
            resistance_levels = self._find_resistance_levels(df)
            
            # Pattern analysis
            pattern_type = self._identify_pattern_type(df)
            pattern_strength = self._calculate_pattern_strength(df, pattern_type)
            
            # Calculate targets
            if pattern_type == "bullish_breakout":
                target_price = current_price * 1.05
                stop_loss = current_price * 0.95
            elif pattern_type == "bearish_breakdown":
                target_price = current_price * 0.95
                stop_loss = current_price * 1.05
            else:
                target_price = current_price
                stop_loss = current_price * 0.97
            
            return PatternAnalysis(
                pattern_type=pattern_type,
                pattern_strength=pattern_strength,
                breakout_probability=pattern_strength * 0.7,
                target_price=target_price,
                stop_loss=stop_loss,
                support_levels=support_levels,
                resistance_levels=resistance_levels,
                trend_direction=trend_direction,
                trend_strength=trend_strength
            )
            
        except Exception as e:
            self.logger.error(f"Error scanning chart patterns: {e}")
            return None
    
    def _identify_support_resistance(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Identify support and resistance levels"""
        try:
            support_levels = self._find_support_levels(df)
            resistance_levels = self._find_resistance_levels(df)
            
            current_price = df['Close'].iloc[-1]
            
            # Find nearest levels
            nearest_support = max([level for level in support_levels if level < current_price], default=0)
            nearest_resistance = min([level for level in resistance_levels if level > current_price], default=float('inf'))
            
            return {
                'support_levels': support_levels,
                'resistance_levels': resistance_levels,
                'nearest_support': nearest_support,
                'nearest_resistance': nearest_resistance,
                'support_distance': (current_price - nearest_support) / current_price * 100 if nearest_support > 0 else 0,
                'resistance_distance': (nearest_resistance - current_price) / current_price * 100 if nearest_resistance != float('inf') else 0
            }
            
        except Exception as e:
            self.logger.error(f"Error identifying support/resistance: {e}")
            return {"error": str(e)}
    
    def _find_support_levels(self, df: pd.DataFrame) -> List[float]:
        """Find support levels"""
        try:
            # Defensive column check
            if 'Low' not in df.columns:
                self.logger.error(f"'Low' column missing from DataFrame. Available columns: {list(df.columns)}")
                return []
            
            # Ensure Low column is numeric
            df['Low'] = pd.to_numeric(df['Low'], errors='coerce')
            
            # Find local minima
            lows = df['Low'].rolling(window=10, center=True).min()
            support_levels = []
            
            for i in range(10, len(df) - 10):
                if pd.notna(df['Low'].iloc[i]) and pd.notna(lows.iloc[i]):
                    if df['Low'].iloc[i] == lows.iloc[i] and df['Low'].iloc[i] < df['Low'].iloc[i-5:i+5].mean():
                        support_levels.append(df['Low'].iloc[i])
            
            # Remove duplicates and sort
            support_levels = list(set(support_levels))
            support_levels.sort()
            
            return support_levels[-5:]  # Return last 5 levels
            
        except Exception as e:
            self.logger.error(f"Error finding support levels: {e}")
            return []

    def _find_resistance_levels(self, df: pd.DataFrame) -> List[float]:
        """Find resistance levels"""
        try:
            # Defensive column check
            if 'High' not in df.columns:
                self.logger.error(f"'High' column missing from DataFrame. Available columns: {list(df.columns)}")
                return []
                
            # Ensure High column is numeric
            df['High'] = pd.to_numeric(df['High'], errors='coerce')
            
            # Find local maxima
            highs = df['High'].rolling(window=10, center=True).max()
            resistance_levels = []
            
            for i in range(10, len(df) - 10):
                if pd.notna(df['High'].iloc[i]) and pd.notna(highs.iloc[i]):
                    if df['High'].iloc[i] == highs.iloc[i] and df['High'].iloc[i] > df['High'].iloc[i-5:i+5].mean():
                        resistance_levels.append(df['High'].iloc[i])
            
            # Remove duplicates and sort
            resistance_levels = list(set(resistance_levels))
            resistance_levels.sort(reverse=True)
            
            return resistance_levels[:5]  # Return top 5 levels
            
        except Exception as e:
            self.logger.error(f"Error finding resistance levels: {e}")
            return []

    def _generate_trading_signals(self, df: pd.DataFrame, indicators: TechnicalIndicators) -> List[SignalAnalysis]:
        """Generate trading signals"""
        try:
            signals = []
            
            # Defensive check for Close column
            if 'Close' not in df.columns:
                self.logger.error(f"'Close' column missing from DataFrame. Available columns: {list(df.columns)}")
                return []
            
            if df.empty or indicators is None:
                return []
                
            current_price = df['Close'].iloc[-1]
            
            # Null check for current price
            if pd.isna(current_price):
                return []
            
            # Moving Average Crossover Signal
            if indicators.sma_20 > indicators.sma_50:
                signals.append(SignalAnalysis(
                    signal_type="buy",
                    signal_strength=0.7,
                    entry_price=current_price,
                    exit_price=current_price * 1.05,
                    risk_reward_ratio=2.0,
                    probability=0.65,
                    timeframe="medium"
                ))
            
            # RSI Oversold Signal
            if indicators.rsi < 30:
                signals.append(SignalAnalysis(
                    signal_type="buy",
                    signal_strength=0.6,
                    entry_price=current_price,
                    exit_price=current_price * 1.03,
                    risk_reward_ratio=1.5,
                    probability=0.60,
                    timeframe="short"
                ))
            
            # MACD Signal
            if indicators.macd > indicators.macd_signal and indicators.macd_histogram > 0:
                signals.append(SignalAnalysis(
                    signal_type="buy",
                    signal_strength=0.8,
                    entry_price=current_price,
                    exit_price=current_price * 1.08,
                    risk_reward_ratio=2.5,
                    probability=0.70,
                    timeframe="medium"
                ))
            
            return signals
            
        except Exception as e:
            self.logger.error(f"Error generating trading signals: {e}")
            return []
    
    def _analyze_volume_patterns(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Analyze volume patterns"""
        try:
            # Defensive check for Volume column
            if 'Volume' not in df.columns:
                self.logger.error(f"'Volume' column missing from DataFrame. Available columns: {list(df.columns)}")
                return {"error": f"'Volume' column missing"}
            
            # Ensure Volume column is numeric
            df['Volume'] = pd.to_numeric(df['Volume'], errors='coerce')
            
            volume_sma = df['Volume'].rolling(window=20).mean()
            current_volume = df['Volume'].iloc[-1]
            avg_volume = volume_sma.iloc[-1]
            
            # Handle NaN values
            if pd.isna(current_volume) or pd.isna(avg_volume):
                return {
                    'current_volume': 0,
                    'average_volume': 0,
                    'volume_ratio': 1,
                    'volume_trend': 'unknown',
                    'volume_confirmation': False
                }
            
            volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
            
            return {
                'current_volume': current_volume,
                'average_volume': avg_volume,
                'volume_ratio': volume_ratio,
                'volume_trend': 'increasing' if volume_ratio > 1.2 else 'decreasing' if volume_ratio < 0.8 else 'normal',
                'volume_confirmation': volume_ratio > 1.5
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing volume patterns: {e}")
            return {"error": str(e)}
    
    def _momentum_analysis(self, df: pd.DataFrame, indicators: TechnicalIndicators) -> Dict[str, Any]:
        """Analyze momentum indicators"""
        try:
            momentum_score = 0
            momentum_signals = []
            
            # RSI momentum
            if indicators.rsi > 50:
                momentum_score += 0.3
                momentum_signals.append("RSI bullish")
            elif indicators.rsi < 50:
                momentum_score -= 0.3
                momentum_signals.append("RSI bearish")
            
            # MACD momentum
            if indicators.macd > indicators.macd_signal:
                momentum_score += 0.4
                momentum_signals.append("MACD bullish")
            elif indicators.macd < indicators.macd_signal:
                momentum_score -= 0.4
                momentum_signals.append("MACD bearish")
            
            # Stochastic momentum
            if indicators.stochastic_k > indicators.stochastic_d:
                momentum_score += 0.3
                momentum_signals.append("Stochastic bullish")
            elif indicators.stochastic_k < indicators.stochastic_d:
                momentum_score -= 0.3
                momentum_signals.append("Stochastic bearish")
            
            return {
                'momentum_score': momentum_score,
                'momentum_direction': 'bullish' if momentum_score > 0 else 'bearish',
                'momentum_strength': abs(momentum_score),
                'momentum_signals': momentum_signals
            }
            
        except Exception as e:
            self.logger.error(f"Error in momentum analysis: {e}")
            return {"error": str(e)}
    
    def _trend_analysis(self, df: pd.DataFrame, indicators: TechnicalIndicators) -> Dict[str, Any]:
        """Analyze trend strength and direction"""
        try:
            trend_score = 0
            trend_signals = []
            
            # Moving average trend
            if indicators.sma_20 > indicators.sma_50 > indicators.sma_200:
                trend_score += 0.5
                trend_signals.append("Strong uptrend")
            elif indicators.sma_20 < indicators.sma_50 < indicators.sma_200:
                trend_score -= 0.5
                trend_signals.append("Strong downtrend")
            
            # ADX trend strength
            if indicators.adx > 25:
                trend_strength = min(indicators.adx / 50, 1.0)
                trend_signals.append(f"Strong trend (ADX: {indicators.adx:.1f})")
            else:
                trend_strength = 0.3
                trend_signals.append("Weak trend")
            
            # Price position relative to moving averages
            current_price = df['Close'].iloc[-1]
            if current_price > indicators.sma_200:
                trend_score += 0.3
                trend_signals.append("Above 200 SMA")
            elif current_price < indicators.sma_200:
                trend_score -= 0.3
                trend_signals.append("Below 200 SMA")
            
            return {
                'trend_score': trend_score,
                'trend_direction': 'bullish' if trend_score > 0 else 'bearish',
                'trend_strength': trend_strength,
                'trend_signals': trend_signals,
                'adx_value': indicators.adx
            }
            
        except Exception as e:
            self.logger.error(f"Error in trend analysis: {e}")
            return {"error": str(e)}
    
    def _identify_pattern_type(self, df: pd.DataFrame) -> str:
        """Identify chart pattern type"""
        try:
            # Simple pattern identification
            recent_prices = df['Close'].tail(20)
            price_trend = (recent_prices.iloc[-1] - recent_prices.iloc[0]) / recent_prices.iloc[0]
            
            if price_trend > 0.05:
                return "bullish_breakout"
            elif price_trend < -0.05:
                return "bearish_breakdown"
            else:
                return "consolidation"
                
        except Exception as e:
            self.logger.error(f"Error identifying pattern type: {e}")
            return "unknown"
    
    def _calculate_pattern_strength(self, df: pd.DataFrame, pattern_type: str) -> float:
        """Calculate pattern strength"""
        try:
            # Simple pattern strength calculation
            volume_confirmation = df['Volume'].tail(5).mean() / df['Volume'].tail(20).mean()
            price_volatility = df['Close'].tail(20).std() / df['Close'].tail(20).mean()
            
            strength = min(volume_confirmation * (1 - price_volatility), 1.0)
            return max(strength, 0.1)  # Minimum strength of 0.1
            
        except Exception as e:
            self.logger.error(f"Error calculating pattern strength: {e}")
            return 0.5
    
    def _calculate_technical_score(self, indicators: TechnicalIndicators, pattern_analysis: PatternAnalysis, 
                                 signals: List[SignalAnalysis], trend_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall technical score"""
        try:
            scores = []
            
            # Trend score (30%)
            trend_score = trend_analysis.get('trend_score', 0)
            scores.append(('trend', (trend_score + 1) / 2, 0.30))  # Normalize to 0-1
            
            # Momentum score (25%)
            momentum_score = 0.5  # Default neutral
            if indicators.rsi > 50:
                momentum_score += 0.2
            if indicators.macd > indicators.macd_signal:
                momentum_score += 0.3
            scores.append(('momentum', momentum_score, 0.25))
            
            # Pattern score (20%)
            if pattern_analysis:
                pattern_score = pattern_analysis.pattern_strength
            else:
                pattern_score = 0.5
            scores.append(('pattern', pattern_score, 0.20))
            
            # Signal score (15%)
            if signals:
                signal_score = sum(signal.signal_strength for signal in signals) / len(signals)
            else:
                signal_score = 0.5
            scores.append(('signals', signal_score, 0.15))
            
            # Volume score (10%)
            volume_score = 0.6  # Default slightly positive
            scores.append(('volume', volume_score, 0.10))
            
            # Calculate weighted score
            weighted_score = sum(score * weight for _, score, weight in scores)
            
            return {
                'overall_score': weighted_score,
                'component_scores': {name: score for name, score, _ in scores},
                'recommendation': 'strong_buy' if weighted_score > 0.8 else 'buy' if weighted_score > 0.6 else 'hold' if weighted_score > 0.4 else 'sell',
                'confidence': weighted_score
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating technical score: {e}")
            return {"error": str(e)}
    
    async def analyze(self, symbol: str, timeframe: str = "1d") -> Dict[str, Any]:
        """
        Main analysis method combining mathematical analysis with CrewAI reasoning
        Hybrid Plus Approach: Math + CrewAI + Tools + Memory + Knowledge Base
        """
        try:
            self.logger.info(f"Starting CrewAI comprehensive technical analysis for {symbol}")
            
            # 1. Mathematical Analysis (Fast, Reliable)
            math_results = await self.mathematical_analysis(symbol, {})
            if "error" in math_results:
                self.logger.error(f"Mathematical analysis failed for {symbol}: {math_results['error']}")
                # Return a structured error response that the test can handle
                return {
                    "error": math_results['error'],
                    "signal": "ERROR",
                    "confidence": 0.0,
                    "technical_indicators": {}
                }

            # Initialize LLM-based results
            crewai_reasoning = {"reasoning": "LLM analysis skipped or failed."}
            pattern_analysis = {"analysis": "LLM analysis skipped or failed."}
            
            # 2. Get market context for CrewAI reasoning
            market_context = await self._get_market_context(symbol, timeframe)
            
            # 3. CrewAI Reasoning (Intelligent Interpretation) - with robust error handling
            if self.use_llm:
                try:
                    crewai_reasoning = await self._get_crewai_technical_reasoning(math_results, market_context)
                    if "error" in crewai_reasoning:
                        self.logger.warning(f"CrewAI technical reasoning failed for {symbol}: {crewai_reasoning['error']}")
                        crewai_reasoning = {"reasoning": f"LLM reasoning failed: {crewai_reasoning['error']}"}
                except Exception as e:
                    self.logger.error(f"Exception in CrewAI technical reasoning for {symbol}: {e}", exc_info=True)
                    crewai_reasoning = {"reasoning": f"LLM reasoning exception: {e}"}

                # 4. CrewAI Analysis for pattern insights - with robust error handling
                try:
                    pattern_analysis = await self._get_crewai_pattern_analysis(
                        data=math_results,
                        context=market_context,
                        symbol=symbol
                    )
                    if "error" in pattern_analysis:
                        self.logger.warning(f"CrewAI pattern analysis failed for {symbol}: {pattern_analysis['error']}")
                        pattern_analysis = {"analysis": f"LLM pattern analysis failed: {pattern_analysis['error']}"}
                except Exception as e:
                    self.logger.error(f"Exception in CrewAI pattern analysis for {symbol}: {e}", exc_info=True)
                    pattern_analysis = {"analysis": f"LLM pattern analysis exception: {e}"}
            
            # 5. Memory Integration
            relevant_experiences = self.get_relevant_experiences(symbol) if self.use_memory else []
            
            # 6. Knowledge Base Insights
            kb_insights = []
            if self.use_knowledge_base:
                # Query for relevant technical patterns
                pattern_type = math_results.get('pattern_analysis', {}).get('pattern_type', 'unknown')
                kb_insights = self.knowledge_base.query_knowledge(f"technical analysis {pattern_type}")
            
            # 7. Final Synthesis (restructured to match test expectations)
            technical_score_results = math_results.get('technical_score', {})
            
            final_analysis = {
                "agent_name": self.name,
                "symbol": symbol,
                "timeframe": timeframe,
                "analysis_timestamp": datetime.now().isoformat(),
                
                # Fields expected by the test
                "signal": technical_score_results.get('recommendation', 'hold'),
                "confidence": technical_score_results.get('confidence', 0.5),
                "technical_indicators": math_results.get('technical_indicators', {}),
                "strategy": "Based on technical score", # Adding a default strategy

                # Detailed results
                "mathematical_analysis": math_results,
                "crewai_reasoning": crewai_reasoning,
                "pattern_insights": pattern_analysis,
                "market_context": market_context,
                "relevant_experiences": relevant_experiences,
                "knowledge_base_insights": kb_insights,
                "agent_weight": self.weight
            }
            
            # 8. Learn from this analysis
            self.add_experience({
                "symbol": symbol,
                "analysis_type": "technical_analysis",
                "key_metrics": {
                    "rsi": math_results.get('technical_indicators', {}).get('rsi', 0),
                    "trend_direction": math_results.get('trend_analysis', {}).get('trend_direction', 'unknown'),
                    "overall_score": technical_score_results.get('overall_score', 0),
                    "recommendation": technical_score_results.get('recommendation', 'hold')
                },
                "market_conditions": market_context
            })
            
            self.logger.info(f"Successfully completed technical analysis for {symbol}")
            return final_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI comprehensive analysis for {symbol}: {e}", exc_info=True)
            return {
                "error": str(e),
                "signal": "FATAL_ERROR",
                "confidence": 0.0,
                "technical_indicators": {}
            }
    
    async def _get_market_context(self, symbol: str, timeframe: str) -> str:
        """Get current market context for LLM reasoning"""
        try:
            return f"""
            Technical market analysis context for {symbol} ({timeframe}):
            - Market volatility: Current VIX levels and market sentiment
            - Sector rotation: Which sectors are leading/lagging
            - Market breadth: Advance/decline ratios and participation
            - Interest rate environment: Impact on technical levels
            - Volume patterns: Institutional vs retail participation
            - Seasonal patterns: Historical seasonal trends for this timeframe
            - Options activity: Put/call ratios and implied volatility
            - Correlation analysis: How stock moves relative to market indices
            """
        except Exception as e:
            self.logger.error(f"Error getting market context: {e}")
            return "Market context not available"

    async def _get_crewai_technical_reasoning(self, math_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Get CrewAI-based technical reasoning for market analysis"""
        try:
            reasoning_prompt = f"""
            You are an expert technical analyst with deep knowledge of chart patterns, indicators, and market psychology.
            
            Technical Analysis Results:
            {math_results}
            
            Market Context:
            {market_context}
            
            Based on this quantitative technical analysis, provide:
            1. Technical Assessment - Overall technical picture and market structure
            2. Pattern Interpretation - Analysis of chart patterns and their significance
            3. Indicator Analysis - How technical indicators confirm or contradict each other
            4. Support/Resistance Analysis - Key levels and their importance
            5. Trend Analysis - Current trend strength and potential continuation/reversal
            6. Risk Assessment - Technical risk factors and potential scenarios
            
            Consider:
            - Moving average relationships and crossovers
            - RSI, MACD, and other oscillator signals
            - Volume confirmation and divergence
            - Chart patterns and their success rates
            - Support and resistance levels
            - Market structure and price action
            - Risk/reward ratios for potential trades
            
            Provide comprehensive technical analysis that combines quantitative data with market psychology.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive technical reasoning and market analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            reasoning = self._parse_crewai_technical_reasoning(str(result))
            
            return reasoning
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI technical reasoning: {str(e)}")
            return {"error": str(e)}

    async def _get_crewai_pattern_analysis(self, data: Dict[str, Any], context: str, symbol: str) -> Dict[str, Any]:
        """Get CrewAI-based pattern analysis for trading insights"""
        try:
            pattern_prompt = f"""
            You are an expert chart pattern analyst specializing in technical analysis and trading psychology.
            
            Technical Analysis Data:
            {data}
            
            Market Context:
            {context}
            
            Symbol: {symbol}
            
            Based on this comprehensive technical analysis, provide:
            1. Pattern Recognition - Identify and analyze chart patterns
            2. Trading Signals - Specific buy/sell signals with entry/exit points
            3. Risk Management - Stop-loss levels and position sizing recommendations
            4. Market Psychology - What patterns tell us about market sentiment
            5. Timing Analysis - When to enter and exit positions
            6. Confirmation Signals - Additional indicators to confirm patterns
            
            Consider:
            - Chart pattern reliability and success rates
            - Volume confirmation and divergence
            - Multiple timeframe analysis
            - Market structure and trend context
            - Risk/reward ratios and probability
            - Market psychology and crowd behavior
            - Technical vs fundamental confirmation
            
            Provide actionable trading insights based on technical pattern analysis.
            """
            
            # Use CrewAI agent for pattern analysis
            task = Task(
                description=pattern_prompt,
                agent=self.crewai_agent,
                expected_output="Detailed pattern analysis and trading recommendations"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            # Parse the response into structured format
            analysis = self._parse_crewai_pattern_analysis(str(result))
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI pattern analysis: {str(e)}")
            return {"error": str(e)}

    def _parse_crewai_technical_reasoning(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI technical reasoning response into structured format"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Split response into sections
            sections = response.split('\n\n')
            parsed_reasoning = {
                "technical_assessment": "",
                "pattern_interpretation": "",
                "indicator_analysis": "",
                "support_resistance_analysis": "",
                "trend_analysis": "",
                "risk_assessment": ""
            }
            
            current_section = None
            for section in sections:
                if "Technical Assessment" in section:
                    current_section = "technical_assessment"
                elif "Pattern Interpretation" in section:
                    current_section = "pattern_interpretation"
                elif "Indicator Analysis" in section:
                    current_section = "indicator_analysis"
                elif "Support/Resistance Analysis" in section:
                    current_section = "support_resistance_analysis"
                elif "Trend Analysis" in section:
                    current_section = "trend_analysis"
                elif "Risk Assessment" in section:
                    current_section = "risk_assessment"
                elif current_section and section.strip():
                    parsed_reasoning[current_section] = section.strip()
            
            return parsed_reasoning
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI technical reasoning response: {str(e)}")
            return {"raw_response": response}

    def _parse_crewai_pattern_analysis(self, response: str) -> Dict[str, Any]:
        """Parse CrewAI pattern analysis response into structured format"""
        try:
            # Ensure response is a string
            if isinstance(response, dict):
                response = response.get('content') or str(response)
            if not isinstance(response, str):
                response = str(response)
            
            # Split response into sections
            sections = response.split('\n\n')
            parsed_analysis = {
                "pattern_recognition": "",
                "trading_signals": "",
                "risk_management": "",
                "market_psychology": "",
                "timing_analysis": "",
                "confirmation_signals": ""
            }
            
            current_section = None
            for section in sections:
                if "Pattern Recognition" in section:
                    current_section = "pattern_recognition"
                elif "Trading Signals" in section:
                    current_section = "trading_signals"
                elif "Risk Management" in section:
                    current_section = "risk_management"
                elif "Market Psychology" in section:
                    current_section = "market_psychology"
                elif "Timing Analysis" in section:
                    current_section = "timing_analysis"
                elif "Confirmation Signals" in section:
                    current_section = "confirmation_signals"
                elif current_section and section.strip():
                    parsed_analysis[current_section] = section.strip()
            
            return parsed_analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing CrewAI pattern analysis response: {str(e)}")
            return {"raw_response": response}


    async def analyze_technical(self, symbol: str) -> dict:
        """Stub for compatibility with coordinator. Calls analyze method."""
        try:
            return await self.analyze(symbol)
        except Exception as e:
            self.logger.error(f"Error in analyze_technical: {e}")
            return {"error": str(e)}


