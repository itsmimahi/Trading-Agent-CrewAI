from __future__ import annotations

import os
from typing import Any, Dict, Optional, Callable

from ..adapters import create_adapter  # type: ignore
from ..routes.market import _LAST_PRICE
from ..storage.paper_state import load_state
from .engine import PortfolioEngine, FeeModel

try:
    from ...integration.event_bus import make_default_event_bus  # type: ignore
except Exception:
    def make_default_event_bus():
        return None


class PortfolioService:
    def __init__(self) -> None:
        # Fee/slippage from env with safe defaults
        def _f(name: str, default: float) -> float:
            try:
                v = os.getenv(name)
                return float(v) if v is not None else default
            except Exception:
                return default
        fm = FeeModel(
            brokerage_min=_f('PTA_BROKERAGE_MIN', 5.0),
            brokerage_bps=_f('PTA_BROKERAGE_BPS', 0.0005),
            slippage_bps=_f('PTA_SLIPPAGE_BPS', 0.0002),
        )
        self.engine = PortfolioEngine(fee_model=fm)

        # Optional market adapter for LTP
        broker = os.getenv('BROKER', 'SHOONYA').upper()
        try:
            self.adapter = create_adapter(broker)
        except Exception:
            self.adapter = None

        # Optional event bus
        self.bus = make_default_event_bus()

    def _get_last_price(self, symbol: str) -> float:
        sym = symbol.upper()
        # Prefer cached
        lp = _LAST_PRICE.get(sym)
        if lp is not None:
            return float(lp)
        # Try adapter
        try:
            if self.adapter is not None:
                polled = self.adapter.poll_price(sym)
                if polled is not None:
                    _LAST_PRICE[sym] = float(polled)
                    return float(polled)
        except Exception:
            pass
        # Fallback
        return 100.0

    # -------- API surface used by routes/agents --------
    def preview(self, symbol: str, side: str, quantity: int) -> Dict[str, Any]:
        price = self._get_last_price(symbol)
        return self.engine.preview(symbol, side, quantity, price)

    def place_order(self, *, symbol: str, side: str, quantity: int, idem_key: Optional[str] = None) -> Dict[str, Any]:
        price = self._get_last_price(symbol)
        order = self.engine.place_order(symbol=symbol, side=side, quantity=quantity, last_price=price, idem_key=idem_key)
        # Emit events
        if self.bus is not None:
            try:
                self.bus.publish('portfolio.updates', {'type': 'order_filled', 'order': order})
                cash, positions = self.engine.holdings()
                pos = positions.get(symbol.upper())
                self.bus.publish('portfolio.updates', {
                    'type': 'position_update',
                    'symbol': symbol.upper(),
                    'position': pos,
                    'cash': cash,
                })
                # Also emit valuation update with metrics
                metrics = self.metrics()
                self.bus.publish('portfolio.updates', {
                    'type': 'valuation_update',
                    'metrics': metrics,
                })
            except Exception:
                pass
        return order

    def holdings(self) -> Dict[str, Any]:
        cash, positions = self.engine.holdings()
        holdings_list = [
            {'symbol': sym, 'quantity': int(pos.get('qty', 0)), 'avg_price': float(pos.get('avg_price', 0.0))}
            for sym, pos in positions.items()
        ]
        return {'cash': cash, 'holdings': holdings_list}

    def margins(self) -> Dict[str, float]:
        return self.engine.margins()

    def metrics(self) -> Dict[str, Any]:
        return self.engine.metrics(lambda s: _LAST_PRICE.get(s.upper()))
