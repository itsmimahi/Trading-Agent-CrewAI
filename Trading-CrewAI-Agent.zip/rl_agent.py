"""
Reinforcement Learning Agent for Trading
Implements DQN, PPO, and A2C algorithms using Stable Baselines3 and PyTorch.
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
from stable_baselines3 import DQN, PPO, A2C
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import configure
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.evaluation import evaluate_policy
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
import os
import pickle
import json
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns

from .trading_environment import TradingEnvironment


class TradingCallback(BaseCallback):
    """
    Custom callback for monitoring training progress and logging metrics.
    """
    
    def __init__(self, eval_env, eval_freq: int = 1000, verbose: int = 1,
                 progress_cb: Optional[Callable[[int, Dict[str, Any]], None]] = None,
                 progress_report_freq: int = 1000):
        super().__init__(verbose)
        self.eval_env = eval_env
        self.eval_freq = eval_freq
        self.best_mean_reward = -np.inf
        self.episode_rewards = []
        self.episode_lengths = []
        self.portfolio_values = []
        self.progress_cb = progress_cb
        self.progress_report_freq = max(1, int(progress_report_freq))
        self._last_reported_step = 0
        
    def _on_step(self) -> bool:
        # Log episode rewards and lengths
        if len(self.locals.get('infos', [])) > 0:
            for info in self.locals['infos']:
                if 'episode' in info:
                    self.episode_rewards.append(info['episode']['r'])
                    self.episode_lengths.append(info['episode']['l'])
        # Progress callback at a throttled frequency
        if self.progress_cb is not None:
            try:
                if (self.num_timesteps - self._last_reported_step) >= self.progress_report_freq:
                    payload = {
                        'n_calls': int(self.n_calls),
                        'timesteps': int(self.num_timesteps),
                        'episode_rewards_count': int(len(self.episode_rewards)),
                        'episode_lengths_count': int(len(self.episode_lengths))
                    }
                    self.progress_cb(int(self.num_timesteps), payload)
                    self._last_reported_step = int(self.num_timesteps)
            except Exception:
                # Never let progress reporting break training
                pass
        
        # Evaluate model periodically
        if self.n_calls % self.eval_freq == 0:
            mean_reward, std_reward = evaluate_policy(
                self.model, self.eval_env, n_eval_episodes=5, deterministic=True
            )
            
            if self.verbose > 0:
                print(f"Eval num_timesteps={self.num_timesteps}, "
                      f"episode_reward={mean_reward:.2f} +/- {std_reward:.2f}")
            
            # Save best model
            if mean_reward > self.best_mean_reward:
                self.best_mean_reward = mean_reward
                if self.verbose > 0:
                    print(f"New best mean reward: {mean_reward:.2f}")
                self.model.save(os.path.join(self.model.logger.dir, "best_model"))
        
        return True


class CustomTradingNetwork(nn.Module):
    """
    Custom neural network architecture for trading.
    Combines CNN for time-series features and dense layers for portfolio features.
    """
    
    def __init__(self, observation_space_shape: Tuple[int], action_space_size: int, 
                 lookback_window: int = 20, features_per_timestep: int = 25):
        super().__init__()
        
        self.lookback_window = lookback_window
        self.features_per_timestep = features_per_timestep
        self.portfolio_features = 6
        
        # CNN for time-series features
        self.conv1 = nn.Conv1d(features_per_timestep, 64, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(64, 128, kernel_size=3, padding=1)
        self.conv3 = nn.Conv1d(128, 64, kernel_size=3, padding=1)
        
        # Calculate CNN output size
        cnn_output_size = 64 * lookback_window
        
        # Dense layers for portfolio features
        self.portfolio_fc = nn.Linear(self.portfolio_features, 32)
        
        # Combined layers
        combined_size = cnn_output_size + 32
        self.fc1 = nn.Linear(combined_size, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, 128)
        self.output = nn.Linear(128, action_space_size)
        
        # Activation functions
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)
        
    def forward(self, x):
        batch_size = x.shape[0]
        
        # Split time-series and portfolio features
        time_series_features = x[:, :self.lookback_window * self.features_per_timestep]
        portfolio_features = x[:, -self.portfolio_features:]
        
        # Reshape time-series features for CNN
        time_series = time_series_features.view(batch_size, self.features_per_timestep, self.lookback_window)
        
        # CNN processing
        conv_out = self.relu(self.conv1(time_series))
        conv_out = self.relu(self.conv2(conv_out))
        conv_out = self.relu(self.conv3(conv_out))
        conv_out = conv_out.view(batch_size, -1)  # Flatten
        
        # Portfolio features processing
        portfolio_out = self.relu(self.portfolio_fc(portfolio_features))
        
        # Combine features
        combined = torch.cat([conv_out, portfolio_out], dim=1)
        
        # Final layers
        x = self.relu(self.fc1(combined))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.relu(self.fc3(x))
        x = self.output(x)
        
        return x


class RLTradingAgent:
    """
    Main RL Trading Agent class that handles training, evaluation, and inference.
    """
    
    def __init__(self, 
                 algorithm: str = "PPO",
                 symbol: str = "AAPL",
                 initial_balance: float = 100000.0,
                 start_date: str = "2020-01-01",
                 end_date: str = "2023-12-31",
                 lookback_window: int = 20,
                 model_dir: str = "models",
                 log_dir: str = "logs"):
        """
        Initialize the RL Trading Agent.
        
        Args:
            algorithm: RL algorithm to use ("DQN", "PPO", "A2C")
            symbol: Stock symbol to trade
            initial_balance: Starting balance
            start_date: Training data start date
            end_date: Training data end date
            lookback_window: Number of days to look back for state
            model_dir: Directory to save models
            log_dir: Directory to save logs
        """
        self.algorithm = algorithm
        self.symbol = symbol
        self.initial_balance = initial_balance
        self.start_date = start_date
        self.end_date = end_date
        self.lookback_window = lookback_window
        self.model_dir = model_dir
        self.log_dir = log_dir
        
        # Create directories
        os.makedirs(model_dir, exist_ok=True)
        os.makedirs(log_dir, exist_ok=True)
        
        # Initialize environment
        self.env = None
        self.model = None
        self.training_history = {
            'episode_rewards': [],
            'episode_lengths': [],
            'portfolio_values': [],
            'training_losses': []
        }
        
    def create_environment(self, train_split: float = 0.8) -> Tuple[TradingEnvironment, TradingEnvironment]:
        """Create training and evaluation environments."""
        # Calculate split date
        start_dt = pd.to_datetime(self.start_date)
        end_dt = pd.to_datetime(self.end_date)
        total_days = (end_dt - start_dt).days
        split_days = int(total_days * train_split)
        split_date = start_dt + pd.Timedelta(days=split_days)
        
        # Create training environment
        train_env = TradingEnvironment(
            symbol=self.symbol,
            initial_balance=self.initial_balance,
            start_date=self.start_date,
            end_date=split_date.strftime('%Y-%m-%d'),
            lookback_window=self.lookback_window
        )
        
        # Create evaluation environment
        eval_env = TradingEnvironment(
            symbol=self.symbol,
            initial_balance=self.initial_balance,
            start_date=split_date.strftime('%Y-%m-%d'),
            end_date=self.end_date,
            lookback_window=self.lookback_window
        )
        
        return train_env, eval_env
    
    def create_model(self, env: TradingEnvironment, algo_params: Optional[Dict[str, Any]] = None, **kwargs) -> Union[DQN, PPO, A2C]:
        """Create the RL model based on the specified algorithm.
        algo_params: optional dict of algorithm-specific overrides (e.g., n_steps for PPO).
        """
        # Set up logging
        logger = configure(self.log_dir, ["stdout", "csv", "tensorboard"])
        
        # Common parameters
        common_params = {
            'env': env,
            'verbose': 1,
            'tensorboard_log': self.log_dir,
            **kwargs
        }

        # Device toggle: choose CPU by default; use CUDA if explicitly enabled and available
        # Control via env RL_DEVICE=cpu|cuda and RL_USE_CUDA=1
        device_env = os.environ.get('RL_DEVICE', '').strip().lower()
        use_cuda_flag = os.environ.get('RL_USE_CUDA', '0') == '1'
        if device_env in ('cuda', 'gpu') or use_cuda_flag:
            if torch.cuda.is_available():
                common_params['device'] = 'cuda'
            else:
                common_params['device'] = 'cpu'
        elif device_env:
            # Respect explicit cpu setting
            common_params['device'] = 'cpu'
        
        algo_params = dict(algo_params or {})
        if self.algorithm == "DQN":
            dqn_defaults = dict(
                learning_rate=1e-4,
                buffer_size=50000,
                learning_starts=1000,
                batch_size=32,
                tau=1.0,
                gamma=0.99,
                train_freq=4,
                gradient_steps=1,
                target_update_interval=1000,
                exploration_fraction=0.1,
                exploration_initial_eps=1.0,
                exploration_final_eps=0.05,
            )
            dqn_defaults.update(algo_params)
            model = DQN(
                policy="MlpPolicy",
                **common_params,
                **dqn_defaults,
            )
        elif self.algorithm == "PPO":
            ppo_defaults = dict(
                learning_rate=3e-4,
                n_steps=2048,
                batch_size=64,
                n_epochs=10,
                gamma=0.99,
                gae_lambda=0.95,
                clip_range=0.2,
                clip_range_vf=None,
                normalize_advantage=True,
                ent_coef=0.0,
                vf_coef=0.5,
                max_grad_norm=0.5,
            )
            ppo_defaults.update(algo_params)
            model = PPO(
                policy="MlpPolicy",
                **common_params,
                **ppo_defaults,
            )
        elif self.algorithm == "A2C":
            a2c_defaults = dict(
                learning_rate=7e-4,
                n_steps=5,
                gamma=0.99,
                gae_lambda=1.0,
                ent_coef=0.01,
                vf_coef=0.25,
                max_grad_norm=0.5,
            )
            a2c_defaults.update(algo_params)
            model = A2C(
                policy="MlpPolicy",
                **common_params,
                **a2c_defaults,
            )
        else:
            raise ValueError(f"Unsupported algorithm: {self.algorithm}")
        
        model.set_logger(logger)
        return model
    
    def train(self, total_timesteps: int = 100000, eval_freq: int = 5000,
              progress_cb: Optional[Callable[[int, Dict[str, Any]], None]] = None,
              progress_report_freq: int = 1000,
              algo_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Train the RL agent."""
        print(f"Training {self.algorithm} agent on {self.symbol}...")

        # Create environments
        train_env, eval_env = self.create_environment()
        self.env = train_env

        # Wrap environments for stable-baselines3
        train_env_vec = DummyVecEnv([lambda: train_env])
        eval_env_vec = DummyVecEnv([lambda: eval_env])

        # Create model
        self.model = self.create_model(train_env_vec, algo_params=algo_params)
        
        # Create callback
        callback = TradingCallback(
            eval_env_vec,
            eval_freq=eval_freq,
            progress_cb=progress_cb,
            progress_report_freq=progress_report_freq
        )

        # Train the model
        start_time = datetime.now()
        self.model.learn(
            total_timesteps=total_timesteps,
            callback=callback,
            progress_bar=True
        )
        training_time = datetime.now() - start_time

        # Save the final model
        model_path = os.path.join(self.model_dir, f"{self.algorithm}_{self.symbol}_final.zip")
        self.model.save(model_path)

        # Update training history
        self.training_history.update({
            'episode_rewards': callback.episode_rewards,
            'episode_lengths': callback.episode_lengths,
            'training_time': training_time.total_seconds(),
            'total_timesteps': total_timesteps
        })

        # Evaluate final model
        final_stats = self.evaluate(eval_env)

        print(f"Training completed in {training_time}")
        print(f"Final evaluation stats: {final_stats}")

        return {
            'training_history': self.training_history,
            'final_stats': final_stats,
            'model_path': model_path
        }
    
    def evaluate(self, env: Optional[TradingEnvironment] = None, n_episodes: int = 5) -> Dict[str, float]:
        """Evaluate the trained model."""
        if self.model is None:
            raise ValueError("Model not trained or loaded")
        
        if env is None:
            _, env = self.create_environment()
        
        # Run evaluation episodes
        episode_rewards = []
        episode_stats = []
        
        for episode in range(n_episodes):
            obs, _ = env.reset()
            episode_reward = 0
            done = False
            
            while not done:
                action, _ = self.model.predict(obs, deterministic=True)
                obs, reward, done, _, info = env.step(action)
                episode_reward += reward
            
            episode_rewards.append(episode_reward)
            episode_stats.append(env.get_portfolio_stats())
        
        # Calculate average statistics
        avg_stats = {}
        if episode_stats:
            for key in episode_stats[0].keys():
                avg_stats[f'avg_{key}'] = np.mean([stats[key] for stats in episode_stats])
                avg_stats[f'std_{key}'] = np.std([stats[key] for stats in episode_stats])
        
        avg_stats['avg_episode_reward'] = np.mean(episode_rewards)
        avg_stats['std_episode_reward'] = np.std(episode_rewards)
        
        return avg_stats
    
    def backtest(self, start_date: str, end_date: str) -> Dict[str, Any]:
        """Run a backtest on the specified date range."""
        if self.model is None:
            raise ValueError("Model not trained or loaded")
        
        # Create backtest environment
        backtest_env = TradingEnvironment(
            symbol=self.symbol,
            initial_balance=self.initial_balance,
            start_date=start_date,
            end_date=end_date,
            lookback_window=self.lookback_window
        )
        
        # Run backtest
        obs, _ = backtest_env.reset()
        done = False
        actions = []
        rewards = []
        portfolio_values = []
        infos = []
        
        while not done:
            action, _ = self.model.predict(obs, deterministic=True)
            obs, reward, done, _, info = backtest_env.step(action)
            
            actions.append(action)
            rewards.append(reward)
            portfolio_values.append(info['portfolio_value'])
            infos.append(info)
        
        # Get final statistics
        final_stats = backtest_env.get_portfolio_stats()
        
        return {
            'actions': actions,
            'rewards': rewards,
            'portfolio_values': portfolio_values,
            'infos': infos,
            'stats': final_stats,
            'start_date': start_date,
            'end_date': end_date
        }
    
    def predict(self, observation: np.ndarray, deterministic: bool = True) -> Tuple[int, float]:
        """Make a prediction using the trained model."""
        if self.model is None:
            raise ValueError("Model not trained or loaded")
        
        action, _ = self.model.predict(observation, deterministic=deterministic)
        
        # Get action probabilities for confidence score
        if hasattr(self.model, 'policy'):
            with torch.no_grad():
                obs_tensor = torch.FloatTensor(observation).unsqueeze(0)
                if self.algorithm == "DQN":
                    q_values = self.model.q_net(obs_tensor)
                    confidence = torch.softmax(q_values, dim=1).max().item()
                else:
                    action_probs = self.model.policy.get_distribution(obs_tensor).distribution.probs
                    confidence = action_probs.max().item()
        else:
            confidence = 0.5  # Default confidence
        
        return int(action), float(confidence)
    
    def get_action_explanation(self, observation: np.ndarray, action: int) -> str:
        """Generate an explanation for the given action."""
        # Extract key features from observation
        portfolio_features = observation[-6:]  # Last 6 features are portfolio state
        
        cash_ratio = portfolio_features[0]
        portfolio_ratio = portfolio_features[1]
        position_ratio = portfolio_features[2]
        avg_price_ratio = portfolio_features[3]
        unrealized_pnl_ratio = portfolio_features[4]
        drawdown = portfolio_features[5]
        
        # Extract some technical indicators (simplified)
        # This is a simplified version - in practice, you'd want more sophisticated feature importance analysis
        recent_features = observation[-50:-6]  # Some recent technical features
        
        action_names = ["HOLD", "BUY", "SELL", "CLOSE_POSITION"]
        action_name = action_names[action]
        
        explanation = f"Action: {action_name}. "
        
        if action == 0:  # HOLD
            explanation += "Maintaining current position. "
        elif action == 1:  # BUY
            explanation += f"Buying signal detected. Portfolio cash ratio: {cash_ratio:.2f}, "
            if position_ratio < 0.1:
                explanation += "low current position, "
            if unrealized_pnl_ratio > 0:
                explanation += "positive unrealized P&L, "
        elif action == 2:  # SELL
            explanation += f"Selling signal detected. Current position ratio: {position_ratio:.2f}, "
            if unrealized_pnl_ratio > 0:
                explanation += "taking profits, "
            elif unrealized_pnl_ratio < -0.05:
                explanation += "cutting losses, "
        elif action == 3:  # CLOSE_POSITION
            explanation += "Closing entire position. "
            if drawdown > 0.1:
                explanation += f"High drawdown detected ({drawdown:.2%}), "
            if unrealized_pnl_ratio < -0.1:
                explanation += "significant losses, "
        
        if drawdown > 0.05:
            explanation += f"Current drawdown: {drawdown:.2%}. "
        
        return explanation
    
    def save_model(self, filepath: str) -> None:
        """Save the trained model."""
        if self.model is None:
            raise ValueError("No model to save")
        
        self.model.save(filepath)
        
        # Save additional metadata
        metadata = {
            'algorithm': self.algorithm,
            'symbol': self.symbol,
            'initial_balance': self.initial_balance,
            'start_date': self.start_date,
            'end_date': self.end_date,
            'lookback_window': self.lookback_window,
            'training_history': self.training_history
        }
        
        metadata_path = filepath.replace('.zip', '_metadata.json')
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2, default=str)
    
    def load_model(self, filepath: str) -> None:
        """Load a trained model."""
        if self.algorithm == "DQN":
            self.model = DQN.load(filepath)
        elif self.algorithm == "PPO":
            self.model = PPO.load(filepath)
        elif self.algorithm == "A2C":
            self.model = A2C.load(filepath)
        
        # Load metadata if available
        metadata_path = filepath.replace('.zip', '_metadata.json')
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                self.training_history = metadata.get('training_history', {})
    
    def plot_training_progress(self, save_path: Optional[str] = None) -> None:
        """Plot training progress and statistics."""
        if not self.training_history.get('episode_rewards'):
            print("No training history available")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Episode rewards
        axes[0, 0].plot(self.training_history['episode_rewards'])
        axes[0, 0].set_title('Episode Rewards')
        axes[0, 0].set_xlabel('Episode')
        axes[0, 0].set_ylabel('Reward')
        
        # Episode lengths
        if self.training_history.get('episode_lengths'):
            axes[0, 1].plot(self.training_history['episode_lengths'])
            axes[0, 1].set_title('Episode Lengths')
            axes[0, 1].set_xlabel('Episode')
            axes[0, 1].set_ylabel('Steps')
        
        # Moving average of rewards
        if len(self.training_history['episode_rewards']) > 10:
            window = min(50, len(self.training_history['episode_rewards']) // 10)
            moving_avg = pd.Series(self.training_history['episode_rewards']).rolling(window).mean()
            axes[1, 0].plot(moving_avg)
            axes[1, 0].set_title(f'Moving Average Rewards (window={window})')
            axes[1, 0].set_xlabel('Episode')
            axes[1, 0].set_ylabel('Average Reward')
        
        # Reward distribution
        axes[1, 1].hist(self.training_history['episode_rewards'], bins=30, alpha=0.7)
        axes[1, 1].set_title('Reward Distribution')
        axes[1, 1].set_xlabel('Reward')
        axes[1, 1].set_ylabel('Frequency')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    def plot_backtest_results(self, backtest_results: Dict[str, Any], save_path: Optional[str] = None) -> None:
        """Plot backtest results."""
        fig, axes = plt.subplots(3, 2, figsize=(15, 12))
        
        # Portfolio value over time
        axes[0, 0].plot(backtest_results['portfolio_values'])
        axes[0, 0].set_title('Portfolio Value Over Time')
        axes[0, 0].set_xlabel('Time Steps')
        axes[0, 0].set_ylabel('Portfolio Value ($)')
        axes[0, 0].grid(True)
        
        # Actions taken
        actions = backtest_results['actions']
        action_names = ['HOLD', 'BUY', 'SELL', 'CLOSE']
        action_counts = [actions.count(i) for i in range(4)]
        axes[0, 1].bar(action_names, action_counts)
        axes[0, 1].set_title('Action Distribution')
        axes[0, 1].set_ylabel('Count')
        
        # Rewards over time
        axes[1, 0].plot(backtest_results['rewards'])
        axes[1, 0].set_title('Rewards Over Time')
        axes[1, 0].set_xlabel('Time Steps')
        axes[1, 0].set_ylabel('Reward')
        axes[1, 0].grid(True)
        
        # Cumulative rewards
        cumulative_rewards = np.cumsum(backtest_results['rewards'])
        axes[1, 1].plot(cumulative_rewards)
        axes[1, 1].set_title('Cumulative Rewards')
        axes[1, 1].set_xlabel('Time Steps')
        axes[1, 1].set_ylabel('Cumulative Reward')
        axes[1, 1].grid(True)
        
        # Drawdown over time
        portfolio_values = np.array(backtest_results['portfolio_values'])
        peak = np.maximum.accumulate(portfolio_values)
        drawdown = (peak - portfolio_values) / peak
        axes[2, 0].fill_between(range(len(drawdown)), drawdown, alpha=0.3, color='red')
        axes[2, 0].set_title('Drawdown Over Time')
        axes[2, 0].set_xlabel('Time Steps')
        axes[2, 0].set_ylabel('Drawdown (%)')
        axes[2, 0].grid(True)
        
        # Performance statistics
        stats = backtest_results['stats']
        stat_names = list(stats.keys())
        stat_values = list(stats.values())
        
        # Only show numeric statistics
        numeric_stats = [(name, value) for name, value in zip(stat_names, stat_values) 
                        if isinstance(value, (int, float))]
        
        if numeric_stats:
            names, values = zip(*numeric_stats[:8])  # Show top 8 stats
            axes[2, 1].barh(names, values)
            axes[2, 1].set_title('Performance Statistics')
            axes[2, 1].set_xlabel('Value')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()

