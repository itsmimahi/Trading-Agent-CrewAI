from flask import Blueprint, Response, current_app
import json
import time

stream_bp = Blueprint('stream', __name__)


def _sse_format(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


@stream_bp.route('/ping', methods=['GET'])
def ping():
    def gen():
        yield _sse_format('ping', {'status': 'ok'})
    resp = Response(gen(), mimetype='text/event-stream')
    resp.headers['Cache-Control'] = 'no-cache'
    resp.headers['Connection'] = 'keep-alive'
    resp.headers['X-Accel-Buffering'] = 'no'
    return resp


@stream_bp.route('/prices/<symbol>', methods=['GET'])
def prices(symbol: str):
    symbol = symbol.upper()

    def gen():
        # Try to stream adapter ticks if available; otherwise mock drift
        adapter = current_app.config.get('MARKET_ADAPTER')
        price = 100.0
        for _ in range(10):
            try:
                if adapter is not None:
                    polled = adapter.poll_price(symbol)
                    if polled is not None:
                        price = float(polled)
                yield _sse_format('price', {'symbol': symbol, 'price': price})
                if adapter is None:
                    price += 0.1
            except Exception:
                yield _sse_format('price', {'symbol': symbol, 'price': price})
                price += 0.1
            time.sleep(1)
    resp = Response(gen(), mimetype='text/event-stream')
    resp.headers['Cache-Control'] = 'no-cache'
    resp.headers['Connection'] = 'keep-alive'
    resp.headers['X-Accel-Buffering'] = 'no'
    return resp
