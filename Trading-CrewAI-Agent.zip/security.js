/**
 * Security Utilities Module
 * Implements input sanitization, XSS prevention, CSRF protection
 */

class SecurityManager {
    constructor() {
        this.csrfToken = null;
        this.sessionId = null;
        this.rateLimitConfig = {
            maxRequests: 50,
            timeWindow: 60000, // 1 minute
            requests: []
        };
        
        this.initializeSecurity();
    }

    /**
     * Initialize security measures
     */
    async initializeSecurity() {
        await this.generateCSRFToken();
        this.setupContentSecurityPolicy();
        this.initializeRateLimiting();
        this.setupInputSanitization();
    }

    /**
     * Generate CSRF token
     */
    async generateCSRFToken() {
        try {
            // Try to get CSRF token from server
            const response = await fetch('/api/csrf-token', {
                credentials: 'include'
            });
            
            if (response.ok) {
                const data = await response.json();
                this.csrfToken = data.token;
            } else {
                // Fallback: generate client-side token
                this.csrfToken = this.generateRandomToken();
            }
            
            // Store in meta tag for easy access
            this.updateCSRFMetaTag();
            
        } catch (error) {
            console.warn('Failed to get CSRF token from server, using client-side generation');
            this.csrfToken = this.generateRandomToken();
            this.updateCSRFMetaTag();
        }
    }

    /**
     * Generate random token
     */
    generateRandomToken() {
        const array = new Uint8Array(32);
        crypto.getRandomValues(array);
        return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
    }

    /**
     * Update CSRF meta tag
     */
    updateCSRFMetaTag() {
        let metaTag = document.querySelector('meta[name="csrf-token"]');
        
        if (!metaTag) {
            metaTag = document.createElement('meta');
            metaTag.name = 'csrf-token';
            document.head.appendChild(metaTag);
        }
        
        metaTag.content = this.csrfToken;
    }

    /**
     * Get CSRF token
     */
    getCSRFToken() {
        return this.csrfToken;
    }

    /**
     * Setup Content Security Policy (if not set by server)
     */
    setupContentSecurityPolicy() {
        // Add CSP meta tag if not present
        if (!document.querySelector('meta[http-equiv="Content-Security-Policy"]')) {
            const cspMeta = document.createElement('meta');
            cspMeta.setAttribute('http-equiv', 'Content-Security-Policy');
            cspMeta.content = [
                "default-src 'self'",
                "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net",
                "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com",
                "font-src 'self' https://fonts.gstatic.com",
                "img-src 'self' data: https:",
                "connect-src 'self' http://localhost:* ws://localhost:*",
                "object-src 'none'",
                "base-uri 'self'"
            ].join('; ');
            
            document.head.appendChild(cspMeta);
        }
    }

    /**
     * Initialize rate limiting
     */
    initializeRateLimiting() {
        // Clean up old requests periodically
        setInterval(() => {
            const now = Date.now();
            this.rateLimitConfig.requests = this.rateLimitConfig.requests.filter(
                timestamp => now - timestamp < this.rateLimitConfig.timeWindow
            );
        }, 10000); // Clean every 10 seconds
    }

    /**
     * Check rate limit
     */
    checkRateLimit() {
        const now = Date.now();
        this.rateLimitConfig.requests.push(now);
        
        // Count requests in current window
        const recentRequests = this.rateLimitConfig.requests.filter(
            timestamp => now - timestamp < this.rateLimitConfig.timeWindow
        );
        
        if (recentRequests.length > this.rateLimitConfig.maxRequests) {
            throw new Error('Rate limit exceeded. Please slow down your requests.');
        }
        
        return true;
    }

    /**
     * Sanitize HTML input to prevent XSS
     */
    sanitizeHTML(input) {
        if (typeof input !== 'string') {
            return input;
        }

        // Create temporary element
        const temp = document.createElement('div');
        temp.textContent = input;
        let sanitized = temp.innerHTML;

        // Remove dangerous protocols
        const dangerousProtocols = [
            'javascript:',
            'data:',
            'vbscript:',
            'onload=',
            'onerror=',
            'onclick=',
            'onmouseover=',
            'onfocus=',
            'onblur='
        ];

        dangerousProtocols.forEach(protocol => {
            const regex = new RegExp(protocol, 'gi');
            sanitized = sanitized.replace(regex, '');
        });

        // Remove script tags and event handlers
        sanitized = sanitized.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        sanitized = sanitized.replace(/on\w+\s*=\s*["'][^"']*["']/gi, '');
        sanitized = sanitized.replace(/on\w+\s*=\s*[^\s>]*/gi, '');

        return sanitized;
    }

    /**
     * Validate and sanitize form data
     */
    sanitizeFormData(formData) {
        const sanitized = {};
        
        for (const [key, value] of Object.entries(formData)) {
            if (typeof value === 'string') {
                sanitized[key] = this.sanitizeHTML(value.trim());
            } else {
                sanitized[key] = value;
            }
        }
        
        return sanitized;
    }

    /**
     * Setup input sanitization for all forms
     */
    setupInputSanitization() {
        // Monitor form submissions
        document.addEventListener('submit', (event) => {
            const form = event.target;
            if (form.tagName === 'FORM') {
                this.sanitizeFormInputs(form);
            }
        });

        // Monitor input changes for real-time validation
        document.addEventListener('input', (event) => {
            const input = event.target;
            if (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA') {
                this.validateInput(input);
            }
        });
    }

    /**
     * Sanitize form inputs
     */
    sanitizeFormInputs(form) {
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            if (input.type !== 'file' && input.value) {
                input.value = this.sanitizeHTML(input.value);
            }
        });
    }

    /**
     * Validate individual input
     */
    validateInput(input) {
        const value = input.value;
        const maxLength = input.getAttribute('maxlength') || 1000;
        
        // Check length
        if (value.length > maxLength) {
            input.setCustomValidity(`Input too long. Maximum ${maxLength} characters allowed.`);
            return false;
        }

        // Check for suspicious patterns
        const suspiciousPatterns = [
            /<script/i,
            /javascript:/i,
            /vbscript:/i,
            /onload=/i,
            /onerror=/i,
            /eval\(/i,
            /expression\(/i
        ];

        for (const pattern of suspiciousPatterns) {
            if (pattern.test(value)) {
                input.setCustomValidity('Input contains potentially dangerous content.');
                return false;
            }
        }

        input.setCustomValidity('');
        return true;
    }

    /**
     * Secure API request wrapper
     */
    async secureRequest(url, options = {}) {
        try {
            // Check rate limit
            this.checkRateLimit();

            // Add CSRF token to headers
            const headers = {
                ...options.headers,
                'X-CSRF-Token': this.csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            };

            // Sanitize request body if present
            let body = options.body;
            if (body && typeof body === 'object') {
                body = JSON.stringify(this.sanitizeFormData(body));
                headers['Content-Type'] = 'application/json';
            }

            const secureOptions = {
                ...options,
                headers,
                body,
                credentials: 'include' // Include cookies
            };

            return await fetch(url, secureOptions);

        } catch (error) {
            console.error('Secure request failed:', error);
            throw error;
        }
    }

    /**
     * Validate session
     */
    async validateSession() {
        try {
            const response = await fetch('/api/session/validate', {
                credentials: 'include'
            });
            
            return response.ok;
        } catch (error) {
            console.warn('Session validation failed:', error);
            return false;
        }
    }

    /**
     * Logout and clear session
     */
    async logout() {
        try {
            await fetch('/api/session/logout', {
                method: 'POST',
                credentials: 'include'
            });
            
            // Clear client-side data
            this.csrfToken = null;
            this.sessionId = null;
            
            // Redirect to login or home
            window.location.href = '/';
            
        } catch (error) {
            console.error('Logout failed:', error);
        }
    }

    /**
     * Get security headers for requests
     */
    getSecurityHeaders() {
        return {
            'X-CSRF-Token': this.csrfToken,
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        };
    }

    /**
     * Check if current origin is trusted
     */
    isTrustedOrigin(url) {
        try {
            const urlObj = new URL(url);
            const trustedHosts = [
                'localhost',
                '127.0.0.1',
                window.location.hostname
            ];
            
            return trustedHosts.includes(urlObj.hostname);
        } catch (error) {
            return false;
        }
    }

    /**
     * Encode output to prevent XSS
     */
    encodeOutput(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize security manager
const securityManager = new SecurityManager();

// Export for global use
window.SecurityManager = SecurityManager;
window.securityManager = securityManager;
