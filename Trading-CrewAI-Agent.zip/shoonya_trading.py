from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from .trading_base import TradingAdapter
from .shoonya import ShoonyaAdapter, ShoonyaApi  # reuse symbol mapping and API wiring


class ShoonyaTradingAdapter(TradingAdapter):
    name = "SHOONYA_TRADING"

    def __init__(self) -> None:
        # Reuse ShoonyaAdapter initialization for auth and mapping
        self._md = ShoonyaAdapter()
        self._api = self._md._api  # type: ignore[attr-defined]
        self._default_product = os.getenv("SHOONYA_PRODUCT", "CNC")
        self._default_order_type = os.getenv("SHOONYA_ORDER_TYPE", "MARKET")

    def _to_side(self, side: str) -> str:
        s = (side or "").lower()
        if s == "buy":
            return "B"
        if s == "sell":
            return "S"
        raise ValueError("side must be buy|sell")

    def place_order(
        self,
        *,
        symbol: str,
        side: str,
        quantity: int,
        order_type: str = "MARKET",
        product: str = "CNC",
        price: Optional[float] = None,
        tag: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not self._api:
            raise RuntimeError("Shoonya API not initialized; check credentials and connectivity")
        if quantity <= 0:
            raise ValueError("quantity must be > 0")
        shoony_code = self._md._map_symbol(symbol)  # e.g., NSE|RELIANCE-EQ
        exch, token = shoony_code.split("|")
        side_code = self._to_side(side)
        ot = (order_type or self._default_order_type).upper()
        prod = (product or self._default_product).upper()
        # Build params according to Noren API place order signature
        params: Dict[str, Any] = {
            "exch": exch,
            "tsym": token,
            "qty": quantity,
            "trantype": side_code,
            "prctyp": ot,  # MARKET/LIMIT
            "prd": prod,    # CNC/MIS/NRML
        }
        if ot == "LIMIT":
            if price is None:
                raise ValueError("price required for LIMIT order")
            params["prc"] = float(price)
        if tag:
            params["ret"] = tag
        # Call API: method names may differ; handle common variants
        if hasattr(self._api, "place_order"):
            res = self._api.place_order(**params)  # type: ignore[attr-defined]
        elif hasattr(self._api, "placeOrder"):
            res = self._api.placeOrder(**params)  # type: ignore[attr-defined]
        else:
            raise RuntimeError("Shoonya API missing place_order method")
        if not isinstance(res, dict):
            raise RuntimeError("Unexpected response from Shoonya place_order")
        if res.get("stat") != "Ok":
            # Normalize error
            raise RuntimeError(str(res))
        order_id = res.get("norenordno") or res.get("order_id") or ""
        return {"status": "accepted", "order_id": order_id, "raw": res}

    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        if not self._api:
            raise RuntimeError("Shoonya API not initialized")
        if hasattr(self._api, "cancel_order"):
            res = self._api.cancel_order(norenordno=order_id)  # type: ignore[attr-defined]
        else:
            raise RuntimeError("Shoonya API missing cancel_order")
        return {"raw": res}

    def list_orders(self) -> List[Dict[str, Any]]:
        if not self._api:
            return []
        if hasattr(self._api, "get_order_book"):
            res = self._api.get_order_book()  # type: ignore[attr-defined]
            return res if isinstance(res, list) else []
        return []

    def get_positions(self) -> List[Dict[str, Any]]:
        if not self._api:
            return []
        if hasattr(self._api, "get_positions"):
            res = self._api.get_positions()  # type: ignore[attr-defined]
            return res if isinstance(res, list) else []
        return []

    def get_balance(self) -> Dict[str, Any]:
        if not self._api:
            return {}
        if hasattr(self._api, "get_balance"):
            res = self._api.get_balance()  # type: ignore[attr-defined]
            return res if isinstance(res, dict) else {}
        return {}

    def info(self) -> Dict[str, Any]:
        base = self._md.info()
        base.update({"name": self.name})
        return base
