# Analysis & Synthesis

> **Source**: `main_advisory_agent/analysis_crew_builder.py`  
> **Phase**: 3

---

## Overview

After all market Crews have completed, `synthesis_step` in `AdvisoryFlow` passes their
results to `AnalysisCrewBuilder`. That builder assembles a second Crew whose sole purpose
is to synthesise the per-market outputs into a single coherent advisory.

Optionally, the synthesis is then validated by the **RL Agent v2** to produce a
risk-adjusted final recommendation.

```mermaid
sequenceDiagram
    participant AF as AdvisoryFlow
    participant ACB as AnalysisCrewBuilder
    participant RL as RLAgentV2

    AF->>ACB: build(market_results, portfolio_snapshot)
    ACB-->>AF: Crew (analyst agents + tasks)
    AF->>AF: crew.kickoff() → synthesis_text

    alt ENABLE_RL_VALIDATION_V2=1
        AF->>RL: rl_a2a_validate_v2(synthesis_text, market_results, current_weights)
        RL-->>AF: annotated synthesis + ValidationResult
    else ENABLE_RL_VALIDATION=1
        AF->>RL: rl_a2a_validate(synthesis_text, market_results)
        RL-->>AF: annotated synthesis
    end

    AF->>AF: state.synthesis_result = annotated_synthesis
```

---

## `AnalysisCrewBuilder`

### Constructor

```python
AnalysisCrewBuilder(
    llm: LLM,
    verbose: bool = False,
)
```

### `build(...)` → `Crew`

```python
crew = builder.build(
    market_results: Dict[str, Any],       # per-market Crew outputs from Phase 1
    portfolio_snapshot: Dict[str, Any],   # live IBKR holdings
    synthesis_text: Optional[str] = None, # pre-built synthesis (for re-validation)
)
```

Agents in the Crew:

| Role | Responsibility |
|------|----------------|
| `MacroAnalyst` | Identify macro regime, interest rate / currency environment |
| `DividendAnalyst` | Yield screening, dividend sustainability analysis |
| `SynthesisAgent` | Combine macro + dividend + per-market results into advisory text |

Tasks run sequentially: macro → dividend → synthesis.

---

## RL Validation

### v1 — HTTP A2A (`ENABLE_RL_VALIDATION=1`)

```python
# analysis_crew_builder.py
def rl_a2a_validate(
    synthesis_text: str,
    market_results: Dict[str, Any],
    timeout_seconds: int = 5,
) -> str
```

Makes a POST to `http://localhost:8100/rl_agent/validate` (v1 RL service).
Returns the synthesis unchanged if the call fails or times out.

Environment variable: `ENABLE_RL_VALIDATION=1`

---

### v2 — Local inference (`ENABLE_RL_VALIDATION_V2=1`)

```python
# analysis_crew_builder.py
def rl_a2a_validate_v2(
    synthesis_text: str,
    market_results: Dict[str, Any],
    current_weights: Optional[Dict[str, float]] = None,
    checkpoint_path: Optional[str] = None,
) -> str
```

Uses a module-level `RLAgentV2` singleton (`_rl_v2_agent`):

1. Load `RLAgentV2` from `RL_V2_CHECKPOINT` (or create untrained instance)
2. Call `agent.validate_strategy(synthesis_text, market_results, current_weights)`
3. Receive `ValidationResult` with per-asset `PositionRecommendation` objects
4. Annotate the synthesis string with the RL recommendation block

Environment variables: `ENABLE_RL_VALIDATION_V2=1`, `RL_V2_CHECKPOINT=<path>`  
Full details: [RL Agent v2](09_rl_agent_v2.md)

---

## `ValidationResult` annotation format

The function appends the following block to `synthesis_text`:

```
---
## RL Portfolio Recommendation (v2)

**Market Regime**: BULL (confidence: 0.82)
**Portfolio Confidence**: 0.75
**No-Trade Override**: False

### Position Recommendations

| Symbol | Current % | Recommended % | Delta | Confidence Band | No-Trade |
|--------|-----------|---------------|-------|-----------------|---------|
| ^NSEI  | 25.0      | 28.5          | +3.5  | [26.1, 30.9]    | No      |
| NVDA   | 10.0      | 12.0          | +2.0  | [10.4, 13.6]    | No      |
| GLD    | 15.0      | 15.0          | 0.0   | [13.5, 16.5]    | Yes     |

### Risk Metrics

| Metric | Value |
|--------|-------|
| Rolling Sharpe | 1.24 |
| Max Drawdown | 8.3% |
| VaR (95%) | 1.8% |
| CVaR (95%) | 2.6% |
| Turnover | 5.5% |

*Synthesis annotation: BULL regime detected; increasing equity allocation
recommended. High-vol assets flagged for no-trade.*
---
```

If `no_trade_override` is `True`, the block also adds a warning:

```
> **WARNING**: RL no-trade override active. High strategy uncertainty detected
> (entropy = 0.38 > threshold 0.30). Existing positions maintained.
```

---

## Combined tools injected into AnalysisCrew

The `AnalysisCrewBuilder` does not use market data tools — it only receives
already-processed text from `market_results`. It does, however, have access to:

- **Memory recall tools** (Phase 5): `recall_market_history` context is embedded in each
  agent's backstory / task description
- **LLM** (via CrewAI): the same `gpt-4.1` Azure deployment used everywhere

---

## Error handling

If `crew.kickoff()` raises an exception:
- `synthesis_step` catches the exception
- `state.synthesis_result` is set to a fallback string: `"[Analysis failed: {error}]"`
- The `approval_gate` still proceeds; the user receives a degraded (but non-crashing) response
- `state.error` is set for observability in logs

If RL validation raises:
- The raw synthesis text (without annotation) is returned
- A warning is logged: `WARN synthesis_step:rl_validate failed`
