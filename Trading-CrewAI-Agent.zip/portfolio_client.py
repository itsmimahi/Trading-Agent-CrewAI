"""
Portfolio Service Integration Helper for Agents
Provides direct in-process access to portfolio service for agents running in the same process.
"""
from typing import Dict, Any, Optional
import os


_portfolio_service_instance: Optional[Any] = None


def get_portfolio_service():
    """Get the global portfolio service instance (lazy loaded)."""
    global _portfolio_service_instance
    if _portfolio_service_instance is None:
        try:
            from paper_trading_agent.portfolio.service import PortfolioService
            _portfolio_service_instance = PortfolioService()
        except Exception as e:
            print(f"Warning: Could not initialize PortfolioService: {e}")
            _portfolio_service_instance = None
    return _portfolio_service_instance


class DirectPortfolioClient:
    """Direct in-process client for portfolio operations (faster than HTTP)."""
    
    def __init__(self):
        self.service = get_portfolio_service()
        self.use_http_fallback = os.getenv('PTA_FORCE_HTTP', '0') == '1'
    
    def holdings(self) -> Dict[str, Any]:
        if self.service and not self.use_http_fallback:
            try:
                return self.service.holdings()
            except Exception:
                pass
        # HTTP fallback via PTAClientTool
        from pta_client import PTAClientTool
        tool = PTAClientTool()
        import json
        return json.loads(tool._run("holdings"))
    
    def margins(self) -> Dict[str, Any]:
        if self.service and not self.use_http_fallback:
            try:
                return self.service.margins()
            except Exception:
                pass
        from pta_client import PTAClientTool
        tool = PTAClientTool()
        import json
        return json.loads(tool._run("margins"))
    
    def preview_order(self, symbol: str, side: str, quantity: int) -> Dict[str, Any]:
        if self.service and not self.use_http_fallback:
            try:
                return self.service.preview(symbol, side, quantity)
            except Exception:
                pass
        from pta_client import PTAClientTool
        tool = PTAClientTool()
        import json
        return json.loads(tool._run("preview_order", symbol=symbol, side=side, quantity=quantity))
    
    def place_order(self, symbol: str, side: str, quantity: int, idem_key: Optional[str] = None) -> Dict[str, Any]:
        if self.service and not self.use_http_fallback:
            try:
                return self.service.place_order(symbol=symbol, side=side, quantity=quantity, idem_key=idem_key)
            except Exception:
                pass
        from pta_client import PTAClientTool
        tool = PTAClientTool()
        import json
        return json.loads(tool._run("submit_order", symbol=symbol, side=side, quantity=quantity, idempotency_key=idem_key))
    
    def metrics(self) -> Dict[str, Any]:
        if self.service and not self.use_http_fallback:
            try:
                return self.service.metrics()
            except Exception:
                pass
        from pta_client import PTAClientTool
        tool = PTAClientTool()
        import json
        # Note: PTAClientTool doesn't have metrics action yet, add it or use HTTP
        try:
            import requests
            base_url = os.getenv("PTA_BASE_URL", "http://localhost:8090").rstrip('/')
            r = requests.get(f"{base_url}/portfolio/metrics", timeout=10)
            return r.json() if r.ok else {"error": r.text}
        except Exception as e:
            return {"error": str(e)}
