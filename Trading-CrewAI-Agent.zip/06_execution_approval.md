# Execution & Approval

> **Sources**: `main_advisory_agent/execution_crew_builder.py`, `main_advisory_agent/advisory_approval_provider.py`  
> **Phase**: 4

---

## Overview

Phase 4 adds two complementary safeguards before any portfolio action is taken:

1. **`PortfolioActionGuard`** — validates risk limits in `portfolio_gate_step`  
2. **`AdvisoryApprovalProvider`** — manages the human-in-the-loop approval cycle  
3. **`ExecutionCrewBuilder`** — assembles the final trade-planning Crew

```mermaid
sequenceDiagram
    participant U as User
    participant PGS as portfolio_gate_step
    participant PAG as PortfolioActionGuard
    participant AAP as AdvisoryApprovalProvider
    participant AES as advisory_execution_resume_step
    participant ECB as ExecutionCrewBuilder

    U->>PGS: "BUY 50 RELIANCE.NS"
    PGS->>PAG: validate_order(symbol, side, qty, portfolio)
    PAG-->>PGS: {allowed: true, risk_fraction: 0.03}
    PGS->>AAP: create_pending(synthesis=..., parsed_order=..., conv_id=...)
    AAP-->>PGS: approval_id UUID
    PGS-->>U: "Review proposal [ID]. Reply APPROVE or REJECT."

    U->>PGS: "APPROVE abc123"
    PGS->>AAP: approve(approval_id)
    AAP-->>PGS: approved synthesis
    PGS->>ECB: build(synthesis, portfolio_snapshot)
    ECB-->>PGS: Crew → kickoff() → execution_result
    PGS-->>U: trade plan markdown
```

---

## `PortfolioActionGuard`

> **Source**: `main_advisory_agent/advisory_approval_provider.py` (nested class)

### Purpose

Stateless pre-flight validator. Checks:
- Order quantity is positive and non-zero
- Symbol is non-empty
- Order risk fraction ≤ `max_order_risk_fraction` (default: 5% of portfolio)
- Position size after fill ≤ `max_position_size` (default: 20% of portfolio)
- Market hours (if `enforce_market_hours=True`)

### Method

```python
result = guard.validate_order(
    symbol="RELIANCE.NS",
    side="BUY",
    quantity=50,
    price=2850.0,           # estimated fill price
    portfolio_value=500_000.0,
    current_positions={"RELIANCE.NS": 40_000.0, ...},
)
# Returns:
# {"allowed": bool, "reason": str, "risk_fraction": float, "projected_position_fraction": float}
```

---

## `AdvisoryApprovalProvider`

### Purpose

Persistent store for pending advisory actions. Supports two approval types:

| Type | Purpose |
|------|---------|
| `TRADE_ORDER` | A direct trade order (`portfolio_gate_step`) |
| `ADVISORY_SYNTHESIS` | Full synthesis that needs sign-off before execution (`execution_step`) |

### Storage

SQLite table `advisory_approvals` in the same database as flow checkpoints
(`ADVISORY_CHECKPOINT_DB`). Schema:

| Column | Type | Description |
|--------|------|-------------|
| `id` | TEXT PK | UUID approval key |
| `conversation_id` | TEXT | Linked conversation |
| `type` | TEXT | `TRADE_ORDER` / `ADVISORY_SYNTHESIS` |
| `payload` | TEXT | JSON-serialised order / synthesis |
| `status` | TEXT | `PENDING` / `APPROVED` / `REJECTED` / `EXPIRED` |
| `created_at` | REAL | Unix timestamp |
| `expires_at` | REAL | `created_at + approval_timeout × 60` |

### Key methods

```python
# Create a new pending entry
approval_id = provider.create_pending(
    conversation_id="conv_abc",
    approval_type="TRADE_ORDER",
    payload={"symbol": "RELIANCE.NS", "side": "BUY", "qty": 50, ...},
    synthesis_text="...",
)

# Approve an entry
result = provider.approve(approval_id)
# Returns: {"success": True, "payload": {...}, "synthesis": "..."}

# Reject an entry
result = provider.reject(approval_id)

# Check for expired entries
expired = provider.expire_old_entries()  # marks PENDING → EXPIRED

# List pending entries for a conversation
pending = provider.list_pending(conversation_id="conv_abc")
```

### Activation

Set `ENABLE_ADVISORY_APPROVAL=1`. Without it, `execution_step` auto-approves all
synthesised recommendations (the default production-safe off state).

---

## `ExecutionCrewBuilder`

### Constructor

```python
ExecutionCrewBuilder(
    llm: LLM,
    tools: list,
    verbose: bool = False,
    max_position_size: float = 0.20,
    max_order_risk_fraction: float = 0.05,
    allow_short: bool = False,
)
```

### `build(...)` → `Crew`

```python
crew = builder.build(
    synthesis: str,                      # annotated synthesis text (post RL)
    portfolio_snapshot: Dict[str, Any],  # live IBKR holdings + cash
    intent: str = "general_advice",
    market_results: Optional[Dict] = None,
)
```

Agents in the Crew:

| Role | Responsibility |
|------|----------------|
| `PortfolioManager` | Review synthesis + current holdings, output position adjustments |
| `RiskAgent` | Compute risk metrics for proposed adjustments |
| `TradingStrategist` | Translate adjustments into concrete, executable orders |

Tasks run sequentially: portfolio review → risk check → trade orders.

### Output format

The Crew produces a markdown trade plan:

```markdown
## Trade Execution Plan

**Date**: 2025-01-15  
**Market**: IN  
**Portfolio Value**: ₹5,00,000

### Proposed Orders

| # | Symbol | Action | Qty | Est. Price | Value | Rationale |
|---|--------|--------|-----|------------|-------|-----------|
| 1 | RELIANCE.NS | BUY | 5 | ₹2,850 | ₹14,250 | Underweight vs target |
| 2 | INFY.NS | SELL | 10 | ₹1,720 | ₹17,200 | Above max position |

### Risk Summary

- Max drawdown impact: -0.8%
- Portfolio cash after trades: ₹1,52,750 (30.5%)
- Estimated commission: ₹47

### Disclaimer
*This is a paper trading plan for educational purposes...*
```

---

## Approval flow state machine

```mermaid
stateDiagram-v2
    [*] --> PENDING : create_pending()
    PENDING --> APPROVED : approve()
    PENDING --> REJECTED : reject()
    PENDING --> EXPIRED : expire_old_entries() [timeout]
    APPROVED --> [*]
    REJECTED --> [*]
    EXPIRED --> [*]
```

### Timeout

Default: 30 minutes (`approval_timeout_minutes=30`). Configurable per-flow instance.

The `portfolio_gate_step` always calls `_check_and_expire_approval` at the start
of processing so stale approvals never execute.

---

## Advisory Synthesis approval (two-pass execution)

When `ENABLE_ADVISORY_APPROVAL=1`, `execution_step` follows a two-pass protocol:

**Pass 1** (first time execution_step is reached for a conversation):

1. Build synthesis via `AnalysisCrewBuilder` + RL validation as normal
2. Create `ADVISORY_SYNTHESIS` approval entry with the synthesis as payload
3. Return the synthesis draft to the user with: *"Reply APPROVE to proceed with the trade plan."*
4. Set `state.advisory_approval_pending = True` and return early — **ExecutionCrew does NOT run yet**

**Pass 2** (user replies, flow resumes via `advisory_execution_resume_step`):

1. `market_router` detects `state.advisory_approval_pending == True` and routes to `advisory_execution_resume`
2. `advisory_execution_resume_step` checks user's decision:
   - `APPROVE <id>` → loads stored synthesis, runs `ExecutionCrewBuilder`
   - `REJECT <id>` → returns dismissal message, no trade plan generated
