import os
import sys
import pathlib
from flask import Flask, jsonify

# Be tolerant if python-dotenv isn't installed
try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    def load_dotenv(*args, **kwargs):  # type: ignore
        return False


def create_app():
    # Load environment variables from .env if present
    try:
        load_dotenv()
    except Exception:
        pass
    app = Flask(__name__)

    # Settings
    app.config['TRADING_MODE'] = os.getenv('TRADING_MODE', 'PAPER').upper()
    app.config['EXECUTION_MODE'] = os.getenv('EXECUTION_MODE', 'ALGOTEST').upper()
    app.config['BROKER'] = os.getenv('BROKER', 'SHOONYA').upper()
    app.config['IDEMPOTENCY_ENABLED'] = True
    # Initialize market data adapter based on broker (stubbed hooks)
    try:
        from .adapters import create_adapter  # type: ignore
        app.config['MARKET_ADAPTER'] = create_adapter(app.config['BROKER'])
    except ImportError:
        # When run as a script, use absolute imports
        try:
            ROOT_DIR = pathlib.Path(__file__).resolve().parents[1]
            if str(ROOT_DIR) not in sys.path:
                sys.path.append(str(ROOT_DIR))
            from paper_trading_agent.adapters import create_adapter  # type: ignore
            app.config['MARKET_ADAPTER'] = create_adapter(app.config['BROKER'])
        except Exception:
            app.config['MARKET_ADAPTER'] = None
    except Exception:
        app.config['MARKET_ADAPTER'] = None

    # Initialize Trading Adapter based on Execution Mode
    app.config['TRADING_ADAPTER'] = None
    if app.config['EXECUTION_MODE'] == 'SHOONYA':
        try:
            from .adapters.shoonya_trading import ShoonyaTradingAdapter
        except ImportError:
            # When run as a script, use absolute imports
            ROOT_DIR = pathlib.Path(__file__).resolve().parents[1]
            if str(ROOT_DIR) not in sys.path:
                sys.path.append(str(ROOT_DIR))
            from paper_trading_agent.adapters.shoonya_trading import ShoonyaTradingAdapter
        # Safety: require explicit env toggles for live trading
        if os.getenv('SHOONYA_LIVE', '0') in ('1', 'true', 'True') and os.getenv('ALLOW_LIVE_TRADING', 'NO') in ('YES', 'yes', '1', 'true', 'True'):
            app.config['TRADING_ADAPTER'] = ShoonyaTradingAdapter()
    elif app.config['EXECUTION_MODE'] == 'ALGOTEST':
        try:
            from .adapters.algotest_trading import AlgoTestTradingAdapter
        except ImportError:
            # When run as a script, use absolute imports
            ROOT_DIR = pathlib.Path(__file__).resolve().parents[1]
            if str(ROOT_DIR) not in sys.path:
                sys.path.append(str(ROOT_DIR))
            from paper_trading_agent.adapters.algotest_trading import AlgoTestTradingAdapter
        app.config['TRADING_ADAPTER'] = AlgoTestTradingAdapter()
        app.logger.info("Execution mode set to ALGOTEST. Using AlgoTest Trading Adapter.")
    else:
        app.logger.info("Execution mode set to PAPER. Using in-memory simulated portfolio.")

    # If a market data adapter is present, start it.
    # This is especially important for PAPER mode to get live price updates.
    market_adapter = app.config.get('MARKET_ADAPTER')
    if market_adapter:
        try:
            market_adapter.start()
            app.logger.info(f"Market data adapter '{app.config['BROKER']}' started successfully.")
        except Exception as e:
            app.logger.error(f"Failed to start market data adapter: {e}")

    @app.route('/health', methods=['GET'])
    def health():
        adapter = app.config.get('MARKET_ADAPTER')
        trading_adapter = app.config.get('TRADING_ADAPTER')
        adapter_info = None
        try:
            adapter_info = adapter.info() if adapter else None
        except Exception:
            adapter_info = None
        return jsonify({
            'status': 'ok',
            'mode': app.config['TRADING_MODE'],
            'execution_mode': app.config.get('EXECUTION_MODE', 'PAPER'),
            'live_trading_enabled': bool(trading_adapter),
            'broker': app.config['BROKER'],
            'adapter': adapter_info,
        })

    # Initialize Portfolio Service (for paper portfolio)
    try:
        from .portfolio.service import PortfolioService  # type: ignore
        app.config['PORTFOLIO_SERVICE'] = PortfolioService()
    except ImportError:
        # When run as a script, use absolute imports
        try:
            ROOT_DIR = pathlib.Path(__file__).resolve().parents[1]
            if str(ROOT_DIR) not in sys.path:
                sys.path.append(str(ROOT_DIR))
            from paper_trading_agent.portfolio.service import PortfolioService  # type: ignore
            app.config['PORTFOLIO_SERVICE'] = PortfolioService()
        except Exception:
            app.config['PORTFOLIO_SERVICE'] = None
    except Exception:
        app.config['PORTFOLIO_SERVICE'] = None

    # Register routes (support both module and script execution)
    try:
        from .routes.market import market_bp
        from .routes.portfolio import portfolio_bp
        from .routes.orders import orders_bp
        from .routes.stream import stream_bp
        from .routes.adapter import adapter_bp
        from .routes.admin import admin_bp
    except ImportError:
        # When run as a script (python paper_trading_agent/app.py), relative imports fail.
        # Add project root to sys.path and import via absolute package path.
        ROOT_DIR = pathlib.Path(__file__).resolve().parents[1]
        if str(ROOT_DIR) not in sys.path:
            sys.path.append(str(ROOT_DIR))
        from paper_trading_agent.routes.market import market_bp  # type: ignore
        from paper_trading_agent.routes.portfolio import portfolio_bp  # type: ignore
        from paper_trading_agent.routes.orders import orders_bp  # type: ignore
        from paper_trading_agent.routes.stream import stream_bp  # type: ignore
        from paper_trading_agent.routes.adapter import adapter_bp  # type: ignore
        from paper_trading_agent.routes.admin import admin_bp  # type: ignore

    app.register_blueprint(market_bp, url_prefix='/market')
    app.register_blueprint(portfolio_bp, url_prefix='/portfolio')
    app.register_blueprint(orders_bp, url_prefix='/orders')
    app.register_blueprint(stream_bp, url_prefix='/stream')
    app.register_blueprint(adapter_bp, url_prefix='/adapter')
    app.register_blueprint(admin_bp, url_prefix='/admin')

    return app


if __name__ == '__main__':
    # Clear previous session logs
    import logging
    try:
        log_files = ['logs/pta.log', '../logs/pta.log']
        for log_file in log_files:
            try:
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write('')  # Clear the log file
            except (FileNotFoundError, OSError):
                pass  # File doesn't exist or can't be accessed
    except Exception:
        pass
    
    app = create_app()
    app.run(host='0.0.0.0', port=int(os.getenv('PTA_PORT', '8090')), debug=False, use_reloader=False, threaded=True)
