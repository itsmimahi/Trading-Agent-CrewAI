// Enhanced Chat Interface Module with Performance Optimizations
class ChatManager {
    constructor() {
        this.messages = [];
        this.conversationId = null;
        this.isTyping = false;
        this.messageIdCounter = 0;
        this.messageQueue = [];
        this.isProcessingQueue = false;
        this.virtualScroll = null;
        this.inputDebounceTimer = null;
        this.typingIndicatorTimer = null;
        
        // Performance settings
        this.maxMessagesInDOM = 100; // Limit DOM messages for performance
        this.debounceDelay = 300;
        this.typingIndicatorDelay = 1000;
        
        this.initializeElements();
        this.bindEvents();
    // Disabled virtual scrolling for chat to avoid raw JSON render artifacts
    // this.setupVirtualScrolling();
        this.loadChatHistory();
    }

    // Initialize DOM elements
    initializeElements() {
        this.elements = {
            chatMessages: document.getElementById('chatMessages'),
            messageInput: document.getElementById('messageInput'),
            sendButton: document.getElementById('sendButton'),
            characterCount: document.getElementById('characterCount'),
            newChatBtn: document.getElementById('newChatBtn'),
            clearBtn: document.getElementById('clearBtn'),
            chatHistory: document.getElementById('chatHistory'),
            quickActionBtns: document.querySelectorAll('.quick-action-btn'),
            typingIndicator: document.getElementById('typingIndicator'),
            jumpToLatest: document.getElementById('jumpToLatest')
        };

        // Validate elements
        Object.entries(this.elements).forEach(([key, element]) => {
            if (!element && key !== 'quickActionBtns' && key !== 'typingIndicator') {
                console.warn(`Chat element not found: ${key}`);
            }
        });

        // Focus input on load
        if (this.elements.messageInput) {
            try { this.elements.messageInput.focus(); } catch (e) {}
        }

        // Create typing indicator if it doesn't exist
        if (!this.elements.typingIndicator && this.elements.chatMessages) {
            this.elements.typingIndicator = this.createTypingIndicator();
        }

        // Scroll awareness for Jump-to-latest
        if (this.elements.chatMessages && this.elements.jumpToLatest) {
            const threshold = 60;
            const updateJump = () => {
                const el = this.elements.chatMessages;
                const atBottom = (el.scrollHeight - el.scrollTop - el.clientHeight) < threshold;
                this.elements.jumpToLatest.hidden = atBottom;
            };
            this.elements.chatMessages.addEventListener('scroll', performanceOptimizer.throttle('chat-scroll', updateJump, 150));
            this.elements.jumpToLatest.addEventListener('click', () => this.scrollToBottom());
            // Initial state
            setTimeout(updateJump, 0);
        }
    }

    // Setup virtual scrolling for message list
    setupVirtualScrolling() {
        // No-op: chat uses custom DOM rendering; virtual scrolling manager is not suitable here
    }

    // Create typing indicator element
    createTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.id = 'typingIndicator';
        indicator.className = 'typing-indicator hidden';
        indicator.innerHTML = `
            <div class="message message-assistant">
                <div class="message-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="message-content">
                    <div class="typing-animation">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <small>AI is typing...</small>
                </div>
            </div>
        `;
        this.elements.chatMessages.appendChild(indicator);
        return indicator;
    }

    // Input helpers (kept minimal to avoid runtime errors)
    handleTyping() {
        // Reserved for future live typing UX; currently no-op since we show indicator only on send
    }

    validateInput() {
        // Basic length guard; detailed state handled by updateSendButtonState
        if (!this.elements.messageInput) return;
        const val = this.elements.messageInput.value || '';
        if (val.length > CONFIG.settings.chatMaxLength) {
            this.elements.messageInput.classList.add('input-invalid');
        } else {
            this.elements.messageInput.classList.remove('input-invalid');
        }
    }

    autoResizeInput() {
        // Only applies to textarea; current input is type="text"; safe no-op
    }

    // Enhanced event binding with debouncing
    bindEvents() {
        // Send button click
        if (this.elements.sendButton) {
            this.elements.sendButton.addEventListener('click', () => this.sendMessage());
        }

        // Enhanced input handling with debouncing
        if (this.elements.messageInput) {
            this.elements.messageInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                } else {
                    // Debounced typing indicator
                    this.handleTyping();
                }
            });

            // Input validation and character counting with debouncing
            this.elements.messageInput.addEventListener('input', (e) => {
                performanceOptimizer.debounce('input-validation', () => {
                    this.validateInput();
                    this.updateCharacterCount();
                }, this.debounceDelay);
            });

            // Auto-resize textarea
            this.elements.messageInput.addEventListener('input', () => {
                this.autoResizeInput();
            });

            // Character count update
            this.elements.messageInput.addEventListener('input', () => {
                this.updateCharacterCount();
                this.updateSendButtonState();
            });
        }

        // New chat button
        if (this.elements.newChatBtn) {
            this.elements.newChatBtn.addEventListener('click', () => this.startNewChat());
        }

        // Clear chat button
        if (this.elements.clearBtn) {
            this.elements.clearBtn.addEventListener('click', () => this.clearChat());
        }

        // Quick action buttons
        if (this.elements.quickActionBtns) {
            this.elements.quickActionBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    const query = btn.getAttribute('data-query');
                    if (query) {
                        this.elements.messageInput.value = query;
                        this.updateCharacterCount();
                        this.updateSendButtonState();
                        this.sendMessage();
                    }
                });
            });
        }
    }

    // Generate unique message ID
    generateMessageId() {
        return `msg_${++this.messageIdCounter}_${Date.now()}`;
    }

    // Update character count display
    updateCharacterCount() {
        if (this.elements.characterCount && this.elements.messageInput) {
            const count = this.elements.messageInput.value.length;
            this.elements.characterCount.textContent = `${count}/${CONFIG.settings.chatMaxLength}`;
            
            // Add warning class if near limit
            if (count > CONFIG.settings.chatMaxLength * 0.9) {
                this.elements.characterCount.classList.add('warning');
            } else {
                this.elements.characterCount.classList.remove('warning');
            }
        }
    }

    // Update send button state
    updateSendButtonState() {
        if (this.elements.sendButton && this.elements.messageInput) {
            const isEmpty = this.elements.messageInput.value.trim().length === 0;
            const isOverLimit = this.elements.messageInput.value.length > CONFIG.settings.chatMaxLength;
            
            this.elements.sendButton.disabled = isEmpty || isOverLimit || this.isTyping;
        }
    }

    // Send message
    async sendMessage() {
        if (!this.elements.messageInput || this.isTyping) return;

        const messageText = this.elements.messageInput.value.trim();
        if (!messageText || messageText.length > CONFIG.settings.chatMaxLength) return;

        // Add user message to chat
        this.addMessage({
            id: this.generateMessageId(),
            type: CONFIG.messageTypes.USER,
            content: messageText,
            timestamp: new Date()
        });

        // Clear input
        this.elements.messageInput.value = '';
        this.updateCharacterCount();
        this.updateSendButtonState();

        // Show typing indicator
        this.showTypingIndicator();

        try {
            // Send to API
            const response = await window.enhancedAPI.sendMessage(messageText);
            
            // Hide typing indicator
            this.hideTypingIndicator();

            if (response.success) {
                // Unwrap payload from gateway wrapper
                const raw = response && response.data ? response.data : {};
                const payload = raw && raw.data ? raw.data : raw;
                const assistantText = (() => {
                    if (!payload) return '';
                    // Prefer explicit fields
                    if (typeof payload.response === 'string') return payload.response;
                    if (typeof payload.message === 'string') return payload.message;
                    if (typeof payload.reply === 'string') return payload.reply;
                    if (typeof payload.content === 'string') return payload.content;
                    // Some backends send {choices:[{message:{content}}]}
                    try {
                        const c = payload.choices || raw.choices;
                        if (Array.isArray(c) && c[0]?.message?.content) return c[0].message.content;
                    } catch {}
                    // Fallbacks
                    if (typeof payload === 'string') return payload;
                    return '';
                })();

                // Add assistant response
                this.addMessage({
                    id: this.generateMessageId(),
                    type: CONFIG.messageTypes.ASSISTANT,
                    content: assistantText,
                    timestamp: new Date(),
                    metadata: payload
                });

                // Update conversation ID if provided
                if (payload && payload.conversation_id) {
                    this.conversationId = payload.conversation_id;
                }

                // Show success toast
                if (window.showToast) {
                    window.showToast('Message sent successfully', CONFIG.toastTypes.SUCCESS);
                }
            } else {
                const errMsg = response.error || 'Failed to send message';
                // Special-case timeouts/abort
                if (response.code === 'timeout') {
                    throw new Error('Request timed out before the response completed. Try again.');
                }
                throw new Error(errMsg);
            }

        } catch (error) {
            console.error('Send message error:', error);
            
            // Hide typing indicator
            this.hideTypingIndicator();

            // Add error message
            this.addMessage({
                id: this.generateMessageId(),
                type: CONFIG.messageTypes.ERROR,
                content: `Error: ${error.message}`,
                timestamp: new Date()
            });

            // Show error toast
            if (window.showToast) {
                window.showToast('Failed to send message: ' + error.message, CONFIG.toastTypes.ERROR);
            }
        }
    }

    // Add message to chat
    addMessage(message) {
        this.messages.push(message);
        this.renderMessage(message);
        this.scrollToBottom();
        this.saveChatHistory();
    }

    // Render message in UI
    renderMessage(message) {
        if (!this.elements.chatMessages) return;

        const messageElement = document.createElement('div');
        messageElement.className = `message message-${message.type}`;
        messageElement.setAttribute('data-message-id', message.id);

    const contentElement = document.createElement('div');
    contentElement.className = 'message-content';
        
        // Process content based on type
        if (message.type === CONFIG.messageTypes.ERROR) {
            contentElement.innerHTML = `<div style="color: var(--danger-color);">${this.escapeHtml(message.content)}</div>`;
        } else {
            contentElement.innerHTML = this.formatMessageContent(message.content);
        }

        const metaElement = document.createElement('div');
        metaElement.className = 'message-meta';
        
        // Add avatar
        const avatarElement = document.createElement('div');
        avatarElement.className = 'message-avatar';
        avatarElement.textContent = message.type === CONFIG.messageTypes.USER ? 'U' : 'AI';
        
        // Add timestamp
        const timeElement = document.createElement('span');
        timeElement.className = 'message-time';
        timeElement.textContent = this.formatTime(message.timestamp);
        
        // Add actions for assistant messages
        if (message.type === CONFIG.messageTypes.ASSISTANT) {
            const actionsElement = document.createElement('div');
            actionsElement.className = 'message-actions';
            
            // Copy button
            const copyBtn = document.createElement('button');
            copyBtn.className = 'message-action';
            copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
            copyBtn.title = 'Copy message';
            copyBtn.addEventListener('click', () => this.copyMessage(message.content));
            
            actionsElement.appendChild(copyBtn);
            metaElement.appendChild(actionsElement);
        }
        
        metaElement.appendChild(avatarElement);
        metaElement.appendChild(timeElement);
        
        messageElement.appendChild(contentElement);
        messageElement.appendChild(metaElement);
        
        // Remove welcome message if this is the first real message
        if (this.messages.length === 1) {
            const welcomeMessage = this.elements.chatMessages.querySelector('.welcome-message');
            if (welcomeMessage) {
                welcomeMessage.remove();
            }
        }
        
    this.elements.chatMessages.appendChild(messageElement);
        
        // Add animation
        requestAnimationFrame(() => {
            messageElement.classList.add('fade-in');
        });

        // Syntax highlighting for code blocks
        try {
            if (window.hljs) {
                messageElement.querySelectorAll('pre code, code').forEach(block => window.hljs.highlightElement(block));
            }
        } catch {}

        // Collapse overly long assistant messages
        if (message.type === CONFIG.messageTypes.ASSISTANT) {
            const approxLength = (message.content || '').length;
            if (approxLength > 1200) {
                messageElement.classList.add('message-collapsed');
                const toggle = document.createElement('button');
                toggle.className = 'message-toggle';
                toggle.type = 'button';
                toggle.textContent = 'Show more';
                toggle.addEventListener('click', () => {
                    const collapsed = messageElement.classList.toggle('message-collapsed');
                    toggle.textContent = collapsed ? 'Show more' : 'Show less';
                    this.scrollToBottom();
                });
                messageElement.appendChild(toggle);
            }
        }
    }

    // Format message content (supports basic markdown)
    formatMessageContent(content) {
        if (typeof content !== 'string') return '';
        
        let formatted = this.escapeHtml(content);
        
        // Basic markdown support
        formatted = formatted
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
        
        // Link detection
        formatted = formatted.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener">$1</a>'
        );
        
        return formatted;
    }

    // Escape HTML to prevent XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Format timestamp
    formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }

    // Copy message to clipboard
    async copyMessage(content) {
        try {
            await navigator.clipboard.writeText(content);
            if (window.showToast) {
                window.showToast('Message copied to clipboard', CONFIG.toastTypes.SUCCESS);
            }
        } catch (error) {
            console.error('Copy failed:', error);
            if (window.showToast) {
                window.showToast('Failed to copy message', CONFIG.toastTypes.ERROR);
            }
        }
    }

    // Show typing indicator
    showTypingIndicator() {
        if (!this.elements.chatMessages || this.isTyping) return;
        
        this.isTyping = true;
        this.updateSendButtonState();
        
        // Remove any stale indicator first to avoid duplicates
        const existing = this.elements.chatMessages.querySelector('#typingIndicator');
        if (existing) existing.remove();

        const typingElement = document.createElement('div');
        typingElement.className = 'typing-indicator';
        typingElement.id = 'typingIndicator';
        typingElement.innerHTML = `
            <div class="typing-dots">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        `;
        this.elements.chatMessages.appendChild(typingElement);
        this.scrollToBottom();
    }

    // Hide typing indicator
    hideTypingIndicator() {
        const typingElement = document.getElementById('typingIndicator');
        if (typingElement) {
            typingElement.remove();
        }
        
        this.isTyping = false;
        this.updateSendButtonState();
    }

    // Scroll to bottom of chat
    scrollToBottom() {
        if (!this.elements.chatMessages) return;
        const container = this.elements.chatMessages;
        requestAnimationFrame(() => {
            // Ensure layout is stable before scrolling
            const target = container.scrollHeight;
            container.scrollTop = target;
        });
    }

    // Start new chat conversation
    startNewChat() {
        this.clearChat();
        this.conversationId = null;
        
        if (window.showToast) {
            window.showToast('New conversation started', CONFIG.toastTypes.INFO);
        }
    }

    // Clear chat messages
    clearChat() {
        this.messages = [];
        this.hideTypingIndicator();
        
        if (this.elements.chatMessages) {
            // Keep only the welcome message
            const welcomeMessage = this.elements.chatMessages.querySelector('.welcome-message');
            this.elements.chatMessages.innerHTML = '';
            
            if (welcomeMessage) {
                this.elements.chatMessages.appendChild(welcomeMessage);
            }
        }
        
        this.saveChatHistory();
    }

    // Save chat history to localStorage
    saveChatHistory() {
        try {
            const chatData = {
                messages: this.messages,
                conversationId: this.conversationId,
                timestamp: Date.now()
            };
            localStorage.setItem('chat_history', JSON.stringify(chatData));
        } catch (error) {
            console.warn('Failed to save chat history:', error);
        }
    }

    // Load chat history from localStorage
    loadChatHistory() {
        try {
            const saved = localStorage.getItem('chat_history');
            if (saved) {
                const chatData = JSON.parse(saved);
                
                // Only load recent history (last 24 hours)
                const dayAgo = Date.now() - (24 * 60 * 60 * 1000);
                if (chatData.timestamp > dayAgo) {
                    this.messages = chatData.messages || [];
                    this.conversationId = chatData.conversationId;
                    
                    // Render messages
                    this.messages.forEach(message => this.renderMessage(message));
                    this.scrollToBottom();
                }
            }
        } catch (error) {
            console.warn('Failed to load chat history:', error);
        }
    }

    // Export chat history
    exportChat() {
        const chatText = this.messages
            .map(msg => {
                const time = this.formatTime(msg.timestamp);
                const sender = msg.type === CONFIG.messageTypes.USER ? 'User' : 'Assistant';
                return `[${time}] ${sender}: ${msg.content}`;
            })
            .join('\n\n');
        
        const blob = new Blob([chatText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `chat_export_${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        if (window.showToast) {
            window.showToast('Chat exported successfully', CONFIG.toastTypes.SUCCESS);
        }
    }

    // Get message count
    getMessageCount() {
        return this.messages.length;
    }

    // Get conversation stats
    getConversationStats() {
        return {
            messageCount: this.messages.length,
            userMessages: this.messages.filter(m => m.type === CONFIG.messageTypes.USER).length,
            assistantMessages: this.messages.filter(m => m.type === CONFIG.messageTypes.ASSISTANT).length,
            errorMessages: this.messages.filter(m => m.type === CONFIG.messageTypes.ERROR).length,
            conversationId: this.conversationId,
            startTime: this.messages[0]?.timestamp,
            lastMessage: this.messages[this.messages.length - 1]?.timestamp
        };
    }
}

// Initialize chat manager
const chatManager = new ChatManager();

// Export for global use
window.chatManager = chatManager;
