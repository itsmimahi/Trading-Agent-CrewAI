"""
Update Main Advisory Agent to use Universal Portfolio Manager
"""
# Add to main advisory agent/pta_client.py or create a new integration file

import os
import sys
import logging

# Add project root to path
project_root = os.path.dirname(os.path.dirname(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from agents.universal_portfolio_manager import get_portfolio_manager
except ImportError:
    def get_portfolio_manager(name):
        # Fallback to existing PTAClientTool
        try:
            from pta_client import PTAClientTool
            class LegacyWrapper:
                def __init__(self):
                    self.client = PTAClientTool()
                    
                def get_holdings(self):
                    import json
                    response = self.client._run("holdings")
                    return json.loads(response)
                    
                def get_metrics(self):
                    try:
                        import json
                        response = self.client._run("metrics")
                        return json.loads(response)
                    except:
                        return {"error": "metrics not available"}
                        
                def place_order(self, symbol, side, quantity, idempotency_key=None):
                    import json
                    kwargs = {"symbol": symbol, "side": side, "quantity": quantity}
                    if idempotency_key:
                        kwargs["idempotency_key"] = idempotency_key
                    response = self.client._run("submit_order", **kwargs)
                    return json.loads(response)
                    
                def is_available(self):
                    return True
                    
            return LegacyWrapper()
        except Exception:
            return None


# Enhanced Advisory Service with Portfolio Integration
class AdvisoryPortfolioService:
    """Enhanced advisory service with portfolio management integration."""
    
    def __init__(self):
        self.portfolio_manager = get_portfolio_manager("MainAdvisoryAgent")
        self.logger = logging.getLogger("AdvisoryPortfolio")
    
    def get_portfolio_context(self) -> dict:
        """Get portfolio context for advisory recommendations."""
        if not self.portfolio_manager or not self.portfolio_manager.is_available():
            return {"status": "portfolio_unavailable"}
            
        try:
            holdings = self.portfolio_manager.get_holdings()
            metrics = self.portfolio_manager.get_metrics()
            
            return {
                "status": "available",
                "cash": holdings.get("cash", 0),
                "positions": len(holdings.get("holdings", [])),
                "total_value": metrics.get("total_value_est", 0),
                "unrealized_pnl": metrics.get("unrealized_pnl", 0),
                "positions_detail": holdings.get("holdings", [])
            }
        except Exception as e:
            self.logger.error(f"Portfolio context failed: {e}")
            return {"status": "error", "error": str(e)}
    
    def validate_trade_recommendation(self, symbol: str, side: str, quantity: int) -> dict:
        """Validate if a trade recommendation is feasible."""
        if not self.portfolio_manager or not self.portfolio_manager.is_available():
            return {"feasible": False, "reason": "Portfolio manager unavailable"}
            
        try:
            can_trade, reason = self.portfolio_manager.can_trade(symbol, side, quantity)
            preview = self.portfolio_manager.preview_order(symbol, side, quantity) if can_trade else {}
            
            return {
                "feasible": can_trade,
                "reason": reason,
                "estimated_cost": preview.get("estimated_total", 0),
                "estimated_fees": preview.get("estimated_fees", 0)
            }
        except Exception as e:
            return {"feasible": False, "reason": f"Validation error: {e}"}
    
    def execute_advisory_trade(self, symbol: str, side: str, quantity: int, reasoning: str = "") -> dict:
        """Execute a trade based on advisory recommendation.""" 
        if not self.portfolio_manager or not self.portfolio_manager.is_available():
            return {"success": False, "error": "Portfolio manager unavailable"}
            
        try:
            # Generate idempotency key based on reasoning
            import hashlib
            idem_key = hashlib.md5(f"{symbol}_{side}_{quantity}_{reasoning}".encode()).hexdigest()[:16]
            
            result = self.portfolio_manager.place_order(symbol, side, quantity, idem_key)
            
            if "error" in result:
                return {"success": False, "error": result["error"]}
            else:
                return {"success": True, "order": result, "reasoning": reasoning}
                
        except Exception as e:
            return {"success": False, "error": str(e)}


# Global instance
_advisory_portfolio_service = None

def get_advisory_portfolio_service():
    """Get the global advisory portfolio service instance."""
    global _advisory_portfolio_service
    if _advisory_portfolio_service is None:
        _advisory_portfolio_service = AdvisoryPortfolioService()
    return _advisory_portfolio_service
