"""
RL Agent Portfolio Integration
Connects RL agent to the Portfolio Management System for realistic trading simulation.
"""
import os
import sys
import logging
from typing import Dict, Any, Optional, Tuple

# Add project root to path for imports
project_root = os.path.dirname(os.path.dirname(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from agents.universal_portfolio_manager import get_portfolio_manager
except ImportError:
    def get_portfolio_manager(name):
        return None

logger = logging.getLogger("RLPortfolio")


class RLPortfolioInterface:
    """
    Interface between RL Agent and Portfolio Management System.
    Provides realistic portfolio state and execution for RL training.
    """
    
    def __init__(self, agent_name: str = "RLAgent"):
        self.agent_name = agent_name
        self.portfolio_manager = get_portfolio_manager(agent_name)
        self.logger = logging.getLogger(f"RLPortfolio.{agent_name}")
        
        # RL-specific tracking
        self.episode_trades = []
        self.initial_portfolio_value = None
        
    def is_available(self) -> bool:
        """Check if portfolio integration is available."""
        return self.portfolio_manager is not None and self.portfolio_manager.is_available()
    
    def reset_episode(self) -> Dict[str, Any]:
        """Reset portfolio state for a new RL episode."""
        if not self.is_available():
            return self._mock_portfolio_state()
            
        try:
            # Get initial state
            holdings = self.portfolio_manager.get_holdings()
            metrics = self.portfolio_manager.get_metrics()
            
            self.initial_portfolio_value = metrics.get("total_value_est", 50000)
            self.episode_trades = []
            
            return self._format_portfolio_state(holdings, metrics)
        except Exception as e:
            self.logger.error(f"Episode reset failed: {e}")
            return self._mock_portfolio_state()
    
    def get_portfolio_state(self) -> Dict[str, Any]:
        """Get current portfolio state for RL observation."""
        if not self.is_available():
            return self._mock_portfolio_state()
            
        try:
            holdings = self.portfolio_manager.get_holdings()
            metrics = self.portfolio_manager.get_metrics()
            return self._format_portfolio_state(holdings, metrics)
        except Exception as e:
            self.logger.error(f"Get portfolio state failed: {e}")
            return self._mock_portfolio_state()
    
    def execute_rl_action(self, action: Dict[str, Any]) -> Tuple[Dict[str, Any], float, bool, Dict[str, Any]]:
        """
        Execute RL action and return (new_state, reward, done, info).
        
        Args:
            action: Dict with 'type' (buy/sell/hold), 'symbol', 'quantity'
            
        Returns:
            Tuple of (observation, reward, terminated, info)
        """
        if not self.is_available():
            return self._mock_portfolio_state(), 0.0, False, {"error": "Portfolio unavailable"}
        
        info = {"action": action, "trade_executed": False}
        
        try:
            action_type = action.get("type", "hold").lower()
            symbol = action.get("symbol", "")
            quantity = action.get("quantity", 0)
            
            # Execute trade if not holding
            if action_type in ["buy", "sell"] and symbol and quantity > 0:
                result = self.portfolio_manager.place_order(symbol, action_type, quantity)
                
                if "error" not in result:
                    self.episode_trades.append({
                        "action": action,
                        "result": result,
                        "timestamp": result.get("timestamp")
                    })
                    info["trade_executed"] = True
                    info["order"] = result
                else:
                    info["trade_error"] = result["error"]
            
            # Get new state
            new_state = self.get_portfolio_state()
            
            # Calculate reward
            reward = self._calculate_rl_reward(new_state, action, info)
            
            # Check if episode should terminate
            done = self._check_episode_termination(new_state)
            
            return new_state, reward, done, info
            
        except Exception as e:
            self.logger.error(f"RL action execution failed: {e}")
            info["error"] = str(e)
            return self.get_portfolio_state(), -1.0, False, info
    
    def _format_portfolio_state(self, holdings: Dict[str, Any], metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Format portfolio data for RL observation."""
        positions = holdings.get("holdings", [])
        
        # Convert to RL-friendly format
        portfolio_state = {
            "cash": float(holdings.get("cash", 0)),
            "total_value": float(metrics.get("total_value_est", 0)),
            "unrealized_pnl": float(metrics.get("unrealized_pnl", 0)),
            "positions_count": len(positions),
            "positions": {}
        }
        
        # Add position details
        for pos in positions:
            symbol = pos.get("symbol", "")
            portfolio_state["positions"][symbol] = {
                "quantity": int(pos.get("quantity", 0)),
                "avg_price": float(pos.get("avg_price", 0)),
                "current_value": int(pos.get("quantity", 0)) * float(pos.get("avg_price", 0))
            }
        
        return portfolio_state
    
    def _mock_portfolio_state(self) -> Dict[str, Any]:
        """Return mock portfolio state when PMS is unavailable."""
        return {
            "cash": 50000.0,
            "total_value": 50000.0,
            "unrealized_pnl": 0.0,
            "positions_count": 0,
            "positions": {},
            "mock": True
        }
    
    def _calculate_rl_reward(self, state: Dict[str, Any], action: Dict[str, Any], info: Dict[str, Any]) -> float:
        """Calculate reward for RL agent based on portfolio performance."""
        if self.initial_portfolio_value is None:
            return 0.0
        
        current_value = state.get("total_value", self.initial_portfolio_value)
        
        # Base reward: portfolio value change
        value_change = current_value - self.initial_portfolio_value
        base_reward = value_change / self.initial_portfolio_value  # Percentage gain/loss
        
        # Penalty for failed trades
        if action.get("type") in ["buy", "sell"] and not info.get("trade_executed", False):
            base_reward -= 0.01  # Small penalty for failed trades
        
        # Bonus for successful trades (encourage action)
        if info.get("trade_executed", False):
            base_reward += 0.001  # Small bonus for taking action
        
        return float(base_reward)
    
    def _check_episode_termination(self, state: Dict[str, Any]) -> bool:
        """Check if RL episode should terminate."""
        if self.initial_portfolio_value is None:
            return False
        
        current_value = state.get("total_value", self.initial_portfolio_value)
        
        # Terminate if portfolio drops by more than 20%
        if current_value < self.initial_portfolio_value * 0.8:
            return True
        
        # Terminate if too many trades in episode
        if len(self.episode_trades) > 50:
            return True
        
        return False
    
    def get_episode_summary(self) -> Dict[str, Any]:
        """Get summary of RL episode performance."""
        if not self.initial_portfolio_value:
            return {"error": "No episode initialized"}
        
        current_state = self.get_portfolio_state()
        final_value = current_state.get("total_value", self.initial_portfolio_value)
        
        return {
            "initial_value": self.initial_portfolio_value,
            "final_value": final_value,
            "total_return": (final_value - self.initial_portfolio_value) / self.initial_portfolio_value,
            "trades_count": len(self.episode_trades),
            "unrealized_pnl": current_state.get("unrealized_pnl", 0),
            "positions_count": current_state.get("positions_count", 0)
        }


# Global instance factory
_rl_instances = {}

def get_rl_portfolio_interface(agent_name: str = "RLAgent") -> RLPortfolioInterface:
    """Get or create RL portfolio interface for an agent."""
    if agent_name not in _rl_instances:
        _rl_instances[agent_name] = RLPortfolioInterface(agent_name)
    return _rl_instances[agent_name]
