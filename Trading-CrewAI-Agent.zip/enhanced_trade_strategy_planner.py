"""
Enhanced Trade Strategy Planner Agent using CrewAI Framework - Hybrid Plus Approach
Synthesizes outputs from other agents and generates comprehensive trade strategies
"""

import warnings
warnings.filterwarnings("ignore")

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from dataclasses import dataclass

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability, AgentTool
from config.settings import config
from crewai import Task, Crew, Process

logger = logging.getLogger(__name__)

class EnhancedTradeStrategyPlanner(EnhancedBaseAgent):
    """
    Enhanced Trade Strategy Planner Agent using CrewAI Framework with Hybrid Plus Approach
    
    Mathematical Core: Signal aggregation, strategy scoring, risk assessment
    LLM Reasoning: Strategy synthesis, market interpretation, decision justification
    Tools: Strategy classifier, signal aggregator, backtesting simulator
    Memory: Strategy performance history, signal accuracy tracking
    Knowledge Base: Trading strategies, market patterns, risk management
    """
    
    def __init__(self, name: str = "EnhancedTradeStrategyPlanner", description: str = "Trade Strategy Planner Agent for synthesizing agent outputs and generating comprehensive trade strategies", role: str = "Trade Strategy Planner", goal: str = "Synthesize agent outputs and generate comprehensive trade strategies", backstory: str = "Expert trade strategist with deep knowledge of market analysis and portfolio management", capabilities: Optional[List[Any]] = None, weight: float = 0.25, use_llm: bool = True, use_memory: bool = True, use_knowledge_base: bool = True, **kwargs):
        if capabilities is None:
            capabilities = [
                AgentCapability.MATHEMATICAL_ANALYSIS,
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.CONTEXTUAL_REASONING,
                AgentCapability.TREND_ANALYSIS
            ]
        super().__init__(
            name=name,
            description=description,
            capabilities=capabilities,
            weight=weight,
            use_llm=use_llm,
            use_memory=use_memory,
            use_knowledge_base=use_knowledge_base,
            role=role,
            goal=goal,
            backstory=backstory,
            **kwargs
        )
        
        # Strategy weights for different agent types
        self.agent_weights = {
            'technical': 0.25,
            'sentiment': 0.20,
            'macro': 0.20,
            'risk': 0.15,
            'research': 0.10,
            'timing': 0.10
        }
        
        # Load strategy knowledge
        self._load_strategy_knowledge()
    
    def _load_strategy_knowledge(self):
        """Load trading strategy knowledge into knowledge base"""
        try:
            strategy_knowledge = [
                "Momentum Strategy: Buy stocks showing upward price momentum with strong volume confirmation",
                "Reversal Strategy: Buy oversold stocks or sell overbought stocks expecting mean reversion",
                "Fundamental Strategy: Buy undervalued stocks based on fundamental analysis",
                "Technical Strategy: Use technical indicators and chart patterns for entry/exit decisions",
                "Value Strategy: Buy stocks trading below intrinsic value with strong fundamentals",
                "Growth Strategy: Buy high-growth stocks with strong earnings momentum",
                "Position Sizing: Risk 1-2% of portfolio per trade for optimal risk management",
                "Stop Loss: Set stop loss at 2-3% below entry for momentum strategies",
                "Take Profit: Set target at 2-3 times the risk for favorable risk-reward"
            ]
            
            if self.use_knowledge_base:
                self.knowledge_base.add_knowledge(strategy_knowledge)
                
        except Exception as e:
            self.logger.error(f"Error loading strategy knowledge: {e}")
    
    async def analyze(self, symbol: str, agent_insights: Dict[str, Any] = None) -> Dict[str, Any]:
        """Main analysis method combining mathematical analysis with CrewAI reasoning"""
        try:
            self.logger.info(f"Starting CrewAI comprehensive trade strategy planning for {symbol}")
            
            # Use provided agent insights or create mock data
            if agent_insights is None:
                agent_insights = self._create_mock_agent_insights(symbol)
            
            # 1. Mathematical Analysis (Signal aggregation and strategy generation)
            math_results = await self.mathematical_analysis(symbol, {'agent_insights': agent_insights})
            if "error" in math_results:
                return math_results
            
            # 2. Get market context for CrewAI reasoning
            market_context = await self._get_market_context(symbol)
            
            # 3. CrewAI Reasoning (Strategy synthesis and interpretation)
            if self.use_llm:
                crewai_reasoning = await self._get_crewai_strategy_reasoning(math_results, market_context)
            else:
                crewai_reasoning = {"reasoning": "CrewAI analysis not available"}
            
            # 4. Final Synthesis
            final_analysis = {
                "agent_name": self.name,
                "symbol": symbol,
                "analysis_timestamp": datetime.now().isoformat(),
                "mathematical_analysis": math_results,
                "crewai_reasoning": crewai_reasoning,
                "market_context": market_context,
                "confidence_score": math_results.get('signal_score', {}).get('confidence', 0.5),
                "recommendation": math_results.get('trade_plan', {}).get('direction', 'HOLD'),
                "agent_weight": self.weight
            }
            
            return final_analysis
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI comprehensive analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Perform mathematical/quantitative strategy analysis"""
        try:
            agent_insights = data.get('agent_insights', {})
            
            # Aggregate signals from all agents
            aggregated_signals = self._aggregate_agent_signals(agent_insights)
            
            # Classify strategy based on signal mix
            strategy_classification = self._classify_strategy(aggregated_signals)
            
            # Calculate signal score
            signal_score = self._calculate_signal_score(aggregated_signals)
            
            # Generate trade plan
            trade_plan = self._generate_trade_plan(aggregated_signals, strategy_classification)
            
            return {
                "symbol": symbol,
                "aggregated_signals": aggregated_signals,
                "strategy_classification": strategy_classification,
                "signal_score": signal_score,
                "trade_plan": trade_plan,
                "calculation_timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in mathematical analysis for {symbol}: {e}")
            return {"error": str(e)}
    
    def _aggregate_agent_signals(self, agent_insights: Dict[str, Any]) -> Dict[str, Any]:
        """Aggregate signals from multiple agents"""
        try:
            aggregated = {
                'buy_signals': 0,
                'sell_signals': 0,
                'hold_signals': 0,
                'weighted_score': 0,
                'consensus_direction': 'hold',
                'consensus_strength': 0
            }
            
            total_weight = 0
            
            for agent_name, insight in agent_insights.items():
                if not insight or 'recommendation' not in insight:
                    continue
                
                # Get agent weight
                agent_type = agent_name.lower().split('_')[0] if '_' in agent_name else agent_name.lower()
                weight = self.agent_weights.get(agent_type, 0.1)
                total_weight += weight
                
                # Process recommendation
                recommendation = insight.get('recommendation', 'hold').lower()
                confidence = insight.get('confidence', 0.5)
                
                if 'buy' in recommendation or 'positive' in recommendation:
                    aggregated['buy_signals'] += weight * confidence
                elif 'sell' in recommendation or 'negative' in recommendation:
                    aggregated['sell_signals'] += weight * confidence
                else:
                    aggregated['hold_signals'] += weight * confidence
                
                aggregated['weighted_score'] += weight * confidence * self._get_direction_score(recommendation)
            
            # Normalize scores
            if total_weight > 0:
                aggregated['buy_signals'] /= total_weight
                aggregated['sell_signals'] /= total_weight
                aggregated['hold_signals'] /= total_weight
                aggregated['weighted_score'] /= total_weight
            
            # Determine consensus
            max_signal = max(aggregated['buy_signals'], aggregated['sell_signals'], aggregated['hold_signals'])
            if max_signal == aggregated['buy_signals']:
                aggregated['consensus_direction'] = 'buy'
                aggregated['consensus_strength'] = aggregated['buy_signals']
            elif max_signal == aggregated['sell_signals']:
                aggregated['consensus_direction'] = 'sell'
                aggregated['consensus_strength'] = aggregated['sell_signals']
            else:
                aggregated['consensus_direction'] = 'hold'
                aggregated['consensus_strength'] = aggregated['hold_signals']
            
            return aggregated
            
        except Exception as e:
            self.logger.error(f"Error aggregating agent signals: {e}")
            return {
                'buy_signals': 0,
                'sell_signals': 0,
                'hold_signals': 0,
                'weighted_score': 0,
                'consensus_direction': 'hold',
                'consensus_strength': 0
            }
    
    def _get_direction_score(self, recommendation: str) -> float:
        """Convert recommendation to numerical score"""
        if 'buy' in recommendation or 'positive' in recommendation:
            return 1.0
        elif 'sell' in recommendation or 'negative' in recommendation:
            return -1.0
        else:
            return 0.0
    
    def _classify_strategy(self, aggregated_signals: Dict[str, Any]) -> Dict[str, Any]:
        """Classify trade strategy based on signal mix"""
        try:
            weighted_score = aggregated_signals.get('weighted_score', 0)
            
            # Determine primary strategy type
            strategy_type = "HOLD"
            confidence = 0.5
            
            if abs(weighted_score) > 0.3:
                if weighted_score > 0:
                    strategy_type = "MOMENTUM"
                    confidence = abs(weighted_score)
                else:
                    strategy_type = "REVERSAL"
                    confidence = abs(weighted_score)
            
            return {
                "primary_strategy": strategy_type,
                "confidence": confidence,
                "direction": "BUY" if weighted_score > 0 else "SELL" if weighted_score < 0 else "HOLD",
                "strength": abs(weighted_score)
            }
            
        except Exception as e:
            self.logger.error(f"Error classifying strategy: {e}")
            return {
                "primary_strategy": "HOLD",
                "confidence": 0.5,
                "direction": "HOLD",
                "strength": 0
            }
    
    def _calculate_signal_score(self, aggregated_signals: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate weighted signal score"""
        try:
            weighted_score = aggregated_signals.get('weighted_score', 0)
            consensus_strength = aggregated_signals.get('consensus_strength', 0)
            
            # Calculate composite score
            composite_score = (weighted_score * 0.6 + consensus_strength * 0.4)
            
            # Determine signal strength
            if abs(composite_score) > 0.7:
                signal_strength = "STRONG"
            elif abs(composite_score) > 0.4:
                signal_strength = "MODERATE"
            else:
                signal_strength = "WEAK"
            
            return {
                "composite_score": composite_score,
                "signal_strength": signal_strength,
                "confidence": consensus_strength,
                "weighted_score": weighted_score
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating signal score: {e}")
            return {
                "composite_score": 0,
                "signal_strength": "WEAK",
                "confidence": 0.5,
                "weighted_score": 0
            }
    
    def _generate_trade_plan(self, aggregated_signals: Dict[str, Any], strategy_classification: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive trade plan"""
        try:
            direction = strategy_classification.get('direction', 'HOLD')
            strategy_type = strategy_classification.get('primary_strategy', 'HOLD')
            confidence = strategy_classification.get('confidence', 0.5)
            
            # Mock price data (in real implementation, get from market data)
            current_price = 100.0  # Mock price
            
            # Calculate entry, target, and stop loss based on strategy
            if direction == "BUY":
                entry_price = current_price
                target_price = current_price * 1.05  # 5% target
                stop_loss = current_price * 0.97  # 3% stop loss
            elif direction == "SELL":
                entry_price = current_price
                target_price = current_price * 0.95  # 5% target
                stop_loss = current_price * 1.03  # 3% stop loss
            else:
                entry_price = current_price
                target_price = current_price
                stop_loss = current_price
            
            # Calculate position size and risk-reward ratio
            position_size = 0.05  # 5% position size
            risk_reward_ratio = abs(target_price - entry_price) / abs(entry_price - stop_loss)
            
            return {
                "direction": direction,
                "strategy_type": strategy_type,
                "entry_price": entry_price,
                "target_price": target_price,
                "stop_loss": stop_loss,
                "position_size": position_size,
                "confidence": confidence,
                "risk_reward_ratio": risk_reward_ratio,
                "time_horizon": "SHORT_TERM" if strategy_type in ["MOMENTUM", "TECHNICAL"] else "MEDIUM_TERM"
            }
            
        except Exception as e:
            self.logger.error(f"Error generating trade plan: {e}")
            return {
                "direction": "HOLD",
                "strategy_type": "HOLD",
                "entry_price": 0,
                "target_price": 0,
                "stop_loss": 0,
                "position_size": 0,
                "confidence": 0.5,
                "risk_reward_ratio": 1.0,
                "time_horizon": "SHORT_TERM"
            }
    
    def _create_mock_agent_insights(self, symbol: str) -> Dict[str, Any]:
        """Create mock agent insights for testing"""
        return {
            "technical_agent": {
                "recommendation": "buy",
                "confidence": 0.7,
                "key_metrics": {"rsi": 35, "trend": "bullish"},
                "reasoning": "Technical indicators show oversold conditions"
            },
            "sentiment_agent": {
                "recommendation": "buy",
                "confidence": 0.6,
                "key_metrics": {"sentiment_score": 0.6},
                "reasoning": "Positive market sentiment"
            },
            "macro_agent": {
                "recommendation": "hold",
                "confidence": 0.5,
                "key_metrics": {"macro_score": 0.5},
                "reasoning": "Neutral macroeconomic conditions"
            },
            "risk_agent": {
                "recommendation": "buy",
                "confidence": 0.8,
                "key_metrics": {"risk_score": 0.3},
                "reasoning": "Low risk environment"
            }
        }
    
    
    async def _get_market_context(self, symbol: str) -> str:
        """Get current market context for CrewAI reasoning"""
        try:
            return f"""
            Trade strategy planning context for {symbol}:
            - Market volatility: Current volatility levels and their impact on strategy selection
            - Sector rotation: Which sectors are leading/lagging and their implications
            - Market breadth: Advance/decline ratios and market participation
            - Interest rate environment: Impact on different strategy types
            - Economic cycle: Current phase and its impact on strategy performance
            - Market sentiment: Overall market mood and its influence on strategy success
            """
        except Exception as e:
            self.logger.error(f"Error getting market context: {e}")
            return "Market context not available"

    async def _get_crewai_strategy_reasoning(self, math_results: Dict[str, Any], market_context: str) -> Dict[str, Any]:
        """Get CrewAI-based strategy reasoning for trade planning"""
        try:
            reasoning_prompt = f"""
            You are an expert trade strategist with deep knowledge of market analysis and portfolio management.
            
            Mathematical Strategy Analysis Results:
            {math_results}
            
            Market Context:
            {market_context}
            
            Based on this comprehensive strategy analysis, provide:
            1. Strategy Assessment - Overall strategy quality and market fit
            2. Risk Analysis - Potential risks and mitigation strategies
            3. Execution Plan - Specific entry/exit timing and position sizing
            4. Alternative Strategies - Backup strategies if primary fails
            5. Market Conditions - How current conditions affect strategy success
            6. Performance Expectations - Expected returns and time horizon
            
            Provide comprehensive strategy analysis that combines quantitative signals with market wisdom.
            """
            
            # Use CrewAI agent for reasoning
            task = Task(
                description=reasoning_prompt,
                agent=self.crewai_agent,
                expected_output="Comprehensive strategy reasoning and trade planning analysis"
            )
            
            crew = Crew(
                agents=[self.crewai_agent],
                tasks=[task],
                process=Process.sequential,
                verbose=False
            )
            
            result = crew.kickoff()
            
            return {"reasoning": str(result)}
            
        except Exception as e:
            self.logger.error(f"Error in CrewAI strategy reasoning: {str(e)}")
            return {"error": str(e)}

    async def plan_strategy(self, symbol: str, agent_insights: Dict[str, Any] = None) -> dict:
        """Main method for planning trade strategies. Calls analyze method."""
        try:
            return await self.analyze(symbol, agent_insights)
        except Exception as e:
            self.logger.error(f"Error in plan_strategy: {e}")
            return {"error": str(e)} 