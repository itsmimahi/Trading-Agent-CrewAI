"""
Market Regime Classifier — RL v2.

Detects one of four market regimes from price or returns data:

    BULL      (0) — sustained uptrend, normal volatility
    BEAR      (1) — sustained downtrend, elevated volatility
    SIDEWAYS  (2) — range-bound, low volatility
    HIGH_VOL  (3) — extreme realised volatility regardless of direction

Classification algorithm (two-pass rule)
-----------------------------------------
1. Volatility gate  → HIGH_VOL when rolling_vol ≥ high_vol_multiplier × historical_median_vol
2. Trend gate       → BULL  when N-day cumulative return ≥ bull_threshold
                    → BEAR  when N-day cumulative return ≤ bear_threshold
3. Default          → SIDEWAYS

A persistence filter prevents rapid regime oscillation: a regime change is
accepted only after the new regime has been the raw signal for at least
``min_persistence`` consecutive steps.
"""

from __future__ import annotations

from collections import Counter
from enum import IntEnum
from typing import Dict, List, Optional

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Regime enum
# ─────────────────────────────────────────────────────────────────────────────

class MarketRegime(IntEnum):
    """Four discrete market regimes used by RL v2 policies."""
    BULL = 0
    BEAR = 1
    SIDEWAYS = 2
    HIGH_VOL = 3


_REGIME_NAMES: Dict[MarketRegime, str] = {
    MarketRegime.BULL: "BULL",
    MarketRegime.BEAR: "BEAR",
    MarketRegime.SIDEWAYS: "SIDEWAYS",
    MarketRegime.HIGH_VOL: "HIGH_VOL",
}

# Severity ordering used to break majority-vote ties
_SEVERITY: Dict[MarketRegime, int] = {
    MarketRegime.HIGH_VOL: 3,
    MarketRegime.BEAR: 2,
    MarketRegime.SIDEWAYS: 1,
    MarketRegime.BULL: 0,
}


# ─────────────────────────────────────────────────────────────────────────────
# Classifier
# ─────────────────────────────────────────────────────────────────────────────

class RegimeClassifier:
    """Rule-based market regime classifier with optional smoothing.

    Parameters
    ----------
    vol_lookback : int
        Rolling window for recent realized volatility (default 20 days).
    trend_lookback : int
        Window for cumulative return trend detection (default 20 days).
    high_vol_multiplier : float
        Trigger HIGH_VOL when rolling_vol / historical_median_vol ≥ this value.
    bull_threshold : float
        Minimum N-day cumulative return (fraction) to classify as BULL.
    bear_threshold : float
        Maximum N-day cumulative return (fraction, negative) to classify as BEAR.
    history_lookback : int
        Look-back window for computing the historical median volatility baseline.
    min_persistence : int
        Consecutive raw-signal steps required before accepting a regime change.
        Set to 1 to disable smoothing.
    """

    def __init__(
        self,
        vol_lookback: int = 20,
        trend_lookback: int = 20,
        high_vol_multiplier: float = 2.0,
        bull_threshold: float = 0.05,
        bear_threshold: float = -0.05,
        history_lookback: int = 252,
        min_persistence: int = 3,
    ) -> None:
        self.vol_lookback = vol_lookback
        self.trend_lookback = trend_lookback
        self.high_vol_multiplier = high_vol_multiplier
        self.bull_threshold = bull_threshold
        self.bear_threshold = bear_threshold
        self.history_lookback = history_lookback
        self.min_persistence = min_persistence

        self._last_regime: MarketRegime = MarketRegime.SIDEWAYS
        self._candidate_regime: MarketRegime = MarketRegime.SIDEWAYS
        self._candidate_streak: int = 0

    # ── Public API ─────────────────────────────────────────────────────────

    def classify(self, prices: np.ndarray) -> MarketRegime:
        """Classify regime from a 1-D closing-price series.

        Args:
            prices: Closing prices in chronological order.
                    Requires at least ``max(vol_lookback, trend_lookback) + 2``
                    elements; returns last known regime otherwise.

        Returns:
            MarketRegime label.
        """
        arr = np.asarray(prices, dtype=float)
        min_len = max(self.trend_lookback, self.vol_lookback) + 2
        if len(arr) < min_len:
            return self._last_regime
        log_returns = np.diff(np.log(np.maximum(arr, 1e-9)))
        raw = self._raw_from_returns(log_returns)
        return self._apply_persistence(raw)

    def classify_from_returns(self, returns: np.ndarray) -> MarketRegime:
        """Classify directly from a log-returns array.

        Args:
            returns: Log-returns in chronological order.

        Returns:
            MarketRegime label.
        """
        arr = np.asarray(returns, dtype=float)
        if len(arr) < max(self.trend_lookback, self.vol_lookback):
            return self._last_regime
        raw = self._raw_from_returns(arr)
        return self._apply_persistence(raw)

    def classify_multi_asset(
        self,
        prices_dict: Dict[str, np.ndarray],
    ) -> MarketRegime:
        """Portfolio-level regime by majority vote across all assets.

        Ties are broken by severity (HIGH_VOL > BEAR > SIDEWAYS > BULL).

        Args:
            prices_dict: Mapping ``{symbol: closing_prices_array}``.

        Returns:
            Majority-vote MarketRegime.
        """
        if not prices_dict:
            return self._last_regime
        votes: List[MarketRegime] = [self.classify(p) for p in prices_dict.values()]
        return self._majority_vote(votes)

    def reset(self) -> None:
        """Reset internal persistence state (call at env.reset())."""
        self._last_regime = MarketRegime.SIDEWAYS
        self._candidate_regime = MarketRegime.SIDEWAYS
        self._candidate_streak = 0

    # ── Static helpers ─────────────────────────────────────────────────────

    @staticmethod
    def to_one_hot(regime: MarketRegime) -> np.ndarray:
        """4-element one-hot encoding of a MarketRegime.

        Args:
            regime: A MarketRegime value.

        Returns:
            float32 array of shape (4,).
        """
        vec = np.zeros(4, dtype=np.float32)
        vec[int(regime)] = 1.0
        return vec

    @staticmethod
    def regime_name(regime: MarketRegime) -> str:
        """Human-readable name of a regime.

        Args:
            regime: A MarketRegime value.

        Returns:
            String name, e.g. "BULL".
        """
        return _REGIME_NAMES.get(regime, "UNKNOWN")

    @property
    def current_regime(self) -> MarketRegime:
        """Last accepted (persistence-filtered) regime."""
        return self._last_regime

    # ── Internal ───────────────────────────────────────────────────────────

    def _raw_from_returns(self, returns: np.ndarray) -> MarketRegime:
        """Compute raw regime label (no persistence filter)."""
        n = len(returns)
        vol_w = min(self.vol_lookback, n)
        hist_w = min(self.history_lookback, n)

        recent_vol = float(np.std(returns[-vol_w:], ddof=1)) * np.sqrt(252)
        hist_vol = float(np.std(returns[-hist_w:], ddof=1)) * np.sqrt(252)

        # Pass 1 — volatility gate
        if hist_vol > 1e-9 and recent_vol >= self.high_vol_multiplier * hist_vol:
            return MarketRegime.HIGH_VOL

        # Pass 2 — trend gate
        trend_w = min(self.trend_lookback, n)
        cum_return = float(np.sum(returns[-trend_w:]))
        if cum_return >= self.bull_threshold:
            return MarketRegime.BULL
        if cum_return <= self.bear_threshold:
            return MarketRegime.BEAR

        return MarketRegime.SIDEWAYS

    def _apply_persistence(self, new_regime: MarketRegime) -> MarketRegime:
        """Accept a regime change only after min_persistence consecutive signals."""
        if new_regime == self._candidate_regime:
            self._candidate_streak += 1
        else:
            self._candidate_regime = new_regime
            self._candidate_streak = 1

        if self._candidate_streak >= self.min_persistence:
            self._last_regime = self._candidate_regime

        return self._last_regime

    @staticmethod
    def _majority_vote(regimes: List[MarketRegime]) -> MarketRegime:
        counts = Counter(regimes)
        max_count = counts.most_common(1)[0][1]
        candidates = [r for r, c in counts.items() if c == max_count]
        return max(candidates, key=lambda r: _SEVERITY[r])
