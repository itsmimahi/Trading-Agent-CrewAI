"""
Flask Application Runner for RL Trading Agent API
Run this file to start the RL Agent API server
"""

from flask import Flask
from flask_cors import CORS
import os
import sys

# Add the parent directory to Python path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from rl_api import rl_api
    RL_DEPENDENCIES_AVAILABLE = True
except ImportError as e:
    print(f"⚠️  Warning: Could not import rl_api: {e}")
    print("🔧 This might be due to missing dependencies.")
    RL_DEPENDENCIES_AVAILABLE = False
    rl_api = None

# Try to import optional bridge endpoints for HTTP fallback compatibility
try:
    from bridge_api import bridge_api  # provides /api/learning_insights, /api/get_weight_updates, etc.
    BRIDGE_API_AVAILABLE = True
except Exception as _e:
    bridge_api = None
    BRIDGE_API_AVAILABLE = False

def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    
    # Enable CORS for all routes
    CORS(app)
    
    # Register the RL API blueprint only if dependencies are available
    if RL_DEPENDENCIES_AVAILABLE and rl_api:
        app.register_blueprint(rl_api)
        status_message = "running"
        endpoints = {
            'health': '/api/rl/health',
            'agents': '/api/rl/agents',
            'docs': 'See API documentation for full endpoint list'
        }
    else:
        status_message = "limited - dependencies needed"
        endpoints = {
            'health': '/health',
            'install_guide': 'Install: pip install torch stable-baselines3 gymnasium yfinance ta'
        }

    # Register bridge compatibility endpoints if present
    if BRIDGE_API_AVAILABLE and bridge_api:
        app.register_blueprint(bridge_api)
        endpoints.update({
            'learning_insights': '/api/learning_insights',
            'weight_updates': '/api/get_weight_updates'
        })
    
    # Add a root health check
    @app.route('/')
    def root():
        return {
            'service': 'RL Trading Agent API',
            'status': status_message,
            'version': '1.0.0',
            'dependencies_available': RL_DEPENDENCIES_AVAILABLE,
            'bridge_api_available': BRIDGE_API_AVAILABLE,
            'endpoints': endpoints
        }
    
    @app.route('/health')
    def health():
        return {
            'status': 'healthy' if RL_DEPENDENCIES_AVAILABLE else 'limited',
            'service': 'RL Trading Agent',
            'dependencies_available': RL_DEPENDENCIES_AVAILABLE,
            'message': 'All systems operational' if RL_DEPENDENCIES_AVAILABLE else 'Install missing dependencies for full functionality'
        }
    
    # Add a minimal RL health endpoint if the full one isn't available
    if not RL_DEPENDENCIES_AVAILABLE:
        @app.route('/api/rl/health')
        def rl_health_minimal():
            return {
                'status': 'dependencies_missing',
                'message': 'RL Agent dependencies not installed',
                'required_packages': ['torch', 'stable-baselines3', 'gymnasium', 'yfinance', 'ta'],
                'install_command': 'pip install torch stable-baselines3 gymnasium yfinance ta'
            }
    
    return app

if __name__ == '__main__':
    # Clear previous session logs
    try:
        log_files = ['logs/rl_api.log', '../logs/rl_api.log']
        for log_file in log_files:
            try:
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write('')  # Clear the log file
            except (FileNotFoundError, OSError):
                pass  # File doesn't exist or can't be accessed
    except Exception:
        pass
    
    app = create_app()
    
    # Resolve port from env to avoid conflicts with Web UI
    port = int(os.environ.get('RL_API_PORT') or os.environ.get('PORT') or '5000')
    
    # Run the application
    print("Starting RL Trading Agent API...")
    print(f"API will be available at: http://localhost:{port}")
    print(f"Health check: http://localhost:{port}/health")
    print(f"RL Health check: http://localhost:{port}/api/rl/health")
    
    if RL_DEPENDENCIES_AVAILABLE:
        print("All RL dependencies available - Full functionality enabled")
        print("Available endpoints:")
        print("   - GET  /api/rl/agents")
        print("   - POST /api/rl/agents")
        print("   - GET  /api/rl/agents/<agent_id>")
        print("   - POST /api/rl/agents/<agent_id>/train")
        print("   - POST /api/rl/agents/<agent_id>/predict")
        print("   - POST /api/rl/agents/<agent_id>/simulate_strategy")
        print("   - POST /api/rl/agents/<agent_id>/feedback")
        if BRIDGE_API_AVAILABLE:
            print("   - GET  /api/learning_insights")
            print("   - GET  /api/get_weight_updates")
        print("   - And more...")
    else:
        print("Limited functionality - Missing RL dependencies")
        print("To enable full functionality, install:")
        print("   pip install torch stable-baselines3 gymnasium yfinance ta")
        print("Currently available endpoints:")
        print("   - GET  / (API info)")
        print("   - GET  /health (basic health check)")
        print("   - GET  /api/rl/health (dependency status)")
        if BRIDGE_API_AVAILABLE:
            print("   - GET  /api/learning_insights")
            print("   - GET  /api/get_weight_updates")
    
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False,
        use_reloader=False,
        threaded=True
    )
