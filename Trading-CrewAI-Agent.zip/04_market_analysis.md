# Market Analysis Layer

> **Source**: `main_advisory_agent/market_crew_builder.py`, `main_advisory_agent/mcp_data_layer.py`  
> **Phases**: 1 (MarketCrewBuilder) + 2 (MCP data tools)

---

## Overview

`market_analysis_step` in `AdvisoryFlow` runs one **Crew per active market** in parallel
using `asyncio.gather`. Each Crew analyses its market independently; results are collected
into `state.market_results[market_code]`.

```mermaid
sequenceDiagram
    participant AF as AdvisoryFlow
    participant MCB as MarketCrewBuilder
    participant IN as IN Crew
    participant US as US Crew
    participant EU as EU Crew

    AF->>MCB: build_market_crew(market="IN", ...)
    AF->>MCB: build_market_crew(market="US", ...)
    AF->>MCB: build_market_crew(market="EU", ...)
    par asyncio.gather
        MCB-->>IN: kickoff()
        MCB-->>US: kickoff()
        MCB-->>EU: kickoff()
    end
    IN-->>AF: {"raw": "...", "market": "IN"}
    US-->>AF: {"raw": "...", "market": "US"}
    EU-->>AF: {"raw": "...", "market": "EU"}
    AF->>AF: store in state.market_results
```

---

## `MarketCrewBuilder`

### Constructor

```python
MarketCrewBuilder(
    llm: LLM,
    tools: list,            # market data tools + A2A tools
    verbose: bool = False,
)
```

### `build_market_crew(...)` → `Crew`

```python
crew = builder.build_market_crew(
    market="IN",                          # market code
    user_input="What's the outlook...",   # original user query
    intent="general_advice",             # classified intent
    entities=[...],                      # extracted entities
    portfolio_snapshot={...},            # live IBKR holdings (context for crews)
)
```

The returned `Crew` has:
- A **Research Agent** (fundamental analysis)
- A **Technical Agent** (chart + indicators)
- A **Sentiment Agent** (news + social)
- Tasks chained: research → technical → sentiment → compile report

---

## Market codes

| Code | Exchange / Region | Market hours (local) |
|------|------------------|----------------------|
| `IN` | NSE / BSE (India) | 09:15 – 15:30 IST |
| `US` | NYSE / NASDAQ (USA) | 09:30 – 16:00 ET |
| `EU` | LSE / Euronext (Europe) | 08:00 – 16:30 GMT |
| `APAC` | TSE (Japan / Asia-Pacific) | 09:00 – 15:00 JST |
| `CRYPTO` | 24 × 7 (any exchange) | Always open |

Active markets for a request are detected by `GlobalMarketRouter.detect_markets()`
based on entities (e.g. "RELIANCE.NS" → `IN`) and keywords in the user query.

---

## Phase 2: MCP data tools

`build_data_tools(av_key)` in `mcp_data_layer.py` returns a list of CrewAI tools that
provide structured market data to every market crew.

### Available tools

| Tool class | Actions | Data source |
|-----------|---------|-------------|
| `StockQuoteTool` | `get_quote`, `get_ohlcv` | Alpha Vantage / yfinance |
| `FundamentalsTool` | `get_fundamentals`, `get_earnings` | Alpha Vantage |
| `NewsTool` | `get_news`, `get_sentiment` | Alpha Vantage News |
| `TechnicalIndicatorTool` | `rsi`, `macd`, `bbands`, `sma`, `ema` | Alpha Vantage |
| `EconomicDataTool` | `get_gdp`, `get_inflation`, `get_interest_rates` | Alpha Vantage |
| `MarketDataTool` | `market_overview`, `top_movers` | yfinance (NIFTY/SENSEX/S&P) |

### How tools are injected

```python
# In market_analysis_step (advisory_flow.py)
_data_tools = build_data_tools(av_key=os.getenv("ALPHA_VANTAGE_API_KEY"))
_combined_tools = self._tools + _data_tools     # merged with A2A tools

builder = MarketCrewBuilder(llm=self._llm, tools=_combined_tools, ...)
```

Tools are injected into each market Crew's agents via `agent.tools = tools`.

---

## Per-market result schema

Each `state.market_results[market_code]` is:

```python
{
    "raw": "Full text output from the market Crew...",
    "market": "IN",
    "intent": "general_advice",
    # if error:
    "error": "Exception message",
}
```

---

## Market routing — `GlobalMarketRouter`

> **Source**: `main_advisory_agent/routing.py`

### `detect_markets(user_input, entities, default_market) → List[str]`

Priority order:
1. Explicit market keywords in user text (`"Indian market"` → `IN`, `"S&P"` → `US`)
2. Entity symbols: `.NS` / `.BO` suffix → `IN`; no suffix with known US symbol → `US`
3. Fallback to `default_market` (default: `IN`)

### `invocation_mode(intent, text, confidence) → str`

- `"single_agent"` — high-confidence intent with a clear single-agent match
- `"orchestrated"` — multi-agent or ambiguous (default)

### `preferred_agents_for_intent(intent) → List[str]`

| Intent | Preferred agents |
|--------|-----------------|
| `fundamental_analysis` | `["fundamental_research"]` |
| `technical_analysis` | `["technical_analysis"]` |
| `sentiment_analysis` | `["sentiment_analysis"]` |
| `risk_assessment` | `["risk_assessment"]` |
| `timing` | `["market_timing"]` |
| `strategy` | `["trade_strategy_planner"]` |
| `general_advice` | `[]` (all agents) |

### `should_bypass_fastpath(intent, text) → (bool, reason)`

Returns `(True, reason)` for queries that require full orchestration regardless of
confidence (e.g. portfolio risk queries, multi-symbol strategies).
