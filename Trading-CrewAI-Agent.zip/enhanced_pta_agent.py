"""
Enhanced PTA Agent (LLM-equipped) that interfaces with the Paper Trading Agent (PTA) service.
Uses CrewAI for reasoning and PTAClientTool (HTTP) for read-only portfolio and paper order ops.
This agent is designed to be invoked over the A2A EventBus and keep the UI on HTTP.
Safety-first guardrails: India-market focus, market-hours checks, risk caps, and idempotent submit.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Optional, List
from datetime import datetime, time as dt_time
try:
    from zoneinfo import ZoneInfo  # Python 3.9+
except Exception:
    ZoneInfo = None  # fallback: skip strict market-hours if tz not available

from crewai import Task, Crew, Process  # type: ignore

from .enhanced_base_agent import EnhancedBaseAgent, AgentCapability
from pta_client import PTAClientTool


_LOG = logging.getLogger(__name__)


def _is_india_market_open(now_utc: Optional[datetime] = None) -> bool:
    """NSE/BSE cash hours: Mon-Fri 09:15–15:30 IST. Returns True if within.
    Pre-open 09:00–09:15; post-close excluded.
    """
    try:
        if ZoneInfo is None:
            return True  # be permissive if tz not available
        now_utc = now_utc or datetime.utcnow()
        ist = now_utc.astimezone(ZoneInfo("Asia/Kolkata"))
        if ist.weekday() >= 5:  # 5=Sat,6=Sun
            return False
        start = dt_time(9, 15)
        end = dt_time(15, 30)
        t = ist.time()
        return start <= t <= end
    except Exception:
        return True


def _is_likely_india_symbol(symbol: str) -> bool:
    s = (symbol or "").upper()
    if not s:
        return False
    # Simple heuristic: letters, digits, dash/underscore allowed; disallow obvious US suffixes
    allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")
    if any(ch not in allowed for ch in s):
        return False
    # Accept common NSE suffix forms like RELIANCE, TCS, INFY, SBIN, or SYMBOL-EQ
    return True


@dataclass
class _OrderPlan:
    symbol: str
    side: str  # "buy" or "sell"
    quantity: int
    confirm: bool = False
    max_notional_pct: float = 0.1  # 10% of available notional by default


class EnhancedPTAAgent(EnhancedBaseAgent):
    """
    LLM-equipped PTA operator. It does NOT touch real brokers; it only calls the PTA service.
    - analyze(): If only symbol provided, summarizes holdings, margins, and LTP with guidance.
    - place_paper_order(): Preview, risk-checks, and optional idempotent submit.
    """

    def __init__(
        self,
        name: str = "EnhancedPTAAgent",
        description: str = "LLM-equipped PTA operator for India paper trading (read-only + paper orders)",
        role: str = "PTA Operator",
        goal: str = "Safely manage paper orders and portfolio views for India markets using PTA",
        backstory: str = "Experienced India markets operator with strict risk guardrails and idempotent flows",
        capabilities: Optional[list[Any]] = None,
        weight: float = 0.15,
        use_llm: bool = True,
        use_memory: bool = True,
        use_knowledge_base: bool = True,
        **kwargs: Any,
    ) -> None:
        if capabilities is None:
            capabilities = [
                AgentCapability.DATA_INTERPRETATION,
                AgentCapability.RISK_ASSESSMENT,
                AgentCapability.MATHEMATICAL_ANALYSIS,
            ]
        super().__init__(
            name=name,
            description=description,
            capabilities=capabilities,
            weight=weight,
            use_llm=use_llm,
            use_memory=use_memory,
            use_knowledge_base=use_knowledge_base,
            role=role,
            goal=goal,
            backstory=backstory,
            **kwargs,
        )
        # PTA tool via HTTP
        self._pta_tool = PTAClientTool()
        # Risk defaults (can be tuned via env)
        try:
            self._max_order_notional_pct = float(os.getenv("PTA_MAX_NOTIONAL_PCT", "0.1"))
        except Exception:
            self._max_order_notional_pct = 0.1

    def _convert_tools_to_crewai(self):  # type: ignore[override]
        tools = super()._convert_tools_to_crewai()
        # Add PTA client tool directly for LLM use
        try:
            tools.append(self._pta_tool)
        except Exception:
            pass
        return tools

    async def mathematical_analysis(self, symbol: str, data: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
        """Minimal math stub: fetch last price via PTA and return basic metrics.
        This satisfies the abstract requirement without heavy computation.
        """
        try:
            ltp = self._pta_json("last_price", symbol=symbol)
            price = ltp.get("price") if isinstance(ltp, dict) else None
            return {"symbol": str(symbol).upper(), "ltp": price, "metrics": {"note": "PTA math stub"}}
        except Exception as e:  # noqa: BLE001
            return {"error": str(e)}

    # -------- Core A2A entrypoints ---------
    async def analyze(self, symbol: str, side: Optional[str] = None, quantity: Optional[int] = None, confirm: bool = False, **kwargs: Any) -> Dict[str, Any]:
        """Summarize holdings/margins/LTP; optional preview/submit a safe paper order with guardrails."""
        # Validate symbol scope
        if not _is_likely_india_symbol(symbol):
            return {"error": "Unsupported symbol format. India NSE/BSE equities only.", "symbol": symbol}

        # Get holdings, margins, LTP
        holdings = self._pta_json("holdings")
        margins = self._pta_json("margins")
        ltp = self._pta_json("last_price", symbol=symbol)
        # Compute portfolio metrics (P&L, equity)
        metrics = self._compute_portfolio_metrics(holdings)
        # Fetch recent orders (best-effort)
        recent_orders = self._pta_json("list_orders")
        summary = {
            "symbol": symbol.upper(),
            "ltp": ltp.get("price") if isinstance(ltp, dict) else ltp,
            "margins": margins,
            "holdings": holdings,
            "portfolio_metrics": metrics,
            "recent_orders": recent_orders if isinstance(recent_orders, list) or isinstance(recent_orders, dict) else recent_orders,
        }

        # If no order intent, produce LLM reasoning summary
        if side is None or quantity is None or quantity <= 0:
            if not self.use_llm:
                return {"summary": summary, "note": "LLM disabled; order not requested"}
            prompt = (
                f"You are an India paper-trading operator. Summarize portfolio impact for {symbol.upper()} at LTP {summary['ltp']} "
                f"with current margins and holdings. Provide cautious guidance with placing any orders."
            )
            task = Task(description=prompt, agent=self.crewai_agent, expected_output="Short PT summary")
            crew = Crew(agents=[self.crewai_agent], tasks=[task], process=Process.sequential, verbose=False)
            result = crew.kickoff()
            return {"summary": summary, "reasoning": str(result)}

        # Otherwise, treat as an order plan
        plan = _OrderPlan(symbol=symbol.upper(), side=str(side).lower(), quantity=int(quantity), confirm=bool(confirm), max_notional_pct=self._max_order_notional_pct)
        checks = self._guards(plan, margins, summary["ltp"])  # risk & hours checks
        if checks.get("blocked"):
            return {"summary": summary, "order_plan": plan.__dict__, "policy": checks}

        preview = self._pta_json(
            "preview_order",
            symbol=plan.symbol,
            side=plan.side,
            quantity=plan.quantity,
        )

        response: Dict[str, Any] = {
            "summary": summary,
            "order_plan": plan.__dict__,
            "policy": checks,
            "preview": preview,
        }

        if not plan.confirm:
            response["note"] = "Not submitted (confirm=false)."
            return response

        # Idempotent submit
        idem = str(uuid.uuid4())
        submit = self._pta_json(
            "submit_order",
            symbol=plan.symbol,
            side=plan.side,
            quantity=plan.quantity,
            idempotency_key=idem,
        )
        response["submitted"] = submit
        response["idempotency_key"] = idem
        return response

    # -------- Helpers ---------
    def _pta_json(self, action: str, **kwargs: Any) -> Dict[str, Any]:
        try:
            raw = self._pta_tool._run(action=action, **kwargs)
            return json.loads(raw)
        except Exception as e:  # noqa: BLE001
            return {"error": f"PTA call failed: {e}", "action": action}

    def _compute_portfolio_metrics(self, holdings_payload: Dict[str, Any]) -> Dict[str, Any]:
        """Compute simple portfolio P&L and equity using PTA holdings and LTP per symbol.
        Returns a dict with cash, invested, current_value, unrealized_pnl, unrealized_pct, and per-position stats.
        Also appends a point to performance_history.
        """
        try:
            positions: List[Dict[str, Any]] = []
            cash = 0.0
            invested = 0.0
            current_value = 0.0
            raw_positions = []
            if isinstance(holdings_payload, dict):
                cash = float(holdings_payload.get("cash", 0.0) or 0.0)
                raw_positions = holdings_payload.get("holdings", []) or []
            for pos in raw_positions:
                try:
                    sym = str(pos.get("symbol", "")).upper()
                    qty = int(pos.get("quantity", 0) or 0)
                    avg = float(pos.get("avg_price", 0.0) or 0.0)
                    if not sym or qty <= 0:
                        continue
                    invested_sym = avg * qty
                    # Get LTP for each symbol (best-effort)
                    ltp_resp = self._pta_json("last_price", symbol=sym)
                    last = float(ltp_resp.get("price", 0.0) or 0.0) if isinstance(ltp_resp, dict) else 0.0
                    curr_sym = last * qty
                    pnl = curr_sym - invested_sym
                    pnl_pct = (pnl / invested_sym) * 100.0 if invested_sym > 0 else 0.0
                    positions.append({
                        "symbol": sym,
                        "quantity": qty,
                        "avg_price": avg,
                        "ltp": last,
                        "invested": invested_sym,
                        "current_value": curr_sym,
                        "unrealized_pnl": pnl,
                        "unrealized_pct": pnl_pct,
                    })
                    invested += invested_sym
                    current_value += curr_sym
                except Exception:
                    continue
            equity = cash + current_value
            unrealized_pnl = current_value - invested
            unrealized_pct = (unrealized_pnl / invested) * 100.0 if invested > 0 else 0.0
            snapshot = {
                "timestamp": datetime.utcnow().isoformat(),
                "cash": cash,
                "invested": invested,
                "current_value": current_value,
                "equity": equity,
                "unrealized_pnl": unrealized_pnl,
                "unrealized_pct": unrealized_pct,
            }
            try:
                # Track basic performance over time
                self.performance_history.append({"equity": equity, **snapshot})
                # Keep last 100 points
                if len(self.performance_history) > 100:
                    self.performance_history = self.performance_history[-100:]
            except Exception:
                pass
            return {**snapshot, "positions": positions}
        except Exception as e:  # noqa: BLE001
            return {"error": f"metrics_failed: {e}"}

    def _guards(self, plan: _OrderPlan, margins: Dict[str, Any], ltp: Optional[float]) -> Dict[str, Any]:
        """Apply safety-first guardrails. Returns a policy dict with blocked: bool and reasons."""
        reasons = []
        blocked = False
        side_ok = plan.side in {"buy", "sell"}
        if not side_ok:
            blocked = True
            reasons.append("Invalid side; must be 'buy' or 'sell'.")
        if plan.quantity <= 0:
            blocked = True
            reasons.append("Quantity must be > 0.")

        # Market hours
        if not _is_india_market_open():
            reasons.append("Outside India cash-market hours (09:15–15:30 IST). Will preview only.")

        # Notional cap: use margins or simple cap
        try:
            available = float(margins.get("available", margins.get("cash", 0.0))) if isinstance(margins, dict) else 0.0
        except Exception:
            available = 0.0
        try:
            last_price = float(ltp) if ltp is not None else 0.0
        except Exception:
            last_price = 0.0
        notional = last_price * max(0, plan.quantity)
        cap = available * plan.max_notional_pct if available > 0 else None
        if cap is not None and notional > cap:
            reasons.append(f"Order notional {notional:.2f} exceeds cap {cap:.2f} ({plan.max_notional_pct*100:.0f}% of available). Preview only.")

        return {
            "blocked": blocked,
            "reasons": reasons,
            "notional": notional,
            "available": available,
            "max_notional_pct": plan.max_notional_pct,
        }
