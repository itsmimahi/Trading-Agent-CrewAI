"""
RL Trading Agent v2 — Multi-asset, regime-conditioned, offline→online pipeline.

Architecture overview
---------------------
* **Algorithm**: PPO (default) or SAC for continuous weight-delta actions.
* **Environment**: ``PortfolioTradingEnv`` — N-asset portfolio with risk-aware reward.
* **Regime conditioning**: the classifier's one-hot vector is already embedded in
  every observation; no separate gating is needed at inference time.
* **Confidence bands**: derived from the policy's action-distribution std
  (Gaussian policy for PPO).  High entropy triggers the no-trade override.
* **Offline training**: ``offline_train()`` downloads historical data and runs
  ``model.learn()`` for the requested number of timesteps.
* **Online fine-tuning**: ``online_finetune()`` accepts a list of recent
  ``(obs, action, reward, next_obs, done)`` transitions, wraps them in a
  lightweight replay env, and runs a short PPO update.

Usage example
-------------
::

    from RL_Agent.rl_agent_v2 import RLAgentV2

    agent = RLAgentV2(symbols=["AAPL", "MSFT", "GOOG"])
    agent.offline_train(start_date="2020-01-01", end_date="2023-12-31")
    agent.save("checkpoints/portfolio_v2.zip")

    # Later, at advisory flow synthesis:
    agent.load("checkpoints/portfolio_v2.zip")
    result = agent.validate_strategy(synthesis_text, market_context)
"""

from __future__ import annotations

import json
import logging
import os
import warnings
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

logger = logging.getLogger(__name__)

# ── Optional heavy imports (graceful degradation) ─────────────────────────
try:
    from stable_baselines3 import PPO, SAC
    from stable_baselines3.common.env_util import make_vec_env
    from stable_baselines3.common.vec_env import DummyVecEnv
    from stable_baselines3.common.callbacks import BaseCallback, EvalCallback
    _SB3_AVAILABLE = True
except ImportError:
    PPO = SAC = None                     # type: ignore[assignment]
    _SB3_AVAILABLE = False

try:
    import torch
    _TORCH_AVAILABLE = True
except ImportError:
    _TORCH_AVAILABLE = False

from .portfolio_trading_env import PortfolioTradingEnv
from .regime_classifier import MarketRegime, RegimeClassifier
from .risk_metrics import RiskSnapshot, build_risk_snapshot


# ─────────────────────────────────────────────────────────────────────────────
# Result data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PositionRecommendation:
    """Per-asset position recommendation produced by RLAgentV2."""
    symbol: str
    current_weight: float              # current allocation fraction
    recommended_weight: float          # target allocation fraction
    weight_delta: float                # recommended change
    confidence_lower: float            # lower confidence band
    confidence_upper: float            # upper confidence band
    no_trade: bool = False             # True when agent is uncertain


@dataclass
class ValidationResult:
    """Output of ``RLAgentV2.validate_strategy()``."""
    regime: str                                    # e.g. "BULL"
    positions: List[PositionRecommendation] = field(default_factory=list)
    portfolio_confidence: float = 0.5             # mean confidence [0, 1]
    no_trade_override: bool = False               # True when all positions are no-trade
    risk_snapshot: Optional[RiskSnapshot] = None
    synthesis_annotation: str = ""               # text to append to advisory synthesis

    def to_annotation(self) -> str:
        """Build the text block appended to the advisory synthesis."""
        lines = [
            "---",
            f"**RL v2 Portfolio Validation** | Regime: {self.regime} | "
            f"Confidence: {self.portfolio_confidence:.1%}",
        ]
        if self.no_trade_override:
            lines.append("⚠️  **No-Trade Override**: policy uncertainty too high — hold current positions.")
        else:
            for pos in self.positions:
                direction = "▲" if pos.weight_delta > 0.01 else ("▼" if pos.weight_delta < -0.01 else "–")
                lines.append(
                    f"  {direction} {pos.symbol}: {pos.current_weight:.1%} → {pos.recommended_weight:.1%}"
                    f"  (CI {pos.confidence_lower:.1%}–{pos.confidence_upper:.1%})"
                    + (" [NO-TRADE]" if pos.no_trade else "")
                )
        if self.risk_snapshot:
            rs = self.risk_snapshot
            lines.append(
                f"  Sharpe: {rs.sharpe_ratio:.2f} | MaxDD: {rs.max_drawdown:.1%} | "
                f"VaR95: {rs.var_95:.1%} | Vol: {rs.volatility:.1%}"
            )
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Training callback
# ─────────────────────────────────────────────────────────────────────────────

class _ProgressCallback(BaseCallback if _SB3_AVAILABLE else object):     # type: ignore[misc]
    """Lightweight callback that logs training progress every N steps."""

    def __init__(self, log_freq: int = 10_000, verbose: int = 0) -> None:
        if _SB3_AVAILABLE:
            super().__init__(verbose=verbose)
        self.log_freq = log_freq
        self._last_log = 0

    def _on_step(self) -> bool:
        if _SB3_AVAILABLE and (self.num_timesteps - self._last_log) >= self.log_freq:
            logger.info(
                "RLAgentV2:train | timesteps=%d | episodes=%d",
                self.num_timesteps,
                len(self.model.ep_info_buffer),
            )
            self._last_log = self.num_timesteps
        return True


# ─────────────────────────────────────────────────────────────────────────────
# Main agent class
# ─────────────────────────────────────────────────────────────────────────────

class RLAgentV2:
    """Multi-asset, regime-conditioned reinforcement learning trading agent.

    Parameters
    ----------
    symbols : list[str]
        Asset tickers to trade.
    algorithm : str
        "PPO" (default) or "SAC".
    device : str
        "cpu" (default) or "cuda".
    lookback : int
        Lookback window passed to ``PortfolioTradingEnv``.
    max_weight_per_asset : float
        Maximum portfolio weight for any single asset.
    uncertainty_threshold : float
        Mean action std above which the no-trade override activates.
    n_envs : int
        Number of parallel environments for training (default 1).
    env_kwargs : dict | None
        Extra kwargs forwarded to ``PortfolioTradingEnv``.
    """

    def __init__(
        self,
        symbols: Optional[List[str]] = None,
        algorithm: str = "PPO",
        device: str = "cpu",
        lookback: int = 20,
        max_weight_per_asset: float = 0.40,
        uncertainty_threshold: float = 0.30,
        n_envs: int = 1,
        env_kwargs: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not _SB3_AVAILABLE:
            logger.warning(
                "RLAgentV2: stable-baselines3 not installed — "
                "training and prediction are disabled (graceful degradation)."
            )

        self.symbols: List[str] = symbols or ["^NSEI", "^NSEBANK", "^GSPC", "GLD", "NVDA"]
        self.n_assets = len(self.symbols)
        self.algorithm = algorithm.upper()
        self.device = device
        self.lookback = lookback
        self.max_weight_per_asset = max_weight_per_asset
        self.uncertainty_threshold = uncertainty_threshold
        self.n_envs = n_envs
        self._env_kwargs: Dict[str, Any] = env_kwargs or {}

        self._model: Optional[Any] = None          # SB3 PPO / SAC model
        self._regime_clf = RegimeClassifier()
        self._current_weights = np.zeros(self.n_assets, dtype=np.float32)
        self._portfolio_history: List[float] = []
        self._returns_history: List[float] = []
        self._is_trained: bool = False

    # ── Training ───────────────────────────────────────────────────────────

    def build_env(
        self,
        data_dict: Optional[Dict[str, pd.DataFrame]] = None,
        start_date: str = "2020-01-01",
        end_date: str = "2023-12-31",
    ) -> PortfolioTradingEnv:
        """Construct a ``PortfolioTradingEnv`` instance.

        Args:
            data_dict:  Pre-loaded OHLCV data (bypasses yfinance).
            start_date: Training window start (yfinance mode).
            end_date:   Training window end (yfinance mode).

        Returns:
            Configured ``PortfolioTradingEnv``.
        """
        kwargs = dict(
            symbols=self.symbols,
            lookback=self.lookback,
            max_weight_per_asset=self.max_weight_per_asset,
            data_dict=data_dict,
            start_date=start_date,
            end_date=end_date,
            regime_classifier=self._regime_clf,
        )
        kwargs.update(self._env_kwargs)
        return PortfolioTradingEnv(**kwargs)

    def offline_train(
        self,
        start_date: str = "2020-01-01",
        end_date: str = "2023-12-31",
        n_timesteps: int = 200_000,
        data_dict: Optional[Dict[str, pd.DataFrame]] = None,
        verbose: int = 0,
    ) -> Dict[str, Any]:
        """Train the policy on historical data.

        Args:
            start_date:   Start of historical window (yfinance mode).
            end_date:     End of historical window.
            n_timesteps:  Total training timesteps.
            data_dict:    Pre-loaded data dict (bypasses yfinance / network).
            verbose:      SB3 verbosity level.

        Returns:
            Dict with training metadata.
        """
        if not _SB3_AVAILABLE:
            logger.warning("RLAgentV2.offline_train: SB3 not available, skipping.")
            return {"status": "skipped", "reason": "stable-baselines3 not installed"}

        env = self.build_env(data_dict=data_dict, start_date=start_date, end_date=end_date)
        vec_env = DummyVecEnv([lambda: env])

        policy_kwargs = dict(net_arch=[256, 256, 128])

        if self.algorithm == "SAC":
            self._model = SAC(
                "MlpPolicy",
                vec_env,
                device=self.device,
                verbose=verbose,
                policy_kwargs=policy_kwargs,
                learning_rate=3e-4,
                buffer_size=100_000,
            )
        else:  # PPO default
            self._model = PPO(
                "MlpPolicy",
                vec_env,
                device=self.device,
                verbose=verbose,
                policy_kwargs=policy_kwargs,
                learning_rate=3e-4,
                n_steps=2048,
                batch_size=64,
                n_epochs=10,
                clip_range=0.2,
            )

        callback = _ProgressCallback(log_freq=20_000, verbose=verbose)
        logger.info(
            "RLAgentV2:offline_train | algorithm=%s | timesteps=%d | device=%s",
            self.algorithm, n_timesteps, self.device,
        )
        self._model.learn(total_timesteps=n_timesteps, callback=callback, reset_num_timesteps=True)
        self._is_trained = True
        logger.info("RLAgentV2:offline_train | complete")
        return {"status": "done", "algorithm": self.algorithm, "timesteps": n_timesteps}

    def online_finetune(
        self,
        experience: List[Tuple[np.ndarray, np.ndarray, float, np.ndarray, bool]],
        n_update_steps: int = 1024,
        verbose: int = 0,
    ) -> Dict[str, Any]:
        """Fine-tune on recent live-trading experience.

        This short training run adapts the policy to recent market conditions
        without forgetting the offline base policy (low learning rate).

        Args:
            experience: List of ``(obs, action, reward, next_obs, done)`` tuples
                        collected from live deployment.
            n_update_steps: Number of gradient steps per fine-tuning call.
            verbose:        SB3 verbosity level.

        Returns:
            Dict with fine-tuning metadata.
        """
        if not _SB3_AVAILABLE or self._model is None:
            logger.warning("RLAgentV2.online_finetune: no trained model available.")
            return {"status": "skipped"}

        if len(experience) < 64:
            logger.debug(
                "RLAgentV2.online_finetune: buffer too small (%d < 64), skipping.",
                len(experience),
            )
            return {"status": "skipped", "reason": "insufficient experience"}

        # Build a lightweight replay environment from the experience buffer
        replay_env = _ReplayEnv(experience, self._model.observation_space, self._model.action_space)
        vec_env = DummyVecEnv([lambda: replay_env])

        # Temporarily lower learning rate for gentle adaptation
        original_lr = self._model.learning_rate
        self._model.set_env(vec_env)
        self._model.learning_rate = 1e-4

        self._model.learn(
            total_timesteps=min(n_update_steps, len(experience)),
            reset_num_timesteps=False,
        )
        # Restore learning rate
        self._model.learning_rate = original_lr
        logger.info(
            "RLAgentV2:online_finetune | steps=%d | buffer_size=%d",
            n_update_steps, len(experience),
        )
        return {"status": "done", "steps": n_update_steps, "buffer_size": len(experience)}

    # ── Inference ──────────────────────────────────────────────────────────

    def predict(
        self,
        obs: np.ndarray,
        deterministic: bool = True,
    ) -> Tuple[np.ndarray, np.ndarray, float]:
        """Get next action with confidence band.

        Args:
            obs:           Observation vector from ``PortfolioTradingEnv``.
            deterministic: Use deterministic (mean) action.

        Returns:
            (actions, confidence_std, mean_entropy)
            - actions:          float32 array (n_assets,)
            - confidence_std:   per-asset action std from policy distribution
            - mean_entropy:     scalar entropy across all assets
        """
        if not _SB3_AVAILABLE or self._model is None:
            zeros = np.zeros(self.n_assets, dtype=np.float32)
            return zeros, zeros, 1.0  # high entropy = uncertain

        action, _ = self._model.predict(obs, deterministic=deterministic)
        action = np.asarray(action, dtype=np.float32).flatten()

        # Extract action distribution std from PPO Gaussian policy
        conf_std = np.zeros(self.n_assets, dtype=np.float32)
        if _TORCH_AVAILABLE and hasattr(self._model, "policy"):
            try:
                import torch
                obs_t = torch.as_tensor(obs.reshape(1, -1), dtype=torch.float32)
                obs_t = obs_t.to(self._model.device)
                with torch.no_grad():
                    dist = self._model.policy.get_distribution(obs_t)
                    std = dist.distribution.scale.cpu().numpy().flatten()
                    conf_std = std[: self.n_assets]
            except Exception as exc:
                logger.debug("RLAgentV2.predict: could not extract std: %s", exc)

        mean_entropy = float(np.mean(conf_std))
        return action, conf_std, mean_entropy

    def validate_strategy(
        self,
        synthesis_text: str,
        market_context: Dict[str, Any],
        current_weights: Optional[np.ndarray] = None,
    ) -> ValidationResult:
        """Validate an advisory synthesis and produce position recommendations.

        This is the main bridge between the CrewAI advisory flow and RL v2.
        It replaces the v1 ``rl_a2a_validate()`` HTTP call with a local,
        fully offline validation.

        Args:
            synthesis_text:  Raw synthesis text from AnalysisCrew.
            market_context:  Per-market crew outputs (``s.market_results``).
            current_weights: Current portfolio weights.  Zeros if None.

        Returns:
            ``ValidationResult`` with regime label, per-asset recommendations,
            confidence bands, no-trade flag, and a text annotation.
        """
        weights = (
            np.asarray(current_weights, dtype=np.float32)
            if current_weights is not None
            else np.zeros(self.n_assets, dtype=np.float32)
        )
        self._current_weights = weights

        # Detect regime from market_context closing prices if available
        regime = self._detect_regime_from_context(market_context)
        regime_name = RegimeClassifier.regime_name(regime)

        if not _SB3_AVAILABLE or self._model is None:
            # Graceful degradation: return neutral result
            result = ValidationResult(
                regime=regime_name,
                portfolio_confidence=0.5,
                no_trade_override=True,
                synthesis_annotation=(
                    f"---\n**RL v2**: model not trained — regime={regime_name} (no-trade)."
                ),
            )
            return result

        # Build a synthetic observation from market context
        obs = self._build_synthetic_obs(market_context, weights, regime)
        action, conf_std, mean_entropy = self.predict(obs)

        no_trade_override = mean_entropy > self.uncertainty_threshold

        positions: List[PositionRecommendation] = []
        for i, sym in enumerate(self.symbols):
            delta = float(action[i]) if i < len(action) else 0.0
            std = float(conf_std[i]) if i < len(conf_std) else 0.0
            new_w = float(np.clip(weights[i] + delta, 0.0, self.max_weight_per_asset))
            positions.append(
                PositionRecommendation(
                    symbol=sym,
                    current_weight=float(weights[i]),
                    recommended_weight=new_w,
                    weight_delta=delta,
                    confidence_lower=max(0.0, new_w - 2 * std),
                    confidence_upper=min(1.0, new_w + 2 * std),
                    no_trade=std > self.uncertainty_threshold,
                )
            )

        portfolio_confidence = float(np.clip(1.0 - mean_entropy / max(self.uncertainty_threshold, 1e-9), 0.0, 1.0))

        # Risk snapshot from history
        risk = None
        if len(self._portfolio_history) >= 2 and len(self._returns_history) >= 2:
            risk = build_risk_snapshot(
                returns_history=np.array(self._returns_history),
                portfolio_values=np.array(self._portfolio_history),
                weights_old=weights,
                weights_new=np.array([p.recommended_weight for p in positions], dtype=np.float32),
            )

        result = ValidationResult(
            regime=regime_name,
            positions=positions,
            portfolio_confidence=portfolio_confidence,
            no_trade_override=no_trade_override,
            risk_snapshot=risk,
        )
        result.synthesis_annotation = result.to_annotation()
        return result

    # ── Persistence ────────────────────────────────────────────────────────

    def save(self, path: str) -> None:
        """Save model weights and agent metadata to disk.

        Args:
            path: File path (``*.zip`` for model; a companion ``*.meta.json``
                  is written alongside).
        """
        if self._model is None:
            raise RuntimeError("No trained model to save.")
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._model.save(path)
        meta = {
            "symbols": self.symbols,
            "algorithm": self.algorithm,
            "lookback": self.lookback,
            "max_weight_per_asset": self.max_weight_per_asset,
            "saved_at": datetime.utcnow().isoformat(),
        }
        meta_path = str(path).replace(".zip", "") + ".meta.json"
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)
        logger.info("RLAgentV2:save | path=%s", path)

    def load(self, path: str) -> None:
        """Load model weights from disk.

        Args:
            path: Path to the ``.zip`` checkpoint saved by ``save()``.
        """
        if not _SB3_AVAILABLE:
            raise RuntimeError("stable-baselines3 required to load model.")
        cls = SAC if self.algorithm == "SAC" else PPO
        self._model = cls.load(path, device=self.device)
        self._is_trained = True
        logger.info("RLAgentV2:load | path=%s", path)

        meta_path = str(path).replace(".zip", "") + ".meta.json"
        if os.path.exists(meta_path):
            with open(meta_path, encoding="utf-8") as f:
                meta = json.load(f)
            self.symbols = meta.get("symbols", self.symbols)
            self.n_assets = len(self.symbols)
            logger.debug("RLAgentV2:load | meta=%s", meta)

    # ── Internal helpers ───────────────────────────────────────────────────

    def _detect_regime_from_context(
        self, market_context: Dict[str, Any]
    ) -> MarketRegime:
        """Extract closing-price arrays from market_context and classify regime."""
        prices_dict: Dict[str, np.ndarray] = {}
        for market, result in market_context.items():
            if isinstance(result, dict) and "prices" in result:
                arr = np.asarray(result["prices"], dtype=float)
                if len(arr) >= 22:
                    prices_dict[market] = arr
            elif isinstance(result, dict) and "close_history" in result:
                arr = np.asarray(result["close_history"], dtype=float)
                if len(arr) >= 22:
                    prices_dict[market] = arr

        if prices_dict:
            return self._regime_clf.classify_multi_asset(prices_dict)
        # Fallback: text-based heuristic
        return self._regime_from_text(market_context)

    def _regime_from_text(self, market_context: Dict[str, Any]) -> MarketRegime:
        """Simple keyword heuristic when no price arrays are available."""
        combined = " ".join(
            str(v.get("raw", v) if isinstance(v, dict) else v)
            for v in market_context.values()
        ).lower()
        bearish_words = {"bearish", "bear", "sell-off", "crash", "decline", "falling"}
        bullish_words = {"bullish", "bull", "rally", "breakout", "uptrend", "surge"}
        volatile_words = {"volatile", "vix", "spike", "whipsaw", "uncertainty"}

        bear_score = sum(1 for w in bearish_words if w in combined)
        bull_score = sum(1 for w in bullish_words if w in combined)
        vol_score  = sum(1 for w in volatile_words if w in combined)

        if vol_score >= 2:
            return MarketRegime.HIGH_VOL
        if bull_score > bear_score:
            return MarketRegime.BULL
        if bear_score > bull_score:
            return MarketRegime.BEAR
        return MarketRegime.SIDEWAYS

    def _build_synthetic_obs(
        self,
        market_context: Dict[str, Any],
        weights: np.ndarray,
        regime: MarketRegime,
    ) -> np.ndarray:
        """Build a synthetic obs vector for inference when live env is unavailable."""
        from .portfolio_trading_env import _N_FEATURES

        obs_size = (
            self.n_assets * self.lookback * _N_FEATURES
            + self.n_assets
            + 4  # regime one-hot
            + 5  # portfolio scalars
        )
        obs = np.zeros(obs_size, dtype=np.float32)

        # Fill weights section
        w_start = self.n_assets * self.lookback * _N_FEATURES
        obs[w_start: w_start + self.n_assets] = weights

        # Regime one-hot
        r_start = w_start + self.n_assets
        obs[r_start: r_start + 4] = RegimeClassifier.to_one_hot(regime)

        return obs


# ─────────────────────────────────────────────────────────────────────────────
# Internal replay environment for online fine-tuning
# ─────────────────────────────────────────────────────────────────────────────

class _ReplayEnv:
    """Lightweight gym-compatible env that replays a fixed experience buffer.

    Used exclusively by ``RLAgentV2.online_finetune()``.
    """

    def __init__(
        self,
        experience: List[Tuple[np.ndarray, np.ndarray, float, np.ndarray, bool]],
        observation_space: Any,
        action_space: Any,
    ) -> None:
        self._exp = experience
        self.observation_space = observation_space
        self.action_space = action_space
        self._idx = 0

    def reset(self, **kwargs: Any) -> Tuple[np.ndarray, Dict]:
        self._idx = 0
        obs, *_ = self._exp[0]
        return np.asarray(obs, dtype=np.float32), {}

    def step(
        self, action: np.ndarray
    ) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        obs, _, reward, next_obs, done = self._exp[self._idx % len(self._exp)]
        self._idx += 1
        terminated = done or self._idx >= len(self._exp)
        return (
            np.asarray(next_obs, dtype=np.float32),
            float(reward),
            terminated,
            False,
            {},
        )

    def render(self) -> None:
        pass
